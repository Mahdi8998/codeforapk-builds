package com.example

import com.example.analytics.BacktestStatsCalculator
import com.example.data.GridSerializer
import com.example.data.model.GridData
import org.junit.Assert.*
import org.junit.Test

class AddendumCRrCapStatsTest {

    private val testRows = listOf(
        listOf("2024-01-01", "EURUSD", "3"),  // Win: 3R
        listOf("2024-01-02", "GBPUSD", "-"),  // Loss: -1R
        listOf("2024-01-03", "USDJPY", ""),   // Excluded (blank)
        listOf("2024-01-04", "EURUSD", "2"),  // Win: 2R
        listOf("2024-01-05", "GBPUSD", "1"),  // Win: 1R
        listOf("2024-01-06", "USDJPY", "-"),  // Loss: -1R
        listOf("2024-01-07", "EURUSD", "4"),  // Win: 4R
        listOf("2024-01-08", "GBPUSD", "0"),  // Excluded (zero)
        listOf("2024-01-09", "USDJPY", "-")   // Loss: -1R
    )

    @Test
    fun testAdvancedStats_withoutRrCap() {
        // Total counted: 7 trades (3 wins: 3, 2, 1, 4 = +10R; 3 losses: -1, -1, -1 = -3R; 2 excluded)
        val stats = BacktestStatsCalculator.calculateAdvancedStats(testRows, plColumnIndex = 2, rrCap = null)

        assertEquals(7, stats.tradeCount)
        assertEquals(2, stats.excludedCount)
        assertEquals(4, stats.winCount)
        assertEquals(3, stats.lossCount)
        assertEquals(10.0, stats.grossProfit, 0.001)
        assertEquals(3.0, stats.grossLoss, 0.001)
        assertEquals(7.0, stats.netProfit, 0.001)
        assertEquals(4.0, stats.bestTrade, 0.001)
        assertEquals(-1.0, stats.worstTrade, 0.001)
        assertEquals(2.5, stats.avgWin, 0.001) // 10 / 4 = 2.5
    }

    @Test
    fun testAdvancedStats_withRrCap1() {
        // Capped at RR=1: wins are capped at min(N, 1) -> 3 becomes 1, 2 becomes 1, 1 stays 1, 4 becomes 1
        // Gross Profit = 1 + 1 + 1 + 1 = 4.0 R
        // Gross Loss = 1 + 1 + 1 = 3.0 R
        // Net Profit = 1.0 R
        val stats = BacktestStatsCalculator.calculateAdvancedStats(testRows, plColumnIndex = 2, rrCap = 1.0)

        assertEquals(7, stats.tradeCount)
        assertEquals(2, stats.excludedCount)
        assertEquals(4, stats.winCount)
        assertEquals(3, stats.lossCount)
        assertEquals(4.0, stats.grossProfit, 0.001)
        assertEquals(3.0, stats.grossLoss, 0.001)
        assertEquals(1.0, stats.netProfit, 0.001)
        assertEquals(1.0, stats.bestTrade, 0.001)
        assertEquals(-1.0, stats.worstTrade, 0.001)
        assertEquals(1.0, stats.avgWin, 0.001)

        // Check equity points
        // Origin: 0.0
        // Trade 1 (3 -> 1): 1.0
        // Trade 2 (- -> -1): 0.0
        // Trade 3 (2 -> 1): 1.0
        // Trade 4 (1 -> 1): 2.0
        // Trade 5 (- -> -1): 1.0
        // Trade 6 (4 -> 1): 2.0
        // Trade 7 (- -> -1): 1.0
        assertEquals(8, stats.equityCurve.size)
        assertEquals(0.0, stats.equityCurve[0].cumulativePl, 0.001)
        assertEquals(1.0, stats.equityCurve[1].cumulativePl, 0.001)
        assertEquals(0.0, stats.equityCurve[2].cumulativePl, 0.001)
        assertEquals(1.0, stats.equityCurve[3].cumulativePl, 0.001)
        assertEquals(2.0, stats.equityCurve[4].cumulativePl, 0.001)
        assertEquals(1.0, stats.equityCurve[5].cumulativePl, 0.001)
        assertEquals(2.0, stats.equityCurve[6].cumulativePl, 0.001)
        assertEquals(1.0, stats.equityCurve[7].cumulativePl, 0.001)
    }

    @Test
    fun testAdvancedStats_withRrCap2() {
        // Capped at RR=2: wins are capped at min(N, 2) -> 3 becomes 2, 2 stays 2, 1 stays 1, 4 becomes 2
        // Gross Profit = 2 + 2 + 1 + 2 = 7.0 R
        // Gross Loss = 3.0 R
        // Net Profit = 4.0 R
        val stats = BacktestStatsCalculator.calculateAdvancedStats(testRows, plColumnIndex = 2, rrCap = 2.0)

        assertEquals(7, stats.tradeCount)
        assertEquals(4, stats.winCount)
        assertEquals(3, stats.lossCount)
        assertEquals(7.0, stats.grossProfit, 0.001)
        assertEquals(3.0, stats.grossLoss, 0.001)
        assertEquals(4.0, stats.netProfit, 0.001)
        assertEquals(2.0, stats.bestTrade, 0.001)
        assertEquals(-1.0, stats.worstTrade, 0.001)
    }

    @Test
    fun testDollarStats_withRrCap() {
        // Initial balance $500, risk 2%
        // Trade 1 (3 -> capped at 1.5): risked = 500 * 0.02 = $10 -> profit = 10 * 1.5 = $15 -> bal = $515
        // Trade 2 (-): risked = 515 * 0.02 = $10.3 -> loss = $10.3 -> bal = $504.7
        val dollarStats = BacktestStatsCalculator.calculateDollarStats(
            rows = testRows.take(2),
            plColumnIndex = 2,
            initialBalance = 500.0,
            riskPercent = 2.0,
            rrCap = 1.5
        )

        assertEquals(500.0, dollarStats.initialBalance, 0.001)
        assertEquals(504.7, dollarStats.finalBalance, 0.01)
        assertEquals(4.7, dollarStats.netProfitDollar, 0.01)
        assertEquals(15.0, dollarStats.bestTradeDollar, 0.01)
        assertEquals(-10.3, dollarStats.worstTradeDollar, 0.01)
    }

    @Test
    fun testGroupStats_withRrCap() {
        val columns = listOf("Date", "Pair", "Result")
        val groupStats = BacktestStatsCalculator.calculateGroupStats(
            columns = columns,
            rows = testRows,
            groupColumnIndex = 1,
            plColumnIndex = 2,
            initialBalance = 500.0,
            riskPercent = 2.0,
            rrCap = 1.0
        )

        // EURUSD trades: "3", "2", "4" -> all capped to 1.0 R -> 3 wins, 0 losses -> Net = 3.0 R
        val eurusd = groupStats.first { it.groupValue == "EURUSD" }
        assertEquals(3, eurusd.tradeCount)
        assertEquals(3, eurusd.winCount)
        assertEquals(0, eurusd.lossCount)
        assertEquals(3.0, eurusd.netProfit, 0.001)

        // GBPUSD trades: "-", "1", "0" (excluded) -> 1 win (1R), 1 loss (-1R) -> Net = 0.0 R
        val gbpusd = groupStats.first { it.groupValue == "GBPUSD" }
        assertEquals(2, gbpusd.tradeCount)
        assertEquals(1, gbpusd.winCount)
        assertEquals(1, gbpusd.lossCount)
        assertEquals(0.0, gbpusd.netProfit, 0.001)
    }

    @Test
    fun testGridSerialization_withRrCap() {
        val grid = GridData(
            columns = listOf("A", "B"),
            rows = listOf(listOf("1", "2")),
            initialBalance = 1000.0,
            riskPercent = 1.5,
            rrCap = 2.5
        )

        val json = GridSerializer.serialize(grid)
        val deserialized = GridSerializer.deserialize(json)

        assertEquals(1000.0, deserialized.initialBalance, 0.001)
        assertEquals(1.5, deserialized.riskPercent, 0.001)
        assertEquals(2.5, deserialized.rrCap!!, 0.001)
    }
}

package com.example.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.analytics.AdvancedStats
import com.example.analytics.ColumnSummary
import com.example.analytics.DollarEquityPoint
import com.example.analytics.DollarStats
import com.example.analytics.EquityPoint
import com.example.analytics.GroupItemStats
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.LossRed
import com.example.ui.theme.ProfitGreen
import com.example.util.NumberParser
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsBottomSheet(
    columns: List<String>,
    filteredRowCount: Int,
    plColumnIndex: Int?,
    selectedTab: Int,
    selectedGroupColIndex: Int?,
    chartMode: Int,
    summaryStats: List<ColumnSummary>,
    advancedStats: AdvancedStats,
    dollarStats: DollarStats,
    groupStats: List<GroupItemStats>,
    initialBalance: Double,
    riskPercent: Double,
    rrCap: Double?,
    onSelectTab: (Int) -> Unit,
    onSetPlColumn: (Int?) -> Unit,
    onSetGroupColumn: (Int) -> Unit,
    onSetChartMode: (Int) -> Unit,
    onUpdateMoneyManagement: (Double, Double) -> Unit,
    onUpdateRrCap: (Double?) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxHeight(0.88f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Outlined.Analytics,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "پنل تحلیل و آمار بکتست",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = "${NumberParser.formatPersian(filteredRowCount)} ردیف فیلترشده",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 5 Tabs: خلاصه | حرفه‌ای | دلاری | گروه‌بندی | نمودارها
            val tabs = listOf("خلاصه", "حرفه‌ای", "دلاری", "گروه‌بندی", "نمودارها")
            PrimaryTabRow(
                selectedTabIndex = selectedTab.coerceIn(0, tabs.lastIndex),
                modifier = Modifier.fillMaxWidth(),
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { onSelectTab(index) },
                        text = {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Tab Contents
            Box(modifier = Modifier.fillMaxSize()) {
                when (selectedTab) {
                    0 -> SummaryTabContent(filteredRowCount, summaryStats)
                    1 -> AdvancedTabContent(
                        columns = columns,
                        plColumnIndex = plColumnIndex,
                        stats = advancedStats,
                        rrCap = rrCap,
                        onSetPlColumn = onSetPlColumn,
                        onUpdateRrCap = onUpdateRrCap
                    )
                    2 -> DollarTabContent(
                        initialBalance = initialBalance,
                        riskPercent = riskPercent,
                        rrCap = rrCap,
                        plColumnIndex = plColumnIndex,
                        columns = columns,
                        stats = dollarStats,
                        onUpdateMoneyManagement = onUpdateMoneyManagement
                    )
                    3 -> GroupTabContent(
                        columns = columns,
                        selectedGroupColIndex = selectedGroupColIndex,
                        groupStats = groupStats,
                        onSetGroupColumn = onSetGroupColumn
                    )
                    4 -> ChartsTabContent(
                        advancedStats = advancedStats,
                        dollarStats = dollarStats,
                        groupStats = groupStats,
                        chartMode = chartMode,
                        onSetChartMode = onSetChartMode
                    )
                }
            }
        }
    }
}

@Composable
private fun SummaryTabContent(
    filteredRowCount: Int,
    summaries: List<ColumnSummary>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (summaries.isEmpty()) {
            item {
                Text(
                    text = "داده‌ای برای محاسبه آمار وجود ندارد.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            items(summaries) { summary ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = summary.columnName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (summary.isNumeric) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                            ) {
                                Text(
                                    text = if (summary.isNumeric) "عددی" else "متنی",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (summary.isNumeric) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        if (summary.isNumeric) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("مجموع", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        text = NumberParser.formatPersian(summary.sum ?: 0.0),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if ((summary.sum ?: 0.0) >= 0) ProfitGreen else LossRed
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("میانگین", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        text = NumberParser.formatPersian(summary.average ?: 0.0),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        } else if (!summary.distinctBreakdown.isNullOrEmpty()) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                summary.distinctBreakdown.forEach { item ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${item.value} (${NumberParser.formatPersian(item.count)})",
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            text = "${NumberParser.formatPersian(item.percentage, 1)}%",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        } else {
                            Text(
                                text = "ستون متنی با تنوع بالا",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdvancedTabContent(
    columns: List<String>,
    plColumnIndex: Int?,
    stats: AdvancedStats,
    rrCap: Double?,
    onSetPlColumn: (Int?) -> Unit,
    onUpdateRrCap: (Double?) -> Unit
) {
    var showDropdown by remember { mutableStateOf(false) }
    val isCapEnabled = rrCap != null && rrCap > 0
    var rrCapInput by remember(rrCap) {
        mutableStateOf(
            if (rrCap != null && rrCap > 0) {
                val formatted = NumberParser.formatPersian(rrCap, 1)
                if (formatted.endsWith("٫۰") || formatted.endsWith(".0")) {
                    NumberParser.formatPersian(rrCap.toInt())
                } else {
                    formatted
                }
            } else "1"
        )
    }
    var rrInputError by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // R:R Cap Settings Card (Addendum C.2)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isCapEnabled) {
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                    }
                )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                            Text(
                                text = "محاسبه سود بر اساس R:R مشخص",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (isCapEnabled) "محدودسازی سقف سود هر معامله به مبنای R:R" else "محاسبه بر اساس ارزش کامل تارگت‌ها",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = isCapEnabled,
                            onCheckedChange = { enabled ->
                                if (enabled) {
                                    val parsed = NumberParser.parseDouble(rrCapInput)
                                    if (parsed != null && parsed > 0) {
                                        rrInputError = false
                                        onUpdateRrCap(parsed)
                                    } else {
                                        rrCapInput = "1"
                                        rrInputError = false
                                        onUpdateRrCap(1.0)
                                    }
                                } else {
                                    rrInputError = false
                                    onUpdateRrCap(null)
                                }
                            }
                        )
                    }

                    if (isCapEnabled) {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = rrCapInput,
                            onValueChange = { newVal ->
                                rrCapInput = newVal
                                val parsed = NumberParser.parseDouble(newVal)
                                if (parsed != null && parsed > 0) {
                                    rrInputError = false
                                    onUpdateRrCap(parsed)
                                } else {
                                    rrInputError = true
                                }
                            },
                            label = { Text("مقدار R:R") },
                            placeholder = { Text("مثلاً 1 یا 1.5 یا 2") },
                            singleLine = true,
                            isError = rrInputError,
                            supportingText = if (rrInputError) {
                                { Text("مقدار R:R باید عددی بزرگتر از صفر باشد.", color = MaterialTheme.colorScheme.error) }
                            } else null,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )

                        // Quick Presets: 1, 1.5, 2, 3
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(1.0 to "۱ R", 1.5 to "۱٫۵ R", 2.0 to "۲ R", 3.0 to "۳ R").forEach { (presetVal, presetLabel) ->
                                val isSelected = rrCap != null && abs(rrCap - presetVal) < 0.01
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        rrCapInput = if (presetVal % 1.0 == 0.0) {
                                            NumberParser.formatPersian(presetVal.toInt())
                                        } else {
                                            NumberParser.formatPersian(presetVal, 1)
                                        }
                                        rrInputError = false
                                        onUpdateRrCap(presetVal)
                                    },
                                    label = { Text(presetLabel, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "با فعال بودن، هر سودی بزرگتر از این R:R به همان اندازه محدود می‌شود؛ مثلاً با R:R = ۱، تارگت ۳ هم +۱ حساب می‌شود. سمت ضرر (استاپ = −۱) تغییری نمی‌کند.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // P/L Column Selector (A.2)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (plColumnIndex == null) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "کدام ستون نتیجه معاملات است؟",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Box {
                        OutlinedButton(
                            onClick = { showDropdown = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = plColumnIndex?.let { columns.getOrNull(it) } ?: "انتخاب ستون نتیجه...",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }

                        DropdownMenu(
                            expanded = showDropdown,
                            onDismissRequest = { showDropdown = false }
                        ) {
                            columns.forEachIndexed { index, colName ->
                                DropdownMenuItem(
                                    text = { Text(colName) },
                                    onClick = {
                                        onSetPlColumn(index)
                                        showDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "در این ستون: علامت - یعنی استاپ خورده؛ عدد یعنی شماره تارگت (مثلاً ۳ یعنی تارگت ۳ خورده)؛ خانه خالی یعنی بدون نتیجه و از محاسبات حذف میشود.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        if (plColumnIndex == null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "لطفاً ستون نتیجه را در بالا انتخاب کنید تا معیارهای تخصصی بکتست نمایش داده شوند.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            // Metrics Grid (A.3)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Excluded rows info line
                    if (stats.excludedCount > 0) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Outlined.Info,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "ردیفهای بدون نتیجه: ${NumberParser.formatPersian(stats.excludedCount)} (از محاسبات حذف شده‌اند)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                        }
                    }

                    // Row 1: Trade Count & Net P/L (in target units)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(
                            title = "تعداد معاملات",
                            value = NumberParser.formatPersian(stats.tradeCount),
                            subtitle = "${NumberParser.formatPersian(stats.winCount)} برد | ${NumberParser.formatPersian(stats.lossCount)} باخت",
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "نتیجه خالص",
                            value = "${if (stats.netProfit > 0) "+" else ""}${NumberParser.formatPersian(stats.netProfit, 2)} تارگت",
                            valueColor = if (stats.netProfit >= 0) ProfitGreen else LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Row 2: Win Rate & Profit Factor
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(
                            title = "درصد برد (Win Rate)",
                            value = "${NumberParser.formatPersian(stats.winRate, 1)}%",
                            valueColor = if (stats.winRate >= 50) ProfitGreen else LossRed,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "فاکتور سود (Profit Factor)",
                            value = stats.profitFactor?.let { NumberParser.formatPersian(it, 2) } ?: "∞",
                            valueColor = if ((stats.profitFactor ?: 2.0) >= 1.5) ProfitGreen else LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Row 3: Avg Win & Avg Loss (in target units)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(
                            title = "میانگین برد",
                            value = "+${NumberParser.formatPersian(stats.avgWin, 2)} تارگت",
                            valueColor = ProfitGreen,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "میانگین ضرر",
                            value = "-${NumberParser.formatPersian(stats.avgLoss, 2)} تارگت",
                            valueColor = LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Row 4: R:R & Expectancy
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(
                            title = "نسبت ریوارد به ریسک",
                            value = stats.rewardToRiskRatio?.let { "1:${NumberParser.formatPersian(it, 2)}" } ?: "∞",
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "امید ریاضی هر معامله",
                            value = "${if (stats.expectancy > 0) "+" else ""}${NumberParser.formatPersian(stats.expectancy, 2)} تارگت",
                            valueColor = if (stats.expectancy >= 0) ProfitGreen else LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Row 5: Best & Worst Trade
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(
                            title = "بهترین معامله",
                            value = "+${NumberParser.formatPersian(stats.bestTrade, 1)} تارگت",
                            valueColor = ProfitGreen,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "بدترین معامله",
                            value = "${NumberParser.formatPersian(stats.worstTrade, 1)} تارگت",
                            valueColor = LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Row 6: Streaks
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(
                            title = "بیشترین برد متوالی",
                            value = "${NumberParser.formatPersian(stats.maxConsecutiveWins)} معامله",
                            valueColor = ProfitGreen,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "بیشترین باخت متوالی",
                            value = "${NumberParser.formatPersian(stats.maxConsecutiveLosses)} معامله",
                            valueColor = LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Row 7: Max Drawdown
                    MetricCard(
                        title = "حداکثر افت سرمایه (Max Drawdown)",
                        value = "${NumberParser.formatPersian(stats.maxDrawdownValue, 2)} تارگت (${NumberParser.formatPersian(stats.maxDrawdownPercent, 1)}%)",
                        valueColor = LossRed,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier,
    valueColor: Color = MaterialTheme.colorScheme.onSurface,
    subtitle: String? = null
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = valueColor
            )
            if (subtitle != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun DollarTabContent(
    initialBalance: Double,
    riskPercent: Double,
    rrCap: Double?,
    plColumnIndex: Int?,
    columns: List<String>,
    stats: DollarStats,
    onUpdateMoneyManagement: (Double, Double) -> Unit
) {
    var showSettingsDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Settings Card (B.3)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Outlined.AccountBalanceWallet,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تنظیمات مدیریت سرمایه",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            Text(
                                text = "موجودی اولیه: ${NumberParser.formatPersian(initialBalance, 0)} $",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "ریسک هر معامله: ${NumberParser.formatPersian(riskPercent, 1)}%",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    FilledTonalButton(
                        onClick = { showSettingsDialog = true },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Outlined.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ویرایش", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }

        // Status Note (C.2)
        item {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (rrCap != null && rrCap > 0) {
                    MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f)
                } else {
                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (rrCap != null && rrCap > 0) Icons.Outlined.Tune else Icons.Outlined.CheckCircle,
                        contentDescription = null,
                        tint = if (rrCap != null && rrCap > 0) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (rrCap != null && rrCap > 0) {
                            val formattedCap = if (rrCap % 1.0 == 0.0) {
                                NumberParser.formatPersian(rrCap.toInt())
                            } else {
                                NumberParser.formatPersian(rrCap, 1)
                            }
                            "مبنای سود: R:R = $formattedCap"
                        } else {
                            "مبنای سود: بدون محدودیت"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        if (plColumnIndex == null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Outlined.HelpOutline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "ستون نتیجه (سود/زیان) هنوز انتخاب نشده است.",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "برای محاسبه شبیه‌سازی دلاری و مدیریت سرمایه، ابتدا در تب «حرفه‌ای» ستون نتیجه را تعیین فرمایید.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else if (stats.tradeCount == 0) {
            item {
                Text(
                    text = "معامله‌ای با نتیجه مشخص (تارگت یا استاپ) برای محاسبه نتایج دلاری یافت نشد.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Row 1: Final Balance & Net P/L Dollar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(
                            title = "موجودی نهایی حساب",
                            value = "${NumberParser.formatPersian(stats.finalBalance, 2)} $",
                            valueColor = if (stats.finalBalance >= stats.initialBalance) ProfitGreen else LossRed,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "سود / زیان خالص دلاری",
                            value = "${if (stats.netProfitDollar > 0) "+" else ""}${NumberParser.formatPersian(stats.netProfitDollar, 2)} $",
                            valueColor = if (stats.netProfitDollar >= 0) ProfitGreen else LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Row 2: Total Return % & Counted Trades
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(
                            title = "بازدهی کل حساب",
                            value = "${if (stats.totalReturnPercent > 0) "+" else ""}${NumberParser.formatPersian(stats.totalReturnPercent, 2)}%",
                            valueColor = if (stats.totalReturnPercent >= 0) ProfitGreen else LossRed,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "معاملات محاسبه‌شده",
                            value = "${NumberParser.formatPersian(stats.tradeCount)} معامله",
                            subtitle = "${NumberParser.formatPersian(stats.winCount)} تارگت • ${NumberParser.formatPersian(stats.lossCount)} استاپ",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Row 3: Avg Win $ & Avg Loss $
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(
                            title = "میانگین سود معامله برنده",
                            value = "+${NumberParser.formatPersian(stats.avgWinDollar, 2)} $",
                            valueColor = ProfitGreen,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "میانگین ضرر معامله بازنده",
                            value = "-${NumberParser.formatPersian(stats.avgLossDollar, 2)} $",
                            valueColor = LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Row 4: Best & Worst Trade $
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(
                            title = "بهترین معامله (سود)",
                            value = "+${NumberParser.formatPersian(stats.bestTradeDollar, 2)} $",
                            valueColor = ProfitGreen,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "بدترین معامله (ضرر)",
                            value = "${NumberParser.formatPersian(stats.worstTradeDollar, 2)} $",
                            valueColor = LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Row 5: Max Drawdown Dollar
                    MetricCard(
                        title = "حداکثر افت سرمایه دلاری (Max Drawdown)",
                        value = "${NumberParser.formatPersian(stats.maxDrawdownDollar, 2)} $ (${NumberParser.formatPersian(stats.maxDrawdownPercent, 1)}%)",
                        valueColor = LossRed,
                        subtitle = "افت سرمایه دلاری به صورت تجمعی مرکب (Peak to Trough)",
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }

    if (showSettingsDialog) {
        MoneyManagementDialog(
            currentInitialBalance = initialBalance,
            currentRiskPercent = riskPercent,
            onSave = { newBal, newRisk ->
                onUpdateMoneyManagement(newBal, newRisk)
                showSettingsDialog = false
            },
            onDismiss = { showSettingsDialog = false }
        )
    }
}

@Composable
private fun MoneyManagementDialog(
    currentInitialBalance: Double,
    currentRiskPercent: Double,
    onSave: (Double, Double) -> Unit,
    onDismiss: () -> Unit
) {
    var balanceText by remember { mutableStateOf(if (currentInitialBalance % 1.0 == 0.0) currentInitialBalance.toLong().toString() else currentInitialBalance.toString()) }
    var riskText by remember { mutableStateOf(if (currentRiskPercent % 1.0 == 0.0) currentRiskPercent.toLong().toString() else currentRiskPercent.toString()) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Outlined.Settings,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("تنظیمات موجودی و مدیریت ریسک", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "ارقام شبیه‌سازی دلاری با اعمال ریسک درصدی مرکب (Compounding) بر روی بالانس محاسبه می‌شوند.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = balanceText,
                    onValueChange = {
                        balanceText = it
                        errorMessage = null
                    },
                    label = { Text("موجودی اولیه حساب (دلار)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = riskText,
                    onValueChange = {
                        riskText = it
                        errorMessage = null
                    },
                    label = { Text("درصد ریسک هر معامله (%)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.errorContainer
                    ) {
                        Text(
                            text = errorMessage!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsedBalance = NumberParser.parseDouble(balanceText)
                    val parsedRisk = NumberParser.parseDouble(riskText)

                    if (parsedBalance == null || parsedBalance <= 0) {
                        errorMessage = "موجودی اولیه باید عددی مثبت و بزرگتر از صفر باشد."
                        return@Button
                    }

                    if (parsedRisk == null || parsedRisk <= 0 || parsedRisk > 100) {
                        errorMessage = "درصد ریسک باید عددی بین 0.1 تا 100 درصد باشد."
                        return@Button
                    }

                    onSave(parsedBalance, parsedRisk)
                }
            ) {
                Text("ذخیره تنظیمات")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("انصراف")
            }
        }
    )
}

@Composable
private fun GroupTabContent(
    columns: List<String>,
    selectedGroupColIndex: Int?,
    groupStats: List<GroupItemStats>,
    onSetGroupColumn: (Int) -> Unit
) {
    var showDropdown by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "ستون برای گروه‌بندی (مثلاً جفت‌ارز یا جهت معامله):",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Box {
                        OutlinedButton(
                            onClick = { showDropdown = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = selectedGroupColIndex?.let { columns.getOrNull(it) } ?: "انتخاب ستون...",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }

                        DropdownMenu(
                            expanded = showDropdown,
                            onDismissRequest = { showDropdown = false }
                        ) {
                            columns.forEachIndexed { index, colName ->
                                DropdownMenuItem(
                                    text = { Text(colName) },
                                    onClick = {
                                        onSetGroupColumn(index)
                                        showDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        if (groupStats.isEmpty()) {
            item {
                Text(
                    text = "اطلاعاتی برای گروه‌بندی وجود ندارد.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            item {
                // Compact Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("گروه / مقدار", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.3f))
                    Text("تعداد", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.7f), textAlign = TextAlign.Center)
                    Text("وین‌ریت", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f), textAlign = TextAlign.Center)
                    Text("سود (تارگت)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                    Text("سود (دلار)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.1f), textAlign = TextAlign.End)
                }
            }

            items(groupStats) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = item.groupValue,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1.3f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = NumberParser.formatPersian(item.tradeCount),
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(0.7f),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "${NumberParser.formatPersian(item.winRate, 0)}%",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (item.winRate >= 50) ProfitGreen else LossRed,
                            modifier = Modifier.weight(0.8f),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "${if (item.netProfit > 0) "+" else ""}${NumberParser.formatPersian(item.netProfit, 1)}R",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = if (item.netProfit >= 0) ProfitGreen else LossRed,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.End
                        )
                        Text(
                            text = "${if (item.netProfitDollar > 0) "+" else ""}${NumberParser.formatPersian(item.netProfitDollar, 1)}$",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = if (item.netProfitDollar >= 0) ProfitGreen else LossRed,
                            modifier = Modifier.weight(1.1f),
                            textAlign = TextAlign.End
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ChartsTabContent(
    advancedStats: AdvancedStats,
    dollarStats: DollarStats,
    groupStats: List<GroupItemStats>,
    chartMode: Int,
    onSetChartMode: (Int) -> Unit
) {
    var equityChartMode by remember { mutableStateOf(0) } // 0: Target (R), 1: Dollar ($)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Equity Curve Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "نمودار رشد سرمایه (Equity Curve)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (equityChartMode == 0) "رشد تجمعی بر مبنای تارگت (R-Multiples)" else "رشد حساب دلاری با مدیریت ریسک مرکب",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Toggle Target R vs Dollar $
                        Row(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                                .padding(2.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (equityChartMode == 0) MaterialTheme.colorScheme.primary else Color.Transparent,
                                modifier = Modifier.clickable { equityChartMode = 0 }
                            ) {
                                Text(
                                    text = "تارگت (R)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (equityChartMode == 0) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (equityChartMode == 1) MaterialTheme.colorScheme.primary else Color.Transparent,
                                modifier = Modifier.clickable { equityChartMode = 1 }
                            ) {
                                Text(
                                    text = "دلاری ($)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (equityChartMode == 1) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (equityChartMode == 0) {
                        EquityCurveChart(
                            points = advancedStats.equityCurve,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                        )
                    } else {
                        DollarEquityCurveChart(
                            points = dollarStats.dollarEquityCurve,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                        )
                    }
                }
            }
        }

        // Group Bar Chart Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "نمودار مقایسه‌ای گروه‌ها",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        // Toggle: 0: تارگت (R), 1: دلاری ($), 2: وین‌ریت (%)
                        Row(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                                .padding(2.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (chartMode == 0) MaterialTheme.colorScheme.primary else Color.Transparent,
                                modifier = Modifier.clickable { onSetChartMode(0) }
                            ) {
                                Text(
                                    text = "تارگت",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (chartMode == 0) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (chartMode == 1) MaterialTheme.colorScheme.primary else Color.Transparent,
                                modifier = Modifier.clickable { onSetChartMode(1) }
                            ) {
                                Text(
                                    text = "دلاری",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (chartMode == 1) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (chartMode == 2) MaterialTheme.colorScheme.primary else Color.Transparent,
                                modifier = Modifier.clickable { onSetChartMode(2) }
                            ) {
                                Text(
                                    text = "وین‌ریت",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (chartMode == 2) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (groupStats.isEmpty()) {
                        Text(
                            text = "داده‌ای برای نمایش نمودار میله‌ای موجود نیست.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        GroupBarChart(
                            stats = groupStats,
                            chartMode = chartMode,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EquityCurveChart(
    points: List<EquityPoint>,
    modifier: Modifier = Modifier
) {
    val axisColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
    val finalProfit = points.lastOrNull()?.cumulativePl ?: 0.0
    val lineColor = if (finalProfit >= 0) ProfitGreen else LossRed

    if (points.size <= 1) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text(
                text = "معاملات کافی برای ترسیم منحنی اکوئیتی وجود ندارد.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val padding = 24f

        val minPl = points.minOf { it.cumulativePl }.coerceAtMost(0.0)
        val maxPl = points.maxOf { it.cumulativePl }.coerceAtLeast(0.0)
        val range = (maxPl - minPl).coerceAtLeast(1.0)

        val totalPoints = points.size

        // Zero reference line
        val zeroY = h - padding - (((0.0 - minPl) / range) * (h - 2 * padding)).toFloat()
        drawLine(
            color = axisColor,
            start = Offset(padding, zeroY),
            end = Offset(w - padding, zeroY),
            strokeWidth = 2f
        )

        // Path for Equity Curve
        val path = Path()
        for ((idx, pt) in points.withIndex()) {
            val x = padding + (idx.toFloat() / (totalPoints - 1)) * (w - 2 * padding)
            val y = h - padding - (((pt.cumulativePl - minPl) / range) * (h - 2 * padding)).toFloat()

            if (idx == 0) {
                path.moveTo(x, y)
            } else {
                path.lineTo(x, y)
            }
        }

        drawPath(
            path = path,
            color = lineColor,
            style = Stroke(width = 4f, cap = StrokeCap.Round)
        )

        // Draw circles at start and end
        val lastPt = points.last()
        val lastX = w - padding
        val lastY = h - padding - (((lastPt.cumulativePl - minPl) / range) * (h - 2 * padding)).toFloat()
        drawCircle(
            color = lineColor,
            radius = 6f,
            center = Offset(lastX, lastY)
        )
    }
}

@Composable
private fun DollarEquityCurveChart(
    points: List<DollarEquityPoint>,
    modifier: Modifier = Modifier
) {
    val axisColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
    val initialBalance = points.firstOrNull()?.balance ?: 500.0
    val finalBalance = points.lastOrNull()?.balance ?: initialBalance
    val lineColor = if (finalBalance >= initialBalance) ProfitGreen else LossRed

    if (points.size <= 1) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text(
                text = "معاملات کافی برای ترسیم منحنی دلاری وجود ندارد.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val padding = 24f

        val minBal = points.minOf { it.balance }.coerceAtMost(initialBalance)
        val maxBal = points.maxOf { it.balance }.coerceAtLeast(initialBalance)
        val range = (maxBal - minBal).coerceAtLeast(1.0)

        val totalPoints = points.size

        // Initial Balance reference line
        val initY = h - padding - (((initialBalance - minBal) / range) * (h - 2 * padding)).toFloat()
        drawLine(
            color = axisColor,
            start = Offset(padding, initY),
            end = Offset(w - padding, initY),
            strokeWidth = 2f
        )

        // Path for Dollar Equity Curve
        val path = Path()
        for ((idx, pt) in points.withIndex()) {
            val x = padding + (idx.toFloat() / (totalPoints - 1)) * (w - 2 * padding)
            val y = h - padding - (((pt.balance - minBal) / range) * (h - 2 * padding)).toFloat()

            if (idx == 0) {
                path.moveTo(x, y)
            } else {
                path.lineTo(x, y)
            }
        }

        drawPath(
            path = path,
            color = lineColor,
            style = Stroke(width = 4f, cap = StrokeCap.Round)
        )

        // Draw circles at start and end
        val lastPt = points.last()
        val lastX = w - padding
        val lastY = h - padding - (((lastPt.balance - minBal) / range) * (h - 2 * padding)).toFloat()
        drawCircle(
            color = lineColor,
            radius = 6f,
            center = Offset(lastX, lastY)
        )
    }
}

@Composable
private fun GroupBarChart(
    stats: List<GroupItemStats>,
    chartMode: Int, // 0: Target (R), 1: Dollar ($), 2: WinRate (%)
    modifier: Modifier = Modifier
) {
    val maxAbsValue = when (chartMode) {
        0 -> stats.maxOfOrNull { abs(it.netProfit) }?.coerceAtLeast(1.0) ?: 1.0
        1 -> stats.maxOfOrNull { abs(it.netProfitDollar) }?.coerceAtLeast(1.0) ?: 1.0
        else -> 100.0
    }

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        stats.forEach { item ->
            val value = when (chartMode) {
                0 -> item.netProfit
                1 -> item.netProfitDollar
                else -> item.winRate
            }
            val ratio = (abs(value) / maxAbsValue).toFloat().coerceIn(0.05f, 1f)
            val barColor = if (value >= 0) ProfitGreen else LossRed

            val displayLabel = when (chartMode) {
                0 -> "${if (value > 0) "+" else ""}${NumberParser.formatPersian(value, 1)}R"
                1 -> "${if (value > 0) "+" else ""}${NumberParser.formatPersian(value, 1)}$"
                else -> "${NumberParser.formatPersian(value, 0)}%"
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = item.groupValue,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.width(70.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(20.dp)
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(4.dp))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(ratio)
                            .background(barColor, RoundedCornerShape(4.dp))
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = displayLabel,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = barColor,
                    modifier = Modifier.width(80.dp),
                    textAlign = TextAlign.End
                )
            }
        }
    }
}

package com.example.ui.editor

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.analytics.AdvancedStats
import com.example.analytics.BacktestStatsCalculator
import com.example.analytics.ColumnSummary
import com.example.analytics.DollarStats
import com.example.analytics.GroupItemStats
import com.example.data.GridSerializer
import com.example.data.local.AppDatabase
import com.example.data.local.WorkbookEntity
import com.example.data.model.ColumnFilterState
import com.example.data.model.GridData
import com.example.data.repository.WorkbookRepository
import com.example.data.xlsx.XlsxEngine
import com.example.util.NumberParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class CellPosition(val rowIndex: Int, val colIndex: Int)

data class FilterDialogState(
    val columnIndex: Int,
    val columnName: String,
    val uniqueValuesWithCount: List<Pair<String, Int>>,
    val selectedValues: Set<String>,
    val searchQuery: String = "",
    val sortAscending: Boolean? = null
)

data class EditorUiState(
    val workbook: WorkbookEntity? = null,
    val grid: GridData = GridData(),
    val visibleRowIndices: List<Int> = emptyList(), // original row indices that pass filter and search
    val searchQuery: String = "",
    val isSearchActive: Boolean = false,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val editingCell: CellPosition? = null,
    val editingCellInitialValue: String = "",
    val activeFilterDialog: FilterDialogState? = null,
    val showStatsPanel: Boolean = false,
    val showRenameDialog: Boolean = false,
    val showExportDialog: Boolean = false,
    val activeRowMenuIndex: Int? = null,
    val activeColMenuIndex: Int? = null,
    val isAutoSaving: Boolean = false,
    val selectedStatsTab: Int = 0, // 0: خلاصه, 1: حرفه‌ای, 2: گروه‌بندی, 3: نمودارها
    val selectedGroupColumnIndex: Int? = null,
    val chartMode: Int = 0 // 0: Net P/L, 1: Win Rate %
)

class EditorViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository: WorkbookRepository
    private var workbookId: Long = 0

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    private val _eventFlow = MutableSharedFlow<String>()
    val eventFlow: SharedFlow<String> = _eventFlow.asSharedFlow()

    // Undo / Redo stacks
    private val undoStack = mutableListOf<GridData>()
    private val redoStack = mutableListOf<GridData>()

    private var autoSaveJob: Job? = null

    // Computed stats caches
    private val _summaryStats = MutableStateFlow<List<ColumnSummary>>(emptyList())
    val summaryStats: StateFlow<List<ColumnSummary>> = _summaryStats.asStateFlow()

    private val _advancedStats = MutableStateFlow(AdvancedStats())
    val advancedStats: StateFlow<AdvancedStats> = _advancedStats.asStateFlow()

    private val _groupStats = MutableStateFlow<List<GroupItemStats>>(emptyList())
    val groupStats: StateFlow<List<GroupItemStats>> = _groupStats.asStateFlow()

    private val _dollarStats = MutableStateFlow(DollarStats())
    val dollarStats: StateFlow<DollarStats> = _dollarStats.asStateFlow()

    init {
        val db = AppDatabase.getDatabase(application)
        repository = WorkbookRepository(db.workbookDao())
    }

    fun loadWorkbook(id: Long) {
        workbookId = id
        viewModelScope.launch(Dispatchers.IO) {
            val entity = repository.getWorkbook(id)
            if (entity != null) {
                val grid = GridSerializer.deserialize(entity.serializedGrid)
                val plCol = entity.plColumnIndex ?: grid.plColumnIndex
                val initialBal = if (entity.initialBalance > 0) entity.initialBalance else grid.initialBalance
                val riskPct = if (entity.riskPercent in 0.0001..100.0) entity.riskPercent else grid.riskPercent
                val rrCap = if (entity.rrCap != null && entity.rrCap > 0) entity.rrCap else grid.rrCap

                val loadedGrid = grid.copy(
                    plColumnIndex = plCol,
                    initialBalance = initialBal,
                    riskPercent = riskPct,
                    rrCap = rrCap
                )
                val defaultGroupCol = BacktestStatsCalculator.findDefaultGroupColumn(loadedGrid.columns, loadedGrid.rows)

                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(
                        workbook = entity,
                        grid = loadedGrid,
                        selectedGroupColumnIndex = defaultGroupCol
                    )
                    undoStack.clear()
                    redoStack.clear()
                    updateVisibleRowsAndStats()
                }
            }
        }
    }

    private fun pushUndoState() {
        val currentGrid = _uiState.value.grid.copy()
        undoStack.add(currentGrid)
        if (undoStack.size > 50) {
            undoStack.removeAt(0)
        }
        redoStack.clear()
        _uiState.value = _uiState.value.copy(
            canUndo = undoStack.isNotEmpty(),
            canRedo = false
        )
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val currentGrid = _uiState.value.grid.copy()
        val previousGrid = undoStack.removeAt(undoStack.lastIndex)
        redoStack.add(currentGrid)

        _uiState.value = _uiState.value.copy(
            grid = previousGrid,
            canUndo = undoStack.isNotEmpty(),
            canRedo = true
        )
        updateVisibleRowsAndStats()
        scheduleAutoSave()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val currentGrid = _uiState.value.grid.copy()
        val nextGrid = redoStack.removeAt(redoStack.lastIndex)
        undoStack.add(currentGrid)

        _uiState.value = _uiState.value.copy(
            grid = nextGrid,
            canUndo = true,
            canRedo = redoStack.isNotEmpty()
        )
        updateVisibleRowsAndStats()
        scheduleAutoSave()
    }

    // Cell Editing
    fun startEditCell(rowIndex: Int, colIndex: Int) {
        val currentVal = _uiState.value.grid.rows.getOrNull(rowIndex)?.getOrNull(colIndex) ?: ""
        _uiState.value = _uiState.value.copy(
            editingCell = CellPosition(rowIndex, colIndex),
            editingCellInitialValue = currentVal
        )
    }

    fun dismissCellEditor() {
        _uiState.value = _uiState.value.copy(editingCell = null)
    }

    fun saveCellEdit(newValue: String, advanceToNextRow: Boolean = true) {
        val cell = _uiState.value.editingCell ?: return
        val currentGrid = _uiState.value.grid
        val currentRows = currentGrid.rows.map { it.toMutableList() }.toMutableList()

        if (cell.rowIndex in currentRows.indices && cell.colIndex in currentRows[cell.rowIndex].indices) {
            val oldVal = currentRows[cell.rowIndex][cell.colIndex]
            if (oldVal != newValue) {
                pushUndoState()
                currentRows[cell.rowIndex][cell.colIndex] = newValue
                val updatedGrid = currentGrid.copy(rows = currentRows)
                _uiState.value = _uiState.value.copy(grid = updatedGrid)
                updateVisibleRowsAndStats()
                scheduleAutoSave()
            }
        }

        if (advanceToNextRow) {
            val nextRow = cell.rowIndex + 1
            if (nextRow < currentRows.size) {
                val nextVal = currentRows[nextRow].getOrElse(cell.colIndex) { "" }
                _uiState.value = _uiState.value.copy(
                    editingCell = CellPosition(nextRow, cell.colIndex),
                    editingCellInitialValue = nextVal
                )
            } else {
                _uiState.value = _uiState.value.copy(editingCell = null)
            }
        } else {
            _uiState.value = _uiState.value.copy(editingCell = null)
        }
    }

    // Row Operations
    fun addBlankRowAtEnd() {
        pushUndoState()
        val grid = _uiState.value.grid
        val colCount = grid.columns.size.coerceAtLeast(1)
        val newRow = List(colCount) { "" }
        val updatedRows = grid.rows + listOf(newRow)
        _uiState.value = _uiState.value.copy(grid = grid.copy(rows = updatedRows))
        updateVisibleRowsAndStats()
        scheduleAutoSave()
    }

    fun insertRowAbove(rowIndex: Int) {
        pushUndoState()
        val grid = _uiState.value.grid
        val colCount = grid.columns.size.coerceAtLeast(1)
        val newRow = List(colCount) { "" }
        val updatedRows = grid.rows.toMutableList().apply {
            add(rowIndex.coerceIn(0, size), newRow)
        }
        _uiState.value = _uiState.value.copy(
            grid = grid.copy(rows = updatedRows),
            activeRowMenuIndex = null
        )
        updateVisibleRowsAndStats()
        scheduleAutoSave()
    }

    fun insertRowBelow(rowIndex: Int) {
        pushUndoState()
        val grid = _uiState.value.grid
        val colCount = grid.columns.size.coerceAtLeast(1)
        val newRow = List(colCount) { "" }
        val updatedRows = grid.rows.toMutableList().apply {
            add((rowIndex + 1).coerceIn(0, size), newRow)
        }
        _uiState.value = _uiState.value.copy(
            grid = grid.copy(rows = updatedRows),
            activeRowMenuIndex = null
        )
        updateVisibleRowsAndStats()
        scheduleAutoSave()
    }

    fun duplicateRow(rowIndex: Int) {
        if (rowIndex !in _uiState.value.grid.rows.indices) return
        pushUndoState()
        val grid = _uiState.value.grid
        val targetRow = grid.rows[rowIndex]
        val updatedRows = grid.rows.toMutableList().apply {
            add(rowIndex + 1, targetRow.toList())
        }
        _uiState.value = _uiState.value.copy(
            grid = grid.copy(rows = updatedRows),
            activeRowMenuIndex = null
        )
        updateVisibleRowsAndStats()
        scheduleAutoSave()
    }

    fun deleteRow(rowIndex: Int) {
        if (rowIndex !in _uiState.value.grid.rows.indices) return
        pushUndoState()
        val grid = _uiState.value.grid
        val updatedRows = grid.rows.toMutableList().apply {
            removeAt(rowIndex)
        }
        _uiState.value = _uiState.value.copy(
            grid = grid.copy(rows = updatedRows),
            activeRowMenuIndex = null
        )
        updateVisibleRowsAndStats()
        scheduleAutoSave()
    }

    // Column Operations
    fun renameColumn(colIndex: Int, newName: String) {
        if (colIndex !in _uiState.value.grid.columns.indices || newName.isBlank()) return
        pushUndoState()
        val grid = _uiState.value.grid
        val updatedCols = grid.columns.toMutableList().apply {
            this[colIndex] = newName.trim()
        }
        _uiState.value = _uiState.value.copy(
            grid = grid.copy(columns = updatedCols),
            activeColMenuIndex = null
        )
        updateVisibleRowsAndStats()
        scheduleAutoSave()
    }

    fun insertColumnLeft(colIndex: Int) {
        pushUndoState()
        val grid = _uiState.value.grid
        val targetIndex = colIndex.coerceIn(0, grid.columns.size)
        val newColName = "ستون جدید"
        val updatedCols = grid.columns.toMutableList().apply {
            add(targetIndex, newColName)
        }
        val updatedRows = grid.rows.map { row ->
            row.toMutableList().apply {
                add(targetIndex, "")
            }
        }
        val newPlIndex = grid.plColumnIndex?.let {
            if (it >= targetIndex) it + 1 else it
        }
        _uiState.value = _uiState.value.copy(
            grid = grid.copy(columns = updatedCols, rows = updatedRows, plColumnIndex = newPlIndex),
            activeColMenuIndex = null
        )
        updateVisibleRowsAndStats()
        scheduleAutoSave()
    }

    fun insertColumnRight(colIndex: Int) {
        insertColumnLeft(colIndex + 1)
    }

    fun deleteColumn(colIndex: Int) {
        if (colIndex !in _uiState.value.grid.columns.indices || _uiState.value.grid.columns.size <= 1) return
        pushUndoState()
        val grid = _uiState.value.grid
        val updatedCols = grid.columns.toMutableList().apply {
            removeAt(colIndex)
        }
        val updatedRows = grid.rows.map { row ->
            row.toMutableList().apply {
                if (colIndex in indices) removeAt(colIndex)
            }
        }
        val newPlIndex = when {
            grid.plColumnIndex == colIndex -> null
            grid.plColumnIndex != null && grid.plColumnIndex > colIndex -> grid.plColumnIndex - 1
            else -> grid.plColumnIndex
        }
        _uiState.value = _uiState.value.copy(
            grid = grid.copy(columns = updatedCols, rows = updatedRows, plColumnIndex = newPlIndex),
            activeColMenuIndex = null
        )
        updateVisibleRowsAndStats()
        scheduleAutoSave()
    }

    fun moveColumn(colIndex: Int, direction: Int) { // direction: -1 for left, +1 for right
        val targetIndex = colIndex + direction
        val grid = _uiState.value.grid
        if (colIndex !in grid.columns.indices || targetIndex !in grid.columns.indices) return

        pushUndoState()
        val updatedCols = grid.columns.toMutableList()
        val col = updatedCols.removeAt(colIndex)
        updatedCols.add(targetIndex, col)

        val updatedRows = grid.rows.map { row ->
            val r = row.toMutableList()
            if (colIndex in r.indices && targetIndex in 0..r.size) {
                val c = r.removeAt(colIndex)
                r.add(targetIndex, c)
            }
            r
        }

        val newPlIndex = when (grid.plColumnIndex) {
            colIndex -> targetIndex
            targetIndex -> colIndex
            else -> grid.plColumnIndex
        }

        _uiState.value = _uiState.value.copy(
            grid = grid.copy(columns = updatedCols, rows = updatedRows, plColumnIndex = newPlIndex),
            activeColMenuIndex = null
        )
        updateVisibleRowsAndStats()
        scheduleAutoSave()
    }

    // Filter & Sort
    fun openFilterDialog(colIndex: Int) {
        val grid = _uiState.value.grid
        if (colIndex !in grid.columns.indices) return

        val colName = grid.columns[colIndex]
        val allValues = grid.rows.map { it.getOrElse(colIndex) { "" }.trim() }
        val countsMap = mutableMapOf<String, Int>()
        for (v in allValues) {
            val key = if (v.isBlank()) "(خالی)" else v
            countsMap[key] = (countsMap[key] ?: 0) + 1
        }
        val uniqueList = countsMap.toList().sortedByDescending { it.second }

        val existingFilter = grid.filterStates[colIndex.toString()]
        val selectedVals = existingFilter?.selectedValues?.toSet() ?: uniqueList.map { it.first }.toSet()

        _uiState.value = _uiState.value.copy(
            activeFilterDialog = FilterDialogState(
                columnIndex = colIndex,
                columnName = colName,
                uniqueValuesWithCount = uniqueList,
                selectedValues = selectedVals,
                sortAscending = existingFilter?.sortAscending
            )
        )
    }

    fun dismissFilterDialog() {
        _uiState.value = _uiState.value.copy(activeFilterDialog = null)
    }

    fun updateFilterDialogSearch(query: String) {
        val current = _uiState.value.activeFilterDialog ?: return
        _uiState.value = _uiState.value.copy(activeFilterDialog = current.copy(searchQuery = query))
    }

    fun toggleFilterValue(value: String) {
        val current = _uiState.value.activeFilterDialog ?: return
        val updated = current.selectedValues.toMutableSet()
        if (updated.contains(value)) {
            updated.remove(value)
        } else {
            updated.add(value)
        }
        _uiState.value = _uiState.value.copy(activeFilterDialog = current.copy(selectedValues = updated))
    }

    fun selectAllFilterValues(selectAll: Boolean) {
        val current = _uiState.value.activeFilterDialog ?: return
        val newSelection = if (selectAll) {
            current.uniqueValuesWithCount.map { it.first }.toSet()
        } else {
            emptySet()
        }
        _uiState.value = _uiState.value.copy(activeFilterDialog = current.copy(selectedValues = newSelection))
    }

    fun setFilterSort(ascending: Boolean?) {
        val current = _uiState.value.activeFilterDialog ?: return
        _uiState.value = _uiState.value.copy(activeFilterDialog = current.copy(sortAscending = ascending))
    }

    fun applyColumnFilter() {
        val current = _uiState.value.activeFilterDialog ?: return
        val grid = _uiState.value.grid
        val allVals = current.uniqueValuesWithCount.map { it.first }.toSet()

        val updatedFilters = grid.filterStates.toMutableMap()
        val key = current.columnIndex.toString()

        val isFiltered = current.selectedValues.size < allVals.size || current.sortAscending != null
        if (isFiltered) {
            updatedFilters[key] = ColumnFilterState(
                columnIndex = current.columnIndex,
                selectedValues = if (current.selectedValues.size < allVals.size) current.selectedValues.toList() else null,
                sortAscending = current.sortAscending
            )
        } else {
            updatedFilters.remove(key)
        }

        _uiState.value = _uiState.value.copy(
            grid = grid.copy(filterStates = updatedFilters),
            activeFilterDialog = null
        )
        updateVisibleRowsAndStats()
        scheduleAutoSave()
    }

    fun clearColumnFilter(colIndex: Int) {
        val grid = _uiState.value.grid
        val updatedFilters = grid.filterStates.toMutableMap()
        updatedFilters.remove(colIndex.toString())
        _uiState.value = _uiState.value.copy(
            grid = grid.copy(filterStates = updatedFilters),
            activeFilterDialog = null
        )
        updateVisibleRowsAndStats()
        scheduleAutoSave()
    }

    fun clearAllFilters() {
        val grid = _uiState.value.grid
        _uiState.value = _uiState.value.copy(
            grid = grid.copy(filterStates = emptyMap()),
            searchQuery = "",
            isSearchActive = false
        )
        updateVisibleRowsAndStats()
        scheduleAutoSave()
    }

    // Global Search
    fun setSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
        updateVisibleRowsAndStats()
    }

    fun toggleSearchActive(active: Boolean) {
        _uiState.value = _uiState.value.copy(
            isSearchActive = active,
            searchQuery = if (!active) "" else _uiState.value.searchQuery
        )
        updateVisibleRowsAndStats()
    }

    // UI Dialogs & Stats
    fun toggleStatsPanel(show: Boolean? = null) {
        val next = show ?: !_uiState.value.showStatsPanel
        _uiState.value = _uiState.value.copy(showStatsPanel = next)
        if (next) {
            updateStatsCalculations()
        }
    }

    fun setStatsTab(tabIndex: Int) {
        _uiState.value = _uiState.value.copy(selectedStatsTab = tabIndex)
    }

    fun setGroupColumn(colIndex: Int) {
        _uiState.value = _uiState.value.copy(selectedGroupColumnIndex = colIndex)
        updateStatsCalculations()
    }

    fun setChartMode(mode: Int) {
        _uiState.value = _uiState.value.copy(chartMode = mode)
    }

    fun updateMoneyManagement(initialBalance: Double, riskPercent: Double) {
        val safeBal = if (initialBalance > 0) initialBalance else 500.0
        val safeRisk = if (riskPercent in 0.0001..100.0) riskPercent else 2.0
        val updatedGrid = _uiState.value.grid.copy(
            initialBalance = safeBal,
            riskPercent = safeRisk
        )
        _uiState.value = _uiState.value.copy(grid = updatedGrid)
        updateStatsCalculations()
        scheduleAutoSave()
    }

    fun updateRrCap(rrCap: Double?) {
        val safeRrCap = if (rrCap != null && rrCap > 0) rrCap else null
        val updatedGrid = _uiState.value.grid.copy(rrCap = safeRrCap)
        _uiState.value = _uiState.value.copy(grid = updatedGrid)
        updateStatsCalculations()
        scheduleAutoSave()
    }

    fun setPlColumnIndex(colIndex: Int?) {
        val grid = _uiState.value.grid.copy(plColumnIndex = colIndex)
        _uiState.value = _uiState.value.copy(grid = grid)
        updateVisibleRowsAndStats()
        scheduleAutoSave()
    }

    fun setRowMenu(rowIndex: Int?) {
        _uiState.value = _uiState.value.copy(activeRowMenuIndex = rowIndex)
    }

    fun setColMenu(colIndex: Int?) {
        _uiState.value = _uiState.value.copy(activeColMenuIndex = colIndex)
    }

    fun setShowRenameDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showRenameDialog = show)
    }

    fun renameWorkbook(newName: String) {
        if (newName.isBlank()) return
        val wb = _uiState.value.workbook ?: return
        val updated = wb.copy(name = newName.trim(), updatedAt = System.currentTimeMillis())
        _uiState.value = _uiState.value.copy(workbook = updated, showRenameDialog = false)
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateWorkbook(updated)
        }
    }

    fun setShowExportDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showExportDialog = show)
    }

    // Filtering & Sorting Algorithm
    private fun updateVisibleRowsAndStats() {
        val grid = _uiState.value.grid
        val totalRows = grid.rows.size
        val searchQuery = _uiState.value.searchQuery.trim().lowercase()

        val matchingIndices = mutableListOf<Int>()

        for (rowIdx in 0 until totalRows) {
            val row = grid.rows[rowIdx]

            // 1. Search Query Check
            if (searchQuery.isNotBlank()) {
                val matchesSearch = row.any { cell ->
                    cell.lowercase().contains(searchQuery) ||
                            NumberParser.fromPersianDigits(cell).lowercase().contains(searchQuery)
                }
                if (!matchesSearch) continue
            }

            // 2. Multi-column AND filter check
            var passesFilters = true
            for ((colStr, filter) in grid.filterStates) {
                val colIdx = filter.columnIndex
                val selectedVals = filter.selectedValues
                if (selectedVals != null) {
                    val rawVal = row.getOrElse(colIdx) { "" }.trim()
                    val cellKey = if (rawVal.isBlank()) "(خالی)" else rawVal
                    if (!selectedVals.contains(cellKey)) {
                        passesFilters = false
                        break
                    }
                }
            }

            if (passesFilters) {
                matchingIndices.add(rowIdx)
            }
        }

        // 3. Sorting check
        val activeSortFilter = grid.filterStates.values.firstOrNull { it.sortAscending != null }
        if (activeSortFilter != null && activeSortFilter.sortAscending != null) {
            val colIdx = activeSortFilter.columnIndex
            val isAsc = activeSortFilter.sortAscending!!

            // Detect if mostly numeric
            val sampleVals = matchingIndices.mapNotNull {
                NumberParser.parseDouble(grid.rows[it].getOrElse(colIdx) { "" })
            }
            val isNumeric = sampleVals.size >= matchingIndices.size * 0.7 && sampleVals.isNotEmpty()

            matchingIndices.sortWith { a, b ->
                val valA = grid.rows[a].getOrElse(colIdx) { "" }
                val valB = grid.rows[b].getOrElse(colIdx) { "" }

                if (isNumeric) {
                    val numA = NumberParser.parseDouble(valA) ?: Double.NEGATIVE_INFINITY
                    val numB = NumberParser.parseDouble(valB) ?: Double.NEGATIVE_INFINITY
                    if (isAsc) numA.compareTo(numB) else numB.compareTo(numA)
                } else {
                    if (isAsc) valA.compareTo(valB, ignoreCase = true) else valB.compareTo(valA, ignoreCase = true)
                }
            }
        }

        _uiState.value = _uiState.value.copy(visibleRowIndices = matchingIndices)
        updateStatsCalculations()
    }

    private fun updateStatsCalculations() {
        val grid = _uiState.value.grid
        val visibleIndices = _uiState.value.visibleRowIndices
        val filteredRows = visibleIndices.map { grid.rows[it] }

        viewModelScope.launch(Dispatchers.Default) {
            val summary = BacktestStatsCalculator.calculateSummary(grid.columns, filteredRows)
            val plIndex = grid.plColumnIndex ?: BacktestStatsCalculator.findCandidatePlColumn(grid.columns, grid.rows)
            val advanced = BacktestStatsCalculator.calculateAdvancedStats(filteredRows, plIndex, grid.rrCap)
            val dollar = BacktestStatsCalculator.calculateDollarStats(
                filteredRows,
                plIndex,
                grid.initialBalance,
                grid.riskPercent,
                grid.rrCap
            )

            val groupCol = _uiState.value.selectedGroupColumnIndex
                ?: BacktestStatsCalculator.findDefaultGroupColumn(grid.columns, filteredRows)

            val groupStatsList = if (groupCol != null) {
                BacktestStatsCalculator.calculateGroupStats(
                    columns = grid.columns,
                    rows = filteredRows,
                    groupColumnIndex = groupCol,
                    plColumnIndex = plIndex,
                    initialBalance = grid.initialBalance,
                    riskPercent = grid.riskPercent,
                    rrCap = grid.rrCap
                )
            } else emptyList()

            _summaryStats.value = summary
            _advancedStats.value = advanced
            _dollarStats.value = dollar
            _groupStats.value = groupStatsList
        }
    }

    // Auto-save & Manual Save
    private fun scheduleAutoSave() {
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch(Dispatchers.IO) {
            delay(500)
            saveToDatabaseInternal()
        }
    }

    fun manualSave() {
        viewModelScope.launch(Dispatchers.IO) {
            saveToDatabaseInternal()
            _eventFlow.emit("جدول با موفقیت ذخیره شد ✅")
        }
    }

    private suspend fun saveToDatabaseInternal() {
        val wb = _uiState.value.workbook ?: return
        val grid = _uiState.value.grid
        val serialized = GridSerializer.serialize(grid)

        val updated = wb.copy(
            serializedGrid = serialized,
            plColumnIndex = grid.plColumnIndex,
            rowCount = grid.rows.size,
            columnCount = grid.columns.size,
            initialBalance = grid.initialBalance,
            riskPercent = grid.riskPercent,
            rrCap = grid.rrCap,
            updatedAt = System.currentTimeMillis()
        )
        _uiState.value = _uiState.value.copy(workbook = updated)
        repository.updateWorkbook(updated)
    }

    // Export XLSX
    fun exportToXlsx(uri: Uri, exportFilteredOnly: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val grid = _uiState.value.grid
                val exportRows = if (exportFilteredOnly) {
                    _uiState.value.visibleRowIndices.map { grid.rows[it] }
                } else {
                    grid.rows
                }

                val context = getApplication<Application>()
                val outputStream = context.contentResolver.openOutputStream(uri)
                    ?: throw IllegalArgumentException("امکان نوشتن در فایل مقصد وجود ندارد.")

                outputStream.use { os ->
                    XlsxEngine.writeXlsx(os, grid.columns, exportRows)
                }

                _eventFlow.emit("فایل اکسل با موفقیت ذخیره شد ✅")
            } catch (e: Exception) {
                _eventFlow.emit("خطا در ذخیره فایل اکسل: ${e.localizedMessage}")
            }
        }
    }
}

package com.example.data

import com.example.data.model.ColumnFilterState
import com.example.data.model.GridData
import org.json.JSONArray
import org.json.JSONObject

object GridSerializer {

    fun serialize(grid: GridData): String {
        val root = JSONObject()

        // columns
        val colsArr = JSONArray()
        for (c in grid.columns) {
            colsArr.put(c)
        }
        root.put("columns", colsArr)

        // rows
        val rowsArr = JSONArray()
        for (row in grid.rows) {
            val rArr = JSONArray()
            for (cell in row) {
                rArr.put(cell)
            }
            rowsArr.put(rArr)
        }
        root.put("rows", rowsArr)

        // filterStates
        val filtersObj = JSONObject()
        for ((key, filter) in grid.filterStates) {
            val fObj = JSONObject()
            fObj.put("columnIndex", filter.columnIndex)
            if (filter.selectedValues != null) {
                val valsArr = JSONArray()
                for (v in filter.selectedValues) {
                    valsArr.put(v)
                }
                fObj.put("selectedValues", valsArr)
            }
            if (filter.sortAscending != null) {
                fObj.put("sortAscending", filter.sortAscending)
            }
            filtersObj.put(key, fObj)
        }
        root.put("filterStates", filtersObj)

        if (grid.plColumnIndex != null) {
            root.put("plColumnIndex", grid.plColumnIndex)
        }

        root.put("initialBalance", grid.initialBalance)
        root.put("riskPercent", grid.riskPercent)
        if (grid.rrCap != null && grid.rrCap > 0) {
            root.put("rrCap", grid.rrCap)
        }

        return root.toString()
    }

    fun deserialize(jsonStr: String): GridData {
        if (jsonStr.isBlank()) {
            return GridData()
        }

        return try {
            val root = JSONObject(jsonStr)

            val columns = mutableListOf<String>()
            val colsArr = root.optJSONArray("columns")
            if (colsArr != null) {
                for (i in 0 until colsArr.length()) {
                    columns.add(colsArr.getString(i))
                }
            }

            val rows = mutableListOf<List<String>>()
            val rowsArr = root.optJSONArray("rows")
            if (rowsArr != null) {
                for (i in 0 until rowsArr.length()) {
                    val rArr = rowsArr.getJSONArray(i)
                    val row = mutableListOf<String>()
                    for (j in 0 until rArr.length()) {
                        row.add(rArr.getString(j))
                    }
                    rows.add(row)
                }
            }

            val filterStates = mutableMapOf<String, ColumnFilterState>()
            val filtersObj = root.optJSONObject("filterStates")
            if (filtersObj != null) {
                val keys = filtersObj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val fObj = filtersObj.getJSONObject(key)
                    val colIdx = fObj.getInt("columnIndex")
                    val selectedVals = if (fObj.has("selectedValues")) {
                        val arr = fObj.getJSONArray("selectedValues")
                        val list = mutableListOf<String>()
                        for (k in 0 until arr.length()) {
                            list.add(arr.getString(k))
                        }
                        list
                    } else null

                    val sortAsc = if (fObj.has("sortAscending")) fObj.getBoolean("sortAscending") else null

                    filterStates[key] = ColumnFilterState(
                        columnIndex = colIdx,
                        selectedValues = selectedVals,
                        sortAscending = sortAsc
                    )
                }
            }

            val plColIndex = if (root.has("plColumnIndex")) root.getInt("plColumnIndex") else null
            val initialBalance = root.optDouble("initialBalance", 500.0)
            val riskPercent = root.optDouble("riskPercent", 2.0)
            val rrCap = if (root.has("rrCap") && !root.isNull("rrCap")) {
                val v = root.optDouble("rrCap", Double.NaN)
                if (!v.isNaN() && v > 0) v else null
            } else null

            GridData(
                columns = columns,
                rows = rows,
                filterStates = filterStates,
                plColumnIndex = plColIndex,
                initialBalance = if (initialBalance > 0) initialBalance else 500.0,
                riskPercent = if (riskPercent in 0.0001..100.0) riskPercent else 2.0,
                rrCap = rrCap
            )
        } catch (_: Exception) {
            GridData()
        }
    }
}

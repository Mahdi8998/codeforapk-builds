package com.example

import com.example.ai.GeminiClient
import com.example.analytics.FilterUtils
import com.example.analytics.StatsEngine
import com.example.analytics.StatsInput
import com.example.data.model.ColumnFilterState
import com.example.data.model.DataMode
import com.example.data.model.GridData
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AddendumEFilteredTest {

    private val geminiClient = GeminiClient()

    @Test
    fun testNoFilters_fullTablePayloadAndHeader() {
        val columns = listOf("تاریخ", "جفت ارز", "سود/زیان")
        val rows = listOf(
            listOf("2024-01-01", "EURUSD", "2"),
            listOf("2024-01-02", "GBPUSD", "-"),
            listOf("2024-01-03", "USDJPY", "1"),
            listOf("2024-01-04", "EURUSD", "-")
        )
        val gridData = GridData(columns = columns, rows = rows, plColumnIndex = 2)

        val snapshot = FilterUtils.buildFilterSnapshot(gridData)
        assertFalse(snapshot.isFiltered)
        assertEquals(4, snapshot.totalRowCount)
        assertEquals(4, snapshot.filteredRowCount)
        assertEquals("FILTER CONTEXT: the rows below are the FULL TABLE (4 rows); no filters applied.", snapshot.filterScopeHeader)

        val payloadComplete = geminiClient.buildDataPayload(gridData, DataMode.COMPLETE, snapshot)
        assertTrue(payloadComplete.startsWith("FILTER CONTEXT: the rows below are the FULL TABLE (4 rows); no filters applied."))
        assertTrue(payloadComplete.contains("EURUSD\t2"))
        assertTrue(payloadComplete.contains("GBPUSD\t-"))
        assertTrue(payloadComplete.contains("USDJPY\t1"))

        val payloadSummary = geminiClient.buildDataPayload(gridData, DataMode.SUMMARY, snapshot)
        assertTrue(payloadSummary.startsWith("FILTER CONTEXT: the rows below are the FULL TABLE (4 rows); no filters applied."))
    }

    @Test
    fun testTwoActiveColumnFiltersAndSearch_filteredRowsAndHeader() {
        val columns = listOf("تاریخ", "جفت ارز", "سشن", "نتیجه")
        val rows = listOf(
            listOf("2024-01-01", "EURUSD", "لندن", "2"),
            listOf("2024-01-02", "GBPUSD", "لندن", "-"),
            listOf("2024-01-03", "EURUSD", "نیویورک", "3"),
            listOf("2024-01-04", "USDJPY", "لندن", "1"),
            listOf("2024-01-05", "EURUSD", "لندن", "1"),
            listOf("2024-01-06", "EURUSD", "توکیو", "-")
        )

        // Column 1 ("جفت ارز") = EURUSD
        // Column 2 ("سشن") = لندن
        // Search = "2024-01-01" (matches 1 row) or no search (matches 2 rows)
        val filterStates = mapOf(
            "1" to ColumnFilterState(columnIndex = 1, selectedValues = listOf("EURUSD")),
            "2" to ColumnFilterState(columnIndex = 2, selectedValues = listOf("لندن"))
        )
        val gridData = GridData(
            columns = columns,
            rows = rows,
            filterStates = filterStates,
            searchQuery = "2024-01",
            plColumnIndex = 3
        )

        val snapshot = FilterUtils.buildFilterSnapshot(gridData, gridData.searchQuery)
        assertTrue(snapshot.isFiltered)
        assertEquals(6, snapshot.totalRowCount)
        assertEquals(2, snapshot.filteredRowCount) // Rows 0 and 4 match EURUSD + لندن + 2024-01
        assertEquals(listOf("2024-01-01", "EURUSD", "لندن", "2"), snapshot.originalOrderFilteredRows[0])
        assertEquals(listOf("2024-01-05", "EURUSD", "لندن", "1"), snapshot.originalOrderFilteredRows[1])

        assertTrue(snapshot.filterScopeHeader.contains("FILTER CONTEXT: the rows below are a FILTERED SUBSET (2 of 6 total rows)."))
        assertTrue(snapshot.filterScopeHeader.contains("جفت ارز = EURUSD"))
        assertTrue(snapshot.filterScopeHeader.contains("سشن = لندن"))
        assertTrue(snapshot.filterScopeHeader.contains("Search = \"2024-01\""))

        val payload = geminiClient.buildDataPayload(gridData, DataMode.COMPLETE, snapshot)
        assertTrue(payload.startsWith(snapshot.filterScopeHeader))
        assertTrue(payload.contains("2024-01-01\tEURUSD\tلندن\t2"))
        assertTrue(payload.contains("2024-01-05\tEURUSD\tلندن\t1"))
        assertFalse(payload.contains("GBPUSD"))
        assertFalse(payload.contains("USDJPY"))
        assertFalse(payload.contains("نیویورک"))
        assertFalse(payload.contains("توکیو"))
    }

    @Test
    fun testSummaryModeWithFilters_statsEngineMetricsAndSampleRows() {
        val columns = listOf("تاریخ", "جفت ارز", "نتیجه")
        val rows = listOf(
            listOf("2024-01-01", "EURUSD", "2"),
            listOf("2024-01-02", "GBPUSD", "3"),  // Filtered out
            listOf("2024-01-03", "EURUSD", "-"),
            listOf("2024-01-04", "USDJPY", "-"),  // Filtered out
            listOf("2024-01-05", "EURUSD", "3"),
            listOf("2024-01-06", "EURUSD", "")    // Open/unresolved
        )

        val filterStates = mapOf(
            "1" to ColumnFilterState(columnIndex = 1, selectedValues = listOf("EURUSD"))
        )
        val gridData = GridData(columns = columns, rows = rows, filterStates = filterStates, plColumnIndex = 2)

        val snapshot = FilterUtils.buildFilterSnapshot(gridData)
        assertEquals(4, snapshot.filteredRowCount)

        val payload = geminiClient.buildDataPayload(gridData, DataMode.SUMMARY, snapshot)
        assertTrue(payload.startsWith("FILTER CONTEXT: the rows below are a FILTERED SUBSET (4 of 6 total rows)."))

        // Extract JSON string from payload
        val jsonStart = payload.indexOf("{")
        val jsonStr = payload.substring(jsonStart)
        val json = JSONObject(jsonStr)

        assertEquals(6, json.getInt("totalRows"))
        assertEquals(4, json.getInt("filteredRowCount"))
        assertTrue(json.getBoolean("isFiltered"))

        // StatsEngine direct calculation on filtered subset:
        val directStats = StatsEngine.compute(
            StatsInput(
                allRows = snapshot.originalOrderFilteredRows,
                totalRowCount = 6,
                headers = columns,
                plColumnIndex = 2
            )
        )

        val advJson = json.getJSONObject("advancedMetrics")
        assertEquals(directStats.advancedStats.tradeCount, advJson.getInt("countedTradeCount"))
        assertEquals(directStats.advancedStats.winCount, advJson.getInt("winCount"))
        assertEquals(directStats.advancedStats.lossCount, advJson.getInt("lossCount"))
        assertEquals(directStats.advancedStats.netProfit, advJson.getDouble("netResultTargetUnitsR"), 0.001)

        // Sample trades should only contain EURUSD trades
        val samples = json.getJSONArray("sampleTrades")
        for (i in 0 until samples.length()) {
            val s = samples.getJSONObject(i)
            assertEquals("EURUSD", s.getString("جفت ارز"))
        }
    }

    @Test
    fun testCompleteMode_rowCapAppliedToFilteredSubset() {
        val columns = listOf("ردیف", "نتیجه")
        val rows = (1..600).map { listOf("Row $it", if (it % 2 == 0) "2" else "-") }
        val gridData = GridData(columns = columns, rows = rows, plColumnIndex = 1)

        val snapshot = FilterUtils.buildFilterSnapshot(gridData)
        val payload = geminiClient.buildDataPayload(gridData, DataMode.COMPLETE, snapshot)

        // Should be capped to 500 rows in payload
        assertTrue(payload.contains("Row 500\t"))
        assertFalse(payload.contains("Row 501\t"))
    }

    @Test
    fun testZeroFilteredRows_returnsNoAnalysisMessage() {
        val columns = listOf("جفت ارز", "نتیجه")
        val rows = listOf(
            listOf("EURUSD", "2"),
            listOf("GBPUSD", "-")
        )
        val filterStates = mapOf(
            "0" to ColumnFilterState(columnIndex = 0, selectedValues = listOf("NZDUSD"))
        )
        val gridData = GridData(columns = columns, rows = rows, filterStates = filterStates, plColumnIndex = 1)

        val snapshot = FilterUtils.buildFilterSnapshot(gridData)
        assertEquals(0, snapshot.filteredRowCount)
        assertTrue(snapshot.isFiltered)

        val payload = geminiClient.buildDataPayload(gridData, DataMode.COMPLETE, snapshot)
        assertTrue(payload.contains("هیچ ردیفی برای تحلیل وجود ندارد؛ فیلترها را بردارید."))
    }
}

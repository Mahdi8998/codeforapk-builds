package com.example

import com.example.analytics.StatsEngine
import com.example.analytics.StatsInput
import org.junit.Assert.*
import org.junit.Test

class AddendumDReactivityTest {

    private val headers = listOf("Date", "Pair", "Direction", "Result")
    private val fullDataset = listOf(
        listOf("2024-01-01", "EURUSD", "Buy", "3"),   // Trade 1: Win 3R
        listOf("2024-01-02", "GBPUSD", "Sell", "-"),  // Trade 2: Loss -1R
        listOf("2024-01-03", "EURUSD", "Buy", "2"),   // Trade 3: Win 2R
        listOf("2024-01-04", "USDJPY", "Buy", ""),    // Trade 4: Blank (excluded)
        listOf("2024-01-05", "GBPUSD", "Sell", "1"),  // Trade 5: Win 1R
        listOf("2024-01-06", "EURUSD", "Sell", "-"),  // Trade 6: Loss -1R
        listOf("2024-01-07", "USDJPY", "Buy", "0"),   // Trade 7: 0 (excluded)
        listOf("2024-01-08", "EURUSD", "Buy", "4")    // Trade 8: Win 4R
    )

    @Test
    fun testStatsEngine_fullDataset_defaultSettings() {
        val input = StatsInput(
            allRows = fullDataset,
            totalRowCount = fullDataset.size,
            headers = headers,
            plColumnIndex = 3,
            selectedGroupColumnIndex = 1,
            rrCap = null,
            initialBalance = 500.0,
            riskPercent = 2.0
        )

        val result = StatsEngine.compute(input)

        // Verifications
        assertEquals(8, result.totalRows)
        assertEquals(8, result.filteredRowCount)
        assertFalse(result.isFiltered)
        assertEquals(3, result.plColumnIndex)
        assertEquals(1, result.selectedGroupColumnIndex)

        // 6 counted trades (4 wins: 3, 2, 1, 4 = +10R; 2 losses: -, - = -2R; 2 excluded: "", "0")
        assertEquals(6, result.advancedStats.tradeCount)
        assertEquals(2, result.advancedStats.excludedCount)
        assertEquals(4, result.advancedStats.winCount)
        assertEquals(2, result.advancedStats.lossCount)
        assertEquals(8.0, result.advancedStats.netProfit, 0.001)
        assertEquals(10.0, result.advancedStats.grossProfit, 0.001)
        assertEquals(2.0, result.advancedStats.grossLoss, 0.001)
        assertEquals(66.7, result.advancedStats.winRate, 0.1) // 4 / 6 = 66.67%
        assertEquals(5.0, result.advancedStats.profitFactor!!, 0.01) // 10 / 2 = 5.0
        assertEquals(1.33, result.advancedStats.expectancy, 0.01) // 8 / 6 = 1.33 R

        // Check Dollar Stats
        assertEquals(500.0, result.dollarStats.initialBalance, 0.001)
        assertEquals(6, result.dollarStats.tradeCount)
        assertTrue(result.dollarStats.finalBalance > 500.0)

        // Check Groups (EURUSD, GBPUSD; USDJPY excluded as it had only blank/zero results)
        assertEquals(2, result.groupStats.size)
        val eurusd = result.groupStats.first { it.groupValue == "EURUSD" }
        assertEquals(4, eurusd.tradeCount)
        assertEquals(75.0, eurusd.winRate, 0.01)
        assertEquals(8.0, eurusd.netProfit, 0.001) // 3 + 2 - 1 + 4 = 8R
    }

    @Test
    fun testStatsEngine_filteredDataset_reactivity() {
        // User filters on Pair == "EURUSD"
        val filteredRows = fullDataset.filter { it[1] == "EURUSD" }
        val input = StatsInput(
            allRows = filteredRows,
            totalRowCount = fullDataset.size,
            headers = headers,
            plColumnIndex = 3,
            selectedGroupColumnIndex = 2, // Group by Direction
            rrCap = null,
            initialBalance = 1000.0,
            riskPercent = 1.0
        )

        val result = StatsEngine.compute(input)

        assertEquals(8, result.totalRows)
        assertEquals(4, result.filteredRowCount)
        assertTrue(result.isFiltered)

        // EURUSD trades: "3", "2", "-", "4" -> 4 counted trades (3 wins: 3, 2, 4 = +9R; 1 loss: -1R)
        assertEquals(4, result.advancedStats.tradeCount)
        assertEquals(3, result.advancedStats.winCount)
        assertEquals(1, result.advancedStats.lossCount)
        assertEquals(8.0, result.advancedStats.netProfit, 0.001)
        assertEquals(75.0, result.advancedStats.winRate, 0.01)

        // Group by Direction in EURUSD: Buy (3, 2, 4) vs Sell (-)
        assertEquals(2, result.groupStats.size)
        val buyGroup = result.groupStats.first { it.groupValue == "Buy" }
        assertEquals(3, buyGroup.tradeCount)
        assertEquals(100.0, buyGroup.winRate, 0.01)
        assertEquals(9.0, buyGroup.netProfit, 0.001)

        val sellGroup = result.groupStats.first { it.groupValue == "Sell" }
        assertEquals(1, sellGroup.tradeCount)
        assertEquals(0.0, sellGroup.winRate, 0.01)
        assertEquals(-1.0, sellGroup.netProfit, 0.001)
    }

    @Test
    fun testStatsEngine_rrCapChange_reactivity() {
        // Apply R:R Cap = 2.0 to full dataset
        val input = StatsInput(
            allRows = fullDataset,
            totalRowCount = fullDataset.size,
            headers = headers,
            plColumnIndex = 3,
            selectedGroupColumnIndex = 1,
            rrCap = 2.0,
            initialBalance = 500.0,
            riskPercent = 2.0
        )

        val result = StatsEngine.compute(input)

        // Wins: "3" -> 2, "2" -> 2, "1" -> 1, "4" -> 2 => Gross Profit = 7.0 R
        // Losses: "-", "-" => Gross Loss = 2.0 R
        // Net Profit = 5.0 R
        assertEquals(6, result.advancedStats.tradeCount)
        assertEquals(4, result.advancedStats.winCount)
        assertEquals(2, result.advancedStats.lossCount)
        assertEquals(7.0, result.advancedStats.grossProfit, 0.001)
        assertEquals(2.0, result.advancedStats.grossLoss, 0.001)
        assertEquals(5.0, result.advancedStats.netProfit, 0.001)
        assertEquals(2.0, result.advancedStats.bestTrade, 0.001)

        // Win rate and loss count DO NOT CHANGE when RR cap changes
        assertEquals(66.7, result.advancedStats.winRate, 0.1)
    }

    @Test
    fun testStatsEngine_emptyDataset_edgeCase() {
        val input = StatsInput(
            allRows = emptyList(),
            totalRowCount = 0,
            headers = headers,
            plColumnIndex = 3,
            selectedGroupColumnIndex = 1
        )

        val result = StatsEngine.compute(input)

        assertEquals(0, result.totalRows)
        assertEquals(0, result.filteredRowCount)
        assertFalse(result.isFiltered)
        assertEquals(0, result.advancedStats.tradeCount)
        assertEquals(0, result.dollarStats.tradeCount)
        assertTrue(result.groupStats.isEmpty())
    }

    @Test
    fun testStatsEngine_nullPlColumn_fallback() {
        val input = StatsInput(
            allRows = fullDataset,
            totalRowCount = fullDataset.size,
            headers = headers,
            plColumnIndex = null, // Should auto-detect column 3 ("Result")
            selectedGroupColumnIndex = null
        )

        val result = StatsEngine.compute(input)

        assertEquals(3, result.plColumnIndex)
        assertEquals(6, result.advancedStats.tradeCount)
    }
}

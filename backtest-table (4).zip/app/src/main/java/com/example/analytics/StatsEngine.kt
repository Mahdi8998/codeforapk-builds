package com.example.analytics

import com.example.util.NumberParser

/**
 * Immutable input for the stats calculation pipeline (Addendum D.2)
 */
data class StatsInput(
    val allRows: List<List<String>>, // Filtered rows in original workbook order
    val totalRowCount: Int,
    val headers: List<String>,
    val plColumnIndex: Int?,
    val selectedGroupColumnIndex: Int? = null,
    val rrCap: Double? = null,
    val initialBalance: Double = 500.0,
    val riskPercent: Double = 2.0
)

/**
 * Immutable single source of truth output containing all statistics for all tabs (Addendum D.2)
 */
data class StatsResult(
    val totalRows: Int = 0,
    val filteredRowCount: Int = 0,
    val isFiltered: Boolean = false,
    val headers: List<String> = emptyList(),
    val plColumnIndex: Int? = null,
    val selectedGroupColumnIndex: Int? = null,
    val rrCap: Double? = null,
    val initialBalance: Double = 500.0,
    val riskPercent: Double = 2.0,
    val summaryStats: List<ColumnSummary> = emptyList(),
    val advancedStats: AdvancedStats = AdvancedStats(),
    val dollarStats: DollarStats = DollarStats(),
    val groupStats: List<GroupItemStats> = emptyList()
)

/**
 * Single pure calculation engine for all backtest statistics (Addendum D.2)
 * Zero cached state, pure derived function of StatsInput -> StatsResult.
 */
object StatsEngine {

    fun compute(input: StatsInput): StatsResult {
        val filteredRows = input.allRows
        val totalRows = input.totalRowCount
        val isFiltered = totalRows > filteredRows.size
        val headers = input.headers

        val summary = BacktestStatsCalculator.calculateSummary(headers, filteredRows)
        val plIndex = input.plColumnIndex ?: BacktestStatsCalculator.findCandidatePlColumn(headers, filteredRows)
        val advanced = BacktestStatsCalculator.calculateAdvancedStats(filteredRows, plIndex, input.rrCap)
        val dollar = BacktestStatsCalculator.calculateDollarStats(
            rows = filteredRows,
            plColumnIndex = plIndex,
            initialBalance = input.initialBalance,
            riskPercent = input.riskPercent,
            rrCap = input.rrCap
        )

        val groupCol = input.selectedGroupColumnIndex
            ?: BacktestStatsCalculator.findDefaultGroupColumn(headers, filteredRows)

        val groupStats = if (groupCol != null) {
            BacktestStatsCalculator.calculateGroupStats(
                columns = headers,
                rows = filteredRows,
                groupColumnIndex = groupCol,
                plColumnIndex = plIndex,
                initialBalance = input.initialBalance,
                riskPercent = input.riskPercent,
                rrCap = input.rrCap
            )
        } else emptyList()

        return StatsResult(
            totalRows = totalRows,
            filteredRowCount = filteredRows.size,
            isFiltered = isFiltered,
            headers = headers,
            plColumnIndex = plIndex,
            selectedGroupColumnIndex = groupCol,
            rrCap = input.rrCap,
            initialBalance = input.initialBalance,
            riskPercent = input.riskPercent,
            summaryStats = summary,
            advancedStats = advanced,
            dollarStats = dollar,
            groupStats = groupStats
        )
    }
}

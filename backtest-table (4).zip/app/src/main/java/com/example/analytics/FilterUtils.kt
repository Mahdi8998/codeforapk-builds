package com.example.analytics

import com.example.data.model.ColumnFilterState
import com.example.data.model.GridData
import com.example.util.NumberParser

data class FilterSnapshot(
    val originalOrderFilteredRows: List<List<String>>,
    val totalRowCount: Int,
    val filteredRowCount: Int,
    val isFiltered: Boolean,
    val activeFilterDescriptions: List<String>,
    val filterScopeHeader: String
)

object FilterUtils {

    fun filterVisibleRowIndices(
        columns: List<String>,
        rows: List<List<String>>,
        filterStates: Map<String, ColumnFilterState>,
        searchQuery: String = "",
        applySorting: Boolean = false
    ): List<Int> {
        val totalRows = rows.size
        val trimmedQuery = searchQuery.trim().lowercase()
        val hasSearch = trimmedQuery.isNotBlank()
        val activeColumnFilters = filterStates.values.filter { it.selectedValues != null }

        val matchingIndices = mutableListOf<Int>()

        for (rowIdx in 0 until totalRows) {
            val row = rows[rowIdx]

            // 1. Search Query Check
            if (hasSearch) {
                val matchesSearch = row.any { cell ->
                    cell.lowercase().contains(trimmedQuery) ||
                            NumberParser.fromPersianDigits(cell).lowercase().contains(trimmedQuery)
                }
                if (!matchesSearch) continue
            }

            // 2. Multi-column AND filter check
            var passesFilters = true
            for (filter in activeColumnFilters) {
                val colIdx = filter.columnIndex
                val selectedVals = filter.selectedValues
                if (selectedVals != null) {
                    val rawVal = row.getOrElse(colIdx) { "" }.trim()
                    val cellKey = if (rawVal.isBlank()) "(خالی)" else rawVal
                    if (!selectedVals.contains(cellKey)) {
                        passesFilters = false
                        break
                    }
                }
            }

            if (passesFilters) {
                matchingIndices.add(rowIdx)
            }
        }

        if (applySorting) {
            val activeSortFilter = filterStates.values.firstOrNull { it.sortAscending != null }
            if (activeSortFilter != null && activeSortFilter.sortAscending != null) {
                val colIdx = activeSortFilter.columnIndex
                val isAsc = activeSortFilter.sortAscending!!

                val sampleVals = matchingIndices.mapNotNull {
                    NumberParser.parseDouble(rows[it].getOrElse(colIdx) { "" })
                }
                val isNumeric = sampleVals.size >= matchingIndices.size * 0.7 && sampleVals.isNotEmpty()

                matchingIndices.sortWith { a, b ->
                    val valA = rows[a].getOrElse(colIdx) { "" }
                    val valB = rows[b].getOrElse(colIdx) { "" }

                    if (isNumeric) {
                        val numA = NumberParser.parseDouble(valA) ?: Double.NEGATIVE_INFINITY
                        val numB = NumberParser.parseDouble(valB) ?: Double.NEGATIVE_INFINITY
                        if (isAsc) numA.compareTo(numB) else numB.compareTo(numA)
                    } else {
                        if (isAsc) valA.compareTo(valB, ignoreCase = true) else valB.compareTo(valA, ignoreCase = true)
                    }
                }
            }
        }

        return matchingIndices
    }

    fun filterVisibleRowIndices(gridData: GridData, searchQuery: String = gridData.searchQuery, applySorting: Boolean = false): List<Int> {
        return filterVisibleRowIndices(gridData.columns, gridData.rows, gridData.filterStates, searchQuery, applySorting)
    }

    fun filterRows(
        columns: List<String>,
        rows: List<List<String>>,
        filterStates: Map<String, ColumnFilterState>,
        searchQuery: String = ""
    ): List<List<String>> {
        val indices = filterVisibleRowIndices(columns, rows, filterStates, searchQuery)
        return indices.sorted().map { rows[it] }
    }

    fun buildFilterSnapshot(
        gridData: GridData,
        searchQuery: String = gridData.searchQuery
    ): FilterSnapshot {
        val totalRows = gridData.rows.size
        val filteredRows = filterRows(gridData.columns, gridData.rows, gridData.filterStates, searchQuery)
        val activeFilterItems = mutableListOf<String>()

        val sortedFilters = gridData.filterStates.values
            .filter { it.selectedValues != null }
            .sortedBy { it.columnIndex }

        for (filter in sortedFilters) {
            val colName = gridData.columns.getOrNull(filter.columnIndex)
                ?: "ستون ${NumberParser.formatPersian(filter.columnIndex + 1)}"
            val selectedValues = filter.selectedValues ?: emptyList()
            activeFilterItems.add("$colName = ${selectedValues.joinToString(", ")}")
        }

        val trimmedQuery = searchQuery.trim()
        if (trimmedQuery.isNotBlank()) {
            activeFilterItems.add("Search = \"$trimmedQuery\"")
        }

        val isFiltered = activeFilterItems.isNotEmpty() || filteredRows.size < totalRows

        val scopeHeader = if (isFiltered) {
            val activeFiltersStr = if (activeFilterItems.isNotEmpty()) {
                activeFilterItems.joinToString("; ")
            } else {
                "custom filter"
            }
            "FILTER CONTEXT: the rows below are a FILTERED SUBSET (${filteredRows.size} of $totalRows total rows). Active filters: $activeFiltersStr. The user is intentionally analyzing this subset."
        } else {
            "FILTER CONTEXT: the rows below are the FULL TABLE ($totalRows rows); no filters applied."
        }

        return FilterSnapshot(
            originalOrderFilteredRows = filteredRows,
            totalRowCount = totalRows,
            filteredRowCount = filteredRows.size,
            isFiltered = isFiltered,
            activeFilterDescriptions = activeFilterItems,
            filterScopeHeader = scopeHeader
        )
    }
}

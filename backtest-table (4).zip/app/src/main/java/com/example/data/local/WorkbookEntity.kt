package com.example.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "workbooks")
data class WorkbookEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val serializedGrid: String,
    val plColumnIndex: Int? = null,
    val rowCount: Int = 0,
    val columnCount: Int = 0,
    val initialBalance: Double = 500.0,
    val riskPercent: Double = 2.0,
    val rrCap: Double? = null
)

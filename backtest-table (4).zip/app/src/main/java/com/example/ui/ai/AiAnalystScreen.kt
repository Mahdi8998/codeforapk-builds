package com.example.ui.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DataMode
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ProfitGreen
import com.example.util.NumberParser
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAnalystScreen(
    workbookId: Long,
    viewModel: AiViewModel,
    onNavigateBack: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val clipboardManager = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    LaunchedEffect(workbookId) {
        viewModel.loadWorkbookForAi(workbookId)
    }

    // Scroll to bottom on new message
    LaunchedEffect(uiState.chatHistory.size, uiState.isLoading) {
        if (uiState.chatHistory.isNotEmpty()) {
            listState.animateScrollToItem(uiState.chatHistory.size)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "تحلیلگر هوشمند Gemini",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = uiState.workbookName.ifBlank { "جدول بکتست" },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    if (uiState.chatHistory.isNotEmpty()) {
                        TextButton(
                            onClick = { viewModel.resetConversation() },
                            modifier = Modifier.testTag("new_chat_button")
                        ) {
                            Icon(Icons.Outlined.RestartAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("چت جدید")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 4.dp,
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    // Privacy notice
                    Text(
                        text = "🔒 داده‌های بکتست صرفاً برای تحلیل به گوگل Gemini ارسال می‌شوند و چت‌ها موقت هستند.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                    )

                    // Input bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = uiState.currentInputText,
                            onValueChange = { viewModel.updateInputText(it) },
                            placeholder = { Text("سوال یا درخواست تحلیل تکمیلی...") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("ai_prompt_input"),
                            shape = RoundedCornerShape(16.dp),
                            maxLines = 3,
                            enabled = !uiState.isLoading
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        FilledIconButton(
                            onClick = { viewModel.sendUserMessage() },
                            enabled = uiState.currentInputText.isNotBlank() && !uiState.isLoading,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("send_ai_message_button")
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.Send,
                                contentDescription = "ارسال",
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { paddingValues ->
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Scope Chip
            item {
                val totalRowsFormatted = NumberParser.formatPersian(uiState.filterSnapshot.totalRowCount)
                val filteredRowsFormatted = NumberParser.formatPersian(uiState.filterSnapshot.filteredRowCount)
                val scopeChipText = if (uiState.filterSnapshot.isFiltered) {
                    "تحلیل روی: ردیفهای فیلترشده ($filteredRowsFormatted از $totalRowsFormatted ردیف)"
                } else {
                    "تحلیل روی: کل جدول ($totalRowsFormatted ردیف)"
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (uiState.filterSnapshot.isFiltered) {
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    },
                    modifier = Modifier.testTag("ai_scope_chip")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            if (uiState.filterSnapshot.isFiltered) Icons.Outlined.FilterAlt else Icons.Outlined.TableChart,
                            contentDescription = null,
                            tint = if (uiState.filterSnapshot.isFiltered) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = scopeChipText,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Medium,
                            color = if (uiState.filterSnapshot.isFiltered) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Zero-row edge case warning
            if (uiState.filterSnapshot.filteredRowCount == 0 && uiState.filterSnapshot.totalRowCount > 0) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("zero_rows_warning"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Outlined.FilterAltOff,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "هیچ ردیفی برای تحلیل وجود ندارد؛ فیلترها را بردارید.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Missing API Key Banner
            if (!uiState.hasApiKey && uiState.apiKey.isBlank()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Key,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "کلید API هوش مصنوعی تنظیم نشده است",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "برای فعال‌سازی تحلیلگر هوشمند، لطفاً کلید Gemini خود را در تنظیمات وارد کنید.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Button(
                                onClick = onOpenSettings,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("تنظیمات")
                            }
                        }
                    }
                }
            }

            // Data Mode Selector
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "حالت ارسال داده به هوش مصنوعی:",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )

                            Row(
                                modifier = Modifier
                                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                                    .padding(2.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (uiState.dataMode == DataMode.SUMMARY) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    modifier = Modifier.clickable { viewModel.setDataMode(DataMode.SUMMARY) }
                                ) {
                                    Text(
                                        text = "خلاصه (بهینه)",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (uiState.dataMode == DataMode.SUMMARY) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (uiState.dataMode == DataMode.COMPLETE) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    modifier = Modifier.clickable { viewModel.setDataMode(DataMode.COMPLETE) }
                                ) {
                                    Text(
                                        text = "کامل (تمام سطرها)",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (uiState.dataMode == DataMode.COMPLETE) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (uiState.dataMode == DataMode.SUMMARY) {
                                "متریک‌های آماری، تفکیک گروه‌ها و ۳۰ معامله نمونه ارسال می‌شود (سریع‌تر و متمرکز بر آمار کلیدی)."
                            } else {
                                "تمام ردیف‌های جدول تا سقف ۵۰۰ ردیف ارسال می‌شود تا جزئیات کامل بررسی گردد."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Preset Analysis Buttons (when conversation is empty)
            if (uiState.chatHistory.isEmpty()) {
                item {
                    Text(
                        text = "تحلیل‌های سریع و تخصصی بکتست:",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 6.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        PresetAnalysisCard(
                            icon = Icons.Default.Analytics,
                            title = "تحلیل کلی استراتژی معاملاتی",
                            description = "ارزیابی جامع عملکرد، وین‌ریت، نقاط قوت، سودآوری و ثبات استراتژی",
                            onClick = { viewModel.triggerPresetAnalysis(1) },
                            enabled = !uiState.isLoading
                        )
                        PresetAnalysisCard(
                            icon = Icons.Default.TrendingDown,
                            title = "بررسی معاملات باخت و خطاها",
                            description = "ریشه‌یابی و کشف الگوهای تکراری در معاملات زیان‌ده",
                            onClick = { viewModel.triggerPresetAnalysis(2) },
                            enabled = !uiState.isLoading
                        )
                        PresetAnalysisCard(
                            icon = Icons.Default.Shield,
                            title = "مدیریت ریسک و حجم معاملات",
                            description = "تحلیل افت سرمایه (Drawdown)، معاملات منفی پیاپی و مدیریت سرمایه",
                            onClick = { viewModel.triggerPresetAnalysis(3) },
                            enabled = !uiState.isLoading
                        )
                        PresetAnalysisCard(
                            icon = Icons.Default.Lightbulb,
                            title = "پیشنهادهای بهبود قوانین و فیلترها",
                            description = "راهکارهای عملی برای افزایش امید ریاضی و بهینه‌سازی ورود/خروج",
                            onClick = { viewModel.triggerPresetAnalysis(4) },
                            enabled = !uiState.isLoading
                        )
                    }
                }
            }

            // Chat History Messages
            items(uiState.chatHistory) { message ->
                if (message.role == "user") {
                    UserMessageCard(message.content)
                } else {
                    AiResponseCard(
                        content = message.content,
                        onCopy = {
                            clipboardManager.setText(AnnotatedString(message.content))
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("تحلیل با موفقیت کپی شد ✅")
                            }
                        }
                    )
                }
            }

            // Loading / Thinking state
            if (uiState.isLoading) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                strokeWidth = 2.5.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "در حال تحلیل داده‌های بکتست با Gemini...",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            // Error Card
            if (uiState.errorMessage != null) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
                        )
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "خطا در ارتباط با هوش مصنوعی",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = uiState.errorMessage ?: "",
                                style = MaterialTheme.typography.bodyMedium
                            )

                            if (uiState.isKeyError) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = onOpenSettings,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("ویرایش کلید API در تنظیمات")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 500 Row Cap Dialog
    if (uiState.showRowCapDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissCapDialog() },
            title = { Text("تعداد زیاد ردیف‌های جدول") },
            text = {
                Text("جدول شما دارای بیش از ۵۰۰ ردیف است. ارسال تمام ردیف‌ها ممکن است با محدودیت طول پرامپت مواجه شود. پیشنهاد می‌کنیم از حالت «خلاصه آماری» استفاده کنید.")
            },
            confirmButton = {
                Button(onClick = { viewModel.confirmSendSummaryFromCapDialog() }) {
                    Text("ارسال به صورت خلاصه آماری")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.dismissCapDialog() }) {
                    Text("انصراف")
                }
            }
        )
    }
}

@Composable
private fun PresetAnalysisCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    onClick: () -> Unit,
    enabled: Boolean
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled) { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(42.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun UserMessageCard(content: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
    ) {
        Surface(
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 4.dp, bottomStart = 16.dp, bottomEnd = 16.dp),
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Text(
                text = content,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White,
                modifier = Modifier.padding(14.dp)
            )
        }
    }
}

@Composable
private fun AiResponseCard(
    content: String,
    onCopy: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "تحلیل تخصصی استراتژی",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                IconButton(
                    onClick = onCopy,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Outlined.ContentCopy,
                        contentDescription = "کپی متن",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Formatted response text
            Text(
                text = content,
                style = MaterialTheme.typography.bodyMedium,
                lineHeight = 24.sp
            )
        }
    }
}

package com.example.ui.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiResult
import com.example.ai.ChatMessage
import com.example.ai.GeminiClient
import com.example.analytics.FilterSnapshot
import com.example.analytics.FilterUtils
import com.example.data.local.AppDatabase
import com.example.data.model.DataMode
import com.example.data.model.GridData
import com.example.data.preferences.SettingsManager
import com.example.data.repository.WorkbookRepository
import com.example.data.GridSerializer
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

data class AiUiState(
    val workbookName: String = "",
    val gridData: GridData = GridData(),
    val filterSnapshot: FilterSnapshot = FilterSnapshot(
        originalOrderFilteredRows = emptyList(),
        totalRowCount = 0,
        filteredRowCount = 0,
        isFiltered = false,
        activeFilterDescriptions = emptyList(),
        filterScopeHeader = ""
    ),
    val dataMode: DataMode = DataMode.SUMMARY,
    val apiKey: String = "",
    val hasApiKey: Boolean = false,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val isKeyError: Boolean = false,
    val chatHistory: List<ChatMessage> = emptyList(),
    val currentInputText: String = "",
    val showRowCapDialog: Boolean = false,
    val pendingPrompt: String? = null
)

class AiViewModel(application: Application) : AndroidViewModel(application) {

    private val geminiClient = GeminiClient()
    private val settingsManager = SettingsManager(application)
    private val repository: WorkbookRepository

    private val _uiState = MutableStateFlow(AiUiState())
    val uiState: StateFlow<AiUiState> = _uiState.asStateFlow()

    init {
        val db = AppDatabase.getDatabase(application)
        repository = WorkbookRepository(db.workbookDao())

        viewModelScope.launch {
            val userKey = settingsManager.geminiApiKey.firstOrNull() ?: ""
            val resolvedKey = if (userKey.isNotBlank()) userKey else BuildConfig.GEMINI_API_KEY
            _uiState.value = _uiState.value.copy(
                apiKey = resolvedKey,
                hasApiKey = resolvedKey.isNotBlank() && resolvedKey != "MY_GEMINI_API_KEY"
            )
        }
    }

    fun loadWorkbookForAi(workbookId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val entity = repository.getWorkbook(workbookId)
            if (entity != null) {
                val grid = GridSerializer.deserialize(entity.serializedGrid)
                val fullGrid = grid.copy(plColumnIndex = entity.plColumnIndex ?: grid.plColumnIndex)
                val snapshot = FilterUtils.buildFilterSnapshot(fullGrid, fullGrid.searchQuery)
                _uiState.value = _uiState.value.copy(
                    workbookName = entity.name,
                    gridData = fullGrid,
                    filterSnapshot = if (_uiState.value.chatHistory.isEmpty()) snapshot else _uiState.value.filterSnapshot
                )
            }
        }
    }

    fun setDataMode(mode: DataMode) {
        _uiState.value = _uiState.value.copy(dataMode = mode)
    }

    fun updateInputText(text: String) {
        _uiState.value = _uiState.value.copy(currentInputText = text)
    }

    fun resetConversation() {
        val snapshot = FilterUtils.buildFilterSnapshot(_uiState.value.gridData, _uiState.value.gridData.searchQuery)
        _uiState.value = _uiState.value.copy(
            chatHistory = emptyList(),
            filterSnapshot = snapshot,
            errorMessage = null,
            currentInputText = ""
        )
    }

    fun triggerPresetAnalysis(presetIndex: Int) {
        val prompt = when (presetIndex) {
            1 -> "لطفاً تحلیل جامع و تخصصی از عملکرد کلی این استراتژی معاملاتی ارائه دهید. نقاط قوت، نقاط ضعف و وضعیت سودآوری را با استناد به ارقام دقیق بررسی کنید."
            2 -> "معاملات زیان‌ده را به طور دقیق بررسی و ریشه‌یابی کنید. چه الگوها، جفت‌ارزها یا شرایط مشترکی در معاملات باخت تکرار شده‌اند؟"
            3 -> "وضعیت مدیریت ریسک، افت سرمایه (Drawdown)، معاملات پیاپی منفی و حجم معاملات را ارزیابی کرده و توصیه‌های لازم برای مدیریت سرمایه ارائه کنید."
            4 -> "با توجه به نتایج بکتست، چه تغییرات و قوانین مشخصی در استراتژی (مانند فیلتر زمان، جفت‌ارزها یا اصلاح حد سود/زیان) پیشنهاد می‌کنید که ارزش تست کردن دارند؟"
            else -> "لطفاً این جدول بکتست را به صورت تخصصی تحلیل کنید."
        }
        sendPrompt(prompt)
    }

    fun sendUserMessage() {
        val text = _uiState.value.currentInputText.trim()
        if (text.isBlank()) return
        _uiState.value = _uiState.value.copy(currentInputText = "")
        sendPrompt(text)
    }

    private fun sendPrompt(prompt: String) {
        val snapshot = if (_uiState.value.chatHistory.isEmpty()) {
            val s = FilterUtils.buildFilterSnapshot(_uiState.value.gridData, _uiState.value.gridData.searchQuery)
            _uiState.value = _uiState.value.copy(filterSnapshot = s)
            s
        } else {
            _uiState.value.filterSnapshot
        }

        if (snapshot.filteredRowCount == 0) {
            _uiState.value = _uiState.value.copy(
                errorMessage = "هیچ ردیفی برای تحلیل وجود ندارد؛ فیلترها را بردارید."
            )
            return
        }

        if (_uiState.value.dataMode == DataMode.COMPLETE && snapshot.filteredRowCount > 500) {
            _uiState.value = _uiState.value.copy(
                showRowCapDialog = true,
                pendingPrompt = prompt
            )
            return
        }

        executeAnalysis(prompt)
    }

    fun confirmSendSummaryFromCapDialog() {
        val prompt = _uiState.value.pendingPrompt ?: return
        _uiState.value = _uiState.value.copy(
            dataMode = DataMode.SUMMARY,
            showRowCapDialog = false,
            pendingPrompt = null
        )
        executeAnalysis(prompt)
    }

    fun dismissCapDialog() {
        _uiState.value = _uiState.value.copy(
            showRowCapDialog = false,
            pendingPrompt = null
        )
    }

    private fun executeAnalysis(prompt: String) {
        val activeSnapshot = _uiState.value.filterSnapshot
        if (activeSnapshot.filteredRowCount == 0) {
            _uiState.value = _uiState.value.copy(
                errorMessage = "هیچ ردیفی برای تحلیل وجود ندارد؛ فیلترها را بردارید."
            )
            return
        }

        val currentHistory = _uiState.value.chatHistory
        val userMsg = ChatMessage(role = "user", content = prompt)
        val updatedHistory = currentHistory + userMsg

        _uiState.value = _uiState.value.copy(
            chatHistory = updatedHistory,
            isLoading = true,
            errorMessage = null,
            isKeyError = false
        )

        viewModelScope.launch(Dispatchers.IO) {
            val userKey = settingsManager.geminiApiKey.firstOrNull() ?: ""
            val resolvedKey = if (userKey.isNotBlank()) userKey else BuildConfig.GEMINI_API_KEY

            if (resolvedKey.isBlank() || resolvedKey == "MY_GEMINI_API_KEY") {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    hasApiKey = false,
                    isKeyError = true,
                    errorMessage = "کلید API تنظیم نشده است. لطفاً ابتدا در بخش تنظیمات کلید خود را وارد کنید."
                )
                return@launch
            }

            val result = geminiClient.sendAnalysis(
                apiKey = resolvedKey,
                prompt = prompt,
                gridData = _uiState.value.gridData,
                dataMode = _uiState.value.dataMode,
                history = currentHistory,
                filterSnapshot = activeSnapshot
            )

            when (result) {
                is AiResult.Success -> {
                    val modelMsg = ChatMessage(role = "model", content = result.responseText)
                    _uiState.value = _uiState.value.copy(
                        chatHistory = _uiState.value.chatHistory + modelMsg,
                        isLoading = false,
                        errorMessage = null
                    )
                }
                is AiResult.Error -> {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = result.errorMessage,
                        isKeyError = result.isKeyError
                    )
                }
            }
        }
    }
}

package ir.mahdi.backtesttable

import ir.mahdi.backtesttable.data.NumberUtils
import ir.mahdi.backtesttable.data.model.GridRow
import ir.mahdi.backtesttable.data.stats.StatsEngine
import ir.mahdi.backtesttable.data.stats.StatsInput
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StatsEngineTest {

    @Test
    fun testPersianNumberParsing() {
        // Persian digits "۱۲.۵" -> 12.5
        val p1 = NumberUtils.parseDouble("۱۲.۵")
        assertEquals(12.5, p1 ?: 0.0, 0.001)

        // Arabic digits "١٢.٥" -> 12.5
        val p2 = NumberUtils.parseDouble("١٢.٥")
        assertEquals(12.5, p2 ?: 0.0, 0.001)

        // Negative sign
        val p3 = NumberUtils.parseDouble("-۳")
        assertEquals(-3.0, p3 ?: 0.0, 0.001)

        // Persian minus
        val p4 = NumberUtils.parseDouble("−۱")
        assertEquals(-1.0, p4 ?: 0.0, 0.001)

        // Formatter tests
        assertEquals("۱۲.۵", NumberUtils.formatNumber(12.5))
        assertEquals("۱,۰۰۰", NumberUtils.formatInt(1000))
    }

    @Test
    fun testStatsComputation() {
        val headers = listOf("جفت‌ارز", "جهت", "نتیجه")
        // Rows:
        // 1: EURUSD, خرید, 2
        // 2: GBPUSD, فروش, -
        // 3: EURUSD, خرید, 3
        // 4: XAUUSD, فروش, -1
        val rows = listOf(
            GridRow(id = 1L, cells = listOf("EURUSD", "خرید", "2")),
            GridRow(id = 2L, cells = listOf("GBPUSD", "فروش", "-")),
            GridRow(id = 3L, cells = listOf("EURUSD", "خرید", "3")),
            GridRow(id = 4L, cells = listOf("XAUUSD", "فروش", "-1"))
        )

        val input = StatsInput(
            visibleRows = rows,
            headers = headers,
            plColumnIndex = 2,
            groupColumnIndex = 0,
            rrCap = null,
            initialBalance = 10000.0,
            riskPercent = 1.0
        )

        val result = StatsEngine.compute(input)

        // 4 trades total: 2 wins, 2 losses
        assertEquals(4, result.countedTrades)
        assertEquals(2, result.winCount)
        assertEquals(2, result.lossCount)
        assertEquals(50.0, result.winRatePercent, 0.01)

        // Net R: 2 - 1 + 3 - 1 = 3 R
        assertEquals(3.0, result.netR, 0.001)

        // Profit Factor: (2 + 3) / (1 + 1) = 5 / 2 = 2.5
        assertEquals(2.5, result.profitFactor, 0.01)

        // Groups: EURUSD (2 wins, +5R), GBPUSD (1 loss, -1R), XAUUSD (1 loss, -1R)
        assertEquals(3, result.groupStats.size)
        val eurStat = result.groupStats.find { it.name == "EURUSD" }
        assertNotNull(eurStat)
        assertEquals(2, eurStat!!.tradeCount)
        assertEquals(5.0, eurStat.netR, 0.001)
        assertEquals(100.0, eurStat.winRatePercent, 0.01)
    }

    @Test
    fun testRrCapBehavior() {
        val headers = listOf("نتیجه")
        // Row with 5R win, but cap is 2.0
        val rows = listOf(
            GridRow(id = 1L, cells = listOf("5")),
            GridRow(id = 2L, cells = listOf("-"))
        )

        val input = StatsInput(
            visibleRows = rows,
            headers = headers,
            plColumnIndex = 0,
            groupColumnIndex = null,
            rrCap = 2.0,
            initialBalance = 1000.0,
            riskPercent = 2.0
        )

        val result = StatsEngine.compute(input)

        // With 2R cap, 5R becomes 2R, minus 1R loss = 1R Net
        assertEquals(1.0, result.netR, 0.001)
        assertEquals(2.0, result.avgWinR, 0.001)
    }
}

package ir.mahdi.backtesttable

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.mahdi.backtesttable.data.db.AppDatabase
import ir.mahdi.backtesttable.data.settings.AppSettingsRepository
import ir.mahdi.backtesttable.data.settings.AppThemeMode
import ir.mahdi.backtesttable.ui.ai.AiViewModel
import ir.mahdi.backtesttable.ui.home.HomeScreen
import ir.mahdi.backtesttable.ui.home.HomeViewModel
import ir.mahdi.backtesttable.ui.settings.SettingsScreen
import ir.mahdi.backtesttable.ui.settings.SettingsViewModel
import ir.mahdi.backtesttable.ui.table.TableScreen
import ir.mahdi.backtesttable.ui.table.TableViewModel
import ir.mahdi.backtesttable.ui.theme.BacktestTableTheme

sealed class AppDestination {
    object Home : AppDestination()
    data class Table(val workbookId: Long) : AppDestination()
    object Settings : AppDestination()
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getInstance(applicationContext)
        val workbookDao = database.workbookDao()
        val settingsRepository = AppSettingsRepository(applicationContext)

        setContent {
            val settingsViewModel = remember { SettingsViewModel(settingsRepository) }
            val homeViewModel = remember { HomeViewModel(workbookDao) }

            val settings by settingsViewModel.settings.collectAsState()

            val isDark = when (settings.themeMode) {
                AppThemeMode.SYSTEM -> isSystemInDarkTheme()
                AppThemeMode.LIGHT -> false
                AppThemeMode.DARK -> true
            }

            // Force Persian RTL layout direction everywhere
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                BacktestTableTheme(darkTheme = isDark) {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        AppNavigation(
                            homeViewModel = homeViewModel,
                            settingsViewModel = settingsViewModel,
                            settingsRepository = settingsRepository,
                            database = database
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AppNavigation(
    homeViewModel: HomeViewModel,
    settingsViewModel: SettingsViewModel,
    settingsRepository: AppSettingsRepository,
    database: AppDatabase
) {
    val settings by settingsViewModel.settings.collectAsState()
    var currentDestination by remember { mutableStateOf<AppDestination>(AppDestination.Home) }

    // Intercept back button when not on Home
    BackHandler(enabled = currentDestination !is AppDestination.Home) {
        currentDestination = AppDestination.Home
    }

    when (val dest = currentDestination) {
        is AppDestination.Home -> {
            HomeScreen(
                homeViewModel = homeViewModel,
                onOpenWorkbook = { workbookId ->
                    currentDestination = AppDestination.Table(workbookId)
                },
                onNavigateToSettings = {
                    currentDestination = AppDestination.Settings
                }
            )
        }
        is AppDestination.Table -> {
            val tableViewModel = remember(dest.workbookId) {
                TableViewModel(dest.workbookId, database.workbookDao())
            }
            val aiViewModel = remember(dest.workbookId) {
                AiViewModel()
            }

            TableScreen(
                tableViewModel = tableViewModel,
                aiViewModel = aiViewModel,
                settings = settings,
                onNavigateBack = {
                    currentDestination = AppDestination.Home
                },
                onNavigateToSettings = {
                    currentDestination = AppDestination.Settings
                }
            )
        }
        is AppDestination.Settings -> {
            SettingsScreen(
                settingsViewModel = settingsViewModel,
                onNavigateBack = {
                    currentDestination = AppDestination.Home
                }
            )
        }
    }
}

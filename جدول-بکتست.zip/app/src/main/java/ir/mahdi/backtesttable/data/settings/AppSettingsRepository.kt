package ir.mahdi.backtesttable.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

enum class AppThemeMode {
    SYSTEM, LIGHT, DARK
}

enum class AiProviderType {
    GEMINI, OPENAI
}

data class AppSettings(
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val activeAiProvider: AiProviderType = AiProviderType.GEMINI,
    val geminiApiKey: String = "",
    val geminiModel: String = AppSettingsRepository.DEFAULT_GEMINI_MODEL,
    val openAiBaseUrl: String = AppSettingsRepository.DEFAULT_OPENAI_BASE_URL,
    val openAiModel: String = AppSettingsRepository.DEFAULT_OPENAI_MODEL,
    val openAiApiKey: String = ""
)

class AppSettingsRepository(private val context: Context) {

    companion object {
        const val DEFAULT_GEMINI_MODEL = "gemini-3.5-flash"
        const val DEFAULT_OPENAI_BASE_URL = "https://openrouter.ai/api/v1"
        const val DEFAULT_OPENAI_MODEL = "google/gemini-3.5-flash"

        private val KEY_THEME_MODE = stringPreferencesKey("theme_mode")
        private val KEY_AI_PROVIDER = stringPreferencesKey("ai_provider")
        private val KEY_GEMINI_API_KEY = stringPreferencesKey("gemini_api_key")
        private val KEY_GEMINI_MODEL = stringPreferencesKey("gemini_model")
        private val KEY_OPENAI_BASE_URL = stringPreferencesKey("openai_base_url")
        private val KEY_OPENAI_MODEL = stringPreferencesKey("openai_model")
        private val KEY_OPENAI_API_KEY = stringPreferencesKey("openai_api_key")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { preferences ->
        val themeModeStr = preferences[KEY_THEME_MODE] ?: AppThemeMode.SYSTEM.name
        val aiProviderStr = preferences[KEY_AI_PROVIDER] ?: AiProviderType.GEMINI.name

        AppSettings(
            themeMode = try { AppThemeMode.valueOf(themeModeStr) } catch (e: Exception) { AppThemeMode.SYSTEM },
            activeAiProvider = try { AiProviderType.valueOf(aiProviderStr) } catch (e: Exception) { AiProviderType.GEMINI },
            geminiApiKey = preferences[KEY_GEMINI_API_KEY] ?: "",
            geminiModel = preferences[KEY_GEMINI_MODEL] ?: DEFAULT_GEMINI_MODEL,
            openAiBaseUrl = preferences[KEY_OPENAI_BASE_URL] ?: DEFAULT_OPENAI_BASE_URL,
            openAiModel = preferences[KEY_OPENAI_MODEL] ?: DEFAULT_OPENAI_MODEL,
            openAiApiKey = preferences[KEY_OPENAI_API_KEY] ?: ""
        )
    }

    suspend fun updateTheme(mode: AppThemeMode) {
        context.dataStore.edit { it[KEY_THEME_MODE] = mode.name }
    }

    suspend fun updateAiProvider(provider: AiProviderType) {
        context.dataStore.edit { it[KEY_AI_PROVIDER] = provider.name }
    }

    suspend fun updateGeminiApiKey(key: String) {
        context.dataStore.edit { it[KEY_GEMINI_API_KEY] = key }
    }

    suspend fun updateGeminiModel(model: String) {
        context.dataStore.edit { it[KEY_GEMINI_MODEL] = model }
    }

    suspend fun updateOpenAiSettings(baseUrl: String, model: String, apiKey: String) {
        context.dataStore.edit {
            it[KEY_OPENAI_BASE_URL] = baseUrl
            it[KEY_OPENAI_MODEL] = model
            it[KEY_OPENAI_API_KEY] = apiKey
        }
    }

    suspend fun resetGeminiModelToDefault() {
        context.dataStore.edit { it[KEY_GEMINI_MODEL] = DEFAULT_GEMINI_MODEL }
    }
}

package ir.mahdi.backtesttable.ui.table

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import ir.mahdi.backtesttable.data.NumberUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TableSettingsDialog(
    headers: List<String>,
    currentPlIndex: Int?,
    currentGroupIndex: Int?,
    initialBalance: Double,
    riskPercent: Double,
    currentRrCap: Double?,
    onDismiss: () -> Unit,
    onSave: (plIndex: Int?, groupIndex: Int?, balance: Double, risk: Double, rrCap: Double?) -> Unit
) {
    var selectedPlIndex by remember { mutableStateOf(currentPlIndex) }
    var selectedGroupIndex by remember { mutableStateOf(currentGroupIndex) }

    var balanceText by remember { mutableStateOf(initialBalance.toString()) }
    var riskText by remember { mutableStateOf(riskPercent.toString()) }

    var isRrCapEnabled by remember { mutableStateOf(currentRrCap != null) }
    var rrCapText by remember { mutableStateOf(currentRrCap?.toString() ?: "2.0") }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    var plExpanded by remember { mutableStateOf(false) }
    var groupExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "تنظیمات جدول و مدیریت ریسک",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Error banner if validation failed
                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                // 1. Result Column Selector
                Text(
                    text = "ستون نتیجه معامله (R):",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )

                ExposedDropdownMenuBox(
                    expanded = plExpanded,
                    onExpandedChange = { plExpanded = !plExpanded }
                ) {
                    val plTitle = if (selectedPlIndex != null && selectedPlIndex!! in headers.indices) {
                        headers[selectedPlIndex!!]
                    } else {
                        "انتخاب نشده"
                    }

                    OutlinedTextField(
                        value = plTitle,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = plExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        textStyle = MaterialTheme.typography.bodyMedium
                    )

                    ExposedDropdownMenu(
                        expanded = plExpanded,
                        onDismissRequest = { plExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("هیچکدام (غیرفعال)") },
                            onClick = {
                                selectedPlIndex = null
                                plExpanded = false
                            }
                        )
                        headers.forEachIndexed { idx, title ->
                            DropdownMenuItem(
                                text = { Text(title) },
                                onClick = {
                                    selectedPlIndex = idx
                                    plExpanded = false
                                }
                            )
                        }
                    }
                }

                Text(
                    text = "در این ستون: «-» یا «-1» نشانگر حد ضرر، و اعداد مثبت نشانگر تارگت (مثلاً 1 یا 2) هستند.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Divider()

                // 2. Group Column Selector
                Text(
                    text = "ستون گروه‌بندی (تفکیک آمار):",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )

                ExposedDropdownMenuBox(
                    expanded = groupExpanded,
                    onExpandedChange = { groupExpanded = !groupExpanded }
                ) {
                    val grpTitle = if (selectedGroupIndex != null && selectedGroupIndex!! in headers.indices) {
                        headers[selectedGroupIndex!!]
                    } else {
                        "انتخاب خودکار هوشمند"
                    }

                    OutlinedTextField(
                        value = grpTitle,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = groupExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        textStyle = MaterialTheme.typography.bodyMedium
                    )

                    ExposedDropdownMenu(
                        expanded = groupExpanded,
                        onDismissRequest = { groupExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("انتخاب خودکار هوشمند") },
                            onClick = {
                                selectedGroupIndex = null
                                groupExpanded = false
                            }
                        )
                        headers.forEachIndexed { idx, title ->
                            DropdownMenuItem(
                                text = { Text(title) },
                                onClick = {
                                    selectedGroupIndex = idx
                                    groupExpanded = false
                                }
                            )
                        }
                    }
                }

                Divider()

                // 3. Money Management: Initial Balance & Risk %
                Text(
                    text = "مدیریت سرمایه (رشد مرکب):",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = balanceText,
                        onValueChange = { balanceText = it },
                        label = { Text("سرمایه اولیه ($)") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = riskText,
                        onValueChange = { riskText = it },
                        label = { Text("ریسک هر معامله (٪)") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true
                    )
                }

                Divider()

                // 4. R:R Cap (محدودیت R:R)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "محدودیت سقف سود (R:R Cap):",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "سود معاملات به این عدد محدود می‌شود (مثلاً تارگت ۲)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = isRrCapEnabled,
                        onCheckedChange = { isRrCapEnabled = it }
                    )
                }

                if (isRrCapEnabled) {
                    OutlinedTextField(
                        value = rrCapText,
                        onValueChange = { rrCapText = it },
                        label = { Text("حداکثر تارگت مجاز (مثلاً 2 یا 3)") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val bal = NumberUtils.parseDouble(balanceText)
                    if (bal == null || bal <= 0.0) {
                        errorMessage = "سرمایه اولیه باید عددی مثبت باشد"
                        return@Button
                    }
                    val risk = NumberUtils.parseDouble(riskText)
                    if (risk == null || risk <= 0.0 || risk > 100.0) {
                        errorMessage = "درصد ریسک باید بین ۰ تا ۱۰۰ باشد"
                        return@Button
                    }
                    val cap = if (isRrCapEnabled) {
                        val c = NumberUtils.parseDouble(rrCapText)
                        if (c == null || c <= 0.0) {
                            errorMessage = "مقدار سقف R:R نامعتبر است"
                            return@Button
                        }
                        c
                    } else null

                    onSave(selectedPlIndex, selectedGroupIndex, bal, risk, cap)
                    onDismiss()
                }
            ) {
                Text("ذخیره تنظیمات")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("انصراف")
            }
        }
    )
}

package ir.mahdi.backtesttable.ui.table

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ir.mahdi.backtesttable.R
import ir.mahdi.backtesttable.data.NumberUtils
import ir.mahdi.backtesttable.data.stats.GroupStat
import ir.mahdi.backtesttable.data.stats.StatsResult
import ir.mahdi.backtesttable.ui.components.CanvasDonutChart
import ir.mahdi.backtesttable.ui.components.CanvasEquityChart
import ir.mahdi.backtesttable.ui.components.CanvasGroupBars
import ir.mahdi.backtesttable.ui.theme.GreenDark
import ir.mahdi.backtesttable.ui.theme.GreenSuccess
import ir.mahdi.backtesttable.ui.theme.RedDark
import ir.mahdi.backtesttable.ui.theme.RedLoss

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StatsTab(
    statsResult: StatsResult,
    headers: List<String>,
    plColumnIndex: Int?,
    groupColumnIndex: Int?,
    rrCap: Double?,
    initialBalance: Double,
    riskPercent: Double,
    onOpenSettings: () -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Quick Config Bar Chips
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val plName = plColumnIndex?.let { headers.getOrNull(it) } ?: "تنظیم نشده"
            AssistChip(
                onClick = onOpenSettings,
                leadingIcon = { Icon(Icons.Default.Flag, contentDescription = null, modifier = Modifier.size(16.dp)) },
                label = { Text("ستون نتیجه: $plName") }
            )

            val grpName = statsResult.resolvedGroupColumnIndex?.let { headers.getOrNull(it) } ?: "هیچکدام"
            AssistChip(
                onClick = onOpenSettings,
                leadingIcon = { Icon(Icons.Default.Group, contentDescription = null, modifier = Modifier.size(16.dp)) },
                label = { Text("گروه‌بندی: $grpName") }
            )

            val rrText = if (rrCap != null) "${NumberUtils.formatNumber(rrCap)}R" else "خاموش"
            AssistChip(
                onClick = onOpenSettings,
                leadingIcon = { Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(16.dp)) },
                label = { Text("سقف R:R: $rrText") }
            )

            AssistChip(
                onClick = onOpenSettings,
                leadingIcon = { Icon(Icons.Default.AttachMoney, contentDescription = null, modifier = Modifier.size(16.dp)) },
                label = { Text("سرمایه: ${NumberUtils.formatInt(initialBalance.toLong())}$ | ریسک: ${NumberUtils.formatNumber(riskPercent)}٪") }
            )
        }

        // 2. Empty State if no counted trades
        if (statsResult.countedTrades == 0) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.empty_stats),
                        contentDescription = null,
                        modifier = Modifier
                            .size(140.dp)
                            .clip(RoundedCornerShape(12.dp))
                    )
                    Text(
                        text = "معامله‌ای با نتیجه معتبر ثبت نشده است",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "برای محاسبه آمار، ابتدا در تنظیمات ستون نتیجه را مشخص کنید و سپس در سطرها علامت «-» برای استاپ یا اعدادی مثل ۱ یا ۲ برای تارگت وارد نمایید.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Button(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تنظیم ستون نتیجه و سرمایه")
                    }
                }
            }
            return@Column
        }

        // 3. Trade Distribution Overview Card (Donut Chart & Counts)
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "توزیع معاملات",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    CanvasDonutChart(
                        winCount = statsResult.winCount,
                        lossCount = statsResult.lossCount,
                        noResultCount = statsResult.noResultCount,
                        invalidCount = statsResult.invalidResultCount,
                        winRate = statsResult.winRatePercent
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        StatRowItem(
                            label = "کل معاملات شمرده‌شده:",
                            value = NumberUtils.formatInt(statsResult.countedTrades),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        StatRowItem(
                            label = "معاملات سودده (تارگت):",
                            value = "${NumberUtils.formatInt(statsResult.winCount)} (${NumberUtils.formatPercent(statsResult.winRatePercent)})",
                            color = GreenDark
                        )
                        StatRowItem(
                            label = "معاملات ضررده (استاپ):",
                            value = "${NumberUtils.formatInt(statsResult.lossCount)} (${NumberUtils.formatPercent(statsResult.lossRatePercent)})",
                            color = RedDark
                        )
                        if (statsResult.noResultCount > 0) {
                            StatRowItem(
                                label = "ردیف‌های بدون نتیجه:",
                                value = NumberUtils.formatInt(statsResult.noResultCount),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (statsResult.invalidResultCount > 0) {
                            StatRowItem(
                                label = "ردیف‌های نامعتبر:",
                                value = NumberUtils.formatInt(statsResult.invalidResultCount),
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                    }
                }
            }
        }

        // 4. Target R-Multiple Performance Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "عملکرد استراتژی بر اساس تارگت (R)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                val isNetPositive = statsResult.netR >= 0
                val netColor = if (isNetPositive) GreenDark else RedDark

                // Hero Metric: Net R
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (isNetPositive) GreenSuccess.copy(alpha = 0.1f) else RedLoss.copy(alpha = 0.1f),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "خالص تارگت محقق‌شده (Net R):",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "${NumberUtils.formatNumber(statsResult.netR, showPlusSign = true)} R",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = netColor
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Grid of R metrics
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth()) {
                        MetricBox(
                            label = "فاکتور سودآوری (PF)",
                            value = if (statsResult.profitFactor.isInfinite()) "∞" else NumberUtils.formatNumber(statsResult.profitFactor),
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        MetricBox(
                            label = "امید ریاضی (Expectancy)",
                            value = "${NumberUtils.formatNumber(statsResult.expectancyR, showPlusSign = true)} R",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth()) {
                        MetricBox(
                            label = "میانگین سود تارگت",
                            value = "+${NumberUtils.formatNumber(statsResult.avgWinR)} R",
                            valueColor = GreenDark,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        MetricBox(
                            label = "میانگین ضرر استاپ",
                            value = "-${NumberUtils.formatNumber(statsResult.avgLossR)} R",
                            valueColor = RedDark,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth()) {
                        MetricBox(
                            label = "نسبت پاداش به ریسک",
                            value = "${NumberUtils.formatNumber(statsResult.rewardToRiskRatio)} : ۱",
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        MetricBox(
                            label = "حداکثر افت (Drawdown)",
                            value = "${NumberUtils.formatNumber(statsResult.maxDrawdownR)} R (${NumberUtils.formatPercent(statsResult.maxDrawdownRPercent)})",
                            valueColor = RedDark,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth()) {
                        MetricBox(
                            label = "بیشترین برد پیاپی",
                            value = "${NumberUtils.formatInt(statsResult.maxConsecutiveWins)} معامله",
                            valueColor = GreenDark,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        MetricBox(
                            label = "بیشترین باخت پیاپی",
                            value = "${NumberUtils.formatInt(statsResult.maxConsecutiveLosses)} معامله",
                            valueColor = RedDark,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "منحنی رشد تارگتی (Cumulative R):",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Canvas R Equity Curve
                CanvasEquityChart(
                    points = statsResult.rEquityPoints,
                    referenceValue = 0.0,
                    unitLabel = "R"
                )
            }
        }

        // 5. Compounding Dollar Growth Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "شبیه‌سازی رشد سرمایه مرکب (دلار)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                val isProfit = statsResult.netDollarProfit >= 0
                val dollarColor = if (isProfit) GreenDark else RedDark

                // Hero Dollar Metric
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (isProfit) GreenSuccess.copy(alpha = 0.1f) else RedLoss.copy(alpha = 0.1f),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "موجودی نهایی:",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "${NumberUtils.formatNumber(statsResult.finalBalance)} $",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = dollarColor
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "سود و بازده:",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "${NumberUtils.formatNumber(statsResult.netDollarProfit, showPlusSign = true)} $ (${NumberUtils.formatPercent(statsResult.totalReturnPercent)})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = dollarColor
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    MetricBox(
                        label = "سرمایه اولیه",
                        value = "${NumberUtils.formatInt(statsResult.initialBalance.toLong())} $",
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    MetricBox(
                        label = "حداکثر افت موجودی",
                        value = "${NumberUtils.formatNumber(statsResult.maxDollarDrawdown)} $ (${NumberUtils.formatPercent(statsResult.maxDollarDrawdownPercent)})",
                        valueColor = RedDark,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    MetricBox(
                        label = "میانگین سود دلاری",
                        value = "+${NumberUtils.formatNumber(statsResult.avgDollarWin)} $",
                        valueColor = GreenDark,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    MetricBox(
                        label = "میانگین ضرر دلاری",
                        value = "-${NumberUtils.formatNumber(statsResult.avgDollarLoss)} $",
                        valueColor = RedDark,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "منحنی رشد سرمایه دلاری:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Canvas Dollar Equity Curve
                CanvasEquityChart(
                    points = statsResult.dollarEquityPoints,
                    referenceValue = statsResult.initialBalance,
                    unitLabel = "$"
                )
            }
        }

        // 6. Group Breakdown Card
        if (statsResult.groupStats.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    val groupColName = statsResult.resolvedGroupColumnIndex?.let { headers.getOrNull(it) } ?: "گروه"
                    Text(
                        text = "تفکیک عملکرد بر اساس ستون «$groupColName»",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    CanvasGroupBars(groups = statsResult.groupStats)

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(12.dp))

                    // Group Details
                    statsResult.groupStats.forEach { g ->
                        GroupDetailRow(stat = g)
                        Divider(modifier = Modifier.padding(vertical = 6.dp))
                    }
                }
            }
        } else {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "ستون مناسبی برای گروه‌بندی پیدا نشد؛ یکی را از فهرست انتخاب کنید",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun StatRowItem(
    label: String,
    value: String,
    color: Color
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}

@Composable
private fun MetricBox(
    label: String,
    value: String,
    valueColor: Color = MaterialTheme.colorScheme.onSurface,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Column {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = valueColor
            )
        }
    }
}

@Composable
private fun GroupDetailRow(stat: GroupStat) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stat.name,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "${NumberUtils.formatInt(stat.tradeCount)} معامله (${NumberUtils.formatInt(stat.winCount)} برد / ${NumberUtils.formatInt(stat.lossCount)} باخت)",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Column(horizontalAlignment = Alignment.End) {
            val isPos = stat.netR >= 0
            val color = if (isPos) GreenDark else RedDark
            Text(
                text = "${NumberUtils.formatNumber(stat.netR, showPlusSign = true)} R",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Text(
                text = "نرخ برد: ${NumberUtils.formatPercent(stat.winRatePercent)} | ${NumberUtils.formatNumber(stat.netDollar, showPlusSign = true)} $",
                style = MaterialTheme.typography.labelSmall,
                color = color
            )
        }
    }
}

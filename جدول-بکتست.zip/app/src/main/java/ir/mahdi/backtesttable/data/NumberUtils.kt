package ir.mahdi.backtesttable.data

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.abs

object NumberUtils {

    /**
     * Shared number parser: parses double after normalizing Persian/Arabic digits,
     * thousands separators (',' and '٬'), decimal separators ('.' and '٫'), and minus signs.
     */
    fun parseDouble(raw: String?): Double? {
        if (raw.isNullOrBlank()) return null
        val normalized = normalizeDigitsAndSeparators(raw)
        return normalized.toDoubleOrNull()
    }

    fun isNumeric(raw: String?): Boolean = parseDouble(raw) != null

    fun normalizeDigitsAndSeparators(input: String): String {
        val sb = StringBuilder()
        val trimmed = input.trim()
        for (ch in trimmed) {
            when (ch) {
                // Persian digits ۰-۹
                in '\u06F0'..'\u06F9' -> sb.append((ch - '\u06F0' + '0'.code).toChar())
                // Arabic-Indic digits ٠-٩
                in '\u0660'..'\u0669' -> sb.append((ch - '\u0660' + '0'.code).toChar())
                // Thousands separators: remove
                ',', '\u066C' -> { /* omit */ }
                // Decimal separators
                '.', '\u066B' -> sb.append('.')
                // Minus signs
                '-', '\u2212', '\u2010', '\u2013' -> sb.append('-')
                // Keep ASCII digits and plus
                in '0'..'9', '+' -> sb.append(ch)
                // Ignore spaces or other non-numerics if inside
                else -> sb.append(ch)
            }
        }
        return sb.toString().trim()
    }

    /**
     * Normalizes text for search and filter matching:
     * - Case-insensitive
     * - Digits normalized (Persian/Arabic -> Latin)
     * - 'ي' -> 'ی'
     * - 'ك' -> 'ک'
     * - ZWNJ replaced with space
     */
    fun normalizeText(text: String?): String {
        if (text == null) return ""
        val sb = StringBuilder()
        for (ch in text.lowercase(Locale.ROOT)) {
            when (ch) {
                in '\u06F0'..'\u06F9' -> sb.append((ch - '\u06F0' + '0'.code).toChar())
                in '\u0660'..'\u0669' -> sb.append((ch - '\u0660' + '0'.code).toChar())
                'ي' -> sb.append('ی')
                'ك' -> sb.append('ک')
                '\u200C' -> sb.append(' ')
                else -> sb.append(ch)
            }
        }
        return sb.toString().trim()
    }

    /**
     * Formats numbers for Persian display:
     * Digits 0-9 converted to ۰-۹, standard thousands separator, max decimals.
     */
    fun toPersianDigits(text: String): String {
        val sb = StringBuilder()
        for (ch in text) {
            when (ch) {
                in '0'..'9' -> sb.append((ch - '0' + '\u06F0'.code).toChar())
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun formatNumber(
        value: Double,
        maxDecimals: Int = 2,
        showPlusSign: Boolean = false,
        isInfiniteSymbol: Boolean = false
    ): String {
        if (value.isInfinite()) {
            return "∞"
        }
        if (value.isNaN()) {
            return "—"
        }

        val isNegative = value < -1e-9
        val absValue = abs(value)

        val pattern = if (maxDecimals == 0) {
            "#,##0"
        } else {
            val zeros = "#".repeat(maxDecimals)
            "#,##0.$zeros"
        }

        val symbols = DecimalFormatSymbols(Locale.US).apply {
            groupingSeparator = ','
            decimalSeparator = '.'
        }
        val df = DecimalFormat(pattern, symbols)
        val formatted = df.format(absValue)
        val persianFormatted = toPersianDigits(formatted)

        return when {
            isNegative -> "-$persianFormatted"
            showPlusSign && value > 1e-9 -> "+$persianFormatted"
            else -> persianFormatted
        }
    }

    fun formatInt(value: Long): String {
        val symbols = DecimalFormatSymbols(Locale.US).apply {
            groupingSeparator = ','
        }
        val df = DecimalFormat("#,##0", symbols)
        return toPersianDigits(df.format(value))
    }

    fun formatInt(value: Int): String = formatInt(value.toLong())

    fun formatPercent(value: Double, maxDecimals: Int = 1): String {
        if (value.isNaN() || value.isInfinite()) return "—"
        return "${formatNumber(value, maxDecimals)}٪"
    }
}

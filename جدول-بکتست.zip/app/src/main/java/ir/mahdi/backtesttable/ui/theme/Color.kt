package ir.mahdi.backtesttable.ui.theme

import androidx.compose.ui.graphics.Color

val Navy900 = Color(0xFF0F172A)
val Navy800 = Color(0xFF1E293B)
val Navy700 = Color(0xFF334155)
val Blue800 = Color(0xFF1E3A8A)
val Blue600 = Color(0xFF2563EB)
val Blue500 = Color(0xFF3B82F6)
val Blue400 = Color(0xFF60A5FA)

val GreenSuccess = Color(0xFF22C55E)
val GreenDark = Color(0xFF16A34A)
val RedLoss = Color(0xFFEF4444)
val RedDark = Color(0xFFDC2626)

val Slate50 = Color(0xFFF8FAFC)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate300 = Color(0xFFCBD5E1)
val Slate400 = Color(0xFF94A3B8)
val Slate500 = Color(0xFF64748B)
val Slate600 = Color(0xFF475569)
val Slate700 = Color(0xFF334155)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)

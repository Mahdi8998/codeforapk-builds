package ir.mahdi.backtesttable.ui.table

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.outlined.FilterAlt
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.mahdi.backtesttable.data.NumberUtils
import ir.mahdi.backtesttable.data.model.FilterState
import ir.mahdi.backtesttable.data.model.GridData
import ir.mahdi.backtesttable.data.model.GridRow
import ir.mahdi.backtesttable.ui.theme.GreenDark
import ir.mahdi.backtesttable.ui.theme.GreenSuccess
import ir.mahdi.backtesttable.ui.theme.RedDark
import ir.mahdi.backtesttable.ui.theme.RedLoss

private val CELL_WIDTH = 120.dp
private val CELL_HEIGHT = 48.dp
private val GUTTER_WIDTH = 50.dp

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun GridTab(
    gridData: GridData,
    visibleRows: List<GridRow>,
    filterState: FilterState,
    plColumnIndex: Int?,
    groupColumnIndex: Int?,
    onUpdateCell: (rowId: Long, colIndex: Int, value: String) -> Unit,
    onAddRow: () -> Unit,
    onInsertRowAbove: (Long) -> Unit,
    onInsertRowBelow: (Long) -> Unit,
    onDuplicateRow: (Long) -> Unit,
    onDeleteRow: (Long) -> Unit,
    onRenameColumn: (Int, String) -> Unit,
    onInsertColumnLeft: (Int) -> Unit,
    onInsertColumnRight: (Int) -> Unit,
    onDeleteColumn: (Int) -> Unit,
    onMoveColumn: (Int, Int) -> Unit,
    onTogglePlColumn: (Int) -> Unit,
    onToggleGroupColumn: (Int) -> Unit,
    onOpenFilterSheet: (Int) -> Unit,
    onClearAllFilters: () -> Unit
) {
    var editingCell by remember {
        mutableStateOf<Triple<Long, Int, String>?>(null) // rowId, colIndex, currentValue
    }
    var rowActionTarget by remember {
        mutableStateOf<Pair<Int, Long>?>(null) // rowNumber, rowId
    }
    var columnActionTarget by remember {
        mutableStateOf<Int?>(null) // colIndex
    }

    val horizontalScrollState = rememberScrollState()

    val totalRowCount = gridData.rows.size
    val visibleRowCount = visibleRows.size
    val isFiltered = visibleRowCount < totalRowCount || filterState.columnFilters.isNotEmpty()

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Filter indicator banner if active
            if (isFiltered) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "فیلتر فعال است: نمایش ${NumberUtils.formatInt(visibleRowCount)} از ${NumberUtils.formatInt(totalRowCount)} ردیف",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        IconButton(
                            onClick = onClearAllFilters,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                Icons.Default.Clear,
                                contentDescription = "حذف همه فیلترها",
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // The SpreadSheet Grid (Two-way scroll)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                Row(modifier = Modifier.fillMaxSize()) {
                    // Left sticky Gutter: Row numbers
                    Column(
                        modifier = Modifier
                            .width(GUTTER_WIDTH)
                            .fillMaxHeight()
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(width = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        // Top-left corner cell
                        Box(
                            modifier = Modifier
                                .width(GUTTER_WIDTH)
                                .height(CELL_HEIGHT)
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .border(width = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "#",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Gutter row numbers list synced with LazyColumn
                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            itemsIndexed(visibleRows, key = { _, row -> row.id }) { index, row ->
                                val rowNum = index + 1
                                Box(
                                    modifier = Modifier
                                        .width(GUTTER_WIDTH)
                                        .height(CELL_HEIGHT)
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .border(width = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
                                        .clickable {
                                            rowActionTarget = Pair(rowNum, row.id)
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = NumberUtils.toPersianDigits(rowNum.toString()),
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    // Main cells area with Horizontal scroll
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .horizontalScroll(horizontalScrollState)
                    ) {
                        Column(modifier = Modifier.width(CELL_WIDTH * gridData.headers.size)) {
                            // Sticky Column Headers
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(CELL_HEIGHT)
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                gridData.headers.forEachIndexed { colIdx, title ->
                                    val isPl = colIdx == plColumnIndex
                                    val isGroup = colIdx == groupColumnIndex
                                    val hasFilter = filterState.columnFilters.containsKey(colIdx)

                                    Box(
                                        modifier = Modifier
                                            .width(CELL_WIDTH)
                                            .height(CELL_HEIGHT)
                                            .border(width = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
                                            .background(
                                                when {
                                                    isPl -> MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                                    isGroup -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.12f)
                                                    else -> MaterialTheme.colorScheme.surfaceVariant
                                                }
                                            )
                                            .padding(horizontal = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxSize(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            // Filter icon button
                                            IconButton(
                                                onClick = { onOpenFilterSheet(colIdx) },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                if (hasFilter) {
                                                    Icon(
                                                        Icons.Filled.FilterAlt,
                                                        contentDescription = "فیلتر شده",
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                } else {
                                                    Icon(
                                                        Icons.Outlined.FilterAlt,
                                                        contentDescription = "فیلتر",
                                                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                            }

                                            // Column title
                                            Text(
                                                text = title,
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = when {
                                                    isPl -> MaterialTheme.colorScheme.primary
                                                    isGroup -> MaterialTheme.colorScheme.secondary
                                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                                },
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f),
                                                textAlign = TextAlign.Center
                                            )

                                            // Column action menu icon
                                            IconButton(
                                                onClick = { columnActionTarget = colIdx },
                                                modifier = Modifier.size(22.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.MoreVert,
                                                    contentDescription = "تنظیمات ستون",
                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // Data Rows
                            LazyColumn(modifier = Modifier.fillMaxSize()) {
                                itemsIndexed(visibleRows, key = { _, row -> row.id }) { _, row ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(CELL_HEIGHT)
                                    ) {
                                        gridData.headers.indices.forEach { colIdx ->
                                            val cellVal = row.cells.getOrNull(colIdx) ?: ""
                                            val isPl = colIdx == plColumnIndex

                                            // Cell text color coding for result column
                                            val isLoss = isPl && (cellVal == "-" || cellVal == "−" || cellVal == "-1")
                                            val isWin = isPl && (NumberUtils.parseDouble(cellVal) ?: 0.0) > 0

                                            val cellBg = when {
                                                isLoss -> RedLoss.copy(alpha = 0.12f)
                                                isWin -> GreenSuccess.copy(alpha = 0.12f)
                                                else -> MaterialTheme.colorScheme.surface
                                            }

                                            val cellTextColor = when {
                                                isLoss -> RedDark
                                                isWin -> GreenDark
                                                else -> MaterialTheme.colorScheme.onSurface
                                            }

                                            Box(
                                                modifier = Modifier
                                                    .width(CELL_WIDTH)
                                                    .height(CELL_HEIGHT)
                                                    .border(width = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
                                                    .background(cellBg)
                                                    .clickable {
                                                        editingCell = Triple(row.id, colIdx, cellVal)
                                                    }
                                                    .padding(horizontal = 8.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = cellVal,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = if (isPl && (isWin || isLoss)) FontWeight.Bold else FontWeight.Normal,
                                                    color = cellTextColor,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    textAlign = TextAlign.Center
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Floating Action Button to add row
        FloatingActionButton(
            onClick = onAddRow,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ) {
            Icon(Icons.Default.Add, contentDescription = "افزودن ردیف جدید")
        }
    }

    // Cell Editor Dialog
    editingCell?.let { (rowId, colIdx, currentVal) ->
        val rowIdx = visibleRows.indexOfFirst { it.id == rowId }
        val rowNum = if (rowIdx >= 0) rowIdx + 1 else 1
        val colTitle = gridData.headers.getOrNull(colIdx) ?: ""
        val isPl = colIdx == plColumnIndex

        CellEditorDialog(
            rowNumber = rowNum,
            columnTitle = colTitle,
            initialValue = currentVal,
            isPlColumn = isPl,
            onDismiss = { editingCell = null },
            onConfirm = { newVal ->
                onUpdateCell(rowId, colIdx, newVal)
            }
        )
    }

    // Row Action Dialog
    rowActionTarget?.let { (rowNum, rowId) ->
        RowActionDialog(
            rowNumber = rowNum,
            onDismiss = { rowActionTarget = null },
            onInsertAbove = { onInsertRowAbove(rowId) },
            onInsertBelow = { onInsertRowBelow(rowId) },
            onDuplicate = { onDuplicateRow(rowId) },
            onDelete = { onDeleteRow(rowId) }
        )
    }

    // Column Action Dialog
    columnActionTarget?.let { colIdx ->
        val colTitle = gridData.headers.getOrNull(colIdx) ?: ""
        val isPl = colIdx == plColumnIndex
        val isGrp = colIdx == groupColumnIndex

        ColumnActionDialog(
            columnIndex = colIdx,
            currentTitle = colTitle,
            isPlColumn = isPl,
            isGroupColumn = isGrp,
            canDelete = gridData.headers.size > 1,
            canMoveLeft = colIdx > 0,
            canMoveRight = colIdx < gridData.headers.size - 1,
            onDismiss = { columnActionTarget = null },
            onRename = { newName -> onRenameColumn(colIdx, newName) },
            onInsertLeft = { onInsertColumnLeft(colIdx) },
            onInsertRight = { onInsertColumnRight(colIdx) },
            onMoveLeft = { onMoveColumn(colIdx, colIdx - 1) },
            onMoveRight = { onMoveColumn(colIdx, colIdx + 1) },
            onDelete = { onDeleteColumn(colIdx) },
            onTogglePlColumn = { onTogglePlColumn(colIdx) },
            onToggleGroupColumn = { onToggleGroupColumn(colIdx) }
        )
    }
}

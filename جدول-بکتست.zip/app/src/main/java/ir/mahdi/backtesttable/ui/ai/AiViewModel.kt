package ir.mahdi.backtesttable.ui.ai

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.mahdi.backtesttable.data.ai.AiChatMessage
import ir.mahdi.backtesttable.data.ai.AiClient
import ir.mahdi.backtesttable.data.ai.AiDataMode
import ir.mahdi.backtesttable.data.ai.AiErrorMapper
import ir.mahdi.backtesttable.data.ai.AiPayloadBuilder
import ir.mahdi.backtesttable.data.ai.GeminiClient
import ir.mahdi.backtesttable.data.ai.OpenAiClient
import ir.mahdi.backtesttable.data.ai.ScopeInfo
import ir.mahdi.backtesttable.data.model.FilterState
import ir.mahdi.backtesttable.data.model.GridRow
import ir.mahdi.backtesttable.data.settings.AiProviderType
import ir.mahdi.backtesttable.data.settings.AppSettings
import ir.mahdi.backtesttable.data.stats.StatsResult
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ChatUiMessage(
    val id: Long = System.currentTimeMillis(),
    val role: String, // "user" or "model"
    val content: String,
    val isStreaming: Boolean = false,
    val isError: Boolean = false
)

class AiViewModel : ViewModel() {

    private val _messages = MutableStateFlow<List<ChatUiMessage>>(emptyList())
    val messages: StateFlow<List<ChatUiMessage>> = _messages.asStateFlow()

    private val _dataMode = MutableStateFlow(AiDataMode.FULL)
    val dataMode: StateFlow<AiDataMode> = _dataMode.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _showOver500RowsDialog = MutableStateFlow(false)
    val showOver500RowsDialog: StateFlow<Boolean> = _showOver500RowsDialog.asStateFlow()

    private var pendingQuery: String? = null
    private var streamJob: Job? = null

    fun setDataMode(mode: AiDataMode) {
        _dataMode.value = mode
    }

    fun clearChat() {
        streamJob?.cancel()
        _isLoading.value = false
        _messages.value = emptyList()
    }

    fun sendPresetQuery(
        queryType: PresetQueryType,
        settings: AppSettings,
        headers: List<String>,
        visibleRows: List<GridRow>,
        totalRowCount: Int,
        filterState: FilterState,
        searchQuery: String,
        plColumnIndex: Int?,
        groupColumnIndex: Int?,
        initialBalance: Double,
        riskPercent: Double,
        rrCap: Double?,
        statsResult: StatsResult
    ) {
        val queryText = when (queryType) {
            PresetQueryType.OVERALL_STRATEGY -> "یک تحلیل جامع از عملکرد کلی استراتژی بر اساس داده‌های موجود ارائه بده، نقاط قوت و ضعف را مشخص کن."
            PresetQueryType.LOSS_ANALYSIS -> "معاملات ضررده را بررسی کن و الگوهای تکرارشونده یا عوامل زمینه‌ساز باخت‌ها را شناسایی کن."
            PresetQueryType.RISK_MANAGEMENT -> "میزان افت سرمایه، نسبت ریسک به ریوارد و پایداری مدیریت سرمایه را تحلیل کن و پیشنهاد بهینه‌سازی بده."
            PresetQueryType.IMPROVEMENT_SUGGESTIONS -> "راهکارهای عملی برای افزایش نرخ برد، فیلتر کردن معاملات کم‌کیفیت و ارتقای فاکتور سودآوری ارائه کن."
        }
        sendMessage(
            userQuery = queryText,
            settings = settings,
            headers = headers,
            visibleRows = visibleRows,
            totalRowCount = totalRowCount,
            filterState = filterState,
            searchQuery = searchQuery,
            plColumnIndex = plColumnIndex,
            groupColumnIndex = groupColumnIndex,
            initialBalance = initialBalance,
            riskPercent = riskPercent,
            rrCap = rrCap,
            statsResult = statsResult
        )
    }

    fun sendMessage(
        userQuery: String,
        settings: AppSettings,
        headers: List<String>,
        visibleRows: List<GridRow>,
        totalRowCount: Int,
        filterState: FilterState,
        searchQuery: String,
        plColumnIndex: Int?,
        groupColumnIndex: Int?,
        initialBalance: Double,
        riskPercent: Double,
        rrCap: Double?,
        statsResult: StatsResult
    ) {
        val cleanQuery = userQuery.trim()
        if (cleanQuery.isBlank() || _isLoading.value) return

        if (visibleRows.isEmpty()) {
            val errMsg = ChatUiMessage(
                role = "model",
                content = "هیچ ردیفی برای تحلیل وجود ندارد؛ فیلترها را بردارید.",
                isError = true
            )
            _messages.value = _messages.value + errMsg
            return
        }

        // Check 500 rows cap for FULL mode
        if (_dataMode.value == AiDataMode.FULL && visibleRows.size > 500) {
            pendingQuery = cleanQuery
            _showOver500RowsDialog.value = true
            return
        }

        executeSend(
            userQuery = cleanQuery,
            settings = settings,
            headers = headers,
            visibleRows = visibleRows,
            totalRowCount = totalRowCount,
            filterState = filterState,
            searchQuery = searchQuery,
            plColumnIndex = plColumnIndex,
            groupColumnIndex = groupColumnIndex,
            initialBalance = initialBalance,
            riskPercent = riskPercent,
            rrCap = rrCap,
            statsResult = statsResult
        )
    }

    fun proceedWithSummaryMode(
        settings: AppSettings,
        headers: List<String>,
        visibleRows: List<GridRow>,
        totalRowCount: Int,
        filterState: FilterState,
        searchQuery: String,
        plColumnIndex: Int?,
        groupColumnIndex: Int?,
        initialBalance: Double,
        riskPercent: Double,
        rrCap: Double?,
        statsResult: StatsResult
    ) {
        _showOver500RowsDialog.value = false
        _dataMode.value = AiDataMode.SUMMARY
        val query = pendingQuery ?: return
        pendingQuery = null
        executeSend(
            userQuery = query,
            settings = settings,
            headers = headers,
            visibleRows = visibleRows,
            totalRowCount = totalRowCount,
            filterState = filterState,
            searchQuery = searchQuery,
            plColumnIndex = plColumnIndex,
            groupColumnIndex = groupColumnIndex,
            initialBalance = initialBalance,
            riskPercent = riskPercent,
            rrCap = rrCap,
            statsResult = statsResult
        )
    }

    fun dismissOver500Dialog() {
        _showOver500RowsDialog.value = false
        pendingQuery = null
    }

    private fun executeSend(
        userQuery: String,
        settings: AppSettings,
        headers: List<String>,
        visibleRows: List<GridRow>,
        totalRowCount: Int,
        filterState: FilterState,
        searchQuery: String,
        plColumnIndex: Int?,
        groupColumnIndex: Int?,
        initialBalance: Double,
        riskPercent: Double,
        rrCap: Double?,
        statsResult: StatsResult
    ) {
        val client: AiClient = when (settings.activeAiProvider) {
            AiProviderType.GEMINI -> {
                if (settings.geminiApiKey.isBlank()) {
                    val errMsg = ChatUiMessage(
                        role = "model",
                        content = "کلید API گوگل Gemini وارد نشده است؛ لطفاً در بخش تنظیمات کلید خود را وارد کنید.",
                        isError = true
                    )
                    _messages.value = _messages.value + errMsg
                    return
                }
                GeminiClient(settings.geminiApiKey, settings.geminiModel)
            }
            AiProviderType.OPENAI -> {
                if (settings.openAiApiKey.isBlank()) {
                    val errMsg = ChatUiMessage(
                        role = "model",
                        content = "کلید API وارد نشده است؛ لطفاً در بخش تنظیمات کلید خود را وارد کنید.",
                        isError = true
                    )
                    _messages.value = _messages.value + errMsg
                    return
                }
                OpenAiClient(settings.openAiBaseUrl, settings.openAiModel, settings.openAiApiKey)
            }
        }

        // Add user message to UI
        val userMsg = ChatUiMessage(role = "user", content = userQuery)
        val assistantMsgId = System.currentTimeMillis() + 1
        val assistantPlaceholder = ChatUiMessage(
            id = assistantMsgId,
            role = "model",
            content = "",
            isStreaming = true
        )

        _messages.value = _messages.value + userMsg + assistantPlaceholder
        _isLoading.value = true

        streamJob = viewModelScope.launch {
            // Build scope info
            val isFiltered = visibleRows.size < totalRowCount || filterState.columnFilters.isNotEmpty() || searchQuery.isNotBlank()
            val filtersDesc = filterState.columnFilters.entries.joinToString("; ") { (cIdx, cf) ->
                val colName = headers.getOrNull(cIdx) ?: "Col$cIdx"
                "$colName in [${cf.selectedValues.joinToString(", ")}]"
            }
            val scopeInfo = ScopeInfo(
                isFiltered = isFiltered,
                visibleCount = visibleRows.size,
                totalCount = totalRowCount,
                activeFiltersDescription = filtersDesc,
                searchQuery = searchQuery
            )

            val payload = AiPayloadBuilder.buildPayload(
                mode = _dataMode.value,
                headers = headers,
                visibleRows = visibleRows,
                scopeInfo = scopeInfo,
                plColumnIndex = plColumnIndex,
                groupColumnIndex = groupColumnIndex,
                initialBalance = initialBalance,
                riskPercent = riskPercent,
                rrCap = rrCap,
                statsResult = statsResult,
                userQuery = userQuery
            )

            // Prepare history for client
            val apiMessages = mutableListOf<AiChatMessage>()
            // We pass the full built payload as the primary prompt
            apiMessages.add(AiChatMessage(role = "user", content = payload))

            var accumulatedText = ""

            val result = client.streamChat(
                messages = apiMessages,
                systemInstruction = AiPayloadBuilder.SYSTEM_PROMPT,
                onToken = { token ->
                    accumulatedText += token
                    _messages.value = _messages.value.map { msg ->
                        if (msg.id == assistantMsgId) {
                            msg.copy(content = accumulatedText)
                        } else msg
                    }
                }
            )

            _isLoading.value = false

            result.fold(
                onSuccess = { fullText ->
                    _messages.value = _messages.value.map { msg ->
                        if (msg.id == assistantMsgId) {
                            msg.copy(
                                content = if (accumulatedText.isNotBlank()) accumulatedText else fullText,
                                isStreaming = false
                            )
                        } else msg
                    }
                },
                onFailure = { error ->
                    val persianError = AiErrorMapper.mapException(error)
                    _messages.value = _messages.value.map { msg ->
                        if (msg.id == assistantMsgId) {
                            msg.copy(
                                content = if (accumulatedText.isNotBlank()) {
                                    "$accumulatedText\n\n[خطا در ادامه دریافت: $persianError]"
                                } else {
                                    persianError
                                },
                                isStreaming = false,
                                isError = true
                            )
                        } else msg
                    }
                }
            )
        }
    }
}

enum class PresetQueryType {
    OVERALL_STRATEGY,
    LOSS_ANALYSIS,
    RISK_MANAGEMENT,
    IMPROVEMENT_SUGGESTIONS
}

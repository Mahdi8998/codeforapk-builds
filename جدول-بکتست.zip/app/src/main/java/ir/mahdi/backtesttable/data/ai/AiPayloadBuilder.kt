package ir.mahdi.backtesttable.data.ai

import ir.mahdi.backtesttable.data.model.GridRow
import ir.mahdi.backtesttable.data.stats.StatsResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

enum class AiDataMode {
    FULL, SUMMARY
}

data class ScopeInfo(
    val isFiltered: Boolean,
    val visibleCount: Int,
    val totalCount: Int,
    val activeFiltersDescription: String,
    val searchQuery: String
)

object AiPayloadBuilder {

    const val SYSTEM_PROMPT = """You are a professional forex backtest analyst. Each row in the provided data represents one trade. Results are recorded in R-multiples (risk units).
Treat empty or invalid-result rows as open or unresolved trades, never as losses.
Use Persian terminology naturally: «تارگت», «استاپ», «موجودی», «ریسک», «مبنا», «R:R».
Dollar figures follow the compounding percentage money management model. When an R:R cap is active, interpret results accordingly and optionally note how uncapped performance would compare.
If FILTER CONTEXT indicates a filtered subset, analyze that specific slice and briefly note that your conclusions apply specifically to this filtered dataset.
Analyze critically, cite real numbers from the data, use structured headings and clear bullet points, give concrete actionable suggestions to improve the strategy, clearly state when the sample size is too small, and never invent or hallucinate data.
Always respond exclusively in fluent Persian.
End your response with this exact one-line disclaimer:
این تحلیل صرفاً جنبه آموزشی و محاسباتی داشته و توصیه مالی محسوب نمی‌شود."""

    suspend fun buildPayload(
        mode: AiDataMode,
        headers: List<String>,
        visibleRows: List<GridRow>,
        scopeInfo: ScopeInfo,
        plColumnIndex: Int?,
        groupColumnIndex: Int?,
        initialBalance: Double,
        riskPercent: Double,
        rrCap: Double?,
        statsResult: StatsResult,
        userQuery: String
    ): String = withContext(Dispatchers.Default) {
        val sb = StringBuilder()

        // 1. Scope Header
        if (scopeInfo.isFiltered) {
            val filtersDesc = scopeInfo.activeFiltersDescription.ifBlank { "none" }
            val searchDesc = if (scopeInfo.searchQuery.isNotBlank()) "\"${scopeInfo.searchQuery}\"" else "none"
            sb.appendLine("FILTER CONTEXT: the rows below are a FILTERED SUBSET (${scopeInfo.visibleCount} of ${scopeInfo.totalCount} total rows). Active filters: $filtersDesc; search: $searchDesc. The user is intentionally analyzing this subset.")
        } else {
            sb.appendLine("FILTER CONTEXT: the rows below are the FULL TABLE (${scopeInfo.totalCount} rows); no filters applied.")
        }

        // 2. Semantics Headers
        val plColName = plColumnIndex?.let { headers.getOrNull(it) } ?: "Result"
        sb.appendLine("RESULT COLUMN \"$plColName\": \"-\" or \"-1\" = stop-loss hit (−1R); positive number N = target N hit (+N R); empty = trade has no result yet (excluded); any other value = invalid (excluded).")
        sb.appendLine("MONEY MANAGEMENT: initial balance $initialBalance USD; risk per trade $riskPercent% of current balance (compounding).")

        if (rrCap != null && rrCap > 0) {
            sb.appendLine("PROFIT BASIS: user-defined R:R cap = ${rrCap}R — a cell \"3\" means price reached 3R but profit is counted as +${minOf(3.0, rrCap)}R; stop = −1R.")
        } else {
            sb.appendLine("PROFIT BASIS: full target value (no cap).")
        }

        sb.appendLine()

        // 3. Data Body
        when (mode) {
            AiDataMode.FULL -> {
                sb.appendLine("--- FULL TABLE DATA (TSV) ---")
                // Header TSV
                sb.appendLine(headers.joinToString("\t") { sanitizeCell(it) })
                // Rows TSV
                visibleRows.forEach { row ->
                    val line = headers.indices.map { cIdx ->
                        sanitizeCell(row.cells.getOrNull(cIdx) ?: "")
                    }.joinToString("\t")
                    sb.appendLine(line)
                }
            }
            AiDataMode.SUMMARY -> {
                sb.appendLine("--- STATISTICAL SUMMARY & SAMPLE DATA (JSON) ---")
                val json = JSONObject().apply {
                    put("headers", JSONArray(headers))
                    put("summary", JSONObject().apply {
                        put("visibleRows", statsResult.totalVisibleRows)
                        put("countedTrades", statsResult.countedTrades)
                        put("winCount", statsResult.winCount)
                        put("lossCount", statsResult.lossCount)
                        put("noResultCount", statsResult.noResultCount)
                        put("invalidResultCount", statsResult.invalidResultCount)
                        put("winRatePercent", statsResult.winRatePercent)
                        put("netR", statsResult.netR)
                        put("profitFactor", if (statsResult.profitFactor.isInfinite()) "Infinity" else statsResult.profitFactor)
                        put("avgWinR", statsResult.avgWinR)
                        put("avgLossR", statsResult.avgLossR)
                        put("rewardToRiskRatio", statsResult.rewardToRiskRatio)
                        put("expectancyR", statsResult.expectancyR)
                        put("bestTradeR", statsResult.bestTradeR)
                        put("worstTradeR", statsResult.worstTradeR)
                        put("maxConsecutiveWins", statsResult.maxConsecutiveWins)
                        put("maxConsecutiveLosses", statsResult.maxConsecutiveLosses)
                        put("maxDrawdownR", statsResult.maxDrawdownR)
                        put("maxDrawdownRPercent", statsResult.maxDrawdownRPercent)
                        put("finalBalanceUSD", statsResult.finalBalance)
                        put("netDollarProfitUSD", statsResult.netDollarProfit)
                        put("totalReturnPercent", statsResult.totalReturnPercent)
                        put("maxDollarDrawdownUSD", statsResult.maxDollarDrawdown)
                        put("maxDollarDrawdownPercent", statsResult.maxDollarDrawdownPercent)
                    })

                    val grpArr = JSONArray()
                    statsResult.groupStats.forEach { g ->
                        grpArr.put(JSONObject().apply {
                            put("name", g.name)
                            put("tradeCount", g.tradeCount)
                            put("winRatePercent", g.winRatePercent)
                            put("netR", g.netR)
                            put("netDollarUSD", g.netDollar)
                        })
                    }
                    put("groupBreakdown", grpArr)

                    // Representative sample up to ~30 rows from visible subset
                    val sampleRows = pickSampleRows(visibleRows, statsResult, plColumnIndex, maxSample = 30)
                    val sampleArr = JSONArray()
                    sampleRows.forEach { r ->
                        val obj = JSONObject()
                        headers.forEachIndexed { cIdx, h ->
                            obj.put(h, r.cells.getOrNull(cIdx) ?: "")
                        }
                        sampleArr.put(obj)
                    }
                    put("representativeSampleRows", sampleArr)
                }
                sb.appendLine(json.toString(2))
            }
        }

        sb.appendLine()
        sb.appendLine("--- USER REQUEST ---")
        sb.appendLine(userQuery)

        sb.toString()
    }

    private fun sanitizeCell(cell: String): String {
        return cell.replace("\t", "    ").replace("\r", " ").replace("\n", " ").trim()
    }

    private fun pickSampleRows(
        visibleRows: List<GridRow>,
        statsResult: StatsResult,
        plColumnIndex: Int?,
        maxSample: Int = 30
    ): List<GridRow> {
        if (visibleRows.size <= maxSample) return visibleRows
        if (plColumnIndex == null) return visibleRows.take(maxSample)

        val wins = mutableListOf<GridRow>()
        val losses = mutableListOf<GridRow>()
        val others = mutableListOf<GridRow>()

        for (row in visibleRows) {
            val cell = row.cells.getOrNull(plColumnIndex)?.trim() ?: ""
            when {
                cell == "-" || cell == "−" || cell == "-1" -> losses.add(row)
                (cell.toDoubleOrNull() ?: 0.0) > 0 -> wins.add(row)
                else -> others.add(row)
            }
        }

        val result = mutableListOf<GridRow>()
        val half = maxSample / 2
        result.addAll(wins.take(half))
        result.addAll(losses.take(half))

        val remaining = maxSample - result.size
        if (remaining > 0) {
            result.addAll(others.take(remaining))
        }

        return result
    }
}

package ir.mahdi.backtesttable.ui.table

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.PostAdd
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun ColumnActionDialog(
    columnIndex: Int,
    currentTitle: String,
    isPlColumn: Boolean,
    isGroupColumn: Boolean,
    canDelete: Boolean,
    canMoveLeft: Boolean,
    canMoveRight: Boolean,
    onDismiss: () -> Unit,
    onRename: (String) -> Unit,
    onInsertLeft: () -> Unit,
    onInsertRight: () -> Unit,
    onMoveLeft: () -> Unit,
    onMoveRight: () -> Unit,
    onDelete: () -> Unit,
    onTogglePlColumn: () -> Unit,
    onToggleGroupColumn: () -> Unit
) {
    var showRenameInput by remember { mutableStateOf(false) }
    var renameText by remember { mutableStateOf(currentTitle) }

    var showDeleteConfirm by remember { mutableStateOf(false) }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("حذف ستون") },
            text = { Text("آیا از حذف ستون «$currentTitle» و داده‌های آن اطمینان دارید؟") },
            confirmButton = {
                OutlinedButton(
                    onClick = {
                        showDeleteConfirm = false
                        onDelete()
                        onDismiss()
                    }
                ) {
                    Text("بله، حذف شود", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDeleteConfirm = false }) {
                    Text("انصراف")
                }
            }
        )
        return
    }

    if (showRenameInput) {
        AlertDialog(
            onDismissRequest = { showRenameInput = false },
            title = { Text("تغییر نام ستون") },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    label = { Text("نام جدید") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                OutlinedButton(
                    onClick = {
                        if (renameText.isNotBlank()) {
                            onRename(renameText)
                        }
                        showRenameInput = false
                        onDismiss()
                    }
                ) {
                    Text("تأیید")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showRenameInput = false }) {
                    Text("انصراف")
                }
            }
        )
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "عملیات ستون: $currentTitle",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Rename
                ColumnActionItem(
                    icon = Icons.Default.Edit,
                    label = "تغییر نام ستون",
                    onClick = { showRenameInput = true }
                )

                Divider()

                // Insert Left / Right
                ColumnActionItem(
                    icon = Icons.Default.PostAdd,
                    label = "افزودن ستون به راست",
                    onClick = {
                        onInsertRight()
                        onDismiss()
                    }
                )

                ColumnActionItem(
                    icon = Icons.Default.PostAdd,
                    label = "افزودن ستون به چپ",
                    onClick = {
                        onInsertLeft()
                        onDismiss()
                    }
                )

                Divider()

                // Move Left / Right
                if (canMoveRight) {
                    ColumnActionItem(
                        icon = Icons.Default.ArrowForward,
                        label = "انتقال ستون به راست",
                        onClick = {
                            onMoveRight()
                            onDismiss()
                        }
                    )
                }

                if (canMoveLeft) {
                    ColumnActionItem(
                        icon = Icons.Default.ArrowBack,
                        label = "انتقال ستون به چپ",
                        onClick = {
                            onMoveLeft()
                            onDismiss()
                        }
                    )
                }

                Divider()

                // Pl Column toggle
                ColumnActionItem(
                    icon = Icons.Default.Flag,
                    label = if (isPlColumn) "غیرفعال‌سازی ستون نتیجه" else "انتخاب به عنوان ستون نتیجه (R)",
                    onClick = {
                        onTogglePlColumn()
                        onDismiss()
                    }
                )

                // Group Column toggle
                ColumnActionItem(
                    icon = Icons.Default.Group,
                    label = if (isGroupColumn) "غیرفعال‌سازی گروه‌بندی این ستون" else "انتخاب به عنوان ستون گروه‌بندی",
                    onClick = {
                        onToggleGroupColumn()
                        onDismiss()
                    }
                )

                if (canDelete) {
                    Divider()
                    ColumnActionItem(
                        icon = Icons.Default.Delete,
                        label = "حذف ستون",
                        isDestructive = true,
                        onClick = { showDeleteConfirm = true }
                    )
                }
            }
        },
        confirmButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("بستن")
            }
        }
    )
}

@Composable
private fun ColumnActionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isDestructive: Boolean = false,
    onClick: () -> Unit
) {
    val color = if (isDestructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = color)
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = color,
            fontWeight = if (isDestructive) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

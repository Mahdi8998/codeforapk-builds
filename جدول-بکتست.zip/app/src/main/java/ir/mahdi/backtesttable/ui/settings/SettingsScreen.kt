package ir.mahdi.backtesttable.ui.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import ir.mahdi.backtesttable.data.settings.AiProviderType
import ir.mahdi.backtesttable.data.settings.AppSettingsRepository
import ir.mahdi.backtesttable.data.settings.AppThemeMode
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settingsViewModel: SettingsViewModel,
    onNavigateBack: () -> Unit
) {
    val settings by settingsViewModel.settings.collectAsState()
    val isTesting by settingsViewModel.isTesting.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    var showGeminiKey by remember { mutableStateOf(false) }
    var showOpenAiKey by remember { mutableStateOf(false) }
    var showGeminiAdvanced by remember { mutableStateOf(false) }

    var openAiBaseUrlTemp by remember(settings.openAiBaseUrl) { mutableStateOf(settings.openAiBaseUrl) }
    var openAiModelTemp by remember(settings.openAiModel) { mutableStateOf(settings.openAiModel) }
    var openAiApiKeyTemp by remember(settings.openAiApiKey) { mutableStateOf(settings.openAiApiKey) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "تنظیمات برنامه",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // 1. Theme Selection
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "پوسته و ظاهر برنامه",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    ThemeOptionRow(
                        title = "پیرو سیستم (خودکار)",
                        selected = settings.themeMode == AppThemeMode.SYSTEM,
                        onClick = { settingsViewModel.updateTheme(AppThemeMode.SYSTEM) }
                    )

                    ThemeOptionRow(
                        title = "پوسته روشن",
                        selected = settings.themeMode == AppThemeMode.LIGHT,
                        onClick = { settingsViewModel.updateTheme(AppThemeMode.LIGHT) }
                    )

                    ThemeOptionRow(
                        title = "پوسته تاریک",
                        selected = settings.themeMode == AppThemeMode.DARK,
                        onClick = { settingsViewModel.updateTheme(AppThemeMode.DARK) }
                    )
                }
            }

            // 2. AI Provider Selection
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "سرویس هوش مصنوعی (AI)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ProviderOption(
                            title = "Google Gemini",
                            selected = settings.activeAiProvider == AiProviderType.GEMINI,
                            onClick = { settingsViewModel.updateAiProvider(AiProviderType.GEMINI) },
                            modifier = Modifier.weight(1f)
                        )

                        ProviderOption(
                            title = "سازگار با OpenAI / OpenRouter",
                            selected = settings.activeAiProvider == AiProviderType.OPENAI,
                            onClick = { settingsViewModel.updateAiProvider(AiProviderType.OPENAI) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(16.dp))

                    // Gemini Configuration
                    if (settings.activeAiProvider == AiProviderType.GEMINI) {
                        Text(
                            text = "تنظیمات Google Gemini",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = settings.geminiApiKey,
                            onValueChange = { settingsViewModel.updateGeminiApiKey(it) },
                            label = { Text("کلید API گوگل (Gemini API Key)") },
                            visualTransformation = if (showGeminiKey) VisualTransformation.None else PasswordVisualTransformation(),
                            trailingIcon = {
                                IconButton(onClick = { showGeminiKey = !showGeminiKey }) {
                                    Icon(
                                        if (showGeminiKey) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = null
                                    )
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "برای دریافت کلید رایگان می‌توانید به نشانی aistudio.google.com/apikey مراجعه کنید.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Advanced Gemini Settings
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showGeminiAdvanced = !showGeminiAdvanced }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "تنظیمات پیشرفته مدل Gemini",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Icon(
                                if (showGeminiAdvanced) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }

                        AnimatedVisibility(visible = showGeminiAdvanced) {
                            Column(modifier = Modifier.padding(top = 8.dp)) {
                                OutlinedTextField(
                                    value = settings.geminiModel,
                                    onValueChange = { settingsViewModel.updateGeminiModel(it) },
                                    label = { Text("نام مدل") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                OutlinedButton(
                                    onClick = { settingsViewModel.resetGeminiModel() },
                                    modifier = Modifier.align(Alignment.End)
                                ) {
                                    Text("بازگشت به مدل پیش‌فرض (${AppSettingsRepository.DEFAULT_GEMINI_MODEL})")
                                }
                            }
                        }
                    } else {
                        // OpenAI / OpenRouter Configuration
                        Text(
                            text = "تنظیمات OpenAI / OpenRouter",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        val isUrlValid = openAiBaseUrlTemp.trim().startsWith("https://", ignoreCase = true)

                        OutlinedTextField(
                            value = openAiBaseUrlTemp,
                            onValueChange = {
                                openAiBaseUrlTemp = it
                                settingsViewModel.updateOpenAiSettings(it, openAiModelTemp, openAiApiKeyTemp)
                            },
                            label = { Text("آدرس پایه (Base URL)") },
                            isError = !isUrlValid && openAiBaseUrlTemp.isNotBlank(),
                            supportingText = {
                                if (!isUrlValid && openAiBaseUrlTemp.isNotBlank()) {
                                    Text("آدرس باید با https:// شروع شود", color = MaterialTheme.colorScheme.error)
                                } else {
                                    Text("پیش‌فرض: ${AppSettingsRepository.DEFAULT_OPENAI_BASE_URL}")
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = openAiModelTemp,
                            onValueChange = {
                                openAiModelTemp = it
                                settingsViewModel.updateOpenAiSettings(openAiBaseUrlTemp, it, openAiApiKeyTemp)
                            },
                            label = { Text("شناسه مدل (Model ID)") },
                            supportingText = { Text("پیش‌فرض: ${AppSettingsRepository.DEFAULT_OPENAI_MODEL}") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = openAiApiKeyTemp,
                            onValueChange = {
                                openAiApiKeyTemp = it
                                settingsViewModel.updateOpenAiSettings(openAiBaseUrlTemp, openAiModelTemp, it)
                            },
                            label = { Text("کلید API (API Key)") },
                            visualTransformation = if (showOpenAiKey) VisualTransformation.None else PasswordVisualTransformation(),
                            trailingIcon = {
                                IconButton(onClick = { showOpenAiKey = !showOpenAiKey }) {
                                    Icon(
                                        if (showOpenAiKey) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = null
                                    )
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Connection Test Button
                    Button(
                        onClick = {
                            settingsViewModel.testConnection { msg, isSuccess ->
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar(msg)
                                }
                            }
                        },
                        enabled = !isTesting,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (isTesting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("در حال بررسی اتصال...")
                        } else {
                            Text("تست اتصال هوش مصنوعی")
                        }
                    }
                }
            }

            // About App Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "درباره جدول بک‌تست",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "جدول بک‌تست یک ابزار اکسل‌مانند آفلاین برای ثبت دستی و تحلیل سریع نتایج معاملات با موتور محاسبات درصدی و مشاور هوش مصنوعی است.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun ThemeOptionRow(
    title: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = title, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun ProviderOption(
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(selected = selected, onClick = onClick)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

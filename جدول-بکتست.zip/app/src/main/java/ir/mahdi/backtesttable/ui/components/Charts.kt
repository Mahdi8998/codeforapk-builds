package ir.mahdi.backtesttable.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.mahdi.backtesttable.data.NumberUtils
import ir.mahdi.backtesttable.data.stats.GroupStat
import ir.mahdi.backtesttable.ui.theme.Blue400
import ir.mahdi.backtesttable.ui.theme.Blue600
import ir.mahdi.backtesttable.ui.theme.GreenSuccess
import ir.mahdi.backtesttable.ui.theme.RedLoss
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Custom Canvas Equity Curve Line Chart (Used for R-Curve and Dollar-Curve).
 * NO external chart libraries.
 */
@Composable
fun CanvasEquityChart(
    points: List<Double>,
    referenceValue: Double = 0.0,
    unitLabel: String = "R",
    modifier: Modifier = Modifier
        .fillMaxWidth()
        .height(180.dp)
) {
    if (points.size < 2) {
        Box(
            modifier = modifier,
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "داده‌های کافی برای رسم نمودار وجود ندارد",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    val minVal = min(points.minOrNull() ?: 0.0, referenceValue)
    val maxVal = max(points.maxOrNull() ?: 0.0, referenceValue)
    val range = if (abs(maxVal - minVal) < 1e-6) 1.0 else maxVal - minVal

    val primaryColor = MaterialTheme.colorScheme.primary
    val outlineColor = MaterialTheme.colorScheme.outlineVariant
    val greenColor = GreenSuccess
    val redColor = RedLoss

    Column(modifier = Modifier.fillMaxWidth()) {
        // Labels row: Max, Min, Current
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "اوج: ${NumberUtils.formatNumber(maxVal)} $unitLabel",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "نهایی: ${NumberUtils.formatNumber(points.last())} $unitLabel",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = if (points.last() >= referenceValue) greenColor else redColor
            )
            Text(
                text = "کف: ${NumberUtils.formatNumber(minVal)} $unitLabel",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Canvas(modifier = modifier.padding(horizontal = 8.dp, vertical = 8.dp)) {
            val width = size.width
            val height = size.height
            val n = points.size

            // Draw zero / reference baseline
            val refY = height - (((referenceValue - minVal) / range) * height).toFloat()
            drawLine(
                color = outlineColor,
                start = Offset(0f, refY),
                end = Offset(width, refY),
                strokeWidth = 2f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
            )

            // Calculate point coordinates
            val coords = points.mapIndexed { idx, value ->
                val x = (idx.toFloat() / (n - 1)) * width
                val y = height - (((value - minVal) / range) * height).toFloat()
                Offset(x, y)
            }

            // Draw area gradient under line
            val fillPath = Path().apply {
                moveTo(coords.first().x, coords.first().y)
                for (i in 1 until coords.size) {
                    lineTo(coords[i].x, coords[i].y)
                }
                lineTo(width, height)
                lineTo(0f, height)
                close()
            }

            val areaBrush = Brush.verticalGradient(
                colors = listOf(
                    primaryColor.copy(alpha = 0.25f),
                    primaryColor.copy(alpha = 0.02f)
                ),
                startY = 0f,
                endY = height
            )
            drawPath(path = fillPath, brush = areaBrush)

            // Draw curve line
            val linePath = Path().apply {
                moveTo(coords.first().x, coords.first().y)
                for (i in 1 until coords.size) {
                    lineTo(coords[i].x, coords[i].y)
                }
            }
            drawPath(
                path = linePath,
                color = primaryColor,
                style = Stroke(width = 4f)
            )

            // Highlight last point
            val last = coords.last()
            drawCircle(
                color = if (points.last() >= referenceValue) greenColor else redColor,
                radius = 6f,
                center = last
            )
        }
    }
}

/**
 * Custom Canvas Donut Chart for Win / Loss / Excluded
 */
@Composable
fun CanvasDonutChart(
    winCount: Int,
    lossCount: Int,
    noResultCount: Int,
    invalidCount: Int,
    winRate: Double,
    modifier: Modifier = Modifier.size(130.dp)
) {
    val total = winCount + lossCount
    val green = GreenSuccess
    val red = RedLoss
    val gray = MaterialTheme.colorScheme.outlineVariant

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.matchParentSize()) {
            val strokeWidth = 24f
            val diameter = min(size.width, size.height) - strokeWidth
            val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
            val arcSize = Size(diameter, diameter)

            if (total == 0) {
                drawArc(
                    color = gray,
                    startAngle = 0f,
                    sweepAngle = 360f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth)
                )
            } else {
                val winAngle = (winCount.toFloat() / total) * 360f
                val lossAngle = 360f - winAngle

                // Draw Wins
                drawArc(
                    color = green,
                    startAngle = -90f,
                    sweepAngle = winAngle,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth)
                )

                // Draw Losses
                drawArc(
                    color = red,
                    startAngle = -90f + winAngle,
                    sweepAngle = lossAngle,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth)
                )
            }
        }

        // Center Win Rate
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = if (total > 0) NumberUtils.formatPercent(winRate) else "—",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "نرخ برد",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * Custom Canvas Group Bar Chart comparing Group Net R
 */
@Composable
fun CanvasGroupBars(
    groups: List<GroupStat>,
    modifier: Modifier = Modifier.fillMaxWidth()
) {
    if (groups.isEmpty()) return

    val maxAbsR = groups.maxOfOrNull { abs(it.netR) }?.takeIf { it > 0.0 } ?: 1.0
    val green = GreenSuccess
    val red = RedLoss

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        groups.forEach { g ->
            val fraction = (abs(g.netR) / maxAbsR).toFloat().coerceIn(0.05f, 1f)
            val isPos = g.netR >= 0

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = g.name,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.width(80.dp),
                    fontWeight = FontWeight.Medium
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(18.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(4.dp))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(fraction)
                            .height(18.dp)
                            .background(
                                if (isPos) green else red,
                                RoundedCornerShape(4.dp)
                            )
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = "${NumberUtils.formatNumber(g.netR, maxDecimals = 1, showPlusSign = true)} R",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (isPos) green else red,
                    modifier = Modifier.width(55.dp)
                )
            }
        }
    }
}

package ir.mahdi.backtesttable.data.stats

import ir.mahdi.backtesttable.data.NumberUtils
import ir.mahdi.backtesttable.data.model.GridRow
import kotlin.math.max
import kotlin.math.min

data class StatsInput(
    val visibleRows: List<GridRow>,
    val headers: List<String>,
    val plColumnIndex: Int?,
    val groupColumnIndex: Int?,
    val rrCap: Double?,
    val initialBalance: Double,
    val riskPercent: Double
)

data class GroupStat(
    val name: String,
    val tradeCount: Int,
    val winCount: Int,
    val lossCount: Int,
    val winRatePercent: Double,
    val netR: Double,
    val netDollar: Double
)

data class ColumnNumericStat(
    val columnIndex: Int,
    val header: String,
    val sum: Double,
    val avg: Double,
    val count: Int
)

data class CategoryValueStat(
    val value: String,
    val count: Int,
    val percent: Double
)

data class ColumnCategoryStat(
    val columnIndex: Int,
    val header: String,
    val values: List<CategoryValueStat>
)

data class ParsedTrade(
    val rowId: Long,
    val rowIndex: Int,
    val isWin: Boolean,
    val rawR: Double,
    val cappedR: Double,
    val groupValue: String
)

data class StatsResult(
    val totalVisibleRows: Int,
    val countedTrades: Int,
    val winCount: Int,
    val lossCount: Int,
    val noResultCount: Int,
    val invalidResultCount: Int,
    val winRatePercent: Double,
    val lossRatePercent: Double,

    // R metrics (labeled with "تارگت")
    val netR: Double,
    val profitFactor: Double, // Double.POSITIVE_INFINITY if no losses
    val avgWinR: Double,
    val avgLossR: Double,
    val rewardToRiskRatio: Double,
    val expectancyR: Double,
    val bestTradeR: Double,
    val worstTradeR: Double,
    val maxConsecutiveWins: Int,
    val maxConsecutiveLosses: Int,
    val maxDrawdownR: Double,
    val maxDrawdownRPercent: Double,
    val rEquityPoints: List<Double>,

    // Dollar compounding simulation
    val initialBalance: Double,
    val finalBalance: Double,
    val netDollarProfit: Double,
    val totalReturnPercent: Double,
    val avgDollarWin: Double,
    val avgDollarLoss: Double,
    val bestDollarTrade: Double,
    val worstDollarTrade: Double,
    val maxDollarDrawdown: Double,
    val maxDollarDrawdownPercent: Double,
    val dollarEquityPoints: List<Double>,

    // Group breakdown
    val resolvedGroupColumnIndex: Int?,
    val groupStats: List<GroupStat>,

    // Summary tab stats
    val numericColumnsStats: List<ColumnNumericStat>,
    val categoryColumnsStats: List<ColumnCategoryStat>,

    // Parsed trades for sample AI payloads
    val parsedTrades: List<ParsedTrade>
)

object StatsEngine {

    fun compute(input: StatsInput): StatsResult {
        val visibleRows = input.visibleRows
        val totalRows = visibleRows.size
        val headers = input.headers
        val plCol = input.plColumnIndex
        val rrCap = input.rrCap
        val initialBalance = if (input.initialBalance > 0) input.initialBalance else 500.0
        val riskPercent = if (input.riskPercent > 0) input.riskPercent else 2.0

        // 1. Generic Summary Stats (Columns analysis)
        val numericStats = mutableListOf<ColumnNumericStat>()
        val categoryStats = mutableListOf<ColumnCategoryStat>()

        if (totalRows > 0) {
            headers.forEachIndexed { colIdx, header ->
                val nonBlankCells = visibleRows.mapNotNull { row ->
                    val c = row.cells.getOrNull(colIdx)?.trim()
                    if (c.isNullOrEmpty()) null else c
                }

                if (nonBlankCells.isNotEmpty()) {
                    val numbers = nonBlankCells.mapNotNull { NumberUtils.parseDouble(it) }
                    // If more than 75% are numeric, treat as numeric column
                    if (numbers.size >= (nonBlankCells.size * 3) / 4) {
                        val sum = numbers.sum()
                        val avg = sum / numbers.size
                        numericStats.add(
                            ColumnNumericStat(
                                columnIndex = colIdx,
                                header = header,
                                sum = sum,
                                avg = avg,
                                count = numbers.size
                            )
                        )
                    } else {
                        // Check distinct non-numeric values
                        val frequencies = nonBlankCells.groupingBy { it }.eachCount()
                        if (frequencies.size in 2..5) {
                            val totalCount = nonBlankCells.size.toDouble()
                            val catValues = frequencies.entries.map { (v, cnt) ->
                                CategoryValueStat(
                                    value = v,
                                    count = cnt,
                                    percent = (cnt / totalCount) * 100.0
                                )
                            }.sortedByDescending { it.count }

                            categoryStats.add(
                                ColumnCategoryStat(
                                    columnIndex = colIdx,
                                    header = header,
                                    values = catValues
                                )
                            )
                        }
                    }
                }
            }
        }

        // Determine group column if not explicitly set
        val resolvedGroupCol = input.groupColumnIndex ?: findDefaultGroupColumn(visibleRows, headers, plCol)

        // If result column is not set or empty
        if (plCol == null || plCol !in headers.indices) {
            return createEmptyStats(
                totalRows = totalRows,
                initialBalance = initialBalance,
                resolvedGroupCol = resolvedGroupCol,
                numericStats = numericStats,
                categoryStats = categoryStats
            )
        }

        // 2. Parse Result Column Semantics (R-multiples)
        var noResultCount = 0
        var invalidResultCount = 0
        val parsedTrades = mutableListOf<ParsedTrade>()

        visibleRows.forEachIndexed { idx, row ->
            val cell = row.cells.getOrNull(plCol)?.trim() ?: ""
            if (cell.isEmpty()) {
                noResultCount++
                return@forEachIndexed
            }

            val groupVal = if (resolvedGroupCol != null && resolvedGroupCol in headers.indices) {
                row.cells.getOrNull(resolvedGroupCol)?.trim()?.ifEmpty { "نامشخص" } ?: "نامشخص"
            } else {
                "سایر"
            }

            // Check Stop-loss hit: "-" (U+002D) or "−" (U+2212) or "-1"
            if (cell == "-" || cell == "−" || cell == "‐" || cell == "–" || cell == "-1") {
                parsedTrades.add(
                    ParsedTrade(
                        rowId = row.id,
                        rowIndex = idx,
                        isWin = false,
                        rawR = -1.0,
                        cappedR = -1.0,
                        groupValue = groupVal
                    )
                )
            } else {
                val num = NumberUtils.parseDouble(cell)
                if (num != null && num > 0.0) {
                    // Target N hit (Win)
                    val capped = if (rrCap != null && rrCap > 0) min(num, rrCap) else num
                    parsedTrades.add(
                        ParsedTrade(
                            rowId = row.id,
                            rowIndex = idx,
                            isWin = true,
                            rawR = num,
                            cappedR = capped,
                            groupValue = groupVal
                        )
                    )
                } else {
                    // 0, negative other than -1, invalid text, etc.
                    invalidResultCount++
                }
            }
        }

        val countedTrades = parsedTrades.size
        if (countedTrades == 0) {
            return createEmptyStats(
                totalRows = totalRows,
                initialBalance = initialBalance,
                resolvedGroupCol = resolvedGroupCol,
                noResultCount = noResultCount,
                invalidResultCount = invalidResultCount,
                numericStats = numericStats,
                categoryStats = categoryStats
            )
        }

        val winCount = parsedTrades.count { it.isWin }
        val lossCount = parsedTrades.count { !it.isWin }
        val winRatePercent = (winCount.toDouble() / countedTrades) * 100.0
        val lossRatePercent = (lossCount.toDouble() / countedTrades) * 100.0

        // R metrics calculations
        val totalWinR = parsedTrades.filter { it.isWin }.sumOf { it.cappedR }
        val totalLossR = lossCount.toDouble() // each loss is -1, magnitude is 1.0
        val netR = totalWinR - totalLossR

        val profitFactor = when {
            lossCount == 0 && winCount > 0 -> Double.POSITIVE_INFINITY
            lossCount == 0 && winCount == 0 -> 0.0
            totalLossR == 0.0 -> Double.POSITIVE_INFINITY
            else -> totalWinR / totalLossR
        }

        val avgWinR = if (winCount > 0) totalWinR / winCount else 0.0
        val avgLossR = if (lossCount > 0) 1.0 else 0.0
        val rewardToRiskRatio = if (avgLossR > 0) avgWinR / avgLossR else 0.0
        val expectancyR = netR / countedTrades

        val bestTradeR = parsedTrades.maxOfOrNull { it.cappedR } ?: 0.0
        val worstTradeR = parsedTrades.minOfOrNull { it.cappedR } ?: 0.0

        // Streaks
        var maxWinStreak = 0
        var maxLossStreak = 0
        var currentWinStreak = 0
        var currentLossStreak = 0

        for (trade in parsedTrades) {
            if (trade.isWin) {
                currentWinStreak++
                currentLossStreak = 0
                if (currentWinStreak > maxWinStreak) maxWinStreak = currentWinStreak
            } else {
                currentLossStreak++
                currentWinStreak = 0
                if (currentLossStreak > maxLossStreak) maxLossStreak = currentLossStreak
            }
        }

        // R Drawdown and Equity curve
        val rEquityPoints = ArrayList<Double>(countedTrades + 1)
        rEquityPoints.add(0.0)
        var runningR = 0.0
        var peakR = 0.0
        var maxDrawdownR = 0.0
        var maxDrawdownRPercent = 0.0

        for (trade in parsedTrades) {
            runningR += trade.cappedR
            rEquityPoints.add(runningR)
            if (runningR > peakR) {
                peakR = runningR
            } else {
                val dd = peakR - runningR
                if (dd > maxDrawdownR) {
                    maxDrawdownR = dd
                    if (peakR > 0.0) {
                        maxDrawdownRPercent = (dd / peakR) * 100.0
                    }
                }
            }
        }

        // 3. Dollar compounding simulation
        // Walk counted trades in row order from initialBalance
        // Loss: balance * (1 - risk/100)
        // Win: balance * (1 + risk/100 * cappedR)
        val dollarEquityPoints = ArrayList<Double>(countedTrades + 1)
        dollarEquityPoints.add(initialBalance)
        var currentBalance = initialBalance
        var peakDollar = initialBalance
        var maxDollarDd = 0.0
        var maxDollarDdPercent = 0.0

        val dollarWinAmounts = mutableListOf<Double>()
        val dollarLossAmounts = mutableListOf<Double>()
        var bestDollarTrade = 0.0
        var worstDollarTrade = 0.0

        val riskFraction = riskPercent / 100.0

        parsedTrades.forEachIndexed { i, trade ->
            val prevBalance = currentBalance
            if (trade.isWin) {
                val gain = prevBalance * (riskFraction * trade.cappedR)
                currentBalance = prevBalance + gain
                dollarWinAmounts.add(gain)
                if (gain > bestDollarTrade || i == 0) bestDollarTrade = gain
            } else {
                val loss = prevBalance * riskFraction
                currentBalance = prevBalance - loss
                dollarLossAmounts.add(loss)
                val tradeDelta = -loss
                if (tradeDelta < worstDollarTrade || i == 0) worstDollarTrade = tradeDelta
            }
            dollarEquityPoints.add(currentBalance)

            if (currentBalance > peakDollar) {
                peakDollar = currentBalance
            } else {
                val dd = peakDollar - currentBalance
                if (dd > maxDollarDd) {
                    maxDollarDd = dd
                    if (peakDollar > 0) {
                        maxDollarDdPercent = (dd / peakDollar) * 100.0
                    }
                }
            }
        }

        val netDollarProfit = currentBalance - initialBalance
        val totalReturnPercent = (netDollarProfit / initialBalance) * 100.0
        val avgDollarWin = if (dollarWinAmounts.isNotEmpty()) dollarWinAmounts.average() else 0.0
        val avgDollarLoss = if (dollarLossAmounts.isNotEmpty()) dollarLossAmounts.average() else 0.0

        // 4. Group breakdown
        val groupMap = parsedTrades.groupBy { it.groupValue }
        val groupStats = groupMap.map { (grpName, trades) ->
            val gCount = trades.size
            val gWins = trades.count { it.isWin }
            val gLosses = trades.count { !it.isWin }
            val gWinRate = (gWins.toDouble() / gCount) * 100.0
            val gNetR = trades.sumOf { it.cappedR }
            // Order-free net dollar formula: Σ(initialBalance * riskPercent/100 * R)
            val gNetDollar = trades.sumOf { initialBalance * riskFraction * it.cappedR }
            GroupStat(
                name = grpName,
                tradeCount = gCount,
                winCount = gWins,
                lossCount = gLosses,
                winRatePercent = gWinRate,
                netR = gNetR,
                netDollar = gNetDollar
            )
        }.sortedByDescending { it.tradeCount }

        return StatsResult(
            totalVisibleRows = totalRows,
            countedTrades = countedTrades,
            winCount = winCount,
            lossCount = lossCount,
            noResultCount = noResultCount,
            invalidResultCount = invalidResultCount,
            winRatePercent = winRatePercent,
            lossRatePercent = lossRatePercent,
            netR = netR,
            profitFactor = profitFactor,
            avgWinR = avgWinR,
            avgLossR = avgLossR,
            rewardToRiskRatio = rewardToRiskRatio,
            expectancyR = expectancyR,
            bestTradeR = bestTradeR,
            worstTradeR = worstTradeR,
            maxConsecutiveWins = maxWinStreak,
            maxConsecutiveLosses = maxLossStreak,
            maxDrawdownR = maxDrawdownR,
            maxDrawdownRPercent = maxDrawdownRPercent,
            rEquityPoints = rEquityPoints,
            initialBalance = initialBalance,
            finalBalance = currentBalance,
            netDollarProfit = netDollarProfit,
            totalReturnPercent = totalReturnPercent,
            avgDollarWin = avgDollarWin,
            avgDollarLoss = avgDollarLoss,
            bestDollarTrade = bestDollarTrade,
            worstDollarTrade = worstDollarTrade,
            maxDollarDrawdown = maxDollarDd,
            maxDollarDrawdownPercent = maxDollarDdPercent,
            dollarEquityPoints = dollarEquityPoints,
            resolvedGroupColumnIndex = resolvedGroupCol,
            groupStats = groupStats,
            numericColumnsStats = numericStats,
            categoryColumnsStats = categoryStats,
            parsedTrades = parsedTrades
        )
    }

    private fun findDefaultGroupColumn(
        rows: List<GridRow>,
        headers: List<String>,
        plCol: Int?
    ): Int? {
        val dateRegex1 = Regex("""^\d{4}[-/]\d{2}[-/]\d{2}$""")
        val dateRegex2 = Regex("""^\d{2}[-/]\d{2}[-/]\d{4}$""")

        for (colIdx in headers.indices) {
            if (colIdx == plCol) continue
            val values = rows.mapNotNull {
                val v = it.cells.getOrNull(colIdx)?.trim()
                if (v.isNullOrEmpty()) null else v
            }
            if (values.isEmpty()) continue

            // Check if numeric
            val numCount = values.count { NumberUtils.isNumeric(it) }
            if (numCount > values.size / 2) continue

            // Check if date-like (> 50% match)
            val dateCount = values.count { dateRegex1.matches(it) || dateRegex2.matches(it) }
            if (dateCount > values.size / 2) continue

            val distinct = values.distinct()
            if (distinct.size in 2..10) {
                return colIdx
            }
        }
        return null
    }

    private fun createEmptyStats(
        totalRows: Int,
        initialBalance: Double,
        resolvedGroupCol: Int?,
        noResultCount: Int = 0,
        invalidResultCount: Int = 0,
        numericStats: List<ColumnNumericStat> = emptyList(),
        categoryStats: List<ColumnCategoryStat> = emptyList()
    ): StatsResult {
        return StatsResult(
            totalVisibleRows = totalRows,
            countedTrades = 0,
            winCount = 0,
            lossCount = 0,
            noResultCount = noResultCount,
            invalidResultCount = invalidResultCount,
            winRatePercent = 0.0,
            lossRatePercent = 0.0,
            netR = 0.0,
            profitFactor = 0.0,
            avgWinR = 0.0,
            avgLossR = 0.0,
            rewardToRiskRatio = 0.0,
            expectancyR = 0.0,
            bestTradeR = 0.0,
            worstTradeR = 0.0,
            maxConsecutiveWins = 0,
            maxConsecutiveLosses = 0,
            maxDrawdownR = 0.0,
            maxDrawdownRPercent = 0.0,
            rEquityPoints = listOf(0.0),
            initialBalance = initialBalance,
            finalBalance = initialBalance,
            netDollarProfit = 0.0,
            totalReturnPercent = 0.0,
            avgDollarWin = 0.0,
            avgDollarLoss = 0.0,
            bestDollarTrade = 0.0,
            worstDollarTrade = 0.0,
            maxDollarDrawdown = 0.0,
            maxDollarDrawdownPercent = 0.0,
            dollarEquityPoints = listOf(initialBalance),
            resolvedGroupColumnIndex = resolvedGroupCol,
            groupStats = emptyList(),
            numericColumnsStats = numericStats,
            categoryColumnsStats = categoryStats,
            parsedTrades = emptyList()
        )
    }
}

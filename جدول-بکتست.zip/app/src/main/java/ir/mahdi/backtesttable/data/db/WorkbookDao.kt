package ir.mahdi.backtesttable.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkbookDao {

    @Query("SELECT * FROM workbooks ORDER BY updatedAt DESC")
    fun getAllWorkbooks(): Flow<List<WorkbookEntity>>

    @Query("SELECT * FROM workbooks WHERE id = :id LIMIT 1")
    suspend fun getWorkbookById(id: Long): WorkbookEntity?

    @Query("SELECT * FROM workbooks WHERE id = :id LIMIT 1")
    fun observeWorkbookById(id: Long): Flow<WorkbookEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkbook(workbook: WorkbookEntity): Long

    @Update
    suspend fun updateWorkbook(workbook: WorkbookEntity)

    @Delete
    suspend fun deleteWorkbook(workbook: WorkbookEntity)

    @Query("DELETE FROM workbooks WHERE id = :id")
    suspend fun deleteWorkbookById(id: Long)

    @Query("SELECT COUNT(*) FROM workbooks")
    suspend fun getCount(): Int
}

package ir.mahdi.backtesttable.data.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

class OpenAiClient(
    private val baseUrl: String,
    private val modelName: String,
    private val apiKey: String,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
) : AiClient {

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private fun getChatUrl(): String {
        val clean = baseUrl.trim().trimEnd('/')
        return if (clean.endsWith("/chat/completions")) clean else "$clean/chat/completions"
    }

    override suspend fun testConnection(): Result<Unit> = withContext(Dispatchers.IO) {
        if (!baseUrl.trim().startsWith("https://", ignoreCase = true)) {
            return@withContext Result.failure(Exception("INVALID_URL: آدرس باید با https:// شروع شود"))
        }
        if (apiKey.isBlank()) {
            return@withContext Result.failure(Exception("NO_KEY"))
        }

        val url = getChatUrl()
        val payload = JSONObject().apply {
            put("model", modelName.ifBlank { "google/gemini-3.5-flash" })
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", "ping")
                })
            })
            put("max_tokens", 5)
        }

        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $apiKey")
            .post(payload.toString().toRequestBody(jsonMediaType))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(Unit)
                } else {
                    val code = response.code
                    val errorBody = response.body?.string() ?: ""
                    Result.failure(Exception("HTTP $code: $errorBody"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun streamChat(
        messages: List<AiChatMessage>,
        systemInstruction: String,
        onToken: (String) -> Unit
    ): Result<String> = withContext(Dispatchers.IO) {
        if (!baseUrl.trim().startsWith("https://", ignoreCase = true)) {
            return@withContext Result.failure(Exception("INVALID_URL: آدرس باید با https:// شروع شود"))
        }
        if (apiKey.isBlank()) {
            return@withContext Result.failure(Exception("NO_KEY"))
        }

        val url = getChatUrl()
        val requestJson = buildRequestBody(messages, systemInstruction, stream = true)

        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $apiKey")
            .post(requestJson.toString().toRequestBody(jsonMediaType))
            .build()

        val fullResponse = StringBuilder()

        try {
            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                val code = response.code
                val err = response.body?.string() ?: ""
                response.close()

                if (code == 404) {
                    return@withContext Result.failure(Exception("HTTP 404 MODEL_NOT_FOUND"))
                }
                return@withContext executeNonStreaming(messages, systemInstruction)
            }

            val body = response.body ?: return@withContext Result.failure(Exception("Empty response body"))
            val reader = BufferedReader(InputStreamReader(body.byteStream()))

            var line: String?
            while (reader.readLine().also { line = it } != null) {
                val currentLine = line ?: break
                if (currentLine.startsWith("data:")) {
                    val data = currentLine.removePrefix("data:").trim()
                    if (data == "[DONE]") {
                        break
                    }
                    if (data.isNotEmpty()) {
                        try {
                            val chunkObj = JSONObject(data)
                            val choices = chunkObj.optJSONArray("choices")
                            if (choices != null && choices.length() > 0) {
                                val choice = choices.getJSONObject(0)
                                val delta = choice.optJSONObject("delta")
                                val text = delta?.optString("content", "") ?: ""
                                if (text.isNotEmpty()) {
                                    fullResponse.append(text)
                                    withContext(Dispatchers.Main) {
                                        onToken(text)
                                    }
                                }
                            }
                        } catch (ignored: Exception) {
                            // Non-JSON SSE line
                        }
                    }
                }
            }
            response.close()

            if (fullResponse.isEmpty()) {
                return@withContext executeNonStreaming(messages, systemInstruction)
            }

            Result.success(fullResponse.toString())
        } catch (e: Exception) {
            try {
                executeNonStreaming(messages, systemInstruction)
            } catch (fallbackError: Exception) {
                Result.failure(e)
            }
        }
    }

    private suspend fun executeNonStreaming(
        messages: List<AiChatMessage>,
        systemInstruction: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val url = getChatUrl()
        val requestJson = buildRequestBody(messages, systemInstruction, stream = false)

        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $apiKey")
            .post(requestJson.toString().toRequestBody(jsonMediaType))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val code = response.code
                    val err = response.body?.string() ?: ""
                    return@withContext Result.failure(Exception("HTTP $code: $err"))
                }
                val bodyStr = response.body?.string() ?: ""
                val obj = JSONObject(bodyStr)
                val choices = obj.optJSONArray("choices")
                if (choices != null && choices.length() > 0) {
                    val choice = choices.getJSONObject(0)
                    val msg = choice.optJSONObject("message")
                    val text = msg?.optString("content", "") ?: ""
                    return@withContext Result.success(text)
                }
                Result.success("")
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun buildRequestBody(
        messages: List<AiChatMessage>,
        systemInstruction: String,
        stream: Boolean
    ): JSONObject {
        return JSONObject().apply {
            put("model", modelName.ifBlank { "google/gemini-3.5-flash" })
            put("stream", stream)
            val msgArray = JSONArray()

            if (systemInstruction.isNotBlank()) {
                msgArray.put(JSONObject().apply {
                    put("role", "system")
                    put("content", systemInstruction)
                })
            }

            for (msg in messages) {
                msgArray.put(JSONObject().apply {
                    put("role", if (msg.role == "model") "assistant" else msg.role)
                    put("content", msg.content)
                })
            }
            put("messages", msgArray)
        }
    }
}

package ir.mahdi.backtesttable.ui.table

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.mahdi.backtesttable.data.NumberUtils
import ir.mahdi.backtesttable.data.db.WorkbookDao
import ir.mahdi.backtesttable.data.db.WorkbookEntity
import ir.mahdi.backtesttable.data.excel.XlsxManager
import ir.mahdi.backtesttable.data.model.ColumnFilter
import ir.mahdi.backtesttable.data.model.FilterState
import ir.mahdi.backtesttable.data.model.GridData
import ir.mahdi.backtesttable.data.model.GridRow
import ir.mahdi.backtesttable.data.stats.StatsEngine
import ir.mahdi.backtesttable.data.stats.StatsInput
import ir.mahdi.backtesttable.data.stats.StatsResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(FlowPreview::class)
class TableViewModel(
    private val workbookId: Long,
    private val workbookDao: WorkbookDao
) : ViewModel() {

    private val _workbookName = MutableStateFlow("جدول")
    val workbookName: StateFlow<String> = _workbookName.asStateFlow()

    private val _gridData = MutableStateFlow(GridData.createInitial())
    val gridData: StateFlow<GridData> = _gridData.asStateFlow()

    private val _filterState = MutableStateFlow(FilterState())
    val filterState: StateFlow<FilterState> = _filterState.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _plColumnIndex = MutableStateFlow<Int?>(null)
    val plColumnIndex: StateFlow<Int?> = _plColumnIndex.asStateFlow()

    private val _groupColumnIndex = MutableStateFlow<Int?>(null)
    val groupColumnIndex: StateFlow<Int?> = _groupColumnIndex.asStateFlow()

    private val _initialBalance = MutableStateFlow(500.0)
    val initialBalance: StateFlow<Double> = _initialBalance.asStateFlow()

    private val _riskPercent = MutableStateFlow(2.0)
    val riskPercent: StateFlow<Double> = _riskPercent.asStateFlow()

    private val _rrCap = MutableStateFlow<Double?>(null)
    val rrCap: StateFlow<Double?> = _rrCap.asStateFlow()

    // Undo / Redo stacks
    private val undoStack = ArrayDeque<GridData>()
    private val redoStack = ArrayDeque<GridData>()
    private val maxHistorySteps = 50

    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()

    private val _canRedo = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()

    private val _saveMessage = MutableSharedFlow<String>()
    val saveMessage = _saveMessage.asSharedFlow()

    // Filtered / visible rows
    val visibleRows: StateFlow<List<GridRow>> = combine(
        _gridData,
        _filterState,
        _searchQuery
    ) { grid, filters, query ->
        computeVisibleRows(grid, filters, query)
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // Reactive pipeline for StatsEngine
    private val statsInputFlow = combine(
        visibleRows,
        _gridData,
        combine(_plColumnIndex, _groupColumnIndex, _rrCap) { pl, grp, rr -> Triple(pl, grp, rr) },
        combine(_initialBalance, _riskPercent) { b, r -> Pair(b, r) }
    ) { visible, grid, colSettings, moneySettings ->
        StatsInput(
            visibleRows = visible,
            headers = grid.headers,
            plColumnIndex = colSettings.first,
            groupColumnIndex = colSettings.second,
            rrCap = colSettings.third,
            initialBalance = moneySettings.first,
            riskPercent = moneySettings.second
        )
    }.distinctUntilChanged()

    val statsResult: StateFlow<StatsResult> = statsInputFlow
        .debounce(200)
        .mapLatest { input ->
            withContext(Dispatchers.Default) {
                StatsEngine.compute(input)
            }
        }
        .flowOn(Dispatchers.Default)
        .stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            StatsEngine.compute(
                StatsInput(
                    visibleRows = emptyList(),
                    headers = emptyList(),
                    plColumnIndex = null,
                    groupColumnIndex = null,
                    rrCap = null,
                    initialBalance = 500.0,
                    riskPercent = 2.0
                )
            )
        )

    private val saveTriggerFlow = combine(
        _gridData,
        _filterState,
        _workbookName,
        _plColumnIndex,
        _groupColumnIndex,
        _initialBalance,
        _riskPercent,
        _rrCap
    ) { params -> params }

    init {
        loadWorkbook()

        // Auto-save debounced (~500ms)
        saveTriggerFlow
            .debounce(500)
            .onEach {
                saveWorkbookToDb(silent = true)
            }
            .launchIn(viewModelScope)
    }

    private fun loadWorkbook() {
        viewModelScope.launch {
            val entity = workbookDao.getWorkbookById(workbookId)
            if (entity != null) {
                _workbookName.value = entity.name
                _gridData.value = GridData.fromJson(entity.gridJson)
                _filterState.value = FilterState.fromJson(entity.filterStateJson)
                _plColumnIndex.value = entity.plColumnIndex
                _groupColumnIndex.value = entity.groupColumnIndex
                _initialBalance.value = entity.initialBalance
                _riskPercent.value = entity.riskPercent
                _rrCap.value = entity.rrCap
            }
        }
    }

    fun manualSave() {
        viewModelScope.launch {
            saveWorkbookToDb(silent = false)
            _saveMessage.emit("ذخیره شد")
        }
    }

    private suspend fun saveWorkbookToDb(silent: Boolean = true) {
        val currentEntity = workbookDao.getWorkbookById(workbookId) ?: return
        val updated = currentEntity.copy(
            name = _workbookName.value,
            updatedAt = System.currentTimeMillis(),
            gridJson = _gridData.value.toJson(),
            filterStateJson = _filterState.value.toJson(),
            plColumnIndex = _plColumnIndex.value,
            groupColumnIndex = _groupColumnIndex.value,
            initialBalance = _initialBalance.value,
            riskPercent = _riskPercent.value,
            rrCap = _rrCap.value
        )
        workbookDao.updateWorkbook(updated)
    }

    // --- History / Undo / Redo ---
    private fun pushHistoryState() {
        if (undoStack.size >= maxHistorySteps) {
            undoStack.removeFirst()
        }
        undoStack.addLast(_gridData.value)
        redoStack.clear()
        updateUndoRedoStates()
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            val previous = undoStack.removeLast()
            redoStack.addLast(_gridData.value)
            _gridData.value = previous
            updateUndoRedoStates()
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            val next = redoStack.removeLast()
            undoStack.addLast(_gridData.value)
            _gridData.value = next
            updateUndoRedoStates()
        }
    }

    private fun updateUndoRedoStates() {
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = redoStack.isNotEmpty()
    }

    // --- Cell Editing ---
    fun updateCell(rowId: Long, columnIndex: Int, newValue: String) {
        val currentGrid = _gridData.value
        val rowIdx = currentGrid.rows.indexOfFirst { it.id == rowId }
        if (rowIdx < 0 || columnIndex !in currentGrid.headers.indices) return

        val oldRow = currentGrid.rows[rowIdx]
        val oldVal = oldRow.cells.getOrNull(columnIndex) ?: ""
        if (oldVal == newValue) return

        pushHistoryState()

        val updatedCells = ArrayList(oldRow.cells)
        while (updatedCells.size <= columnIndex) {
            updatedCells.add("")
        }
        updatedCells[columnIndex] = newValue

        val updatedRows = ArrayList(currentGrid.rows)
        updatedRows[rowIdx] = oldRow.copy(cells = updatedCells)

        _gridData.value = currentGrid.copy(rows = updatedRows)
    }

    // --- Row Operations ---
    fun addBlankRowAtEnd(): Long {
        pushHistoryState()
        val currentGrid = _gridData.value
        val newId = System.currentTimeMillis()
        val newRow = GridRow(id = newId, cells = List(currentGrid.headers.size) { "" })
        _gridData.value = currentGrid.copy(rows = currentGrid.rows + newRow)
        return newId
    }

    fun insertRowAbove(rowId: Long) {
        pushHistoryState()
        val currentGrid = _gridData.value
        val idx = currentGrid.rows.indexOfFirst { it.id == rowId }
        val targetIdx = if (idx >= 0) idx else 0
        val newRow = GridRow(id = System.currentTimeMillis(), cells = List(currentGrid.headers.size) { "" })
        val newRows = ArrayList(currentGrid.rows)
        newRows.add(targetIdx, newRow)
        _gridData.value = currentGrid.copy(rows = newRows)
    }

    fun insertRowBelow(rowId: Long) {
        pushHistoryState()
        val currentGrid = _gridData.value
        val idx = currentGrid.rows.indexOfFirst { it.id == rowId }
        val targetIdx = if (idx >= 0) idx + 1 else currentGrid.rows.size
        val newRow = GridRow(id = System.currentTimeMillis(), cells = List(currentGrid.headers.size) { "" })
        val newRows = ArrayList(currentGrid.rows)
        newRows.add(targetIdx, newRow)
        _gridData.value = currentGrid.copy(rows = newRows)
    }

    fun duplicateRow(rowId: Long) {
        pushHistoryState()
        val currentGrid = _gridData.value
        val idx = currentGrid.rows.indexOfFirst { it.id == rowId }
        if (idx < 0) return
        val original = currentGrid.rows[idx]
        val duplicate = GridRow(id = System.currentTimeMillis(), cells = ArrayList(original.cells))
        val newRows = ArrayList(currentGrid.rows)
        newRows.add(idx + 1, duplicate)
        _gridData.value = currentGrid.copy(rows = newRows)
    }

    fun deleteRow(rowId: Long) {
        pushHistoryState()
        val currentGrid = _gridData.value
        val newRows = currentGrid.rows.filter { it.id != rowId }
        _gridData.value = currentGrid.copy(rows = newRows.ifEmpty {
            listOf(GridRow(id = System.currentTimeMillis(), cells = List(currentGrid.headers.size) { "" }))
        })
    }

    // --- Column Operations ---
    fun renameColumn(colIndex: Int, newName: String) {
        val currentGrid = _gridData.value
        if (colIndex !in currentGrid.headers.indices) return
        val cleanName = newName.trim().ifBlank { currentGrid.headers[colIndex] }
        pushHistoryState()
        val newHeaders = ArrayList(currentGrid.headers)
        newHeaders[colIndex] = cleanName
        _gridData.value = currentGrid.copy(headers = newHeaders)
    }

    fun insertColumnLeft(colIndex: Int) {
        val currentGrid = _gridData.value
        if (colIndex !in currentGrid.headers.indices) return
        pushHistoryState()
        val insertIdx = colIndex
        val newHeaders = ArrayList(currentGrid.headers)
        newHeaders.add(insertIdx, "ستون جدید")

        val newRows = currentGrid.rows.map { row ->
            val cells = ArrayList(row.cells)
            cells.add(insertIdx, "")
            row.copy(cells = cells)
        }

        adjustColumnIndicesForInsert(insertIdx)
        _gridData.value = currentGrid.copy(headers = newHeaders, rows = newRows)
    }

    fun insertColumnRight(colIndex: Int) {
        val currentGrid = _gridData.value
        if (colIndex !in currentGrid.headers.indices) return
        pushHistoryState()
        val insertIdx = colIndex + 1
        val newHeaders = ArrayList(currentGrid.headers)
        newHeaders.add(insertIdx, "ستون جدید")

        val newRows = currentGrid.rows.map { row ->
            val cells = ArrayList(row.cells)
            if (insertIdx <= cells.size) {
                cells.add(insertIdx, "")
            } else {
                while (cells.size < insertIdx) cells.add("")
                cells.add("")
            }
            row.copy(cells = cells)
        }

        adjustColumnIndicesForInsert(insertIdx)
        _gridData.value = currentGrid.copy(headers = newHeaders, rows = newRows)
    }

    fun deleteColumn(colIndex: Int) {
        val currentGrid = _gridData.value
        if (currentGrid.headers.size <= 1 || colIndex !in currentGrid.headers.indices) return
        pushHistoryState()
        val newHeaders = ArrayList(currentGrid.headers)
        newHeaders.removeAt(colIndex)

        val newRows = currentGrid.rows.map { row ->
            val cells = ArrayList(row.cells)
            if (colIndex in cells.indices) {
                cells.removeAt(colIndex)
            }
            row.copy(cells = cells)
        }

        adjustColumnIndicesForDelete(colIndex)
        _gridData.value = currentGrid.copy(headers = newHeaders, rows = newRows)
    }

    fun moveColumn(fromIndex: Int, toIndex: Int) {
        val currentGrid = _gridData.value
        if (fromIndex !in currentGrid.headers.indices || toIndex !in currentGrid.headers.indices || fromIndex == toIndex) return
        pushHistoryState()

        val newHeaders = ArrayList(currentGrid.headers)
        val h = newHeaders.removeAt(fromIndex)
        newHeaders.add(toIndex, h)

        val newRows = currentGrid.rows.map { row ->
            val cells = ArrayList(row.cells)
            val c = if (fromIndex in cells.indices) cells.removeAt(fromIndex) else ""
            if (toIndex <= cells.size) cells.add(toIndex, c) else cells.add(c)
            row.copy(cells = cells)
        }

        // Adjust plColumn and groupColumn
        if (_plColumnIndex.value == fromIndex) {
            _plColumnIndex.value = toIndex
        } else if (_plColumnIndex.value != null) {
            val pl = _plColumnIndex.value!!
            if (fromIndex < toIndex && pl in (fromIndex + 1)..toIndex) {
                _plColumnIndex.value = pl - 1
            } else if (fromIndex > toIndex && pl in toIndex until fromIndex) {
                _plColumnIndex.value = pl + 1
            }
        }

        if (_groupColumnIndex.value == fromIndex) {
            _groupColumnIndex.value = toIndex
        } else if (_groupColumnIndex.value != null) {
            val grp = _groupColumnIndex.value!!
            if (fromIndex < toIndex && grp in (fromIndex + 1)..toIndex) {
                _groupColumnIndex.value = grp - 1
            } else if (fromIndex > toIndex && grp in toIndex until fromIndex) {
                _groupColumnIndex.value = grp + 1
            }
        }

        _gridData.value = currentGrid.copy(headers = newHeaders, rows = newRows)
    }

    private fun adjustColumnIndicesForInsert(insertIdx: Int) {
        val pl = _plColumnIndex.value
        if (pl != null && pl >= insertIdx) {
            _plColumnIndex.value = pl + 1
        }
        val grp = _groupColumnIndex.value
        if (grp != null && grp >= insertIdx) {
            _groupColumnIndex.value = grp + 1
        }
    }

    private fun adjustColumnIndicesForDelete(delIdx: Int) {
        val pl = _plColumnIndex.value
        if (pl != null) {
            when {
                pl == delIdx -> _plColumnIndex.value = null
                pl > delIdx -> _plColumnIndex.value = pl - 1
            }
        }
        val grp = _groupColumnIndex.value
        if (grp != null) {
            when {
                grp == delIdx -> _groupColumnIndex.value = null
                grp > delIdx -> _groupColumnIndex.value = grp - 1
            }
        }
    }

    // --- Filters & Sorting & Search ---
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun applyColumnFilter(colIndex: Int, selectedValues: Set<String>) {
        val current = _filterState.value
        val newFilters = current.columnFilters.toMutableMap()
        newFilters[colIndex] = ColumnFilter(selectedValues = selectedValues)
        _filterState.value = current.copy(columnFilters = newFilters)
    }

    fun clearColumnFilter(colIndex: Int) {
        val current = _filterState.value
        val newFilters = current.columnFilters.toMutableMap()
        newFilters.remove(colIndex)
        _filterState.value = current.copy(columnFilters = newFilters)
    }

    fun clearAllFilters() {
        _filterState.value = FilterState()
        _searchQuery.value = ""
    }

    fun setSort(colIndex: Int?, ascending: Boolean) {
        val current = _filterState.value
        _filterState.value = current.copy(
            sortColumnIndex = colIndex,
            sortAscending = ascending
        )
    }

    // --- Workbook Settings ---
    fun renameWorkbook(newName: String) {
        val clean = newName.trim()
        if (clean.isNotBlank()) {
            _workbookName.value = clean
        }
    }

    fun setPlColumnIndex(index: Int?) {
        _plColumnIndex.value = index
    }

    fun setGroupColumnIndex(index: Int?) {
        _groupColumnIndex.value = index
    }

    fun updateMoneyManagement(balance: Double, risk: Double): Boolean {
        if (balance <= 0 || risk <= 0 || risk > 100) return false
        _initialBalance.value = balance
        _riskPercent.value = risk
        return true
    }

    fun updateRrCap(cap: Double?): Boolean {
        if (cap != null && cap <= 0) return false
        _rrCap.value = cap
        return true
    }

    // --- Export ---
    suspend fun exportToXlsx(context: Context, uri: Uri, exportFilteredOnly: Boolean): Result<Unit> {
        val headers = _gridData.value.headers
        val rowsToExport = if (exportFilteredOnly) visibleRows.value else _gridData.value.rows
        return XlsxManager.exportToUri(context, uri, headers, rowsToExport)
    }

    // --- Internal Visible Rows Computation ---
    private fun computeVisibleRows(
        grid: GridData,
        filters: FilterState,
        searchQuery: String
    ): List<GridRow> {
        val normQuery = NumberUtils.normalizeText(searchQuery)
        val activeFilters = filters.columnFilters

        var result = grid.rows.filter { row ->
            // Search match: any cell matches query
            if (normQuery.isNotEmpty()) {
                val matchesSearch = row.cells.any { cell ->
                    NumberUtils.normalizeText(cell).contains(normQuery)
                }
                if (!matchesSearch) return@filter false
            }

            // Column filters match: all must match
            for ((colIdx, colFilter) in activeFilters) {
                val cellVal = row.cells.getOrNull(colIdx)?.trim() ?: ""
                val normCell = NumberUtils.normalizeText(cellVal)
                val matchesCol = colFilter.selectedValues.any { sel ->
                    NumberUtils.normalizeText(sel) == normCell
                }
                if (!matchesCol) return@filter false
            }

            true
        }

        // Apply sorting
        val sortCol = filters.sortColumnIndex
        if (sortCol != null && sortCol in grid.headers.indices) {
            val asc = filters.sortAscending
            // Check if column is mostly numeric
            val nonBlankCells = result.mapNotNull { it.cells.getOrNull(sortCol)?.trim() }.filter { it.isNotEmpty() }
            val numericCount = nonBlankCells.count { NumberUtils.isNumeric(it) }
            val isNumeric = nonBlankCells.isNotEmpty() && numericCount >= (nonBlankCells.size * 3) / 4

            result = if (isNumeric) {
                result.sortedWith { r1, r2 ->
                    val v1 = NumberUtils.parseDouble(r1.cells.getOrNull(sortCol))
                    val v2 = NumberUtils.parseDouble(r2.cells.getOrNull(sortCol))
                    val cmp = when {
                        v1 == null && v2 == null -> 0
                        v1 == null -> 1
                        v2 == null -> -1
                        else -> v1.compareTo(v2)
                    }
                    if (asc) cmp else -cmp
                }
            } else {
                result.sortedWith { r1, r2 ->
                    val s1 = r1.cells.getOrNull(sortCol) ?: ""
                    val s2 = r2.cells.getOrNull(sortCol) ?: ""
                    val cmp = s1.compareTo(s2, ignoreCase = true)
                    if (asc) cmp else -cmp
                }
            }
        }

        return result
    }
}

package ir.mahdi.backtesttable.data.excel

import android.content.Context
import android.net.Uri
import ir.mahdi.backtesttable.data.model.GridData
import ir.mahdi.backtesttable.data.model.GridRow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.poi.ss.usermodel.Cell
import org.apache.poi.ss.usermodel.CellType
import org.apache.poi.ss.usermodel.DateUtil
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Locale

object XlsxManager {

    suspend fun importFromUri(context: Context, uri: Uri): Result<GridData> = withContext(Dispatchers.IO) {
        try {
            val inputStream: InputStream = context.contentResolver.openInputStream(uri)
                ?: return@withContext Result.failure(Exception("قادر به باز کردن فایل اکسل انتخاب‌شده نیستیم"))

            inputStream.use { stream ->
                val workbook = XSSFWorkbook(stream)
                if (workbook.numberOfSheets == 0) {
                    return@withContext Result.failure(Exception("فایل اکسل حاوی هیچ برگه‌ای نیست"))
                }

                val sheet = workbook.getSheetAt(0)
                val rowIterator = sheet.iterator()

                var headers: List<String>? = null
                val rows = mutableListOf<GridRow>()
                var rowIdCounter = System.currentTimeMillis()

                var maxColumns = 0

                while (rowIterator.hasNext()) {
                    val poiRow = rowIterator.next()
                    val cellValues = mutableListOf<String>()
                    val lastCellNum = poiRow.lastCellNum.toInt()
                    if (lastCellNum <= 0) continue

                    var rowHasContent = false
                    for (c in 0 until lastCellNum) {
                        val cell = poiRow.getCell(c)
                        val text = getCellStringValue(cell)
                        if (text.isNotBlank()) rowHasContent = true
                        cellValues.add(text)
                    }

                    if (!rowHasContent) continue

                    if (headers == null) {
                        // Trim trailing blank headers
                        var lastNonEmpty = cellValues.size - 1
                        while (lastNonEmpty >= 0 && cellValues[lastNonEmpty].isBlank()) {
                            lastNonEmpty--
                        }
                        if (lastNonEmpty < 0) continue

                        val cleanedHeaders = cellValues.take(lastNonEmpty + 1).mapIndexed { idx, h ->
                            h.ifBlank { "ستون ${idx + 1}" }
                        }
                        headers = cleanedHeaders
                        maxColumns = cleanedHeaders.size
                    } else {
                        // Pad or truncate to maxColumns
                        val rowCells = ArrayList<String>(maxColumns)
                        for (i in 0 until maxColumns) {
                            rowCells.add(cellValues.getOrNull(i) ?: "")
                        }
                        rows.add(GridRow(id = rowIdCounter++, cells = rowCells))
                    }
                }

                workbook.close()

                if (headers.isNullOrEmpty()) {
                    return@withContext Result.failure(Exception("داده معتبری در برگه اول فایل اکسل یافت نشد"))
                }

                if (rows.isEmpty()) {
                    rows.add(GridRow(id = rowIdCounter, cells = List(headers.size) { "" }))
                }

                Result.success(GridData(headers = headers, rows = rows))
            }
        } catch (e: Exception) {
            Result.failure(Exception("خطا در خواندن فایل اکسل: ${e.localizedMessage ?: "فرمت نامعتبر"}"))
        }
    }

    suspend fun exportToUri(
        context: Context,
        uri: Uri,
        headers: List<String>,
        rows: List<GridRow>
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                ?: return@withContext Result.failure(Exception("قادر به ایجاد فایل خروجی نیستیم"))

            outputStream.use { stream ->
                val workbook = XSSFWorkbook()
                val sheet = workbook.createSheet("Backtest")

                // Write Header Row
                val headerRow = sheet.createRow(0)
                headers.forEachIndexed { index, headerTitle ->
                    val cell = headerRow.createCell(index)
                    cell.setCellValue(headerTitle)
                }

                // Write Data Rows
                rows.forEachIndexed { rowIndex, gridRow ->
                    val dataRow = sheet.createRow(rowIndex + 1)
                    headers.forEachIndexed { colIndex, _ ->
                        val cellValue = gridRow.cells.getOrNull(colIndex) ?: ""
                        val cell = dataRow.createCell(colIndex)
                        cell.setCellValue(cellValue)
                    }
                }

                workbook.write(stream)
                workbook.close()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(Exception("خطا در صدور فایل اکسل: ${e.localizedMessage ?: "خطای ناشناخته"}"))
        }
    }

    private fun getCellStringValue(cell: Cell?): String {
        if (cell == null) return ""
        return when (cell.cellType) {
            CellType.STRING -> cell.stringCellValue.trim()
            CellType.NUMERIC -> {
                if (DateUtil.isCellDateFormatted(cell)) {
                    val date = cell.dateCellValue
                    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                    sdf.format(date)
                } else {
                    val d = cell.numericCellValue
                    // Convert without trailing .0 for integers
                    if (d == d.toLong().toDouble() && !d.isInfinite() && !d.isNaN()) {
                        d.toLong().toString()
                    } else {
                        d.toString()
                    }
                }
            }
            CellType.BOOLEAN -> cell.booleanCellValue.toString()
            CellType.FORMULA -> {
                try {
                    val d = cell.numericCellValue
                    if (d == d.toLong().toDouble() && !d.isInfinite() && !d.isNaN()) {
                        d.toLong().toString()
                    } else {
                        d.toString()
                    }
                } catch (e: Exception) {
                    try {
                        cell.stringCellValue.trim()
                    } catch (e2: Exception) {
                        ""
                    }
                }
            }
            CellType.BLANK -> ""
            else -> ""
        }
    }
}

package ir.mahdi.backtesttable.ui.table

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.mahdi.backtesttable.data.NumberUtils

@Composable
fun RowActionDialog(
    rowNumber: Int,
    onDismiss: () -> Unit,
    onInsertAbove: () -> Unit,
    onInsertBelow: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    val persianRow = NumberUtils.toPersianDigits(rowNumber.toString())

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "عملیات ردیف $persianRow",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                RowItem(
                    icon = Icons.Default.Add,
                    label = "درج ردیف در بالا",
                    onClick = {
                        onInsertAbove()
                        onDismiss()
                    }
                )

                RowItem(
                    icon = Icons.Default.Add,
                    label = "درج ردیف در پایین",
                    onClick = {
                        onInsertBelow()
                        onDismiss()
                    }
                )

                RowItem(
                    icon = Icons.Default.ContentCopy,
                    label = "تکرار ردیف (کپی)",
                    onClick = {
                        onDuplicate()
                        onDismiss()
                    }
                )

                Divider()

                RowItem(
                    icon = Icons.Default.Delete,
                    label = "حذف این ردیف",
                    isDestructive = true,
                    onClick = {
                        onDelete()
                        onDismiss()
                    }
                )
            }
        },
        confirmButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("بستن")
            }
        }
    )
}

@Composable
private fun RowItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isDestructive: Boolean = false,
    onClick: () -> Unit
) {
    val color = if (isDestructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = color)
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = color,
            fontWeight = if (isDestructive) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

package ir.mahdi.backtesttable.data.ai

data class AiChatMessage(
    val role: String, // "user" or "model" / "assistant"
    val content: String
)

interface AiClient {
    suspend fun streamChat(
        messages: List<AiChatMessage>,
        systemInstruction: String,
        onToken: (String) -> Unit
    ): Result<String>

    suspend fun testConnection(): Result<Unit>
}

object AiErrorMapper {
    fun mapException(e: Throwable): String {
        val msg = e.message ?: ""
        return when {
            msg.contains("NO_KEY", ignoreCase = true) -> "کلید API یافت نشد؛ لطفاً در تنظیمات کلید را وارد کنید."
            msg.contains("401") || msg.contains("403") -> "کلید API نامعتبر است"
            msg.contains("429") -> "محدودیت تعداد درخواست؛ کمی بعد دوباره تلاش کنید"
            msg.contains("404") || msg.contains("MODEL_NOT_FOUND", ignoreCase = true) -> "مدل یافت نشد؛ نام مدل را در تنظیمات (بخش پیشرفته) بررسی کنید"
            msg.contains("INVALID_URL", ignoreCase = true) || msg.contains("UnknownHostException", ignoreCase = true) -> "آدرس پایه نامعتبر یا در دسترس نیست"
            msg.contains("SocketTimeoutException", ignoreCase = true) || msg.contains("ConnectException", ignoreCase = true) -> "عدم اتصال به اینترنت"
            else -> e.localizedMessage?.takeIf { it.isNotBlank() } ?: "خطا در برقراری ارتباط با سرویس هوش مصنوعی؛ تلاش مجدد"
        }
    }
}

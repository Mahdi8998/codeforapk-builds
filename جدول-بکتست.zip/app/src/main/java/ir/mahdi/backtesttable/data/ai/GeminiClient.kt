package ir.mahdi.backtesttable.data.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

class GeminiClient(
    private val apiKey: String,
    private val modelName: String,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
) : AiClient {

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    override suspend fun testConnection(): Result<Unit> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(Exception("NO_KEY"))
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent"
        val payload = JSONObject().apply {
            val contents = JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", "ping"))
                    })
                })
            }
            put("contents", contents)
            put("generationConfig", JSONObject().put("maxOutputTokens", 5))
        }

        val request = Request.Builder()
            .url(url)
            .addHeader("x-goog-api-key", apiKey)
            .post(payload.toString().toRequestBody(jsonMediaType))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(Unit)
                } else {
                    val code = response.code
                    val errorBody = response.body?.string() ?: ""
                    Result.failure(Exception("HTTP $code: $errorBody"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun streamChat(
        messages: List<AiChatMessage>,
        systemInstruction: String,
        onToken: (String) -> Unit
    ): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(Exception("NO_KEY"))
        }

        val streamUrl = "https://generativelanguage.googleapis.com/v1beta/models/${modelName}:streamGenerateContent?alt=sse"

        val requestJson = buildRequestBody(messages, systemInstruction)
        val request = Request.Builder()
            .url(streamUrl)
            .addHeader("x-goog-api-key", apiKey)
            .post(requestJson.toString().toRequestBody(jsonMediaType))
            .build()

        val fullResponse = StringBuilder()

        try {
            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                val code = response.code
                val err = response.body?.string() ?: ""
                response.close()

                // Fall back to non-streaming if stream endpoint failed with 4xx or other
                if (code == 404) {
                    return@withContext Result.failure(Exception("HTTP 404 MODEL_NOT_FOUND"))
                }
                return@withContext executeNonStreaming(messages, systemInstruction)
            }

            val body = response.body ?: return@withContext Result.failure(Exception("Empty response body"))
            val reader = BufferedReader(InputStreamReader(body.byteStream()))

            var line: String?
            while (reader.readLine().also { line = it } != null) {
                val currentLine = line ?: break
                if (currentLine.startsWith("data:")) {
                    val data = currentLine.removePrefix("data:").trim()
                    if (data.isNotEmpty()) {
                        try {
                            val chunkObj = JSONObject(data)
                            val candidates = chunkObj.optJSONArray("candidates")
                            if (candidates != null && candidates.length() > 0) {
                                val cand = candidates.getJSONObject(0)
                                val content = cand.optJSONObject("content")
                                val parts = content?.optJSONArray("parts")
                                if (parts != null && parts.length() > 0) {
                                    val text = parts.getJSONObject(0).optString("text", "")
                                    if (text.isNotEmpty()) {
                                        fullResponse.append(text)
                                        withContext(Dispatchers.Main) {
                                            onToken(text)
                                        }
                                    }
                                }
                            }
                        } catch (ignored: Exception) {
                            // Non-JSON SSE event
                        }
                    }
                }
            }
            response.close()

            if (fullResponse.isEmpty()) {
                // If stream was empty, try fallback
                return@withContext executeNonStreaming(messages, systemInstruction)
            }

            Result.success(fullResponse.toString())
        } catch (e: Exception) {
            // Try fallback
            try {
                executeNonStreaming(messages, systemInstruction)
            } catch (fallbackError: Exception) {
                Result.failure(e)
            }
        }
    }

    private suspend fun executeNonStreaming(
        messages: List<AiChatMessage>,
        systemInstruction: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val nonStreamUrl = "https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent"
        val requestJson = buildRequestBody(messages, systemInstruction)
        val request = Request.Builder()
            .url(nonStreamUrl)
            .addHeader("x-goog-api-key", apiKey)
            .post(requestJson.toString().toRequestBody(jsonMediaType))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val code = response.code
                    val err = response.body?.string() ?: ""
                    return@withContext Result.failure(Exception("HTTP $code: $err"))
                }
                val bodyStr = response.body?.string() ?: ""
                val obj = JSONObject(bodyStr)
                val candidates = obj.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val cand = candidates.getJSONObject(0)
                    val content = cand.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        val text = parts.getJSONObject(0).optString("text", "")
                        return@withContext Result.success(text)
                    }
                }
                Result.success("")
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun buildRequestBody(messages: List<AiChatMessage>, systemInstruction: String): JSONObject {
        return JSONObject().apply {
            if (systemInstruction.isNotBlank()) {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", systemInstruction))
                    })
                })
            }
            val contents = JSONArray()
            for (msg in messages) {
                contents.put(JSONObject().apply {
                    put("role", if (msg.role == "model" || msg.role == "assistant") "model" else "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", msg.content))
                    })
                })
            }
            put("contents", contents)
        }
    }
}

package ir.mahdi.backtesttable.ui.table

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Summarize
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.mahdi.backtesttable.data.settings.AppSettings
import ir.mahdi.backtesttable.ui.ai.AiViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

enum class TableScreenTab(val title: String) {
    GRID("جدول"),
    STATS("آمار"),
    SUMMARY("خلاصه"),
    AI("تحلیلگر AI")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TableScreen(
    tableViewModel: TableViewModel,
    aiViewModel: AiViewModel,
    settings: AppSettings,
    onNavigateBack: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val workbookName by tableViewModel.workbookName.collectAsState()
    val gridData by tableViewModel.gridData.collectAsState()
    val filterState by tableViewModel.filterState.collectAsState()
    val searchQuery by tableViewModel.searchQuery.collectAsState()
    val plColumnIndex by tableViewModel.plColumnIndex.collectAsState()
    val groupColumnIndex by tableViewModel.groupColumnIndex.collectAsState()
    val initialBalance by tableViewModel.initialBalance.collectAsState()
    val riskPercent by tableViewModel.riskPercent.collectAsState()
    val rrCap by tableViewModel.rrCap.collectAsState()
    val visibleRows by tableViewModel.visibleRows.collectAsState()
    val statsResult by tableViewModel.statsResult.collectAsState()
    val canUndo by tableViewModel.canUndo.collectAsState()
    val canRedo by tableViewModel.canRedo.collectAsState()

    var selectedTab by remember { mutableStateOf(TableScreenTab.GRID) }
    var isSearchActive by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showTableSettingsDialog by remember { mutableStateOf(false) }
    var activeFilterColIndex by remember { mutableStateOf<Int?>(null) }

    // Export Excel Dialog State
    var showExportDialog by remember { mutableStateOf(false) }
    var exportFilteredOnly by remember { mutableStateOf(false) }

    // SAF Document Creator for XLSX export
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                val res = tableViewModel.exportToXlsx(context, uri, exportFilteredOnly)
                res.fold(
                    onSuccess = {
                        snackbarHostState.showSnackbar("فایل اکسل با موفقیت ذخیره شد")
                    },
                    onFailure = { err ->
                        snackbarHostState.showSnackbar(err.message ?: "خطا در صدور اکسل")
                    }
                )
            }
        }
    }

    LaunchedEffect(Unit) {
        tableViewModel.saveMessage.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    if (isSearchActive) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { tableViewModel.setSearchQuery(it) },
                            placeholder = { Text("جستجو در تمام خانه‌ها...") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            trailingIcon = {
                                IconButton(onClick = {
                                    tableViewModel.setSearchQuery("")
                                    isSearchActive = false
                                }) {
                                    Icon(Icons.Default.Close, contentDescription = "بستن جستجو")
                                }
                            }
                        )
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { showRenameDialog = true }
                        ) {
                            Text(
                                text = workbookName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                Icons.Default.Edit,
                                contentDescription = "تغییر نام جدول",
                                modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                actions = {
                    if (!isSearchActive) {
                        // Undo
                        IconButton(
                            onClick = { tableViewModel.undo() },
                            enabled = canUndo
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "بازگردانی")
                        }

                        // Redo
                        IconButton(
                            onClick = { tableViewModel.redo() },
                            enabled = canRedo
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "انجام مجدد")
                        }

                        // Search
                        IconButton(onClick = { isSearchActive = true }) {
                            Icon(Icons.Default.Search, contentDescription = "جستجو")
                        }

                        // Save
                        IconButton(onClick = { tableViewModel.manualSave() }) {
                            Icon(Icons.Default.Save, contentDescription = "ذخیره")
                        }

                        // More Menu
                        IconButton(onClick = { showMenu = !showMenu }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "گزینه‌های بیشتر")
                        }

                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("تنظیمات جدول و مدیریت ریسک") },
                                leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null) },
                                onClick = {
                                    showMenu = false
                                    showTableSettingsDialog = true
                                }
                            )

                            DropdownMenuItem(
                                text = { Text("خروجی فایل اکسل (XLSX)") },
                                leadingIcon = { Icon(Icons.Default.FileUpload, contentDescription = null) },
                                onClick = {
                                    showMenu = false
                                    val isFilterActive = visibleRows.size < gridData.rows.size || filterState.columnFilters.isNotEmpty()
                                    if (isFilterActive) {
                                        showExportDialog = true
                                    } else {
                                        exportFilteredOnly = false
                                        exportLauncher.launch("$workbookName.xlsx")
                                    }
                                }
                            )

                            DropdownMenuItem(
                                text = { Text("تنظیمات کلی برنامه و هوش مصنوعی") },
                                leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null) },
                                onClick = {
                                    showMenu = false
                                    onNavigateToSettings()
                                }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == TableScreenTab.GRID,
                    onClick = { selectedTab = TableScreenTab.GRID },
                    icon = { Icon(Icons.Default.TableChart, contentDescription = null) },
                    label = { Text(TableScreenTab.GRID.title) }
                )

                NavigationBarItem(
                    selected = selectedTab == TableScreenTab.STATS,
                    onClick = { selectedTab = TableScreenTab.STATS },
                    icon = { Icon(Icons.Default.QueryStats, contentDescription = null) },
                    label = { Text(TableScreenTab.STATS.title) }
                )

                NavigationBarItem(
                    selected = selectedTab == TableScreenTab.SUMMARY,
                    onClick = { selectedTab = TableScreenTab.SUMMARY },
                    icon = { Icon(Icons.Default.Summarize, contentDescription = null) },
                    label = { Text(TableScreenTab.SUMMARY.title) }
                )

                NavigationBarItem(
                    selected = selectedTab == TableScreenTab.AI,
                    onClick = { selectedTab = TableScreenTab.AI },
                    icon = { Icon(Icons.Default.AutoAwesome, contentDescription = null) },
                    label = { Text(TableScreenTab.AI.title) }
                )
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (selectedTab) {
                TableScreenTab.GRID -> {
                    GridTab(
                        gridData = gridData,
                        visibleRows = visibleRows,
                        filterState = filterState,
                        plColumnIndex = plColumnIndex,
                        groupColumnIndex = groupColumnIndex,
                        onUpdateCell = { rowId, colIdx, value ->
                            tableViewModel.updateCell(rowId, colIdx, value)
                        },
                        onAddRow = { tableViewModel.addBlankRowAtEnd() },
                        onInsertRowAbove = { tableViewModel.insertRowAbove(it) },
                        onInsertRowBelow = { tableViewModel.insertRowBelow(it) },
                        onDuplicateRow = { tableViewModel.duplicateRow(it) },
                        onDeleteRow = { tableViewModel.deleteRow(it) },
                        onRenameColumn = { colIdx, name -> tableViewModel.renameColumn(colIdx, name) },
                        onInsertColumnLeft = { tableViewModel.insertColumnLeft(it) },
                        onInsertColumnRight = { tableViewModel.insertColumnRight(it) },
                        onDeleteColumn = { tableViewModel.deleteColumn(it) },
                        onMoveColumn = { from, to -> tableViewModel.moveColumn(from, to) },
                        onTogglePlColumn = { colIdx ->
                            tableViewModel.setPlColumnIndex(if (plColumnIndex == colIdx) null else colIdx)
                        },
                        onToggleGroupColumn = { colIdx ->
                            tableViewModel.setGroupColumnIndex(if (groupColumnIndex == colIdx) null else colIdx)
                        },
                        onOpenFilterSheet = { colIdx -> activeFilterColIndex = colIdx },
                        onClearAllFilters = { tableViewModel.clearAllFilters() }
                    )
                }
                TableScreenTab.STATS -> {
                    StatsTab(
                        statsResult = statsResult,
                        headers = gridData.headers,
                        plColumnIndex = plColumnIndex,
                        groupColumnIndex = groupColumnIndex,
                        rrCap = rrCap,
                        initialBalance = initialBalance,
                        riskPercent = riskPercent,
                        onOpenSettings = { showTableSettingsDialog = true }
                    )
                }
                TableScreenTab.SUMMARY -> {
                    SummaryTab(
                        totalRowCount = gridData.rows.size,
                        statsResult = statsResult
                    )
                }
                TableScreenTab.AI -> {
                    AiTab(
                        aiViewModel = aiViewModel,
                        settings = settings,
                        headers = gridData.headers,
                        visibleRows = visibleRows,
                        totalRowCount = gridData.rows.size,
                        filterState = filterState,
                        searchQuery = searchQuery,
                        plColumnIndex = plColumnIndex,
                        groupColumnIndex = groupColumnIndex,
                        initialBalance = initialBalance,
                        riskPercent = riskPercent,
                        rrCap = rrCap,
                        statsResult = statsResult,
                        onNavigateToSettings = onNavigateToSettings
                    )
                }
            }
        }
    }

    // Rename Dialog
    if (showRenameDialog) {
        var tempName by remember { mutableStateOf(workbookName) }
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = { Text("تغییر نام جدول") },
            text = {
                OutlinedTextField(
                    value = tempName,
                    onValueChange = { tempName = it },
                    label = { Text("نام جدول") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                OutlinedButton(
                    onClick = {
                        tableViewModel.renameWorkbook(tempName)
                        showRenameDialog = false
                    }
                ) {
                    Text("تأیید")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showRenameDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }

    // Table Settings Dialog
    if (showTableSettingsDialog) {
        TableSettingsDialog(
            headers = gridData.headers,
            currentPlIndex = plColumnIndex,
            currentGroupIndex = groupColumnIndex,
            initialBalance = initialBalance,
            riskPercent = riskPercent,
            currentRrCap = rrCap,
            onDismiss = { showTableSettingsDialog = false },
            onSave = { newPl, newGrp, newBal, newRisk, newCap ->
                tableViewModel.setPlColumnIndex(newPl)
                tableViewModel.setGroupColumnIndex(newGrp)
                tableViewModel.updateMoneyManagement(newBal, newRisk)
                tableViewModel.updateRrCap(newCap)
            }
        )
    }

    // Column Filter Bottom Sheet
    activeFilterColIndex?.let { colIdx ->
        val colTitle = gridData.headers.getOrNull(colIdx) ?: ""
        val currentFilter = filterState.columnFilters[colIdx]

        ColumnFilterSheet(
            columnIndex = colIdx,
            columnTitle = colTitle,
            allRows = gridData.rows,
            currentlySelectedValues = currentFilter?.selectedValues,
            onDismiss = { activeFilterColIndex = null },
            onApplyFilter = { selected ->
                tableViewModel.applyColumnFilter(colIdx, selected)
                activeFilterColIndex = null
            },
            onClearFilter = {
                tableViewModel.clearColumnFilter(colIdx)
                activeFilterColIndex = null
            },
            onSort = { asc ->
                tableViewModel.setSort(colIdx, asc)
                activeFilterColIndex = null
            }
        )
    }

    // Export Options Dialog (If filters are active)
    if (showExportDialog) {
        var exportChoiceFiltered by remember { mutableStateOf(true) }

        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = { Text("خروجی اکسل (XLSX)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("فیلتر روی جدول شما فعال است. کدام ردیف‌ها صادر شوند؟")

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { exportChoiceFiltered = true }
                    ) {
                        RadioButton(
                            selected = exportChoiceFiltered,
                            onClick = { exportChoiceFiltered = true }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("فقط ردیف‌های فیلترشده (${visibleRows.size} ردیف)")
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { exportChoiceFiltered = false }
                    ) {
                        RadioButton(
                            selected = !exportChoiceFiltered,
                            onClick = { exportChoiceFiltered = false }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("همه ردیف‌های جدول (${gridData.rows.size} ردیف)")
                    }
                }
            },
            confirmButton = {
                OutlinedButton(
                    onClick = {
                        showExportDialog = false
                        exportFilteredOnly = exportChoiceFiltered
                        exportLauncher.launch("$workbookName.xlsx")
                    }
                ) {
                    Text("انتخاب محل ذخیره")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showExportDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }
}

package ir.mahdi.backtesttable.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.mahdi.backtesttable.data.ai.AiErrorMapper
import ir.mahdi.backtesttable.data.ai.GeminiClient
import ir.mahdi.backtesttable.data.ai.OpenAiClient
import ir.mahdi.backtesttable.data.settings.AiProviderType
import ir.mahdi.backtesttable.data.settings.AppSettings
import ir.mahdi.backtesttable.data.settings.AppSettingsRepository
import ir.mahdi.backtesttable.data.settings.AppThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(private val repository: AppSettingsRepository) : ViewModel() {

    val settings: StateFlow<AppSettings> = repository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    private val _testStatus = MutableStateFlow<String?>(null)
    val testStatus: StateFlow<String?> = _testStatus.asStateFlow()

    private val _isTesting = MutableStateFlow(false)
    val isTesting: StateFlow<Boolean> = _isTesting.asStateFlow()

    fun updateTheme(mode: AppThemeMode) {
        viewModelScope.launch { repository.updateTheme(mode) }
    }

    fun updateAiProvider(provider: AiProviderType) {
        viewModelScope.launch { repository.updateAiProvider(provider) }
    }

    fun updateGeminiApiKey(key: String) {
        viewModelScope.launch { repository.updateGeminiApiKey(key) }
    }

    fun updateGeminiModel(model: String) {
        viewModelScope.launch { repository.updateGeminiModel(model) }
    }

    fun resetGeminiModel() {
        viewModelScope.launch { repository.resetGeminiModelToDefault() }
    }

    fun updateOpenAiSettings(baseUrl: String, model: String, apiKey: String) {
        viewModelScope.launch { repository.updateOpenAiSettings(baseUrl, model, apiKey) }
    }

    fun testConnection(onResult: (String, Boolean) -> Unit) {
        viewModelScope.launch {
            _isTesting.value = true
            val current = settings.value
            val client = when (current.activeAiProvider) {
                AiProviderType.GEMINI -> {
                    if (current.geminiApiKey.isBlank()) {
                        _isTesting.value = false
                        onResult("کلید API گوگل Gemini وارد نشده است", false)
                        return@launch
                    }
                    GeminiClient(current.geminiApiKey, current.geminiModel)
                }
                AiProviderType.OPENAI -> {
                    if (!current.openAiBaseUrl.trim().startsWith("https://", ignoreCase = true)) {
                        _isTesting.value = false
                        onResult("آدرس باید با https:// شروع شود", false)
                        return@launch
                    }
                    if (current.openAiApiKey.isBlank()) {
                        _isTesting.value = false
                        onResult("کلید API وارد نشده است", false)
                        return@launch
                    }
                    OpenAiClient(current.openAiBaseUrl, current.openAiModel, current.openAiApiKey)
                }
            }

            val result = client.testConnection()
            _isTesting.value = false
            result.fold(
                onSuccess = {
                    onResult("اتصال برقرار است ✅", true)
                },
                onFailure = { error ->
                    val persianMsg = AiErrorMapper.mapException(error)
                    onResult(persianMsg, false)
                }
            )
        }
    }
}

package ir.mahdi.backtesttable.data

import ir.mahdi.backtesttable.data.db.WorkbookEntity
import ir.mahdi.backtesttable.data.model.GridData
import ir.mahdi.backtesttable.data.model.GridRow

object SampleDataGenerator {

    fun createSampleWorkbook(): WorkbookEntity {
        val headers = listOf(
            "تاریخ",
            "جفت‌ارز",
            "جهت",
            "قیمت ورود",
            "قیمت خروج",
            "حجم",
            "نتیجه",
            "توضیحات"
        )

        // 40 realistic rows:
        // ~45% '-' (18 rows), ~30% '1' (12 rows), ~15% '2' (6 rows), ~10% '3' (4 rows), plus 3-4 empty cells
        val sampleTrades = listOf(
            TradeSpec("2024-05-01", "EURUSD", "خرید", "1.0720", "1.0695", "0.5", "-", "شکست سطح حمایتی"),
            TradeSpec("2024-05-02", "GBPUSD", "خرید", "1.2540", "1.2610", "0.5", "1", "برخورد به تارگت اول"),
            TradeSpec("2024-05-03", "USDJPY", "فروش", "154.20", "153.10", "0.4", "2", "واگرایی مکدی در مقاومت"),
            TradeSpec("2024-05-04", "XAUUSD", "خرید", "2310.5", "2335.0", "0.2", "3", "موج جنبشی قدرتمند طلا"),
            TradeSpec("2024-05-06", "EURUSD", "فروش", "1.0760", "1.0785", "0.5", "-", "استاپ هانت لندن"),
            TradeSpec("2024-05-07", "USDJPY", "خرید", "154.50", "154.10", "0.4", "-", "فشار فروش پیش‌بینی نشده"),
            TradeSpec("2024-05-08", "GBPUSD", "فروش", "1.2590", "1.2530", "0.5", "1", "پولبک به خط روند"),
            TradeSpec("2024-05-09", "XAUUSD", "فروش", "2340.0", "2355.0", "0.2", "-", "خبر تورم آمریکا"),
            TradeSpec("2024-05-10", "EURUSD", "خرید", "1.0770", "1.0840", "0.5", "2", "سقف دوقلو شکسته شد"),
            TradeSpec("2024-05-13", "USDJPY", "فروش", "155.80", "155.20", "0.4", "1", "اصلاح فیبوناچی ۶۱.۸"),
            TradeSpec("2024-05-14", "GBPUSD", "خرید", "1.2510", "1.2480", "0.5", "-", "استاپ روی ساپورت"),
            TradeSpec("2024-05-15", "XAUUSD", "خرید", "2360.0", "2395.0", "0.2", "3", "رالی صعودی اونس"),
            TradeSpec("2024-05-16", "EURUSD", "خرید", "1.0820", "1.0860", "0.5", "1", "بریک‌اوت کانال رنج"),
            TradeSpec("2024-05-17", "USDJPY", "فروش", "156.30", "156.75", "0.4", "-", "ادامه روند صعودی دلار"),
            TradeSpec("2024-05-20", "GBPUSD", "فروش", "1.2720", "1.2750", "0.5", "-", "شکست فیک خط روند"),
            TradeSpec("2024-05-21", "EURUSD", "فروش", "1.0880", "1.0810", "0.5", "2", "ریجکت از عرضه روزانه"),
            TradeSpec("2024-05-22", "XAUUSD", "خرید", "2410.0", "2395.0", "0.2", "-", "ریزش شارپ در نیویورک"),
            TradeSpec("2024-05-23", "USDJPY", "خرید", "156.80", "157.40", "0.4", "1", "تثبیت بالای مقاومت"),
            TradeSpec("2024-05-24", "GBPUSD", "خرید", "1.2700", "1.2670", "0.5", "-", "استاپ خورد"),
            TradeSpec("2024-05-27", "EURUSD", "خرید", "1.0850", "1.0890", "0.5", "1", "سیگنال الگوی پین‌بار"),
            TradeSpec("2024-05-28", "XAUUSD", "فروش", "2350.0", "2315.0", "0.2", "3", "تارگت سه در کف رنج"),
            TradeSpec("2024-05-29", "USDJPY", "فروش", "157.60", "158.10", "0.4", "-", "فشار خرید روی ین"),
            TradeSpec("2024-05-30", "GBPUSD", "فروش", "1.2750", "1.2680", "0.5", "2", "الگوی سر و شانه"),
            TradeSpec("2024-05-31", "EURUSD", "فروش", "1.0840", "1.0875", "0.5", "-", "استاپ با اسپرد شبانه"),
            TradeSpec("2024-06-03", "XAUUSD", "خرید", "2325.0", "2310.0", "0.2", "-", "نفوذ به زیر حمایت"),
            TradeSpec("2024-06-04", "USDJPY", "خرید", "155.00", "155.60", "0.4", "1", "تایید تقاضای ۴ ساعته"),
            TradeSpec("2024-06-05", "GBPUSD", "خرید", "1.2780", "1.2740", "0.5", "-", "فیک بریک لندن"),
            TradeSpec("2024-06-06", "EURUSD", "خرید", "1.0870", "1.0910", "0.5", "1", "جلسه بانک مرکزی اروپا"),
            TradeSpec("2024-06-07", "XAUUSD", "فروش", "2385.0", "2300.0", "0.2", "3", "ریزش شدید ان‌اف‌پی"),
            TradeSpec("2024-06-10", "USDJPY", "فروش", "157.00", "157.45", "0.4", "-", "تثبیت نشد"),
            TradeSpec("2024-06-11", "GBPUSD", "فروش", "1.2730", "1.2660", "0.5", "2", "تارگت دوم محقق شد"),
            TradeSpec("2024-06-12", "EURUSD", "فروش", "1.0810", "1.0845", "0.5", "-", "استاپ خورد"),
            TradeSpec("2024-06-13", "XAUUSD", "خرید", "2315.0", "2300.0", "0.2", "-", "فشار نزولی ادامه‌دار"),
            TradeSpec("2024-06-14", "USDJPY", "خرید", "157.20", "157.80", "0.4", "1", "حرکت بعد از خبر"),
            TradeSpec("2024-06-17", "GBPUSD", "خرید", "1.2680", "1.2650", "0.5", "-", "استاپ خورد"),
            TradeSpec("2024-06-18", "EURUSD", "خرید", "1.0730", "1.0790", "0.5", "2", "واکنش عالی به FVG"),
            TradeSpec("2024-06-19", "XAUUSD", "خرید", "2330.0", "2330.0", "0.2", "", "معامله در جریان - بدون نتیجه"),
            TradeSpec("2024-06-20", "USDJPY", "فروش", "158.00", "158.00", "0.4", "", "بدون نتیجه هنوز"),
            TradeSpec("2024-06-21", "GBPUSD", "خرید", "1.2650", "1.2650", "0.5", "", "پوزیشن باز"),
            TradeSpec("2024-06-24", "EURUSD", "فروش", "1.0710", "1.0745", "0.5", "-", "استاپ خورد")
        )

        var rowId = 1000L
        val rows = sampleTrades.map { spec ->
            GridRow(
                id = rowId++,
                cells = listOf(
                    spec.date,
                    spec.symbol,
                    spec.direction,
                    spec.entry,
                    spec.exit,
                    spec.volume,
                    spec.result,
                    spec.note
                )
            )
        }

        val grid = GridData(headers = headers, rows = rows)

        return WorkbookEntity(
            name = "جدول نمونه استراتژی فارکس",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            gridJson = grid.toJson(),
            filterStateJson = "",
            plColumnIndex = 6,
            groupColumnIndex = 1,
            initialBalance = 500.0,
            riskPercent = 2.0,
            rrCap = null
        )
    }

    private data class TradeSpec(
        val date: String,
        val symbol: String,
        val direction: String,
        val entry: String,
        val exit: String,
        val volume: String,
        val result: String,
        val note: String
    )
}

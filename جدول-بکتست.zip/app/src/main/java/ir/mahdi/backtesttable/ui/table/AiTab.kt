package ir.mahdi.backtesttable.ui.table

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.mahdi.backtesttable.R
import ir.mahdi.backtesttable.data.NumberUtils
import ir.mahdi.backtesttable.data.ai.AiDataMode
import ir.mahdi.backtesttable.data.model.FilterState
import ir.mahdi.backtesttable.data.model.GridRow
import ir.mahdi.backtesttable.data.settings.AppSettings
import ir.mahdi.backtesttable.data.stats.StatsResult
import ir.mahdi.backtesttable.ui.ai.AiViewModel
import ir.mahdi.backtesttable.ui.ai.ChatUiMessage
import ir.mahdi.backtesttable.ui.ai.PresetQueryType

@Composable
fun AiTab(
    aiViewModel: AiViewModel,
    settings: AppSettings,
    headers: List<String>,
    visibleRows: List<GridRow>,
    totalRowCount: Int,
    filterState: FilterState,
    searchQuery: String,
    plColumnIndex: Int?,
    groupColumnIndex: Int?,
    initialBalance: Double,
    riskPercent: Double,
    rrCap: Double?,
    statsResult: StatsResult,
    onNavigateToSettings: () -> Unit
) {
    val messages by aiViewModel.messages.collectAsState()
    val dataMode by aiViewModel.dataMode.collectAsState()
    val isLoading by aiViewModel.isLoading.collectAsState()
    val showOver500Dialog by aiViewModel.showOver500RowsDialog.collectAsState()

    var inputQuery by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val context = LocalContext.current

    LaunchedEffect(messages.size, messages.lastOrNull()?.content?.length) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val isFiltered = visibleRows.size < totalRowCount || filterState.columnFilters.isNotEmpty()

    Column(modifier = Modifier.fillMaxSize()) {
        // 1. Scope Banner & Mode Selector Bar
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isFiltered) {
                            "تحلیل روی ردیف‌های فیلترشده (${NumberUtils.formatInt(visibleRows.size)} از ${NumberUtils.formatInt(totalRowCount)})"
                        } else {
                            "تحلیل روی کل جدول (${NumberUtils.formatInt(totalRowCount)} ردیف)"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Row {
                        IconButton(
                            onClick = { aiViewModel.clearChat() },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                Icons.Default.Delete,
                                contentDescription = "چت جدید",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        IconButton(
                            onClick = onNavigateToSettings,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                Icons.Default.Settings,
                                contentDescription = "تنظیمات هوش مصنوعی",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Mode Selector Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "حالت ارسال داده:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    FilterChip(
                        selected = dataMode == AiDataMode.FULL,
                        onClick = { aiViewModel.setDataMode(AiDataMode.FULL) },
                        label = { Text("کامل (تمام سطرها)") }
                    )
                    FilterChip(
                        selected = dataMode == AiDataMode.SUMMARY,
                        onClick = { aiViewModel.setDataMode(AiDataMode.SUMMARY) },
                        label = { Text("خلاصه آماری + نمونه") }
                    )
                }
            }
        }

        // 2. Preset Prompt Buttons (Horizontal scroll)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            PresetButton(
                title = "تحلیل کلی استراتژی",
                enabled = !isLoading,
                onClick = {
                    aiViewModel.sendPresetQuery(
                        PresetQueryType.OVERALL_STRATEGY,
                        settings, headers, visibleRows, totalRowCount, filterState, searchQuery,
                        plColumnIndex, groupColumnIndex, initialBalance, riskPercent, rrCap, statsResult
                    )
                }
            )

            PresetButton(
                title = "بررسی باخت‌ها",
                enabled = !isLoading,
                onClick = {
                    aiViewModel.sendPresetQuery(
                        PresetQueryType.LOSS_ANALYSIS,
                        settings, headers, visibleRows, totalRowCount, filterState, searchQuery,
                        plColumnIndex, groupColumnIndex, initialBalance, riskPercent, rrCap, statsResult
                    )
                }
            )

            PresetButton(
                title = "مدیریت ریسک و حجم",
                enabled = !isLoading,
                onClick = {
                    aiViewModel.sendPresetQuery(
                        PresetQueryType.RISK_MANAGEMENT,
                        settings, headers, visibleRows, totalRowCount, filterState, searchQuery,
                        plColumnIndex, groupColumnIndex, initialBalance, riskPercent, rrCap, statsResult
                    )
                }
            )

            PresetButton(
                title = "پیشنهاد بهبود",
                enabled = !isLoading,
                onClick = {
                    aiViewModel.sendPresetQuery(
                        PresetQueryType.IMPROVEMENT_SUGGESTIONS,
                        settings, headers, visibleRows, totalRowCount, filterState, searchQuery,
                        plColumnIndex, groupColumnIndex, initialBalance, riskPercent, rrCap, statsResult
                    )
                }
            )
        }

        Divider()

        // 3. Chat Messages / Empty State
        if (messages.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.empty_ai),
                        contentDescription = null,
                        modifier = Modifier
                            .size(130.dp)
                            .clip(RoundedCornerShape(12.dp))
                    )
                    Text(
                        text = "تحلیلگر هوشمند استراتژی معاملاتی",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "داده‌های جدول شما به عنوان بستر تحلیلی در اختیار هوش مصنوعی قرار می‌گیرد تا نقاط قوت، ضعف و الگوهای معاملاتی را با دیدگاه حرفه‌ای بررسی کند.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "برای شروع، یکی از دکمه‌های آماده بالا را انتخاب کنید یا پرسش خود را در کادر زیر بنویسید.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    ChatBubble(
                        message = msg,
                        onCopy = { text ->
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("AI Response", text))
                            Toast.makeText(context, "پاسخ در حافظه کپی شد", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }

        // 4. Input Text Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 3.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputQuery,
                    onValueChange = { inputQuery = it },
                    placeholder = { Text("پرسش خود از تحلیلگر هوش مصنوعی...") },
                    modifier = Modifier.weight(1f),
                    maxLines = 3,
                    shape = RoundedCornerShape(24.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = {
                        val q = inputQuery
                        inputQuery = ""
                        aiViewModel.sendMessage(
                            q, settings, headers, visibleRows, totalRowCount, filterState, searchQuery,
                            plColumnIndex, groupColumnIndex, initialBalance, riskPercent, rrCap, statsResult
                        )
                    },
                    enabled = inputQuery.isNotBlank() && !isLoading,
                    modifier = Modifier
                        .size(48.dp)
                        .background(
                            if (inputQuery.isNotBlank() && !isLoading) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            CircleShape
                        )
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            Icons.Default.Send,
                            contentDescription = "ارسال",
                            tint = if (inputQuery.isNotBlank()) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }

    // Over 500 rows dialog for FULL mode
    if (showOver500Dialog) {
        AlertDialog(
            onDismissRequest = { aiViewModel.dismissOver500Dialog() },
            title = { Text("حجم زیاد داده‌های جدول") },
            text = {
                Text("جدول شما دارای بیش از ۵۰۰ ردیف است. ارسال تمام داده‌ها به صورت کامل ممکن است از سقف مجاز توکن فراتر رفته یا پردازش را کند کند. آیا مایلید با حالت «خلاصه آماری + نمونه» ادامه دهید؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        aiViewModel.proceedWithSummaryMode(
                            settings, headers, visibleRows, totalRowCount, filterState, searchQuery,
                            plColumnIndex, groupColumnIndex, initialBalance, riskPercent, rrCap, statsResult
                        )
                    }
                ) {
                    Text("ارسال خلاصه آماری")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { aiViewModel.dismissOver500Dialog() }) {
                    Text("انصراف")
                }
            }
        )
    }
}

@Composable
private fun PresetButton(
    title: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    AssistChip(
        onClick = onClick,
        enabled = enabled,
        leadingIcon = {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp))
        },
        label = { Text(title, fontSize = 12.sp) }
    )
}

@Composable
private fun ChatBubble(
    message: ChatUiMessage,
    onCopy: (String) -> Unit
) {
    val isUser = message.role == "user"

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.88f)
                .background(
                    color = if (isUser) {
                        MaterialTheme.colorScheme.primaryContainer
                    } else if (message.isError) {
                        MaterialTheme.colorScheme.errorContainer
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    },
                    shape = RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    )
                )
                .padding(14.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isUser) "شما" else "تحلیلگر استراتژی",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isUser) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.primary
                    )

                    if (!isUser && message.content.isNotEmpty()) {
                        IconButton(
                            onClick = { onCopy(message.content) },
                            modifier = Modifier.size(20.dp)
                        ) {
                            Icon(
                                Icons.Default.ContentCopy,
                                contentDescription = "کپی",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                SelectionContainer {
                    Text(
                        text = message.content.ifBlank {
                            if (message.isStreaming) "در حال پردازش و تحلیل داده‌ها..." else ""
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (isUser) {
                            MaterialTheme.colorScheme.onPrimaryContainer
                        } else if (message.isError) {
                            MaterialTheme.colorScheme.onErrorContainer
                        } else {
                            MaterialTheme.colorScheme.onSurface
                        },
                        lineHeight = 22.sp
                    )
                }

                if (message.isStreaming) {
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.dp)
                    )
                }
            }
        }
    }
}

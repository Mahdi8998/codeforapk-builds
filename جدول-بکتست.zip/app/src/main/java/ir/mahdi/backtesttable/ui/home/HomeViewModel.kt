package ir.mahdi.backtesttable.ui.home

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.mahdi.backtesttable.data.SampleDataGenerator
import ir.mahdi.backtesttable.data.db.WorkbookDao
import ir.mahdi.backtesttable.data.db.WorkbookEntity
import ir.mahdi.backtesttable.data.excel.XlsxManager
import ir.mahdi.backtesttable.data.model.GridData
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(private val workbookDao: WorkbookDao) : ViewModel() {

    val workbooks: StateFlow<List<WorkbookEntity>> = workbookDao.getAllWorkbooks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun createNewWorkbook(onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val list = workbooks.value
            val existingNumbers = list.mapNotNull { wb ->
                val prefix = "جدول جدید "
                if (wb.name.startsWith(prefix)) {
                    wb.name.removePrefix(prefix).trim().toIntOrNull()
                } else null
            }.toSet()

            var nextNum = 1
            while (existingNumbers.contains(nextNum)) {
                nextNum++
            }

            val name = "جدول جدید $nextNum"
            val initialGrid = GridData.createInitial()
            val entity = WorkbookEntity(
                name = name,
                gridJson = initialGrid.toJson(),
                initialBalance = 500.0,
                riskPercent = 2.0
            )
            val newId = workbookDao.insertWorkbook(entity)
            onCreated(newId)
        }
    }

    fun loadSampleWorkbook(onLoaded: (Long) -> Unit) {
        viewModelScope.launch {
            val entity = SampleDataGenerator.createSampleWorkbook()
            val newId = workbookDao.insertWorkbook(entity)
            onLoaded(newId)
        }
    }

    fun importFromExcel(context: Context, uri: Uri, onResult: (Result<Long>) -> Unit) {
        viewModelScope.launch {
            val importResult = XlsxManager.importFromUri(context, uri)
            importResult.fold(
                onSuccess = { gridData ->
                    val name = "اکسل واردشده ${workbooks.value.size + 1}"
                    val entity = WorkbookEntity(
                        name = name,
                        gridJson = gridData.toJson(),
                        initialBalance = 500.0,
                        riskPercent = 2.0
                    )
                    val newId = workbookDao.insertWorkbook(entity)
                    onResult(Result.success(newId))
                },
                onFailure = { error ->
                    onResult(Result.failure(error))
                }
            )
        }
    }

    fun duplicateWorkbook(workbook: WorkbookEntity, onDuplicated: (Long) -> Unit) {
        viewModelScope.launch {
            val duplicate = workbook.copy(
                id = 0,
                name = "رونوشت از ${workbook.name}",
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            val newId = workbookDao.insertWorkbook(duplicate)
            onDuplicated(newId)
        }
    }

    fun renameWorkbook(workbookId: Long, newName: String) {
        viewModelScope.launch {
            val existing = workbookDao.getWorkbookById(workbookId) ?: return@launch
            workbookDao.updateWorkbook(
                existing.copy(
                    name = newName.trim().ifBlank { existing.name },
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    fun deleteWorkbook(workbookId: Long) {
        viewModelScope.launch {
            workbookDao.deleteWorkbookById(workbookId)
        }
    }
}

package ir.mahdi.backtesttable.ui.table

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.mahdi.backtesttable.data.NumberUtils
import ir.mahdi.backtesttable.data.model.GridRow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ColumnFilterSheet(
    columnIndex: Int,
    columnTitle: String,
    allRows: List<GridRow>,
    currentlySelectedValues: Set<String>?, // null means all selected
    onDismiss: () -> Unit,
    onApplyFilter: (Set<String>) -> Unit,
    onClearFilter: () -> Unit,
    onSort: (ascending: Boolean) -> Unit
) {
    // 1. Extract unique values and counts
    val valueCounts = remember(allRows, columnIndex) {
        allRows.map { it.cells.getOrNull(columnIndex)?.trim() ?: "" }
            .groupingBy { it }
            .eachCount()
            .toList()
            .sortedByDescending { it.second }
    }

    val allUniqueValues = remember(valueCounts) { valueCounts.map { it.first }.toSet() }

    var selectedSet by remember {
        mutableStateOf(currentlySelectedValues ?: allUniqueValues)
    }

    var valueSearchQuery by remember { mutableStateOf("") }

    val filteredList = remember(valueCounts, valueSearchQuery) {
        val norm = NumberUtils.normalizeText(valueSearchQuery)
        if (norm.isEmpty()) {
            valueCounts
        } else {
            valueCounts.filter { (v, _) ->
                NumberUtils.normalizeText(v).contains(norm)
            }
        }
    }

    val isAllSelected = selectedSet.size == allUniqueValues.size

    ModalBottomSheet(
        onDismissRequest = onDismiss
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "فیلتر و مرتب‌سازی: $columnTitle",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                TextButton(onClick = {
                    onClearFilter()
                    onDismiss()
                }) {
                    Text("حذف فیلتر این ستون")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sort buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        onSort(true)
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.ArrowUpward, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("مرتب‌سازی صعودی")
                }
                OutlinedButton(
                    onClick = {
                        onSort(false)
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.ArrowDownward, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("مرتب‌سازی نزولی")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider()
            Spacer(modifier = Modifier.height(8.dp))

            // Search box inside filter
            OutlinedTextField(
                value = valueSearchQuery,
                onValueChange = { valueSearchQuery = it },
                placeholder = { Text("جستجو در مقادیر...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (valueSearchQuery.isNotEmpty()) {
                        IconButton(onClick = { valueSearchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = null)
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Select All row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        selectedSet = if (isAllSelected) emptySet() else allUniqueValues
                    }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = isAllSelected,
                    onCheckedChange = { checked ->
                        selectedSet = if (checked) allUniqueValues else emptySet()
                    }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "انتخاب همه (${NumberUtils.formatInt(allUniqueValues.size)})",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Divider()

            // List of values
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 240.dp)
            ) {
                items(filteredList) { (valStr, count) ->
                    val isChecked = selectedSet.contains(valStr)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedSet = if (isChecked) {
                                    selectedSet - valStr
                                } else {
                                    selectedSet + valStr
                                }
                            }
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { checked ->
                                    selectedSet = if (checked) {
                                        selectedSet + valStr
                                    } else {
                                        selectedSet - valStr
                                    }
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (valStr.isEmpty()) "(خالی)" else valStr,
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (valStr.isEmpty()) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Text(
                            text = NumberUtils.formatInt(count),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Apply / Cancel buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("انصراف")
                }
                Button(
                    onClick = {
                        onApplyFilter(selectedSet)
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("اعمال فیلتر")
                }
            }
        }
    }
}

package ir.mahdi.backtesttable.data.model

import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

val jsonSerializer = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
    isLenient = true
}

@Serializable
data class GridRow(
    val id: Long,
    val cells: List<String>
)

@Serializable
data class GridData(
    val headers: List<String>,
    val rows: List<GridRow>
) {
    fun toJson(): String = jsonSerializer.encodeToString(this)

    companion object {
        fun fromJson(json: String): GridData {
            return try {
                jsonSerializer.decodeFromString(json)
            } catch (e: Exception) {
                GridData(
                    headers = listOf("ستون ۱", "ستون ۲", "ستون ۳", "ستون ۴", "ستون ۵"),
                    rows = listOf(GridRow(id = 1L, cells = List(5) { "" }))
                )
            }
        }

        fun createInitial(nameIndex: Int = 1): GridData {
            return GridData(
                headers = listOf("ستون ۱", "ستون ۲", "ستون ۳", "ستون ۴", "ستون ۵"),
                rows = listOf(GridRow(id = System.currentTimeMillis(), cells = List(5) { "" }))
            )
        }
    }
}

@Serializable
data class ColumnFilter(
    val selectedValues: Set<String> = emptySet()
)

@Serializable
data class FilterState(
    val columnFilters: Map<Int, ColumnFilter> = emptyMap(),
    val sortColumnIndex: Int? = null,
    val sortAscending: Boolean = true
) {
    fun toJson(): String = jsonSerializer.encodeToString(this)

    companion object {
        fun fromJson(json: String?): FilterState {
            if (json.isNullOrBlank()) return FilterState()
            return try {
                jsonSerializer.decodeFromString(json)
            } catch (e: Exception) {
                FilterState()
            }
        }
    }
}

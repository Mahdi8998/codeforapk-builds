package com.example

import com.example.analytics.BacktestStatsCalculator
import com.example.util.NumberParser
import org.junit.Assert.*
import org.junit.Test

class AddendumAResultStatsTest {

    @Test
    fun testTradeResultParsing_stopLossVariants() {
        assertEquals(-1.0, NumberParser.parseTradeResult("-")!!, 0.001)
        assertEquals(-1.0, NumberParser.parseTradeResult("−")!!, 0.001) // Unicode minus
        assertEquals(-1.0, NumberParser.parseTradeResult("–")!!, 0.001) // En-dash
        assertEquals(-1.0, NumberParser.parseTradeResult("  -  ")!!, 0.001)
        assertEquals(-1.0, NumberParser.parseTradeResult("  −  ")!!, 0.001)
        assertEquals(-1.0, NumberParser.parseTradeResult("-1")!!, 0.001)
        assertEquals(-1.0, NumberParser.parseTradeResult("−۱")!!, 0.001)
    }

    @Test
    fun testTradeResultParsing_targetHits() {
        assertEquals(1.0, NumberParser.parseTradeResult("1")!!, 0.001)
        assertEquals(2.0, NumberParser.parseTradeResult("2")!!, 0.001)
        assertEquals(3.0, NumberParser.parseTradeResult("3")!!, 0.001)
        assertEquals(3.0, NumberParser.parseTradeResult("۳")!!, 0.001) // Persian 3
        assertEquals(1.5, NumberParser.parseTradeResult("1.5")!!, 0.001)
        assertEquals(1.5, NumberParser.parseTradeResult("۱٫۵")!!, 0.001) // Persian decimal
        assertEquals(-2.0, NumberParser.parseTradeResult("-2")!!, 0.001)
        assertEquals(-2.0, NumberParser.parseTradeResult("−۲")!!, 0.001)
    }

    @Test
    fun testTradeResultParsing_excludedCells() {
        assertNull(NumberParser.parseTradeResult(null))
        assertNull(NumberParser.parseTradeResult(""))
        assertNull(NumberParser.parseTradeResult("   "))
        assertNull(NumberParser.parseTradeResult("0"))
        assertNull(NumberParser.parseTradeResult("۰"))
        assertNull(NumberParser.parseTradeResult("0.0"))
        assertNull(NumberParser.parseTradeResult("برد"))
        assertNull(NumberParser.parseTradeResult("باخت"))
        assertNull(NumberParser.parseTradeResult("text"))
        assertNull(NumberParser.parseTradeResult("invalid"))
    }

    @Test
    fun testAdvancedStats_withMixedAndExcludedRows() {
        val rows = listOf(
            listOf("2024-01-01", "EURUSD", "1"),
            listOf("2024-01-02", "GBPUSD", "-"),
            listOf("2024-01-03", "USDJPY", ""),    // Excluded
            listOf("2024-01-04", "EURUSD", "2"),
            listOf("2024-01-05", "GBPUSD", "   "), // Excluded
            listOf("2024-01-06", "USDJPY", "-"),
            listOf("2024-01-07", "EURUSD", "3"),
            listOf("2024-01-08", "GBPUSD", "0"),   // Excluded
            listOf("2024-01-09", "USDJPY", "text"),// Excluded
            listOf("2024-01-10", "EURUSD", "-")
        )

        val stats = BacktestStatsCalculator.calculateAdvancedStats(rows, plColumnIndex = 2)

        assertEquals(6, stats.tradeCount)
        assertEquals(4, stats.excludedCount)
        assertEquals(3, stats.winCount)
        assertEquals(3, stats.lossCount)
        assertEquals(50.0, stats.winRate, 0.01)
        assertEquals(6.0, stats.grossProfit, 0.01)
        assertEquals(3.0, stats.grossLoss, 0.01)
        assertEquals(3.0, stats.netProfit, 0.01)
        assertEquals(2.0, stats.profitFactor!!, 0.01)
        assertEquals(2.0, stats.avgWin, 0.01)
        assertEquals(1.0, stats.avgLoss, 0.01)
        assertEquals(2.0, stats.rewardToRiskRatio!!, 0.01)
        assertEquals(0.5, stats.expectancy, 0.01)
        assertEquals(3.0, stats.bestTrade, 0.01)
        assertEquals(-1.0, stats.worstTrade, 0.01)

        // Equity curve checks (should only contain origin + 6 counted trades = 7 points)
        assertEquals(7, stats.equityCurve.size)
        assertEquals(0.0, stats.equityCurve[0].cumulativePl, 0.001)
        assertEquals(1.0, stats.equityCurve[1].cumulativePl, 0.001) // +1
        assertEquals(0.0, stats.equityCurve[2].cumulativePl, 0.001) // -1
        assertEquals(2.0, stats.equityCurve[3].cumulativePl, 0.001) // +2
        assertEquals(1.0, stats.equityCurve[4].cumulativePl, 0.001) // -1
        assertEquals(4.0, stats.equityCurve[5].cumulativePl, 0.001) // +3
        assertEquals(3.0, stats.equityCurve[6].cumulativePl, 0.001) // -1

        assertEquals(1.0, stats.maxDrawdownValue, 0.01)
    }

    @Test
    fun testGroupStats_withExcludedRows() {
        val columns = listOf("Pair", "Result")
        val rows = listOf(
            listOf("EURUSD", "1"),
            listOf("EURUSD", "-"),
            listOf("GBPUSD", "2"),
            listOf("GBPUSD", ""),  // Excluded: must not increase GBPUSD trade count
            listOf("USDJPY", "-"),
            listOf("USDJPY", "-")
        )

        val groups = BacktestStatsCalculator.calculateGroupStats(columns, rows, groupColumnIndex = 0, plColumnIndex = 1)

        val eurusd = groups.find { it.groupValue == "EURUSD" }
        assertNotNull(eurusd)
        assertEquals(2, eurusd!!.tradeCount)
        assertEquals(50.0, eurusd.winRate, 0.01)
        assertEquals(0.0, eurusd.netProfit, 0.01)

        val gbpusd = groups.find { it.groupValue == "GBPUSD" }
        assertNotNull(gbpusd)
        assertEquals(1, gbpusd!!.tradeCount) // Only 1 counted trade
        assertEquals(100.0, gbpusd.winRate, 0.01)
        assertEquals(2.0, gbpusd.netProfit, 0.01)

        val usdjpy = groups.find { it.groupValue == "USDJPY" }
        assertNotNull(usdjpy)
        assertEquals(2, usdjpy!!.tradeCount)
        assertEquals(0.0, usdjpy.winRate, 0.01)
        assertEquals(-2.0, usdjpy.netProfit, 0.01)
    }
}

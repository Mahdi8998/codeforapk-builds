package com.example.data.repository

import com.example.data.local.WorkbookDao
import com.example.data.local.WorkbookEntity
import kotlinx.coroutines.flow.Flow

class WorkbookRepository(private val workbookDao: WorkbookDao) {
    val allWorkbooks: Flow<List<WorkbookEntity>> = workbookDao.getAllWorkbooks()

    suspend fun getWorkbook(id: Long): WorkbookEntity? = workbookDao.getWorkbookById(id)

    suspend fun saveWorkbook(workbook: WorkbookEntity): Long = workbookDao.insertWorkbook(workbook)

    suspend fun updateWorkbook(workbook: WorkbookEntity) = workbookDao.updateWorkbook(workbook)

    suspend fun deleteWorkbook(workbook: WorkbookEntity) = workbookDao.deleteWorkbook(workbook)

    suspend fun deleteWorkbookById(id: Long) = workbookDao.deleteWorkbookById(id)
}

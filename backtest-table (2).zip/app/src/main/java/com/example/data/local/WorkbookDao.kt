package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkbookDao {
    @Query("SELECT * FROM workbooks ORDER BY updatedAt DESC")
    fun getAllWorkbooks(): Flow<List<WorkbookEntity>>

    @Query("SELECT * FROM workbooks WHERE id = :id")
    suspend fun getWorkbookById(id: Long): WorkbookEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkbook(workbook: WorkbookEntity): Long

    @Update
    suspend fun updateWorkbook(workbook: WorkbookEntity)

    @Delete
    suspend fun deleteWorkbook(workbook: WorkbookEntity)

    @Query("DELETE FROM workbooks WHERE id = :id")
    suspend fun deleteWorkbookById(id: Long)
}

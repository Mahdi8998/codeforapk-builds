package com.example.data.xlsx

import android.util.Xml
import com.example.data.model.GridData
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object XlsxEngine {

    /**
     * Reads an XLSX stream and returns GridData containing columns (first row) and rows (subsequent rows).
     */
    fun readXlsx(inputStream: InputStream): GridData {
        val zipBytes = inputStream.readBytes()
        val sharedStrings = mutableListOf<String>()
        var sheetXmlBytes: ByteArray? = null

        // 1. First pass: extract shared strings and find first sheet xml
        ZipInputStream(ByteArrayInputStream(zipBytes)).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                val name = entry.name
                if (name == "xl/sharedStrings.xml") {
                    val content = zis.readBytes()
                    parseSharedStrings(content, sharedStrings)
                } else if (name.startsWith("xl/worksheets/sheet") && name.endsWith(".xml")) {
                    if (sheetXmlBytes == null) {
                        sheetXmlBytes = zis.readBytes()
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        if (sheetXmlBytes == null) {
            throw IllegalArgumentException("فایل اکسل معتبر نیست یا شیت کاری یافت نشد.")
        }

        // 2. Second pass: parse sheet rows and cells
        val rawRows = parseSheetXml(sheetXmlBytes!!, sharedStrings)
        if (rawRows.isEmpty()) {
            return GridData(columns = listOf("ستون ۱"), rows = emptyList())
        }

        // Remove empty leading rows
        val firstNonEmptyRowIdx = rawRows.indexOfFirst { row -> row.any { it.isNotBlank() } }
        if (firstNonEmptyRowIdx == -1) {
            return GridData(columns = listOf("ستون ۱"), rows = emptyList())
        }

        val cleanRows = rawRows.subList(firstNonEmptyRowIdx, rawRows.size)
        val headers = cleanRows.first().mapIndexed { i, h ->
            if (h.isBlank()) "ستون ${i + 1}" else h.trim()
        }

        val colCount = headers.size
        val dataRows = if (cleanRows.size > 1) {
            cleanRows.subList(1, cleanRows.size).map { row ->
                if (row.size < colCount) {
                    row + List(colCount - row.size) { "" }
                } else {
                    row.subList(0, colCount)
                }
            }
        } else {
            emptyList()
        }

        return GridData(columns = headers, rows = dataRows)
    }

    private fun parseSharedStrings(xmlBytes: ByteArray, outStrings: MutableList<String>) {
        val parser: XmlPullParser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(xmlBytes), "UTF-8")

        var eventType = parser.eventType
        var currentString = StringBuilder()
        var insideSi = false
        var insideT = false

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    val tag = parser.name
                    if (tag.equals("si", ignoreCase = true)) {
                        insideSi = true
                        currentString.clear()
                    } else if (tag.equals("t", ignoreCase = true)) {
                        insideT = true
                    }
                }
                XmlPullParser.TEXT -> {
                    if (insideSi && insideT) {
                        currentString.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    val tag = parser.name
                    if (tag.equals("t", ignoreCase = true)) {
                        insideT = false
                    } else if (tag.equals("si", ignoreCase = true)) {
                        insideSi = false
                        outStrings.add(currentString.toString())
                    }
                }
            }
            eventType = parser.next()
        }
    }

    private fun parseSheetXml(xmlBytes: ByteArray, sharedStrings: List<String>): List<List<String>> {
        val parser: XmlPullParser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(xmlBytes), "UTF-8")

        val resultRows = mutableListOf<MutableList<String>>()
        var currentRow: MutableMap<Int, String>? = null
        var currentCellColIndex = 0
        var currentCellType = "" // "s", "inlineStr", "str", or ""
        var currentCellValue = StringBuilder()
        var insideValue = false
        var insideInlineText = false

        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    val tag = parser.name
                    if (tag.equals("row", ignoreCase = true)) {
                        currentRow = mutableMapOf()
                        currentCellColIndex = 0
                    } else if (tag.equals("c", ignoreCase = true)) {
                        currentCellType = parser.getAttributeValue(null, "t") ?: ""
                        val ref = parser.getAttributeValue(null, "r")
                        if (ref != null) {
                            val colIdx = colRefToIndex(ref)
                            currentCellColIndex = colIdx
                        }
                        currentCellValue.clear()
                    } else if (tag.equals("v", ignoreCase = true)) {
                        insideValue = true
                    } else if (tag.equals("t", ignoreCase = true)) {
                        insideInlineText = true
                    }
                }
                XmlPullParser.TEXT -> {
                    if (insideValue || insideInlineText) {
                        currentCellValue.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    val tag = parser.name
                    if (tag.equals("v", ignoreCase = true)) {
                        insideValue = false
                    } else if (tag.equals("t", ignoreCase = true)) {
                        insideInlineText = false
                    } else if (tag.equals("c", ignoreCase = true)) {
                        val text = currentCellValue.toString()
                        val finalValue = when (currentCellType) {
                            "s" -> {
                                val sIndex = text.toIntOrNull()
                                if (sIndex != null && sIndex in sharedStrings.indices) {
                                    sharedStrings[sIndex]
                                } else {
                                    text
                                }
                            }
                            else -> text
                        }
                        currentRow?.put(currentCellColIndex, finalValue)
                        currentCellColIndex++
                    } else if (tag.equals("row", ignoreCase = true)) {
                        if (currentRow != null) {
                            val maxCol = if (currentRow.isNotEmpty()) currentRow.keys.maxOrNull() ?: 0 else 0
                            val rowList = MutableList(maxCol + 1) { col ->
                                currentRow[col] ?: ""
                            }
                            resultRows.add(rowList)
                            currentRow = null
                        }
                    }
                }
            }
            eventType = parser.next()
        }

        return resultRows
    }

    private fun colRefToIndex(cellRef: String): Int {
        val colPart = cellRef.takeWhile { it.isLetter() }.uppercase()
        var col = 0
        for (ch in colPart) {
            col = col * 26 + (ch - 'A' + 1)
        }
        return (col - 1).coerceAtLeast(0)
    }

    fun indexToColRef(index: Int): String {
        var temp = index + 1
        val sb = StringBuilder()
        while (temp > 0) {
            val rem = (temp - 1) % 26
            sb.append((rem + 'A'.code).toChar())
            temp = (temp - 1) / 26
        }
        return sb.reverse().toString()
    }

    /**
     * Writes headers + rows to an XLSX output stream.
     */
    fun writeXlsx(
        outputStream: OutputStream,
        columns: List<String>,
        rows: List<List<String>>
    ) {
        ZipOutputStream(outputStream).use { zos ->
            // 1. [Content_Types].xml
            zos.putNextEntry(ZipEntry("[Content_Types].xml"))
            zos.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>""".trimIndent().toByteArray(StandardCharsets.UTF_8)
            )
            zos.closeEntry()

            // 2. _rels/.rels
            zos.putNextEntry(ZipEntry("_rels/.rels"))
            zos.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>""".trimIndent().toByteArray(StandardCharsets.UTF_8)
            )
            zos.closeEntry()

            // 3. xl/_rels/workbook.xml.rels
            zos.putNextEntry(ZipEntry("xl/_rels/workbook.xml.rels"))
            zos.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>""".trimIndent().toByteArray(StandardCharsets.UTF_8)
            )
            zos.closeEntry()

            // 4. xl/styles.xml
            zos.putNextEntry(ZipEntry("xl/styles.xml"))
            zos.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts>
  <fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>
  <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs>
</styleSheet>""".trimIndent().toByteArray(StandardCharsets.UTF_8)
            )
            zos.closeEntry()

            // 5. xl/workbook.xml
            zos.putNextEntry(ZipEntry("xl/workbook.xml"))
            zos.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="Sheet1" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>""".trimIndent().toByteArray(StandardCharsets.UTF_8)
            )
            zos.closeEntry()

            // 6. xl/worksheets/sheet1.xml
            zos.putNextEntry(ZipEntry("xl/worksheets/sheet1.xml"))
            val sheetBuilder = StringBuilder()
            val totalRows = rows.size + 1
            val maxCol = columns.size.coerceAtLeast(1)
            val lastColRef = indexToColRef(maxCol - 1)

            sheetBuilder.append(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <dimension ref="A1:${lastColRef}${totalRows}"/>
  <sheetData>
"""
            )

            // Header row (Row 1)
            sheetBuilder.append("    <row r=\"1\">\n")
            for (colIdx in columns.indices) {
                val colRef = indexToColRef(colIdx)
                val text = escapeXml(columns[colIdx])
                sheetBuilder.append("      <c r=\"${colRef}1\" t=\"inlineStr\"><is><t>$text</t></is></c>\n")
            }
            sheetBuilder.append("    </row>\n")

            // Data rows (Row 2 .. N)
            for (rowIdx in rows.indices) {
                val rowNum = rowIdx + 2
                val row = rows[rowIdx]
                sheetBuilder.append("    <row r=\"$rowNum\">\n")
                for (colIdx in columns.indices) {
                    val colRef = indexToColRef(colIdx)
                    val cellValue = row.getOrElse(colIdx) { "" }
                    if (cellValue.isNotBlank()) {
                        val num = com.example.util.NumberParser.parseDouble(cellValue)
                        if (num != null && !cellValue.contains(":") && !cellValue.contains("/")) {
                            // Write as number
                            sheetBuilder.append("      <c r=\"$colRef$rowNum\"><v>$num</v></c>\n")
                        } else {
                            // Write as inline string
                            val text = escapeXml(cellValue)
                            sheetBuilder.append("      <c r=\"$colRef$rowNum\" t=\"inlineStr\"><is><t>$text</t></is></c>\n")
                        }
                    }
                }
                sheetBuilder.append("    </row>\n")
            }

            sheetBuilder.append(
                """  </sheetData>
</worksheet>"""
            )

            zos.write(sheetBuilder.toString().toByteArray(StandardCharsets.UTF_8))
            zos.closeEntry()
        }
    }

    private fun escapeXml(text: String): String {
        return text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }
}

package com.example.analytics

import com.example.util.NumberParser
import kotlin.math.abs
import kotlin.math.max

data class ColumnSummary(
    val columnIndex: Int,
    val columnName: String,
    val isNumeric: Boolean,
    val sum: Double? = null,
    val average: Double? = null,
    val distinctBreakdown: List<ValueCountPercent>? = null
)

data class ValueCountPercent(
    val value: String,
    val count: Int,
    val percentage: Double
)

data class AdvancedStats(
    val tradeCount: Int = 0,
    val excludedCount: Int = 0,
    val winCount: Int = 0,
    val lossCount: Int = 0,
    val breakEvenCount: Int = 0,
    val netProfit: Double = 0.0,
    val winRate: Double = 0.0, // 0.0 to 100.0
    val grossProfit: Double = 0.0,
    val grossLoss: Double = 0.0, // absolute sum of losses in R
    val profitFactor: Double? = null, // null represents infinity (no losses)
    val avgWin: Double = 0.0,
    val avgLoss: Double = 0.0,
    val rewardToRiskRatio: Double? = null, // null represents infinity
    val expectancy: Double = 0.0,
    val bestTrade: Double = 0.0,
    val worstTrade: Double = 0.0,
    val maxConsecutiveWins: Int = 0,
    val maxConsecutiveLosses: Int = 0,
    val maxDrawdownValue: Double = 0.0,
    val maxDrawdownPercent: Double = 0.0,
    val equityCurve: List<EquityPoint> = emptyList()
)

data class EquityPoint(
    val tradeIndex: Int,
    val tradePl: Double,
    val cumulativePl: Double
)

data class GroupItemStats(
    val groupValue: String,
    val tradeCount: Int,
    val winRate: Double,
    val netProfit: Double,
    val netProfitDollar: Double = 0.0
)

data class DollarStats(
    val initialBalance: Double = 500.0,
    val riskPercent: Double = 2.0,
    val finalBalance: Double = 500.0,
    val netProfitDollar: Double = 0.0,
    val totalReturnPercent: Double = 0.0,
    val tradeCount: Int = 0,
    val excludedCount: Int = 0,
    val winCount: Int = 0,
    val lossCount: Int = 0,
    val avgWinDollar: Double = 0.0,
    val avgLossDollar: Double = 0.0,
    val bestTradeDollar: Double = 0.0,
    val worstTradeDollar: Double = 0.0,
    val maxDrawdownDollar: Double = 0.0,
    val maxDrawdownPercent: Double = 0.0,
    val dollarEquityCurve: List<DollarEquityPoint> = emptyList()
)

data class DollarEquityPoint(
    val tradeIndex: Int,
    val tradeDeltaDollar: Double,
    val balance: Double
)

object BacktestStatsCalculator {

    fun calculateSummary(
        columns: List<String>,
        rows: List<List<String>>
    ): List<ColumnSummary> {
        if (columns.isEmpty() || rows.isEmpty()) {
            return columns.mapIndexed { index, col ->
                ColumnSummary(
                    columnIndex = index,
                    columnName = col,
                    isNumeric = false,
                    sum = 0.0,
                    average = 0.0,
                    distinctBreakdown = emptyList()
                )
            }
        }

        return columns.mapIndexed { colIdx, colName ->
            val values = rows.map { row -> row.getOrElse(colIdx) { "" }.trim() }
            val nonEmptyValues = values.filter { it.isNotBlank() }

            val parsedNumbers = nonEmptyValues.mapNotNull { NumberParser.parseDouble(it) }
            val isMostlyNumeric = nonEmptyValues.isNotEmpty() && (parsedNumbers.size.toDouble() / nonEmptyValues.size) >= 0.7

            if (isMostlyNumeric && parsedNumbers.isNotEmpty()) {
                val sum = parsedNumbers.sum()
                val avg = sum / parsedNumbers.size
                ColumnSummary(
                    columnIndex = colIdx,
                    columnName = colName,
                    isNumeric = true,
                    sum = sum,
                    average = avg,
                    distinctBreakdown = null
                )
            } else {
                val frequencyMap = mutableMapOf<String, Int>()
                for (v in values) {
                    val key = if (v.isBlank()) "(خالی)" else v
                    frequencyMap[key] = (frequencyMap[key] ?: 0) + 1
                }
                val total = values.size
                val distinctCount = frequencyMap.size

                val breakdown = if (distinctCount in 2..5) {
                    frequencyMap.map { (valName, count) ->
                        ValueCountPercent(
                            value = valName,
                            count = count,
                            percentage = if (total > 0) (count.toDouble() / total) * 100.0 else 0.0
                        )
                    }.sortedByDescending { it.count }
                } else {
                    null
                }

                ColumnSummary(
                    columnIndex = colIdx,
                    columnName = colName,
                    isNumeric = false,
                    sum = null,
                    average = null,
                    distinctBreakdown = breakdown
                )
            }
        }
    }

    fun calculateAdvancedStats(
        rows: List<List<String>>,
        plColumnIndex: Int?
    ): AdvancedStats {
        if (plColumnIndex == null || rows.isEmpty()) {
            return AdvancedStats(excludedCount = rows.size)
        }

        val pls = mutableListOf<Double>()
        var excludedCount = 0

        for (row in rows) {
            val cell = row.getOrElse(plColumnIndex) { "" }
            val parsed = NumberParser.parseTradeResult(cell)
            if (parsed != null) {
                pls.add(parsed)
            } else {
                excludedCount++
            }
        }

        if (pls.isEmpty()) {
            return AdvancedStats(excludedCount = excludedCount)
        }

        var winCount = 0
        var lossCount = 0
        var grossProfit = 0.0
        var grossLoss = 0.0
        var bestTrade = pls.first()
        var worstTrade = pls.first()

        var currentConsecWins = 0
        var maxConsecWins = 0
        var currentConsecLosses = 0
        var maxConsecLosses = 0

        var cumulative = 0.0
        var peak = 0.0
        var maxDrawdownVal = 0.0
        var maxDrawdownPct = 0.0

        val equityCurve = mutableListOf<EquityPoint>()
        equityCurve.add(EquityPoint(tradeIndex = 0, tradePl = 0.0, cumulativePl = 0.0))

        for ((idx, pl) in pls.withIndex()) {
            cumulative += pl
            equityCurve.add(EquityPoint(tradeIndex = idx + 1, tradePl = pl, cumulativePl = cumulative))

            if (pl > 0.000001) {
                winCount++
                grossProfit += pl
                currentConsecWins++
                currentConsecLosses = 0
                maxConsecWins = max(maxConsecWins, currentConsecWins)
            } else if (pl < -0.000001) {
                lossCount++
                grossLoss += abs(pl)
                currentConsecLosses++
                currentConsecWins = 0
                maxConsecLosses = max(maxConsecLosses, currentConsecLosses)
            }

            if (pl > bestTrade) bestTrade = pl
            if (pl < worstTrade) worstTrade = pl

            if (cumulative > peak) {
                peak = cumulative
            } else {
                val currentDd = peak - cumulative
                if (currentDd > maxDrawdownVal) {
                    maxDrawdownVal = currentDd
                    if (peak > 0.000001) {
                        maxDrawdownPct = (currentDd / peak) * 100.0
                    }
                }
            }
        }

        val tradeCount = pls.size
        val netProfit = cumulative
        val decisiveTrades = winCount + lossCount
        val winRate = if (decisiveTrades > 0) (winCount.toDouble() / decisiveTrades) * 100.0 else 0.0

        val profitFactor = when {
            grossLoss == 0.0 && grossProfit > 0 -> null // Infinity
            grossLoss == 0.0 && grossProfit == 0.0 -> 0.0
            else -> grossProfit / grossLoss
        }

        val avgWin = if (winCount > 0) grossProfit / winCount else 0.0
        val avgLoss = if (lossCount > 0) grossLoss / lossCount else 0.0

        val rrRatio = when {
            avgLoss == 0.0 && avgWin > 0 -> null // Infinity
            avgLoss == 0.0 && avgWin == 0.0 -> 0.0
            else -> avgWin / avgLoss
        }

        val expectancy = if (tradeCount > 0) netProfit / tradeCount else 0.0

        return AdvancedStats(
            tradeCount = tradeCount,
            excludedCount = excludedCount,
            winCount = winCount,
            lossCount = lossCount,
            breakEvenCount = 0,
            netProfit = netProfit,
            winRate = winRate,
            grossProfit = grossProfit,
            grossLoss = grossLoss,
            profitFactor = profitFactor,
            avgWin = avgWin,
            avgLoss = avgLoss,
            rewardToRiskRatio = rrRatio,
            expectancy = expectancy,
            bestTrade = bestTrade,
            worstTrade = worstTrade,
            maxConsecutiveWins = maxConsecWins,
            maxConsecutiveLosses = maxConsecLosses,
            maxDrawdownValue = maxDrawdownVal,
            maxDrawdownPercent = maxDrawdownPct,
            equityCurve = equityCurve
        )
    }

    /**
     * Calculates compounding dollar balance simulation over counted trades (B.2)
     */
    fun calculateDollarStats(
        rows: List<List<String>>,
        plColumnIndex: Int?,
        initialBalance: Double = 500.0,
        riskPercent: Double = 2.0
    ): DollarStats {
        val safeInitialBalance = if (initialBalance > 0) initialBalance else 500.0
        val safeRiskPercent = if (riskPercent in 0.0001..100.0) riskPercent else 2.0

        if (plColumnIndex == null || rows.isEmpty()) {
            return DollarStats(
                initialBalance = safeInitialBalance,
                riskPercent = safeRiskPercent,
                finalBalance = safeInitialBalance,
                excludedCount = rows.size
            )
        }

        var currentBalance = safeInitialBalance
        var peakBalance = safeInitialBalance
        var maxDdDollar = 0.0
        var maxDdPercent = 0.0

        var winCount = 0
        var lossCount = 0
        var excludedCount = 0
        val winDeltas = mutableListOf<Double>()
        val lossDeltas = mutableListOf<Double>()
        val tradeDeltas = mutableListOf<Double>()

        val curve = mutableListOf<DollarEquityPoint>()
        curve.add(DollarEquityPoint(tradeIndex = 0, tradeDeltaDollar = 0.0, balance = safeInitialBalance))

        var tradeIdx = 0
        for (row in rows) {
            val cell = row.getOrElse(plColumnIndex) { "" }
            val parsedR = NumberParser.parseTradeResult(cell)
            if (parsedR == null) {
                excludedCount++
                continue
            }

            tradeIdx++
            val r = parsedR
            val newBalance = if (r > 0) {
                winCount++
                currentBalance * (1.0 + (safeRiskPercent / 100.0) * r)
            } else {
                lossCount++
                currentBalance * (1.0 - (safeRiskPercent / 100.0) * abs(r))
            }

            val delta = newBalance - currentBalance
            tradeDeltas.add(delta)
            if (delta > 0) {
                winDeltas.add(delta)
            } else if (delta < 0) {
                lossDeltas.add(abs(delta))
            }

            currentBalance = newBalance
            curve.add(DollarEquityPoint(tradeIndex = tradeIdx, tradeDeltaDollar = delta, balance = currentBalance))

            if (currentBalance > peakBalance) {
                peakBalance = currentBalance
            } else {
                val ddDollar = peakBalance - currentBalance
                if (ddDollar > maxDdDollar) {
                    maxDdDollar = ddDollar
                    if (peakBalance > 0.000001) {
                        maxDdPercent = (ddDollar / peakBalance) * 100.0
                    }
                }
            }
        }

        val netProfitDollar = currentBalance - safeInitialBalance
        val totalReturnPercent = if (safeInitialBalance > 0) (netProfitDollar / safeInitialBalance) * 100.0 else 0.0
        val avgWinDollar = if (winDeltas.isNotEmpty()) winDeltas.average() else 0.0
        val avgLossDollar = if (lossDeltas.isNotEmpty()) lossDeltas.average() else 0.0
        val bestTradeDollar = if (tradeDeltas.isNotEmpty()) tradeDeltas.maxOrNull() ?: 0.0 else 0.0
        val worstTradeDollar = if (tradeDeltas.isNotEmpty()) tradeDeltas.minOrNull() ?: 0.0 else 0.0

        return DollarStats(
            initialBalance = safeInitialBalance,
            riskPercent = safeRiskPercent,
            finalBalance = currentBalance,
            netProfitDollar = netProfitDollar,
            totalReturnPercent = totalReturnPercent,
            tradeCount = tradeIdx,
            excludedCount = excludedCount,
            winCount = winCount,
            lossCount = lossCount,
            avgWinDollar = avgWinDollar,
            avgLossDollar = avgLossDollar,
            bestTradeDollar = bestTradeDollar,
            worstTradeDollar = worstTradeDollar,
            maxDrawdownDollar = maxDdDollar,
            maxDrawdownPercent = maxDdPercent,
            dollarEquityCurve = curve
        )
    }

    fun calculateGroupStats(
        columns: List<String>,
        rows: List<List<String>>,
        groupColumnIndex: Int,
        plColumnIndex: Int?,
        initialBalance: Double = 500.0,
        riskPercent: Double = 2.0
    ): List<GroupItemStats> {
        if (groupColumnIndex !in columns.indices || rows.isEmpty()) {
            return emptyList()
        }

        val safeInitialBalance = if (initialBalance > 0) initialBalance else 500.0
        val safeRiskPercent = if (riskPercent in 0.0001..100.0) riskPercent else 2.0

        val groupMap = mutableMapOf<String, MutableList<Double>>()

        for (row in rows) {
            val pl = if (plColumnIndex != null && plColumnIndex in row.indices) {
                NumberParser.parseTradeResult(row[plColumnIndex])
            } else null

            // Excluded rows (null result when P/L column is selected) are omitted from group calculations
            if (plColumnIndex != null && pl == null) {
                continue
            }

            val rawGroup = row.getOrElse(groupColumnIndex) { "" }.trim()
            val groupKey = if (rawGroup.isBlank()) "(بدون مقدار)" else rawGroup

            val list = groupMap.getOrPut(groupKey) { mutableListOf() }
            if (pl != null) {
                list.add(pl)
            }
        }

        return groupMap.map { (key, plList) ->
            val total = plList.size
            val wins = plList.count { it > 0.000001 }
            val losses = plList.count { it < -0.000001 }
            val decisive = wins + losses
            val winRate = if (decisive > 0) (wins.toDouble() / decisive) * 100.0 else 0.0
            val netPl = plList.sum()
            val netPlDollar = safeInitialBalance * (safeRiskPercent / 100.0) * netPl

            GroupItemStats(
                groupValue = key,
                tradeCount = total,
                winRate = winRate,
                netProfit = netPl,
                netProfitDollar = netPlDollar
            )
        }.sortedByDescending { it.tradeCount }
    }

    /**
     * Finds default candidate column for group breakdown (first non-numeric column with 2..10 distinct values)
     */
    fun findDefaultGroupColumn(columns: List<String>, rows: List<List<String>>): Int? {
        if (columns.isEmpty() || rows.isEmpty()) return null
        for (colIdx in columns.indices) {
            val values = rows.map { it.getOrElse(colIdx) { "" }.trim() }
            val distinctCount = values.distinct().size
            val parsedNums = values.mapNotNull { NumberParser.parseDouble(it) }
            val isNumeric = values.isNotEmpty() && parsedNums.size.toDouble() / values.size > 0.7
            if (!isNumeric && distinctCount in 2..10) {
                return colIdx
            }
        }
        return if (columns.isNotEmpty()) 0 else null
    }

    /**
     * Finds candidate P/L column automatically if possible (looking for keywords or column with trade results)
     */
    fun findCandidatePlColumn(columns: List<String>, rows: List<List<String>>): Int? {
        val keywords = listOf("نتیجه", "result", "تارگت", "target", "سود", "زیان", "p/l", "pl", "profit", "loss", "pnl", "پیپ")
        for (colIdx in columns.indices) {
            val name = columns[colIdx].lowercase()
            if (keywords.any { name.contains(it) }) {
                return colIdx
            }
        }
        // Check for column with parsed trade results (dashes or positive integers/decimals)
        for (colIdx in columns.indices) {
            val values = rows.mapNotNull { NumberParser.parseTradeResult(it.getOrElse(colIdx) { "" }) }
            if (values.size >= 3 && values.any { it < 0 } && values.any { it > 0 }) {
                return colIdx
            }
        }
        return null
    }
}

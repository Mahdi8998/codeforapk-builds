package com.example.util

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

object NumberParser {

    /**
     * Converts Persian/Arabic digits and Persian decimal separator '٫' to standard English digits and '.'
     * Also removes thousands separators (',' and '٬' and ' ' and '_').
     */
    fun normalizeToEnglish(text: String): String {
        if (text.isBlank()) return ""
        val sb = StringBuilder(text.length)
        for (ch in text) {
            when (ch) {
                in '۰'..'۹' -> sb.append((ch - '۰' + '0'.code).toChar())
                in '٠'..'٩' -> sb.append((ch - '٠' + '0'.code).toChar())
                '٫', '/' -> sb.append('.')
                ',', '٬', '،', ' ', '_' -> {
                    // skip thousands separator
                }
                else -> sb.append(ch)
            }
        }
        return sb.toString().trim()
    }

    /**
     * Attempts to parse a string into Double, supporting Persian/Arabic numerals, decimal separators, and thousands separators.
     */
    fun parseDouble(text: String?): Double? {
        if (text.isNullOrBlank()) return null
        val normalized = normalizeToEnglish(text)
        return try {
            normalized.toDoubleOrNull()
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Parses a trade result according to Target/Stop semantics:
     * - Lone dash "-" or "−" or "–" or "—" or "―" or "﹣" or "－" (with optional spaces) -> -1.0 (Stop-loss hit / معامله استاپ خورده)
     * - Positive number N (integer/decimal, e.g. 1, 2, 3, 1.5, ۳, ۱٫۵) -> +N (Target N hit)
     * - Negative number (e.g. -2, -1, −۲) -> negative value (-N)
     * - Empty/whitespace -> null (EXCLUDED / بدون نتیجه)
     * - 0, text, or other symbols -> null (EXCLUDED)
     */
    fun parseTradeResult(text: String?): Double? {
        if (text.isNullOrBlank()) return null
        val trimmed = text.trim()
        val isLoneDash = trimmed == "-" || trimmed == "−" || trimmed == "–" ||
                trimmed == "—" || trimmed == "―" || trimmed == "﹣" || trimmed == "－" || trimmed == "_"
        if (isLoneDash) {
            return -1.0
        }
        val withStandardMinus = if (
            trimmed.startsWith("−") || trimmed.startsWith("–") ||
            trimmed.startsWith("—") || trimmed.startsWith("―") ||
            trimmed.startsWith("﹣") || trimmed.startsWith("－")
        ) {
            "-" + trimmed.substring(1).trim()
        } else {
            trimmed
        }
        val normalized = normalizeToEnglish(withStandardMinus)
        val parsed = try {
            normalized.toDoubleOrNull()
        } catch (_: Exception) {
            null
        } ?: return null

        if (kotlin.math.abs(parsed) < 0.000001) return null
        return parsed
    }

    fun isNumeric(text: String?): Boolean {
        return parseDouble(text) != null
    }

    /**
     * Formats a number with thousands separators, using Persian digits.
     */
    fun formatPersian(value: Double, maxDecimals: Int = 2): String {
        val pattern = if (maxDecimals > 0) "#,##0.${"#".repeat(maxDecimals)}" else "#,##0"
        val symbols = DecimalFormatSymbols(Locale.US).apply {
            groupingSeparator = '،'
            decimalSeparator = '٫'
        }
        val df = DecimalFormat(pattern, symbols)
        val formatted = df.format(value)
        return toPersianDigits(formatted)
    }

    fun formatPersian(value: Long): String {
        val symbols = DecimalFormatSymbols(Locale.US).apply {
            groupingSeparator = '،'
        }
        val df = DecimalFormat("#,##0", symbols)
        val formatted = df.format(value)
        return toPersianDigits(formatted)
    }

    fun formatPersian(value: Int): String = formatPersian(value.toLong())

    fun toPersianDigits(text: String): String {
        val sb = StringBuilder(text.length)
        for (ch in text) {
            when (ch) {
                in '0'..'9' -> sb.append((ch - '0' + '۰'.code).toChar())
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun fromPersianDigits(text: String): String {
        val sb = StringBuilder(text.length)
        for (ch in text) {
            when (ch) {
                in '۰'..'۹' -> sb.append((ch - '۰' + '0'.code).toChar())
                in '٠'..'٩' -> sb.append((ch - '٠' + '0'.code).toChar())
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }
}

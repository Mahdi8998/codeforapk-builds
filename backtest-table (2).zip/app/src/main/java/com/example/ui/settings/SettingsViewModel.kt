package com.example.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiResult
import com.example.ai.GeminiClient
import com.example.data.preferences.AppTheme
import com.example.data.preferences.SettingsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SettingsUiState(
    val currentApiKeyInput: String = "",
    val isKeyVisible: Boolean = false,
    val isTestingKey: Boolean = false,
    val testResultMessage: String? = null,
    val isTestSuccess: Boolean = false
)

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsManager = SettingsManager(application)
    private val geminiClient = GeminiClient()

    val appTheme: StateFlow<AppTheme> = settingsManager.appTheme.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        AppTheme.FOLLOW_SYSTEM
    )

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            settingsManager.geminiApiKey.collect { savedKey ->
                _uiState.value = _uiState.value.copy(currentApiKeyInput = savedKey)
            }
        }
    }

    fun updateApiKeyInput(key: String) {
        val trimmed = key.trim()
        _uiState.value = _uiState.value.copy(
            currentApiKeyInput = key,
            testResultMessage = null
        )
        viewModelScope.launch {
            settingsManager.setGeminiApiKey(trimmed)
        }
    }

    fun toggleKeyVisibility() {
        _uiState.value = _uiState.value.copy(isKeyVisible = !_uiState.value.isKeyVisible)
    }

    fun setAppTheme(theme: AppTheme) {
        viewModelScope.launch {
            settingsManager.setAppTheme(theme)
        }
    }

    fun testConnection() {
        val key = _uiState.value.currentApiKeyInput.trim()
        if (key.isBlank()) {
            _uiState.value = _uiState.value.copy(
                testResultMessage = "لطفاً ابتدا کلید API را وارد کنید.",
                isTestSuccess = false
            )
            return
        }

        _uiState.value = _uiState.value.copy(
            isTestingKey = true,
            testResultMessage = null
        )

        viewModelScope.launch(Dispatchers.IO) {
            val result = geminiClient.testConnection(key)
            when (result) {
                is AiResult.Success -> {
                    _uiState.value = _uiState.value.copy(
                        isTestingKey = false,
                        testResultMessage = result.responseText,
                        isTestSuccess = true
                    )
                }
                is AiResult.Error -> {
                    _uiState.value = _uiState.value.copy(
                        isTestingKey = false,
                        testResultMessage = result.errorMessage,
                        isTestSuccess = false
                    )
                }
            }
        }
    }
}

package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand Colors (Fintech Emerald / Forest)
val EmeraldPrimary = Color(0xFF0D9488)
val EmeraldPrimaryDark = Color(0xFF14B8A6)
val EmeraldContainer = Color(0xFFCCFBF1)
val EmeraldContainerDark = Color(0xFF115E59)

val ProfitGreen = Color(0xFF16A34A)
val LossRed = Color(0xFFDC2626)
val ProfitGreenLight = Color(0xFFDCFCE7)
val LossRedLight = Color(0xFFFEE2E2)
val WarningAmber = Color(0xFFD97706)

val SlateBackgroundLight = Color(0xFFF8FAFC)
val SlateSurfaceLight = Color(0xFFFFFFFF)
val SlateSurfaceVariantLight = Color(0xFFF1F5F9)
val SlateBorderLight = Color(0xFFE2E8F0)
val SlateTextPrimaryLight = Color(0xFF0F172A)
val SlateTextSecondaryLight = Color(0xFF64748B)

val SlateBackgroundDark = Color(0xFF090D16)
val SlateSurfaceDark = Color(0xFF131B2E)
val SlateSurfaceVariantDark = Color(0xFF1E293B)
val SlateBorderDark = Color(0xFF334155)
val SlateTextPrimaryDark = Color(0xFFF8FAFC)
val SlateTextSecondaryDark = Color(0xFF94A3B8)

package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.ai.AiAnalystScreen
import com.example.ui.ai.AiViewModel
import com.example.ui.editor.EditorScreen
import com.example.ui.editor.EditorViewModel
import com.example.ui.home.HomeScreen
import com.example.ui.home.HomeViewModel
import com.example.ui.settings.SettingsScreen
import com.example.ui.settings.SettingsViewModel

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Editor : Screen("editor/{workbookId}") {
        fun createRoute(workbookId: Long) = "editor/$workbookId"
    }
    data object AiAnalyst : Screen("ai_analyst/{workbookId}") {
        fun createRoute(workbookId: Long) = "ai_analyst/$workbookId"
    }
    data object Settings : Screen("settings")
}

@Composable
fun AppNavigation(
    settingsViewModel: SettingsViewModel
) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        // Home Screen
        composable(Screen.Home.route) {
            val homeViewModel: HomeViewModel = viewModel()
            HomeScreen(
                viewModel = homeViewModel,
                onOpenWorkbook = { workbookId ->
                    navController.navigate(Screen.Editor.createRoute(workbookId))
                },
                onOpenSettings = {
                    navController.navigate(Screen.Settings.route)
                }
            )
        }

        // Editor Screen
        composable(
            route = Screen.Editor.route,
            arguments = listOf(navArgument("workbookId") { type = NavType.LongType })
        ) { backStackEntry ->
            val workbookId = backStackEntry.arguments?.getLong("workbookId") ?: 0L
            val editorViewModel: EditorViewModel = viewModel()
            EditorScreen(
                workbookId = workbookId,
                viewModel = editorViewModel,
                onNavigateBack = {
                    navController.popBackStack()
                },
                onOpenAiAnalyst = { wbId ->
                    navController.navigate(Screen.AiAnalyst.createRoute(wbId))
                }
            )
        }

        // AI Strategy Analyst Screen
        composable(
            route = Screen.AiAnalyst.route,
            arguments = listOf(navArgument("workbookId") { type = NavType.LongType })
        ) { backStackEntry ->
            val workbookId = backStackEntry.arguments?.getLong("workbookId") ?: 0L
            val aiViewModel: AiViewModel = viewModel()
            AiAnalystScreen(
                workbookId = workbookId,
                viewModel = aiViewModel,
                onNavigateBack = {
                    navController.popBackStack()
                },
                onOpenSettings = {
                    navController.navigate(Screen.Settings.route)
                }
            )
        }

        // Settings Screen
        composable(Screen.Settings.route) {
            SettingsScreen(
                viewModel = settingsViewModel,
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}

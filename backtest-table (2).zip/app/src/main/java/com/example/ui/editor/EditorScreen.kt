package com.example.ui.editor

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.LossRed
import com.example.ui.theme.ProfitGreen
import com.example.util.NumberParser
import kotlinx.coroutines.flow.collectLatest

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun EditorScreen(
    workbookId: Long,
    viewModel: EditorViewModel,
    onNavigateBack: () -> Unit,
    onOpenAiAnalyst: (Long) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val summaryStats by viewModel.summaryStats.collectAsState()
    val advancedStats by viewModel.advancedStats.collectAsState()
    val groupStats by viewModel.groupStats.collectAsState()
    val dollarStats by viewModel.dollarStats.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    var showOverflowMenu by remember { mutableStateOf(false) }

    var renameColumnDialogIndex by remember { mutableStateOf<Int?>(null) }
    var renameColumnInput by remember { mutableStateOf("") }
    var deleteColumnConfirmIndex by remember { mutableStateOf<Int?>(null) }
    var deleteRowConfirmIndex by remember { mutableStateOf<Int?>(null) }
    var exportFilteredOnly by remember { mutableStateOf(false) }

    // SAF Export Launcher
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.exportToXlsx(uri, exportFilteredOnly)
        }
    }

    LaunchedEffect(workbookId) {
        viewModel.loadWorkbook(workbookId)
    }

    LaunchedEffect(Unit) {
        viewModel.eventFlow.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    val grid = uiState.grid
    val visibleIndices = uiState.visibleRowIndices
    val horizontalScrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                title = {
                    Column(
                        modifier = Modifier.clickable { viewModel.setShowRenameDialog(true) }
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = uiState.workbook?.name ?: "در حال بارگذاری...",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                Icons.Outlined.Edit,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = "${NumberParser.formatPersian(grid.rows.size)} ردیف • ${NumberParser.formatPersian(grid.columns.size)} ستون",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    // Undo
                    IconButton(
                        onClick = { viewModel.undo() },
                        enabled = uiState.canUndo,
                        modifier = Modifier.testTag("undo_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Undo,
                            contentDescription = "بازگردانی (Undo)",
                            tint = if (uiState.canUndo) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                        )
                    }

                    // Redo
                    IconButton(
                        onClick = { viewModel.redo() },
                        enabled = uiState.canRedo,
                        modifier = Modifier.testTag("redo_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Redo,
                            contentDescription = "انجام مجدد (Redo)",
                            tint = if (uiState.canRedo) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                        )
                    }

                    // Search Toggle
                    IconButton(
                        onClick = { viewModel.toggleSearchActive(!uiState.isSearchActive) },
                        modifier = Modifier.testTag("toggle_search_button")
                    ) {
                        Icon(
                            if (uiState.isSearchActive) Icons.Default.SearchOff else Icons.Default.Search,
                            contentDescription = "جستجو",
                            tint = if (uiState.isSearchActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Statistics Sheet
                    IconButton(
                        onClick = { viewModel.toggleStatsPanel(true) },
                        modifier = Modifier.testTag("stats_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (grid.filterStates.isNotEmpty()) {
                                    Badge { Text(NumberParser.formatPersian(grid.filterStates.size)) }
                                }
                            }
                        ) {
                            Icon(
                                Icons.Outlined.Analytics,
                                contentDescription = "آمار و تحلیل",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    // AI Strategy Analyst
                    IconButton(
                        onClick = { onOpenAiAnalyst(workbookId) },
                        modifier = Modifier.testTag("ai_analyst_button")
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.AutoAwesome,
                                    contentDescription = "تحلیلگر هوشمند Gemini",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    // Overflow Menu
                    Box {
                        IconButton(onClick = { showOverflowMenu = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "منو")
                        }

                        DropdownMenu(
                            expanded = showOverflowMenu,
                            onDismissRequest = { showOverflowMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("ذخیره دستی") },
                                leadingIcon = { Icon(Icons.Outlined.Save, contentDescription = null) },
                                onClick = {
                                    showOverflowMenu = false
                                    viewModel.manualSave()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("خروجی اکسل (.xlsx)") },
                                leadingIcon = { Icon(Icons.Outlined.Download, contentDescription = null) },
                                onClick = {
                                    showOverflowMenu = false
                                    viewModel.setShowExportDialog(true)
                                }
                            )
                            if (grid.filterStates.isNotEmpty() || uiState.searchQuery.isNotBlank()) {
                                DropdownMenuItem(
                                    text = { Text("حذف همه فیلترها") },
                                    leadingIcon = { Icon(Icons.Outlined.FilterAltOff, contentDescription = null) },
                                    onClick = {
                                        showOverflowMenu = false
                                        viewModel.clearAllFilters()
                                    }
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 3.dp,
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Add Row Button
                    Button(
                        onClick = { viewModel.addBlankRowAtEnd() },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("add_row_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("سطر جدید")
                    }

                    // Row count & filter status
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (grid.filterStates.isNotEmpty()) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier
                                    .clickable { viewModel.clearAllFilters() }
                                    .padding(end = 8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${NumberParser.formatPersian(grid.filterStates.size)} فیلتر",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "حذف فیلترها",
                                        modifier = Modifier.size(12.dp),
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                        }

                        Text(
                            text = "ردیف‌ها: ${NumberParser.formatPersian(visibleIndices.size)} از ${NumberParser.formatPersian(grid.rows.size)}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Global Search Bar
            if (uiState.isSearchActive) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = uiState.searchQuery,
                            onValueChange = { viewModel.setSearchQuery(it) },
                            placeholder = { Text("جستجو در کل جدول...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            trailingIcon = {
                                if (uiState.searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                        Icon(Icons.Default.Close, contentDescription = null)
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("global_search_input")
                        )

                        if (uiState.searchQuery.isNotBlank()) {
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "${NumberParser.formatPersian(visibleIndices.size)} نتیجه",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            // Virtualized Excel Grid Layout
            // Horizontal scroll container with columns and rows
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                        .horizontalScroll(horizontalScrollState)
                ) {
                    Column {
                        // Header Row
                        Row(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .height(46.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Row Index Header Cell (#)
                            Box(
                                modifier = Modifier
                                    .width(50.dp)
                                    .fillMaxHeight()
                                    .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "#",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            // Column Headers
                            grid.columns.forEachIndexed { colIndex, colName ->
                                val isPlColumn = grid.plColumnIndex == colIndex
                                val isFiltered = grid.filterStates.containsKey(colIndex.toString())

                                Box(
                                    modifier = Modifier
                                        .width(130.dp)
                                        .fillMaxHeight()
                                        .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                                        .combinedClickable(
                                            onClick = { viewModel.openFilterDialog(colIndex) },
                                            onLongClick = { viewModel.setColMenu(colIndex) }
                                        )
                                        .padding(horizontal = 8.dp),
                                    contentAlignment = Alignment.CenterStart
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            modifier = Modifier.weight(1f),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = colName,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                color = if (isPlColumn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                            )
                                            if (isPlColumn) {
                                                Spacer(modifier = Modifier.width(2.dp))
                                                Text(
                                                    text = "★",
                                                    fontSize = 10.sp,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }

                                        Icon(
                                            if (isFiltered) Icons.Default.FilterAlt else Icons.Outlined.FilterList,
                                            contentDescription = "فیلتر",
                                            modifier = Modifier.size(16.dp),
                                            tint = if (isFiltered) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                        )
                                    }

                                    // Column Context Menu
                                    if (uiState.activeColMenuIndex == colIndex) {
                                        DropdownMenu(
                                            expanded = true,
                                            onDismissRequest = { viewModel.setColMenu(null) }
                                        ) {
                                            DropdownMenuItem(
                                                text = { Text("فیلتر و مرتب‌سازی") },
                                                leadingIcon = { Icon(Icons.Default.FilterList, contentDescription = null) },
                                                onClick = {
                                                    viewModel.setColMenu(null)
                                                    viewModel.openFilterDialog(colIndex)
                                                }
                                            )
                                            DropdownMenuItem(
                                                text = { Text("تغییر نام ستون") },
                                                leadingIcon = { Icon(Icons.Outlined.Edit, contentDescription = null) },
                                                onClick = {
                                                    renameColumnDialogIndex = colIndex
                                                    renameColumnInput = colName
                                                    viewModel.setColMenu(null)
                                                }
                                            )
                                            DropdownMenuItem(
                                                text = { Text(if (isPlColumn) "عدم انتخاب به عنوان سود/زیان" else "تعیین به عنوان ستون سود/زیان (P/L)") },
                                                leadingIcon = { Icon(Icons.Default.Star, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                                                onClick = {
                                                    viewModel.setPlColumnIndex(if (isPlColumn) null else colIndex)
                                                    viewModel.setColMenu(null)
                                                }
                                            )
                                            DropdownMenuItem(
                                                text = { Text("افزودن ستون به راست") },
                                                leadingIcon = { Icon(Icons.Outlined.Add, contentDescription = null) },
                                                onClick = { viewModel.insertColumnRight(colIndex) }
                                            )
                                            DropdownMenuItem(
                                                text = { Text("افزودن ستون به چپ") },
                                                leadingIcon = { Icon(Icons.Outlined.Add, contentDescription = null) },
                                                onClick = { viewModel.insertColumnLeft(colIndex) }
                                            )
                                            if (colIndex > 0) {
                                                DropdownMenuItem(
                                                    text = { Text("انتقال ستون به چپ") },
                                                    leadingIcon = { Icon(Icons.Default.ArrowBack, contentDescription = null) },
                                                    onClick = { viewModel.moveColumn(colIndex, -1) }
                                                )
                                            }
                                            if (colIndex < grid.columns.size - 1) {
                                                DropdownMenuItem(
                                                    text = { Text("انتقال ستون به راست") },
                                                    leadingIcon = { Icon(Icons.Default.ArrowForward, contentDescription = null) },
                                                    onClick = { viewModel.moveColumn(colIndex, 1) }
                                                )
                                            }
                                            HorizontalDivider()
                                            DropdownMenuItem(
                                                text = { Text("حذف ستون", color = MaterialTheme.colorScheme.error) },
                                                leadingIcon = { Icon(Icons.Outlined.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                                                onClick = {
                                                    deleteColumnConfirmIndex = colIndex
                                                    viewModel.setColMenu(null)
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Lazy Data Rows
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .background(MaterialTheme.colorScheme.surface)
                        ) {
                            items(visibleIndices, key = { it }) { rowIndex ->
                                val row = grid.rows[rowIndex]

                                Row(
                                    modifier = Modifier
                                        .height(42.dp)
                                        .background(if (rowIndex % 2 == 0) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Row Index Cell (#)
                                    Box(
                                        modifier = Modifier
                                            .width(50.dp)
                                            .fillMaxHeight()
                                            .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                                            .combinedClickable(
                                                onClick = { viewModel.setRowMenu(rowIndex) },
                                                onLongClick = { viewModel.setRowMenu(rowIndex) }
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = NumberParser.formatPersian(rowIndex + 1),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )

                                        // Row Context Menu
                                        if (uiState.activeRowMenuIndex == rowIndex) {
                                            DropdownMenu(
                                                expanded = true,
                                                onDismissRequest = { viewModel.setRowMenu(null) }
                                            ) {
                                                DropdownMenuItem(
                                                    text = { Text("افزودن سطر در بالا") },
                                                    leadingIcon = { Icon(Icons.Outlined.Add, contentDescription = null) },
                                                    onClick = { viewModel.insertRowAbove(rowIndex) }
                                                )
                                                DropdownMenuItem(
                                                    text = { Text("افزودن سطر در پایین") },
                                                    leadingIcon = { Icon(Icons.Outlined.Add, contentDescription = null) },
                                                    onClick = { viewModel.insertRowBelow(rowIndex) }
                                                )
                                                DropdownMenuItem(
                                                    text = { Text("تکرار / کپی سطر") },
                                                    leadingIcon = { Icon(Icons.Outlined.ContentCopy, contentDescription = null) },
                                                    onClick = { viewModel.duplicateRow(rowIndex) }
                                                )
                                                HorizontalDivider()
                                                DropdownMenuItem(
                                                    text = { Text("حذف این سطر", color = MaterialTheme.colorScheme.error) },
                                                    leadingIcon = { Icon(Icons.Outlined.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                                                    onClick = {
                                                        deleteRowConfirmIndex = rowIndex
                                                        viewModel.setRowMenu(null)
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    // Row Cells
                                    grid.columns.forEachIndexed { colIndex, _ ->
                                        val cellValue = row.getOrElse(colIndex) { "" }
                                        val isPlCol = grid.plColumnIndex == colIndex
                                        val tradeResult = if (isPlCol) NumberParser.parseTradeResult(cellValue) else null
                                        val numVal = if (!isPlCol) NumberParser.parseDouble(cellValue) else null

                                        val cellTextColor = when {
                                            tradeResult != null && tradeResult > 0 -> ProfitGreen
                                            tradeResult != null && tradeResult < 0 -> LossRed
                                            numVal != null && numVal > 0 -> ProfitGreen
                                            numVal != null && numVal < 0 -> LossRed
                                            else -> MaterialTheme.colorScheme.onSurface
                                        }

                                        Box(
                                            modifier = Modifier
                                                .width(130.dp)
                                                .fillMaxHeight()
                                                .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                                                .clickable { viewModel.startEditCell(rowIndex, colIndex) }
                                                .padding(horizontal = 8.dp),
                                            contentAlignment = Alignment.CenterStart
                                        ) {
                                            Text(
                                                text = if (isPlCol) {
                                                    cellValue
                                                } else if (NumberParser.isNumeric(cellValue) && !cellValue.contains(":") && !cellValue.contains("/")) {
                                                    NumberParser.formatPersian(NumberParser.parseDouble(cellValue) ?: 0.0)
                                                } else {
                                                    cellValue
                                                },
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = cellTextColor,
                                                fontWeight = if (tradeResult != null || numVal != null) FontWeight.Bold else FontWeight.Normal,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Cell Editor Bottom Sheet
    if (uiState.editingCell != null) {
        val cell = uiState.editingCell!!
        val colName = grid.columns.getOrElse(cell.colIndex) { "ستون" }
        CellEditorBottomSheet(
            columnName = colName,
            rowIndex = cell.rowIndex,
            initialValue = uiState.editingCellInitialValue,
            onSave = { newVal, advance ->
                viewModel.saveCellEdit(newVal, advance)
            },
            onDismiss = { viewModel.dismissCellEditor() }
        )
    }

    // Filter Bottom Sheet
    if (uiState.activeFilterDialog != null) {
        FilterBottomSheet(
            filterState = uiState.activeFilterDialog!!,
            onUpdateSearch = { viewModel.updateFilterDialogSearch(it) },
            onToggleValue = { viewModel.toggleFilterValue(it) },
            onSelectAll = { viewModel.selectAllFilterValues(it) },
            onSetSort = { viewModel.setFilterSort(it) },
            onApply = { viewModel.applyColumnFilter() },
            onClear = {
                uiState.activeFilterDialog?.let { viewModel.clearColumnFilter(it.columnIndex) }
            },
            onDismiss = { viewModel.dismissFilterDialog() }
        )
    }

    // Statistics Bottom Sheet
    if (uiState.showStatsPanel) {
        StatsBottomSheet(
            columns = grid.columns,
            filteredRowCount = visibleIndices.size,
            plColumnIndex = grid.plColumnIndex,
            selectedTab = uiState.selectedStatsTab,
            selectedGroupColIndex = uiState.selectedGroupColumnIndex,
            chartMode = uiState.chartMode,
            summaryStats = summaryStats,
            advancedStats = advancedStats,
            groupStats = groupStats,
            dollarStats = dollarStats,
            initialBalance = grid.initialBalance,
            riskPercent = grid.riskPercent,
            onSelectTab = { viewModel.setStatsTab(it) },
            onSetPlColumn = { viewModel.setPlColumnIndex(it) },
            onSetGroupColumn = { viewModel.setGroupColumn(it) },
            onSetChartMode = { viewModel.setChartMode(it) },
            onUpdateMoneyManagement = { bal, risk -> viewModel.updateMoneyManagement(bal, risk) },
            onDismiss = { viewModel.toggleStatsPanel(false) }
        )
    }

    // Rename Workbook Dialog
    if (uiState.showRenameDialog) {
        var nameInput by remember { mutableStateOf(uiState.workbook?.name ?: "") }
        AlertDialog(
            onDismissRequest = { viewModel.setShowRenameDialog(false) },
            title = { Text("تغییر نام جدول") },
            text = {
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    label = { Text("نام جدول") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = { viewModel.renameWorkbook(nameInput) }) {
                    Text("ذخیره")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.setShowRenameDialog(false) }) {
                    Text("انصراف")
                }
            }
        )
    }

    // Rename Column Dialog
    if (renameColumnDialogIndex != null) {
        AlertDialog(
            onDismissRequest = { renameColumnDialogIndex = null },
            title = { Text("تغییر نام ستون") },
            text = {
                OutlinedTextField(
                    value = renameColumnInput,
                    onValueChange = { renameColumnInput = it },
                    label = { Text("عنوان ستون") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        renameColumnDialogIndex?.let { viewModel.renameColumn(it, renameColumnInput) }
                        renameColumnDialogIndex = null
                    }
                ) {
                    Text("ذخیره")
                }
            },
            dismissButton = {
                TextButton(onClick = { renameColumnDialogIndex = null }) {
                    Text("انصراف")
                }
            }
        )
    }

    // Delete Column Confirm Dialog
    if (deleteColumnConfirmIndex != null) {
        val colIdx = deleteColumnConfirmIndex!!
        val colName = grid.columns.getOrElse(colIdx) { "" }
        AlertDialog(
            onDismissRequest = { deleteColumnConfirmIndex = null },
            icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("حذف ستون") },
            text = { Text("آیا از حذف ستون «$colName» و کلیه داده‌های آن مطمئن هستید؟") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteColumn(colIdx)
                        deleteColumnConfirmIndex = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteColumnConfirmIndex = null }) {
                    Text("انصراف")
                }
            }
        )
    }

    // Delete Row Confirm Dialog
    if (deleteRowConfirmIndex != null) {
        val rIdx = deleteRowConfirmIndex!!
        AlertDialog(
            onDismissRequest = { deleteRowConfirmIndex = null },
            icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("حذف سطر") },
            text = { Text("آیا از حذف سطر ${NumberParser.formatPersian(rIdx + 1)} مطمئن هستید؟") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteRow(rIdx)
                        deleteRowConfirmIndex = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteRowConfirmIndex = null }) {
                    Text("انصراف")
                }
            }
        )
    }

    // Export Dialog (Choose all vs filtered)
    if (uiState.showExportDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowExportDialog(false) },
            title = { Text("خروجی فایل اکسل (.xlsx)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("کدام داده‌ها در فایل اکسل ذخیره شوند؟")
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { exportFilteredOnly = false }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = !exportFilteredOnly, onClick = { exportFilteredOnly = false })
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تمام ردیف‌های جدول (${NumberParser.formatPersian(grid.rows.size)} ردیف)")
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { exportFilteredOnly = true }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = exportFilteredOnly, onClick = { exportFilteredOnly = true })
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("فقط ردیف‌های فیلترشده فعلی (${NumberParser.formatPersian(visibleIndices.size)} ردیف)")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.setShowExportDialog(false)
                        val fileName = (uiState.workbook?.name ?: "backtest") + ".xlsx"
                        exportLauncher.launch(fileName)
                    }
                ) {
                    Text("انتخاب محل ذخیره")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.setShowExportDialog(false) }) {
                    Text("انصراف")
                }
            }
        )
    }
}

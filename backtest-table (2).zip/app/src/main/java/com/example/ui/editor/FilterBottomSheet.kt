package com.example.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.util.NumberParser

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilterBottomSheet(
    filterState: FilterDialogState,
    onUpdateSearch: (String) -> Unit,
    onToggleValue: (String) -> Unit,
    onSelectAll: (Boolean) -> Unit,
    onSetSort: (Boolean?) -> Unit,
    onApply: () -> Unit,
    onClear: () -> Unit,
    onDismiss: () -> Unit
) {
    val filteredUniqueList = remember(filterState.uniqueValuesWithCount, filterState.searchQuery) {
        if (filterState.searchQuery.isBlank()) {
            filterState.uniqueValuesWithCount
        } else {
            val q = filterState.searchQuery.lowercase()
            filterState.uniqueValuesWithCount.filter {
                it.first.lowercase().contains(q) ||
                        NumberParser.fromPersianDigits(it.first).lowercase().contains(q)
            }
        }
    }

    val isAllSelected = remember(filterState.selectedValues, filterState.uniqueValuesWithCount) {
        filterState.selectedValues.size == filterState.uniqueValuesWithCount.size
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxHeight(0.85f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.FilterList,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "فیلتر و مرتب‌سازی: «${filterState.columnName}»",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                TextButton(onClick = onClear) {
                    Text("حذف فیلتر", color = MaterialTheme.colorScheme.error)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sort Section
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = filterState.sortAscending == true,
                    onClick = {
                        onSetSort(if (filterState.sortAscending == true) null else true)
                    },
                    label = { Text("مرتب‌سازی صعودی ↑") },
                    leadingIcon = {
                        Icon(Icons.Default.ArrowUpward, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    modifier = Modifier.weight(1f)
                )

                FilterChip(
                    selected = filterState.sortAscending == false,
                    onClick = {
                        onSetSort(if (filterState.sortAscending == false) null else false)
                    },
                    label = { Text("مرتب‌سازی نزولی ↓") },
                    leadingIcon = {
                        Icon(Icons.Default.ArrowDownward, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search within filter values
            OutlinedTextField(
                value = filterState.searchQuery,
                onValueChange = onUpdateSearch,
                placeholder = { Text("جستجو بین مقادیر...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (filterState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onUpdateSearch("") }) {
                            Icon(Icons.Default.Close, contentDescription = null)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("filter_search_input")
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Select All Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectAll(!isAllSelected) }
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = isAllSelected,
                    onCheckedChange = { onSelectAll(it) }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "انتخاب همه مقادیر (${NumberParser.formatPersian(filterState.uniqueValuesWithCount.size)})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            HorizontalDivider()

            // Values List
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 6.dp)
            ) {
                items(filteredUniqueList, key = { it.first }) { (valName, count) ->
                    val isChecked = filterState.selectedValues.contains(valName)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onToggleValue(valName) }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isChecked,
                            onCheckedChange = { onToggleValue(valName) }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = valName,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f)
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = NumberParser.formatPersian(count),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Bottom Action Buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("انصراف")
                }

                Button(
                    onClick = onApply,
                    modifier = Modifier
                        .weight(1.5f)
                        .testTag("apply_filter_button"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("اعمال فیلتر (${NumberParser.formatPersian(filterState.selectedValues.size)})")
                }
            }
        }
    }
}

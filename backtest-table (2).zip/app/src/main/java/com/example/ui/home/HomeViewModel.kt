package com.example.ui.home

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GridSerializer
import com.example.data.SampleData
import com.example.data.local.AppDatabase
import com.example.data.local.WorkbookEntity
import com.example.data.model.GridData
import com.example.data.repository.WorkbookRepository
import com.example.data.xlsx.XlsxEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: WorkbookRepository

    val workbooks: StateFlow<List<WorkbookEntity>>

    init {
        val db = AppDatabase.getDatabase(application)
        repository = WorkbookRepository(db.workbookDao())
        workbooks = repository.allWorkbooks.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
    }

    fun createEmptyWorkbook(onCreated: (Long) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val initialGrid = GridData(
                columns = listOf("تاریخ", "جفت‌ارز", "جهت", "قیمت ورود", "قیمت خروج", "حجم", "سود/زیان", "توضیحات"),
                rows = List(10) { List(8) { "" } },
                plColumnIndex = 6
            )
            val entity = WorkbookEntity(
                name = "جدول بدون نام",
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis(),
                serializedGrid = GridSerializer.serialize(initialGrid),
                plColumnIndex = 6,
                rowCount = initialGrid.rows.size,
                columnCount = initialGrid.columns.size,
                initialBalance = initialGrid.initialBalance,
                riskPercent = initialGrid.riskPercent
            )
            val newId = repository.saveWorkbook(entity)
            withContext(Dispatchers.Main) {
                onCreated(newId)
            }
        }
    }

    fun createSampleWorkbook(onCreated: (Long) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val sampleGrid = SampleData.createSampleGridData()
            val entity = WorkbookEntity(
                name = "بکتست استراتژی پرایس‌اکشن (نمونه)",
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis(),
                serializedGrid = GridSerializer.serialize(sampleGrid),
                plColumnIndex = sampleGrid.plColumnIndex,
                rowCount = sampleGrid.rows.size,
                columnCount = sampleGrid.columns.size,
                initialBalance = sampleGrid.initialBalance,
                riskPercent = sampleGrid.riskPercent
            )
            val newId = repository.saveWorkbook(entity)
            withContext(Dispatchers.Main) {
                onCreated(newId)
            }
        }
    }

    fun importFromXlsx(uri: Uri, onResult: (Result<Long>) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val context = getApplication<Application>()
                val inputStream = context.contentResolver.openInputStream(uri)
                    ?: throw IllegalArgumentException("امکان باز کردن فایل انتخاب شده وجود ندارد.")

                val gridData = inputStream.use { XlsxEngine.readXlsx(it) }

                // Determine name from Uri or default
                val fileName = getFileName(uri) ?: "جدول وارد شده"
                val cleanName = fileName.removeSuffix(".xlsx").removeSuffix(".XLSX")

                val entity = WorkbookEntity(
                    name = cleanName,
                    createdAt = System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis(),
                    serializedGrid = GridSerializer.serialize(gridData),
                    plColumnIndex = gridData.plColumnIndex,
                    rowCount = gridData.rows.size,
                    columnCount = gridData.columns.size,
                    initialBalance = gridData.initialBalance,
                    riskPercent = gridData.riskPercent
                )
                val newId = repository.saveWorkbook(entity)
                withContext(Dispatchers.Main) {
                    onResult(Result.success(newId))
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onResult(Result.failure(e))
                }
            }
        }
    }

    fun renameWorkbook(workbook: WorkbookEntity, newName: String) {
        if (newName.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            val updated = workbook.copy(
                name = newName.trim(),
                updatedAt = System.currentTimeMillis()
            )
            repository.updateWorkbook(updated)
        }
    }

    fun duplicateWorkbook(workbook: WorkbookEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            val duplicate = workbook.copy(
                id = 0,
                name = "${workbook.name} (کپی)",
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            repository.saveWorkbook(duplicate)
        }
    }

    fun deleteWorkbook(workbook: WorkbookEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteWorkbook(workbook)
        }
    }

    private fun getFileName(uri: Uri): String? {
        val cursor = getApplication<Application>().contentResolver.query(uri, null, null, null, null)
        return cursor?.use {
            if (it.moveToFirst()) {
                val nameIndex = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (nameIndex >= 0) it.getString(nameIndex) else null
            } else null
        }
    }
}

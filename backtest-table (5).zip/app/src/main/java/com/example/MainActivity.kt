package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.example.data.preferences.AppPreferences
import com.example.ui.screens.EditorScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.BacktestTheme
import com.example.ui.viewmodel.EditorViewModel
import com.example.ui.viewmodel.HomeViewModel

sealed class AppScreen {
    object Home : AppScreen()
    data class Editor(val workbookId: Long) : AppScreen()
    object Settings : AppScreen()
}

class MainActivity : ComponentActivity() {

    private val homeViewModel: HomeViewModel by viewModels()
    private val editorViewModel: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val preferences = AppPreferences(this)

        setContent {
            var themeMode by remember { mutableStateOf(preferences.themeMode) }
            var currentScreen by remember { mutableStateOf<AppScreen>(AppScreen.Home) }

            BacktestTheme(themeMode = themeMode) {
                // Persian UI / RTL Layout globally
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    when (val screen = currentScreen) {
                        is AppScreen.Home -> {
                            HomeScreen(
                                viewModel = homeViewModel,
                                onOpenWorkbook = { id ->
                                    currentScreen = AppScreen.Editor(id)
                                },
                                onNavigateToSettings = {
                                    currentScreen = AppScreen.Settings
                                }
                            )
                        }
                        is AppScreen.Editor -> {
                            BackHandler {
                                currentScreen = AppScreen.Home
                            }
                            EditorScreen(
                                workbookId = screen.workbookId,
                                viewModel = editorViewModel,
                                onNavigateBack = {
                                    currentScreen = AppScreen.Home
                                },
                                onNavigateToSettings = {
                                    currentScreen = AppScreen.Settings
                                }
                            )
                        }
                        is AppScreen.Settings -> {
                            BackHandler {
                                currentScreen = AppScreen.Home
                            }
                            SettingsScreen(
                                preferences = preferences,
                                onThemeChanged = { newTheme ->
                                    themeMode = newTheme
                                },
                                onNavigateBack = {
                                    currentScreen = AppScreen.Home
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

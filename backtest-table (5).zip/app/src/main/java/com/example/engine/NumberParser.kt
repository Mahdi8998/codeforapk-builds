package com.example.engine

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

sealed class TradeResult {
    data class Counted(val value: Double, val isWin: Boolean) : TradeResult()
    data class Excluded(val reason: String) : TradeResult()
}

object NumberParser {

    /**
     * Normalizes digits (Persian/Arabic to Latin), trims whitespace,
     * strips thousand separators, and converts Persian comma '٫' to '.'.
     */
    fun normalize(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return ""

        val sb = StringBuilder(trimmed.length)
        for (ch in trimmed) {
            when (ch) {
                // Persian digits
                '۰' -> sb.append('0')
                '۱' -> sb.append('1')
                '۲' -> sb.append('2')
                '۳' -> sb.append('3')
                '۴' -> sb.append('4')
                '۵' -> sb.append('5')
                '۶' -> sb.append('6')
                '۷' -> sb.append('7')
                '۸' -> sb.append('8')
                '۹' -> sb.append('9')
                // Arabic-Indic digits
                '٠' -> sb.append('0')
                '١' -> sb.append('1')
                '٢' -> sb.append('2')
                '٣' -> sb.append('3')
                '٤' -> sb.append('4')
                '٥' -> sb.append('5')
                '٦' -> sb.append('6')
                '٧' -> sb.append('7')
                '٨' -> sb.append('8')
                '٩' -> sb.append('9')
                // Persian decimal separator and standard decimal
                '٫' -> sb.append('.')
                '.' -> sb.append('.')
                // Minus signs
                '−', '—', '–', '-' -> sb.append('-')
                // Thousands separators: ignore/strip
                ',', '٬', ' ' -> {} // skip thousand separators
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * Parses numeric value or null. Used by grid, summary stats, sorting, etc.
     */
    fun parseNumberOrNull(raw: String): Double? {
        val norm = normalize(raw)
        if (norm.isEmpty()) return null
        return norm.toDoubleOrNull()
    }

    /**
     * Single shared trade result parser (Section 5.5.2):
     * - Lone dash '-' or '−' -> Loss (-1.0)
     * - Empty / whitespace-only -> Excluded
     * - Positive number N -> Win (+N)
     * - Negative number -> Loss (that negative number)
     * - 0, text, other symbol -> Excluded
     */
    fun parseTradeResult(raw: String): TradeResult {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) {
            return TradeResult.Excluded("خانه خالی است")
        }

        // Lone dash check: "-" (U+002D) or "−" (U+2212) or "—" (U+2014)
        if (trimmed == "-" || trimmed == "−" || trimmed == "—" || trimmed == "–") {
            return TradeResult.Counted(value = -1.0, isWin = false)
        }

        val num = parseNumberOrNull(raw)
        if (num == null) {
            return TradeResult.Excluded("غیر عددی")
        }

        return when {
            num > 0.0 -> TradeResult.Counted(value = num, isWin = true)
            num < 0.0 -> TradeResult.Counted(value = num, isWin = false)
            else -> TradeResult.Excluded("مقدار صفر معتبر نیست") // 0 is excluded per spec (no breakeven)
        }
    }

    /**
     * Formats number with thousand separators and up to maxDecimals.
     */
    fun formatDouble(value: Double, maxDecimals: Int = 2): String {
        if (value.isInfinite()) {
            return if (value > 0) "∞" else "-∞"
        }
        if (value.isNaN()) {
            return "—"
        }
        val symbols = DecimalFormatSymbols(Locale.US).apply {
            groupingSeparator = ','
            decimalSeparator = '.'
        }
        val pattern = if (maxDecimals <= 0) {
            "#,##0"
        } else {
            "#,##0." + "#".repeat(maxDecimals)
        }
        val df = DecimalFormat(pattern, symbols)
        return df.format(value)
    }

    /**
     * Formats currency or dollar amount with 2 decimal places.
     */
    fun formatDollar(value: Double): String {
        return formatDouble(value, 2)
    }

    /**
     * Formats percentage with 1 or 2 decimals.
     */
    fun formatPercent(value: Double, decimals: Int = 1): String {
        return "${formatDouble(value, decimals)}٪"
    }

    /**
     * Formats target R with optional sign and "تارگت".
     */
    fun formatR(value: Double, includeSign: Boolean = false): String {
        val formatted = formatDouble(value, 2)
        val withSign = if (includeSign && value > 0) "+$formatted" else formatted
        return "$withSign R"
    }
}

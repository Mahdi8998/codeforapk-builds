package com.example.engine

import kotlin.math.max
import kotlin.math.min

data class StatsInput(
    val allRows: List<List<String>>, // Filtered rows snapshot in original order
    val headers: List<String>,
    val plColumnIndex: Int?,
    val rrCap: Double?,
    val initialBalance: Double = 500.0,
    val riskPercent: Double = 2.0
)

data class GroupStat(
    val groupValue: String,
    val tradeCount: Int,
    val winCount: Int,
    val lossCount: Int,
    val winRatePercent: Double,
    val netR: Double,
    val netDollar: Double
)

data class ColumnSummary(
    val columnIndex: Int,
    val columnName: String,
    val isNumeric: Boolean,
    val sum: Double? = null,
    val average: Double? = null,
    val frequencyBreakdown: List<Pair<String, Double>> = emptyList() // Value to % (e.g. ("خرید", 60.0))
)

data class StatsResult(
    val totalFilteredRowCount: Int = 0,
    val hasResultColumn: Boolean = false,
    val plColumnName: String = "",
    val countedTradesCount: Int = 0,
    val excludedTradesCount: Int = 0,
    val winCount: Int = 0,
    val lossCount: Int = 0,
    val winRatePercent: Double = 0.0,
    val netR: Double = 0.0,
    val profitFactor: Double = 0.0, // Double.POSITIVE_INFINITY if no losses
    val avgWinR: Double = 0.0,
    val avgLossR: Double = 0.0,
    val rewardToRiskRatio: Double = 0.0,
    val expectancyR: Double = 0.0,
    val bestTradeR: Double? = null,
    val worstTradeR: Double? = null,
    val maxConsecutiveWins: Int = 0,
    val maxConsecutiveLosses: Int = 0,
    val maxDrawdownR: Double = 0.0,
    val maxDrawdownPercentR: Double = 0.0,
    // Group breakdowns
    val defaultGroupColumnIndex: Int? = null,
    val groupStatsByColumn: Map<Int, List<GroupStat>> = emptyMap(),
    // Chart points
    val rEquityCurvePoints: List<Double> = emptyList(),
    val dollarEquityCurvePoints: List<Double> = emptyList(),
    // Dollar simulation metrics
    val initialBalance: Double = 500.0,
    val riskPercent: Double = 2.0,
    val finalDollarBalance: Double = 500.0,
    val netDollarProfit: Double = 0.0,
    val totalReturnPercent: Double = 0.0,
    val avgWinDollar: Double = 0.0,
    val avgLossDollar: Double = 0.0,
    val bestTradeDollar: Double? = null,
    val worstTradeDollar: Double? = null,
    val maxDollarDrawdown: Double = 0.0,
    val maxDollarDrawdownPercent: Double = 0.0,
    // Generic column summaries (Tab «خلاصه»)
    val columnSummaries: List<ColumnSummary> = emptyList()
)

object StatsEngine {

    fun compute(input: StatsInput): StatsResult {
        val totalRows = input.allRows.size
        val colSummaries = computeColumnSummaries(input.allRows, input.headers)

        val plCol = input.plColumnIndex
        if (plCol == null || plCol < 0 || plCol >= input.headers.size) {
            return StatsResult(
                totalFilteredRowCount = totalRows,
                hasResultColumn = false,
                columnSummaries = colSummaries
            )
        }

        val plColName = input.headers.getOrElse(plCol) { "نتیجه" }

        // Process rows in original order
        var countedCount = 0
        var excludedCount = 0
        var winsCount = 0
        var lossesCount = 0

        val countedTradeValues = mutableListOf<Double>() // Capped R value for each counted trade
        val countedRowIndices = mutableListOf<Int>()

        for (rowIndex in input.allRows.indices) {
            val row = input.allRows[rowIndex]
            val cellValue = row.getOrElse(plCol) { "" }
            when (val res = NumberParser.parseTradeResult(cellValue)) {
                is TradeResult.Excluded -> {
                    excludedCount++
                }
                is TradeResult.Counted -> {
                    countedCount++
                    val effectiveVal = if (res.isWin) {
                        winsCount++
                        if (input.rrCap != null && input.rrCap > 0.0) {
                            min(res.value, input.rrCap)
                        } else {
                            res.value
                        }
                    } else {
                        lossesCount++
                        // Loss is negative (e.g. -1.0 or -2.0); cap does NOT affect losses
                        res.value
                    }
                    countedTradeValues.add(effectiveVal)
                    countedRowIndices.add(rowIndex)
                }
            }
        }

        if (countedCount == 0) {
            return StatsResult(
                totalFilteredRowCount = totalRows,
                hasResultColumn = true,
                plColumnName = plColName,
                countedTradesCount = 0,
                excludedTradesCount = excludedCount,
                initialBalance = input.initialBalance,
                riskPercent = input.riskPercent,
                finalDollarBalance = input.initialBalance,
                columnSummaries = colSummaries
            )
        }

        val winRate = (winsCount.toDouble() / countedCount.toDouble()) * 100.0

        var sumWins = 0.0
        var sumLosses = 0.0 // positive magnitude of losses
        var netR = 0.0

        for (v in countedTradeValues) {
            netR += v
            if (v > 0.0) {
                sumWins += v
            } else {
                sumLosses += -v
            }
        }

        val profitFactor = when {
            lossesCount == 0 || sumLosses == 0.0 -> Double.POSITIVE_INFINITY
            winsCount == 0 || sumWins == 0.0 -> 0.0
            else -> sumWins / sumLosses
        }

        val avgWinR = if (winsCount > 0) sumWins / winsCount else 0.0
        val avgLossR = if (lossesCount > 0) sumLosses / lossesCount else 0.0
        val rrRatio = when {
            avgLossR > 0.0 -> avgWinR / avgLossR
            avgWinR > 0.0 -> Double.POSITIVE_INFINITY
            else -> 0.0
        }
        val expectancyR = if (countedCount > 0) netR / countedCount else 0.0
        val bestTradeR = countedTradeValues.maxOrNull()
        val worstTradeR = countedTradeValues.minOrNull()

        // Consecutive wins and losses
        var maxConsecWins = 0
        var maxConsecLosses = 0
        var currentWins = 0
        var currentLosses = 0

        for (v in countedTradeValues) {
            if (v > 0.0) {
                currentWins++
                currentLosses = 0
                if (currentWins > maxConsecWins) maxConsecWins = currentWins
            } else {
                currentLosses++
                currentWins = 0
                if (currentLosses > maxConsecLosses) maxConsecLosses = currentLosses
            }
        }

        // Equity curve for Target R & Drawdown
        val rCurve = mutableListOf<Double>()
        rCurve.add(0.0)
        var cumulativeR = 0.0
        var peakR = 0.0
        var maxDrawdownR = 0.0
        var maxDrawdownPercentR = 0.0

        for (v in countedTradeValues) {
            cumulativeR += v
            rCurve.add(cumulativeR)
            if (cumulativeR > peakR) {
                peakR = cumulativeR
            } else {
                val dd = peakR - cumulativeR
                if (dd > maxDrawdownR) {
                    maxDrawdownR = dd
                }
                if (peakR > 0.0) {
                    val ddPercent = (dd / peakR) * 100.0
                    if (ddPercent > maxDrawdownPercentR) {
                        maxDrawdownPercentR = ddPercent
                    }
                }
            }
        }

        // Dollar compounding simulation (Section 5.5.7)
        val dollarCurve = mutableListOf<Double>()
        dollarCurve.add(input.initialBalance)
        var currentDollar = input.initialBalance
        var peakDollar = input.initialBalance
        var maxDollarDd = 0.0
        var maxDollarDdPercent = 0.0

        var sumWinDollars = 0.0
        var sumLossDollars = 0.0
        var bestTradeDollar: Double? = null
        var worstTradeDollar: Double? = null

        val riskFrac = input.riskPercent / 100.0

        for (v in countedTradeValues) {
            val balanceBefore = currentDollar
            if (v > 0.0) {
                // Win: balance * (1 + riskFrac * R)
                currentDollar = balanceBefore * (1.0 + riskFrac * v)
            } else {
                // Loss: balance * (1 - riskFrac * |R|)
                val lossMag = -v
                currentDollar = max(0.0, balanceBefore * (1.0 - riskFrac * lossMag))
            }
            dollarCurve.add(currentDollar)

            val tradeDelta = currentDollar - balanceBefore
            if (tradeDelta > 0.0) {
                sumWinDollars += tradeDelta
            } else {
                sumLossDollars += -tradeDelta
            }

            if (bestTradeDollar == null || tradeDelta > bestTradeDollar) {
                bestTradeDollar = tradeDelta
            }
            if (worstTradeDollar == null || tradeDelta < worstTradeDollar) {
                worstTradeDollar = tradeDelta
            }

            if (currentDollar > peakDollar) {
                peakDollar = currentDollar
            } else {
                val dd = peakDollar - currentDollar
                if (dd > maxDollarDd) {
                    maxDollarDd = dd
                }
                if (peakDollar > 0.0) {
                    val ddPct = (dd / peakDollar) * 100.0
                    if (ddPct > maxDollarDdPercent) {
                        maxDollarDdPercent = ddPct
                    }
                }
            }
        }

        val netDollarProfit = currentDollar - input.initialBalance
        val totalReturnPercent = if (input.initialBalance > 0) {
            (netDollarProfit / input.initialBalance) * 100.0
        } else 0.0

        val avgWinDollar = if (winsCount > 0) sumWinDollars / winsCount else 0.0
        val avgLossDollar = if (lossesCount > 0) sumLossDollars / lossesCount else 0.0

        // Compute group breakdowns for potential group columns (columns with 2..15 distinct non-numeric values)
        val groupStatsMap = mutableMapOf<Int, List<GroupStat>>()
        var defaultGroupCol: Int? = null

        for (colIdx in input.headers.indices) {
            if (colIdx == plCol) continue
            val distinctValues = input.allRows.map { it.getOrElse(colIdx) { "" }.trim() }
                .filter { it.isNotEmpty() }
                .distinct()

            if (distinctValues.size in 2..20) {
                if (defaultGroupCol == null) {
                    defaultGroupCol = colIdx
                }
                val stats = computeGroupStatsForColumn(
                    rows = input.allRows,
                    colIndex = colIdx,
                    countedRowIndices = countedRowIndices,
                    countedTradeValues = countedTradeValues,
                    initialBalance = input.initialBalance,
                    riskPercent = input.riskPercent
                )
                groupStatsMap[colIdx] = stats
            }
        }

        return StatsResult(
            totalFilteredRowCount = totalRows,
            hasResultColumn = true,
            plColumnName = plColName,
            countedTradesCount = countedCount,
            excludedTradesCount = excludedCount,
            winCount = winsCount,
            lossCount = lossesCount,
            winRatePercent = winRate,
            netR = netR,
            profitFactor = profitFactor,
            avgWinR = avgWinR,
            avgLossR = avgLossR,
            rewardToRiskRatio = rrRatio,
            expectancyR = expectancyR,
            bestTradeR = bestTradeR,
            worstTradeR = worstTradeR,
            maxConsecutiveWins = maxConsecWins,
            maxConsecutiveLosses = maxConsecLosses,
            maxDrawdownR = maxDrawdownR,
            maxDrawdownPercentR = maxDrawdownPercentR,
            defaultGroupColumnIndex = defaultGroupCol,
            groupStatsByColumn = groupStatsMap,
            rEquityCurvePoints = rCurve,
            dollarEquityCurvePoints = dollarCurve,
            initialBalance = input.initialBalance,
            riskPercent = input.riskPercent,
            finalDollarBalance = currentDollar,
            netDollarProfit = netDollarProfit,
            totalReturnPercent = totalReturnPercent,
            avgWinDollar = avgWinDollar,
            avgLossDollar = avgLossDollar,
            bestTradeDollar = bestTradeDollar,
            worstTradeDollar = worstTradeDollar,
            maxDollarDrawdown = maxDollarDd,
            maxDollarDrawdownPercent = maxDollarDdPercent,
            columnSummaries = colSummaries
        )
    }

    private fun computeGroupStatsForColumn(
        rows: List<List<String>>,
        colIndex: Int,
        countedRowIndices: List<Int>,
        countedTradeValues: List<Double>,
        initialBalance: Double,
        riskPercent: Double
    ): List<GroupStat> {
        // Map row index to its counted trade R value
        val rowToRMap = mutableMapOf<Int, Double>()
        for (i in countedRowIndices.indices) {
            rowToRMap[countedRowIndices[i]] = countedTradeValues[i]
        }

        // Group rows that have counted results by their group value
        val groupMap = mutableMapOf<String, MutableList<Double>>()
        for (i in countedRowIndices.indices) {
            val rowIndex = countedRowIndices[i]
            val rVal = countedTradeValues[i]
            val groupKey = rows[rowIndex].getOrElse(colIndex) { "" }.trim().ifEmpty { "نامشخص" }
            groupMap.getOrPut(groupKey) { mutableListOf() }.add(rVal)
        }

        val baseRiskAmount = initialBalance * (riskPercent / 100.0)

        return groupMap.map { (key, rValues) ->
            val total = rValues.size
            val wins = rValues.count { it > 0.0 }
            val losses = rValues.count { it < 0.0 }
            val winRate = if (total > 0) (wins.toDouble() / total) * 100.0 else 0.0
            val netR = rValues.sum()
            // Net dollar per group = order-free sum of single-trade effects: initialBalance * riskPercent/100 * R(trade)
            val netDollar = netR * baseRiskAmount

            GroupStat(
                groupValue = key,
                tradeCount = total,
                winCount = wins,
                lossCount = losses,
                winRatePercent = winRate,
                netR = netR,
                netDollar = netDollar
            )
        }.sortedByDescending { it.tradeCount }
    }

    private fun computeColumnSummaries(
        rows: List<List<String>>,
        headers: List<String>
    ): List<ColumnSummary> {
        val summaries = mutableListOf<ColumnSummary>()

        for (col in headers.indices) {
            val colName = headers[col]
            val values = rows.map { it.getOrElse(col) { "" }.trim() }
            val nonBlankValues = values.filter { it.isNotEmpty() }

            if (nonBlankValues.isEmpty()) {
                summaries.add(ColumnSummary(col, colName, isNumeric = false))
                continue
            }

            // Check if column is numeric
            val parsedNumbers = nonBlankValues.mapNotNull { NumberParser.parseNumberOrNull(it) }
            val isMostlyNumeric = parsedNumbers.size >= (nonBlankValues.size * 0.75)

            if (isMostlyNumeric && parsedNumbers.isNotEmpty()) {
                val sum = parsedNumbers.sum()
                val avg = sum / parsedNumbers.size
                summaries.add(
                    ColumnSummary(
                        columnIndex = col,
                        columnName = colName,
                        isNumeric = true,
                        sum = sum,
                        average = avg
                    )
                )
            } else {
                // Categorical breakdown for columns with 2 to 5 distinct non-numeric values
                val frequencies = nonBlankValues.groupingBy { it }.eachCount()
                if (frequencies.size in 2..5) {
                    val total = nonBlankValues.size.toDouble()
                    val breakdown = frequencies.map { (v, count) ->
                        v to ((count / total) * 100.0)
                    }.sortedByDescending { it.second }
                    summaries.add(
                        ColumnSummary(
                            columnIndex = col,
                            columnName = colName,
                            isNumeric = false,
                            frequencyBreakdown = breakdown
                        )
                    )
                } else {
                    summaries.add(ColumnSummary(col, colName, isNumeric = false))
                }
            }
        }
        return summaries
    }
}

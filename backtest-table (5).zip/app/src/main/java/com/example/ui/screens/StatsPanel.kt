package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.NumberParser
import com.example.engine.StatsResult
import com.example.ui.theme.LossRed
import com.example.ui.theme.ProfitGreen

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StatsPanel(
    stats: StatsResult,
    headers: List<String>,
    totalWorkbookRows: Int,
    isFilterActive: Boolean,
    plColumnIndex: Int?,
    onSelectPlColumn: (Int) -> Unit,
    rrCap: Double?,
    onUpdateRrCap: (Double?) -> Unit,
    initialBalance: Double,
    riskPercent: Double,
    onUpdateMoneySettings: (Double, Double) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(1) } // 0: خلاصه, 1: حرفه‌ای, 2: گروه‌بندی, 3: نمودارها, 4: دلاری
    val tabTitles = listOf("خلاصه", "حرفه‌ای", "گروه‌بندی", "نمودارها", "دلاری")

    var showMoneyDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Panel Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "پنل آنالیز و آمار پیشرفته",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                val rowInfo = if (isFilterActive) {
                    "محاسبه روی ${stats.totalFilteredRowCount} ردیف فیلترشده از $totalWorkbookRows ردیف"
                } else {
                    "محاسبه روی $totalWorkbookRows ردیف جدول"
                }
                Text(
                    text = rowInfo,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "بستن پنل")
            }
        }

        // Check if Result Column is configured
        if (plColumnIndex == null || plColumnIndex !in headers.indices) {
            ResultColumnPickerCard(
                headers = headers,
                onSelectColumn = onSelectPlColumn,
                modifier = Modifier.padding(16.dp)
            )
            return@Column
        }

        // Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            edgePadding = 16.dp,
            divider = { HorizontalDivider() }
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }
        }

        // Content per Tab
        Box(modifier = Modifier.weight(1f)) {
            when (selectedTab) {
                0 -> SummaryTab(stats = stats)
                1 -> ProRTab(
                    stats = stats,
                    rrCap = rrCap,
                    onUpdateRrCap = onUpdateRrCap
                )
                2 -> GroupingTab(stats = stats, headers = headers)
                3 -> LazyColumn(modifier = Modifier.fillMaxSize()) {
                    item { ChartsTabContent(stats = stats) }
                }
                4 -> DollarTab(
                    stats = stats,
                    rrCap = rrCap,
                    initialBalance = initialBalance,
                    riskPercent = riskPercent,
                    onOpenMoneySettings = { showMoneyDialog = true }
                )
            }
        }
    }

    if (showMoneyDialog) {
        MoneySettingsDialog(
            currentBalance = initialBalance,
            currentRisk = riskPercent,
            onDismiss = { showMoneyDialog = false },
            onSave = { b, r ->
                onUpdateMoneySettings(b, r)
                showMoneyDialog = false
            }
        )
    }
}

@Composable
fun ResultColumnPickerCard(
    headers: List<String>,
    onSelectColumn: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = "کدام ستون نتیجه معاملات است؟",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "در این ستون: علامت - یعنی استاپ خورده؛ عدد یعنی شماره تارگت (مثلاً ۳ یعنی تارگت ۳ خورده)؛ خانه خالی یعنی بدون نتیجه و از محاسبات حذف می‌شود.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Box {
                Button(
                    onClick = { expanded = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("انتخاب ستون نتیجه معاملات")
                }

                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    headers.forEachIndexed { idx, name ->
                        DropdownMenuItem(
                            text = { Text(name) },
                            onClick = {
                                onSelectColumn(idx)
                                expanded = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SummaryTab(stats: StatsResult) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "اطلاعات کلی ردیف‌ها",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "تعداد ردیف‌های بررسی‌شده: ${stats.totalFilteredRowCount}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        items(stats.columnSummaries) { col ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = col.columnName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    if (col.isNumeric) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "مجموع: ${NumberParser.formatDouble(col.sum ?: 0.0, 2)}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "میانگین: ${NumberParser.formatDouble(col.average ?: 0.0, 2)}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    } else if (col.frequencyBreakdown.isNotEmpty()) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            col.frequencyBreakdown.forEach { (valName, pct) ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(valName, style = MaterialTheme.typography.bodySmall)
                                    Text(
                                        "${NumberParser.formatDouble(pct, 1)}٪",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                LinearProgressIndicator(
                                    progress = { (pct / 100f).toFloat() },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(4.dp)
                                        .clip(RoundedCornerShape(2.dp)),
                                    color = MaterialTheme.colorScheme.primary,
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            }
                        }
                    } else {
                        Text(
                            text = "ستون متنی عمومی",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProRTab(
    stats: StatsResult,
    rrCap: Double?,
    onUpdateRrCap: (Double?) -> Unit
) {
    var isCapOn by remember(rrCap) { mutableStateOf(rrCap != null && rrCap > 0.0) }
    var capInput by remember(rrCap) { mutableStateOf(if (rrCap != null && rrCap > 0.0) rrCap.toString() else "2") }
    var capError by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // R:R Cap settings card (Section 5.5.5)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "محاسبه سود بر اساس R:R مشخص",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Switch(
                            checked = isCapOn,
                            onCheckedChange = { checked ->
                                isCapOn = checked
                                if (!checked) {
                                    capError = null
                                    onUpdateRrCap(null)
                                } else {
                                    val parsed = NumberParser.parseNumberOrNull(capInput)
                                    if (parsed != null && parsed > 0.0) {
                                        capError = null
                                        onUpdateRrCap(parsed)
                                    } else {
                                        capError = "مقدار باید عددی بزرگتر از صفر باشد"
                                    }
                                }
                            }
                        )
                    }

                    if (isCapOn) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = capInput,
                            onValueChange = { input ->
                                capInput = input
                                val parsed = NumberParser.parseNumberOrNull(input)
                                if (parsed != null && parsed > 0.0) {
                                    capError = null
                                    onUpdateRrCap(parsed)
                                } else {
                                    capError = "مقدار R:R باید بزرگتر از صفر باشد"
                                }
                            },
                            label = { Text("مقدار R:R (مثلاً 1 یا 1.5 یا 2)") },
                            isError = capError != null,
                            supportingText = { capError?.let { Text(it, color = LossRed) } },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "با فعال بودن، هر سودی بزرگتر از این R:R به همان اندازه محدود می‌شود؛ مثلاً با R:R = ۱، تارگت ۳ هم +۱ حساب می‌شود. سمت ضرر (استاپ = −۱) تغییری نمی‌کند.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Persistent chip when cap is ON
        if (rrCap != null && rrCap > 0.0) {
            item {
                AssistChip(
                    onClick = {},
                    label = {
                        Text("مبنا: R:R = ${NumberParser.formatDouble(rrCap, 2)} — درصد برد و آمار ضرر تغییری نمی‌کنند (طبیعی است).")
                    },
                    leadingIcon = { Icon(Icons.Default.Info, contentDescription = null) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        labelColor = MaterialTheme.colorScheme.onPrimaryContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        if (stats.countedTradesCount == 0) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "—",
                            style = MaterialTheme.typography.displayMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "هیچ معامله نتیجه‌داری در این مجموعه یافت نشد.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (stats.excludedTradesCount > 0) {
                            Text(
                                text = "ردیف‌های بدون نتیجه: ${stats.excludedTradesCount}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        } else {
            item {
                // Info header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "تعداد معاملات نتیجه‌دار: ${stats.countedTradesCount}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "ردیف‌های بدون نتیجه: ${stats.excludedTradesCount}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    maxItemsInEachRow = 2
                ) {
                    MetricCard(
                        title = "نتیجه خالص (تارگت)",
                        value = NumberParser.formatR(stats.netR, includeSign = true),
                        color = if (stats.netR >= 0) ProfitGreen else LossRed,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "نرخ برد",
                        value = NumberParser.formatPercent(stats.winRatePercent),
                        color = if (stats.winRatePercent >= 50) ProfitGreen else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    maxItemsInEachRow = 2
                ) {
                    MetricCard(
                        title = "فکتور سود (Profit Factor)",
                        value = NumberParser.formatDouble(stats.profitFactor, 2),
                        color = if (stats.profitFactor >= 1.5) ProfitGreen else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "نسبت ریوارد به ریسک",
                        value = NumberParser.formatDouble(stats.rewardToRiskRatio, 2),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    maxItemsInEachRow = 2
                ) {
                    MetricCard(
                        title = "میانگین برد (R)",
                        value = "+${NumberParser.formatDouble(stats.avgWinR, 2)}",
                        color = ProfitGreen,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "میانگین ضرر (R)",
                        value = "-${NumberParser.formatDouble(stats.avgLossR, 2)}",
                        color = LossRed,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    maxItemsInEachRow = 2
                ) {
                    MetricCard(
                        title = "امید ریاضی هر معامله",
                        value = NumberParser.formatR(stats.expectancyR, includeSign = true),
                        color = if (stats.expectancyR >= 0) ProfitGreen else LossRed,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "بیشترین برد متوالی",
                        value = stats.maxConsecutiveWins.toString(),
                        color = ProfitGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    maxItemsInEachRow = 2
                ) {
                    MetricCard(
                        title = "بهترین معامله (R)",
                        value = stats.bestTradeR?.let { "+${NumberParser.formatDouble(it, 2)}" } ?: "—",
                        color = ProfitGreen,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "بدترین معامله (R)",
                        value = stats.worstTradeR?.let { NumberParser.formatDouble(it, 2) } ?: "—",
                        color = LossRed,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    maxItemsInEachRow = 2
                ) {
                    MetricCard(
                        title = "بیشترین باخت متوالی",
                        value = stats.maxConsecutiveLosses.toString(),
                        color = LossRed,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "حداکثر افت سرمایه (Drawdown)",
                        value = "${NumberParser.formatDouble(stats.maxDrawdownR, 2)} R (${NumberParser.formatDouble(stats.maxDrawdownPercentR, 1)}٪)",
                        color = LossRed,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
fun GroupingTab(stats: StatsResult, headers: List<String>) {
    var selectedColIndex by remember(stats.defaultGroupColumnIndex) {
        mutableStateOf(stats.defaultGroupColumnIndex)
    }
    var expanded by remember { mutableStateOf(false) }

    val availableCols = stats.groupStatsByColumn.keys.toList()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        if (availableCols.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "هیچ ستونی با ۲ تا ۲۰ مقدار دسته‌بندی معتبر برای گروه‌بندی یافت نشد.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
            return@Column
        }

        // Dropdown to choose group column
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("ستون گروه‌بندی:", style = MaterialTheme.typography.titleSmall)
            Box {
                OutlinedButton(onClick = { expanded = true }) {
                    Text(selectedColIndex?.let { headers.getOrElse(it) { "ستون $it" } } ?: "انتخاب ستون")
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    availableCols.forEach { colIdx ->
                        DropdownMenuItem(
                            text = { Text(headers.getOrElse(colIdx) { "ستون $colIdx" }) },
                            onClick = {
                                selectedColIndex = colIdx
                                expanded = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        val groupList = selectedColIndex?.let { stats.groupStatsByColumn[it] } ?: emptyList()

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(groupList) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = item.groupValue,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = NumberParser.formatR(item.netR, includeSign = true),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (item.netR >= 0) ProfitGreen else LossRed
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "معاملات: ${item.tradeCount} (برد ${item.winCount} / باخت ${item.lossCount})",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                text = "نرخ برد: ${NumberParser.formatDouble(item.winRatePercent, 1)}٪",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DollarTab(
    stats: StatsResult,
    rrCap: Double?,
    initialBalance: Double,
    riskPercent: Double,
    onOpenMoneySettings: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Settings card at top (Section 5.5.4)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenMoneySettings() },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "مدیریت سرمایه (درصدی - بهره مرکب)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "موجودی اولیه: ${NumberParser.formatDollar(initialBalance)}$ | ریسک: $riskPercent٪",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = onOpenMoneySettings) {
                            Icon(Icons.Default.Tune, contentDescription = "تنظیمات سرمایه")
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    val capStatus = if (rrCap != null && rrCap > 0.0) {
                        "مبنای سود: R:R = ${NumberParser.formatDouble(rrCap, 2)}"
                    } else {
                        "مبنای سود: بدون محدودیت"
                    }
                    Text(
                        text = "$capStatus | ترتیب ردیف‌ها به‌عنوان ترتیب زمانی معاملات در نظر گرفته می‌شود.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (stats.countedTradesCount == 0) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "—",
                            style = MaterialTheme.typography.displayMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "معامله‌ای برای شبیه‌سازی دلاری وجود ندارد.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        } else {
            item {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    maxItemsInEachRow = 2
                ) {
                    MetricCard(
                        title = "موجودی نهایی",
                        value = "${NumberParser.formatDollar(stats.finalDollarBalance)} $",
                        color = if (stats.finalDollarBalance >= initialBalance) ProfitGreen else LossRed,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "سود / زیان خالص",
                        value = "${if (stats.netDollarProfit >= 0) "+" else ""}${NumberParser.formatDollar(stats.netDollarProfit)} $",
                        color = if (stats.netDollarProfit >= 0) ProfitGreen else LossRed,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    maxItemsInEachRow = 2
                ) {
                    MetricCard(
                        title = "بازده کل (٪)",
                        value = "${if (stats.totalReturnPercent >= 0) "+" else ""}${NumberParser.formatDouble(stats.totalReturnPercent, 2)}٪",
                        color = if (stats.totalReturnPercent >= 0) ProfitGreen else LossRed,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "تعداد معاملات محاسبه‌شده",
                        value = "${stats.countedTradesCount} (بدون نتیجه: ${stats.excludedTradesCount})",
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    maxItemsInEachRow = 2
                ) {
                    MetricCard(
                        title = "میانگین سود دلاری",
                        value = "+${NumberParser.formatDollar(stats.avgWinDollar)} $",
                        color = ProfitGreen,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "میانگین ضرر دلاری",
                        value = "-${NumberParser.formatDollar(stats.avgLossDollar)} $",
                        color = LossRed,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    maxItemsInEachRow = 2
                ) {
                    MetricCard(
                        title = "بهترین معامله (دلاری)",
                        value = stats.bestTradeDollar?.let { "+${NumberParser.formatDollar(it)} $" } ?: "—",
                        color = ProfitGreen,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "بدترین معامله (دلاری)",
                        value = stats.worstTradeDollar?.let { "${NumberParser.formatDollar(it)} $" } ?: "—",
                        color = LossRed,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                MetricCard(
                    title = "حداکثر افت سرمایه دلاری (Drawdown)",
                    value = "${NumberParser.formatDollar(stats.maxDollarDrawdown)} $ (${NumberParser.formatDouble(stats.maxDollarDrawdownPercent, 1)}٪ نسبت به قله)",
                    color = LossRed,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    color: Color = MaterialTheme.colorScheme.onSurface,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
    }
}

@Composable
fun MoneySettingsDialog(
    currentBalance: Double,
    currentRisk: Double,
    onDismiss: () -> Unit,
    onSave: (Double, Double) -> Unit
) {
    var balanceText by remember { mutableStateOf(currentBalance.toString()) }
    var riskText by remember { mutableStateOf(currentRisk.toString()) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تنظیمات مدیریت سرمایه", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = balanceText,
                    onValueChange = { balanceText = it },
                    label = { Text("موجودی اولیه حساب (دلار)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = riskText,
                    onValueChange = { riskText = it },
                    label = { Text("درصد ریسک هر معامله (٪)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                errorMsg?.let {
                    Text(it, color = LossRed, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val b = NumberParser.parseNumberOrNull(balanceText)
                    val r = NumberParser.parseNumberOrNull(riskText)

                    if (b == null || b <= 0) {
                        errorMsg = "موجودی اولیه باید بزرگتر از صفر باشد."
                        return@Button
                    }
                    if (r == null || r <= 0 || r > 100) {
                        errorMsg = "درصد ریسک باید بین ۰ و ۱۰۰ باشد."
                        return@Button
                    }

                    onSave(b, r)
                }
            ) {
                Text("ذخیره")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("انصراف")
            }
        }
    )
}

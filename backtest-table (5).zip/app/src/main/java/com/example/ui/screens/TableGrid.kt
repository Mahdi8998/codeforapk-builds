package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FilterState
import com.example.engine.NumberParser
import com.example.engine.TradeResult
import com.example.ui.theme.LossRed
import com.example.ui.theme.LossRedBg
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.ProfitGreenBg
import com.example.xlsx.XlsxEngine

@Composable
fun TableGrid(
    headers: List<String>,
    rows: List<List<String>>, // Filtered rows to display
    originalRowIndices: List<Int>, // Mapping back to full workbook row index
    selectedRow: Int?,
    selectedCol: Int?,
    plColumnIndex: Int?,
    filterState: FilterState,
    onSelectCell: (row: Int, col: Int) -> Unit,
    onUpdateCell: (row: Int, col: Int, value: String) -> Unit,
    onRenameColumn: (col: Int, newName: String) -> Unit,
    onDeleteColumn: (col: Int) -> Unit,
    onAddColumn: (insertAtIndex: Int, name: String) -> Unit,
    onSetPlColumn: (col: Int) -> Unit,
    onUpdateColumnFilter: (col: Int, selectedValues: Set<String>?) -> Unit,
    onSortColumn: (col: Int, ascending: Boolean) -> Unit,
    onAddRow: (insertAtIndex: Int) -> Unit,
    onDeleteRow: (rowIndex: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val hScrollState = rememberScrollState()
    val vListState = rememberLazyListState()

    var columnMenuIndex by remember { mutableStateOf<Int?>(null) }
    var rowMenuIndex by remember { mutableStateOf<Int?>(null) }

    var renameColIndex by remember { mutableStateOf<Int?>(null) }
    var filterColIndex by remember { mutableStateOf<Int?>(null) }
    var showAddColDialog by remember { mutableStateOf(false) }

    val defaultColWidth = 115.dp
    val gutterWidth = 48.dp
    val cellHeight = 44.dp
    val headerHeight = 48.dp

    // Table Grid is strictly LTR per Section 5.1
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.surface)
        ) {
            // Header Row (Horizontal scroll)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(headerHeight)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ) {
                // Sticky top-left corner
                Box(
                    modifier = Modifier
                        .width(gutterWidth)
                        .fillMaxHeight()
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                    contentAlignment = Alignment.Center
                ) {
                    IconButton(
                        onClick = { showAddColDialog = true },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            Icons.Default.Add,
                            contentDescription = "افزودن ستون",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Scrollable column headers
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .horizontalScroll(hScrollState)
                ) {
                    headers.forEachIndexed { colIdx, headerTitle ->
                        val colLetter = XlsxEngine.columnIndexToLetters(colIdx)
                        val isPl = colIdx == plColumnIndex
                        val hasFilter = filterState.selectedValues.containsKey(colIdx)
                        val isSorted = filterState.sortColumnIndex == colIdx

                        Box(
                            modifier = Modifier
                                .width(defaultColWidth)
                                .fillMaxHeight()
                                .background(
                                    if (isPl) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                                .clickable { columnMenuIndex = colIdx }
                                .padding(horizontal = 6.dp, vertical = 2.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = colLetter,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (isPl) {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Icon(
                                                Icons.Default.Flag,
                                                contentDescription = "ستون نتیجه",
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(12.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = headerTitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (hasFilter) {
                                        Icon(
                                            Icons.Default.FilterList,
                                            contentDescription = "فیلتر فعال",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                    if (isSorted) {
                                        Icon(
                                            if (filterState.sortAscending) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                            contentDescription = "مرتب‌سازی",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                    Icon(
                                        Icons.Default.MoreVert,
                                        contentDescription = "منو",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Data Rows (Vertical scroll)
            LazyColumn(
                state = vListState,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                itemsIndexed(rows) { displayRowIdx, rowData ->
                    val actualRowIdx = originalRowIndices.getOrElse(displayRowIdx) { displayRowIdx }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(cellHeight)
                    ) {
                        // Sticky Row Gutter
                        Box(
                            modifier = Modifier
                                .width(gutterWidth)
                                .fillMaxHeight()
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                                .clickable { rowMenuIndex = actualRowIdx },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${displayRowIdx + 1}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        // Cells (Synchronized horizontal scroll)
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .horizontalScroll(hScrollState)
                        ) {
                            headers.forEachIndexed { colIdx, _ ->
                                val cellVal = rowData.getOrElse(colIdx) { "" }
                                val isSelected = selectedRow == displayRowIdx && selectedCol == colIdx
                                val isPlCol = colIdx == plColumnIndex

                                // P/L Result styling
                                val (cellBg, cellTextColor) = if (isPlCol) {
                                    when (val r = NumberParser.parseTradeResult(cellVal)) {
                                        is TradeResult.Counted -> {
                                            if (r.isWin) Pair(ProfitGreenBg, ProfitGreen)
                                            else Pair(LossRedBg, LossRed)
                                        }
                                        is TradeResult.Excluded -> Pair(Color.Transparent, MaterialTheme.colorScheme.onSurface)
                                    }
                                } else {
                                    Pair(Color.Transparent, MaterialTheme.colorScheme.onSurface)
                                }

                                val isNumeric = NumberParser.parseNumberOrNull(cellVal) != null

                                Box(
                                    modifier = Modifier
                                        .width(defaultColWidth)
                                        .fillMaxHeight()
                                        .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else cellBg)
                                        .border(
                                            width = if (isSelected) 2.dp else 0.5.dp,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                                        )
                                        .clickable {
                                            onSelectCell(displayRowIdx, colIdx)
                                        }
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                    contentAlignment = if (isNumeric || isPlCol) Alignment.CenterEnd else Alignment.CenterStart
                                ) {
                                    Text(
                                        text = cellVal,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (isPlCol) cellTextColor else MaterialTheme.colorScheme.onSurface,
                                        fontWeight = if (isPlCol && cellVal.isNotBlank()) FontWeight.Bold else FontWeight.Normal,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        textAlign = if (isNumeric || isPlCol) TextAlign.End else TextAlign.Start
                                    )
                                }
                            }
                        }
                    }
                }

                // Add row button at the bottom of the table
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .clickable { onAddRow(rows.size) }
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                            .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Spacer(modifier = Modifier.width(gutterWidth))
                        Icon(
                            Icons.Default.Add,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "افزودن ردیف جدید (+)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }

    // Column Context Menu
    columnMenuIndex?.let { colIdx ->
        val headerName = headers.getOrElse(colIdx) { "" }
        DropdownMenu(
            expanded = true,
            onDismissRequest = { columnMenuIndex = null }
        ) {
            DropdownMenuItem(
                text = { Text("تغییر نام ستون") },
                leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                onClick = {
                    columnMenuIndex = null
                    renameColIndex = colIdx
                }
            )
            DropdownMenuItem(
                text = { Text("فیلتر بر اساس مقادیر") },
                leadingIcon = { Icon(Icons.Default.FilterList, contentDescription = null) },
                onClick = {
                    columnMenuIndex = null
                    filterColIndex = colIdx
                }
            )
            DropdownMenuItem(
                text = { Text("مرتب‌سازی صعودی (A-Z, 0-9)") },
                leadingIcon = { Icon(Icons.Default.ArrowUpward, contentDescription = null) },
                onClick = {
                    columnMenuIndex = null
                    onSortColumn(colIdx, true)
                }
            )
            DropdownMenuItem(
                text = { Text("مرتب‌سازی نزولی (Z-A, 9-0)") },
                leadingIcon = { Icon(Icons.Default.ArrowDownward, contentDescription = null) },
                onClick = {
                    columnMenuIndex = null
                    onSortColumn(colIdx, false)
                }
            )
            HorizontalDivider()
            DropdownMenuItem(
                text = { Text(if (colIdx == plColumnIndex) "ستون نتیجه فعلی (✓)" else "انتخاب به‌عنوان ستون نتیجه") },
                leadingIcon = { Icon(Icons.Default.Flag, contentDescription = null) },
                onClick = {
                    columnMenuIndex = null
                    onSetPlColumn(colIdx)
                }
            )
            DropdownMenuItem(
                text = { Text("افزودن ستون به راست") },
                leadingIcon = { Icon(Icons.Default.Add, contentDescription = null) },
                onClick = {
                    columnMenuIndex = null
                    onAddColumn(colIdx + 1, "ستون جدید")
                }
            )
            if (headers.size > 1) {
                DropdownMenuItem(
                    text = { Text("حذف این ستون", color = LossRed) },
                    leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = LossRed) },
                    onClick = {
                        columnMenuIndex = null
                        onDeleteColumn(colIdx)
                    }
                )
            }
        }
    }

    // Row Context Menu
    rowMenuIndex?.let { actualRowIdx ->
        DropdownMenu(
            expanded = true,
            onDismissRequest = { rowMenuIndex = null }
        ) {
            DropdownMenuItem(
                text = { Text("افزودن ردیف بالا") },
                leadingIcon = { Icon(Icons.Default.Add, contentDescription = null) },
                onClick = {
                    rowMenuIndex = null
                    onAddRow(actualRowIdx)
                }
            )
            DropdownMenuItem(
                text = { Text("افزودن ردیف پایین") },
                leadingIcon = { Icon(Icons.Default.Add, contentDescription = null) },
                onClick = {
                    rowMenuIndex = null
                    onAddRow(actualRowIdx + 1)
                }
            )
            DropdownMenuItem(
                text = { Text("حذف این ردیف", color = LossRed) },
                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = LossRed) },
                onClick = {
                    rowMenuIndex = null
                    onDeleteRow(actualRowIdx)
                }
            )
        }
    }

    // Rename Column Dialog
    renameColIndex?.let { colIdx ->
        var newTitle by remember { mutableStateOf(headers.getOrElse(colIdx) { "" }) }
        AlertDialog(
            onDismissRequest = { renameColIndex = null },
            title = { Text("تغییر نام ستون") },
            text = {
                OutlinedTextField(
                    value = newTitle,
                    onValueChange = { newTitle = it },
                    label = { Text("نام ستون") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (newTitle.isNotBlank()) {
                        onRenameColumn(colIdx, newTitle.trim())
                    }
                    renameColIndex = null
                }) {
                    Text("ذخیره")
                }
            },
            dismissButton = {
                TextButton(onClick = { renameColIndex = null }) {
                    Text("انصراف")
                }
            }
        )
    }

    // Add Column Dialog
    if (showAddColDialog) {
        var colName by remember { mutableStateOf("ستون جدید") }
        AlertDialog(
            onDismissRequest = { showAddColDialog = false },
            title = { Text("افزودن ستون جدید") },
            text = {
                OutlinedTextField(
                    value = colName,
                    onValueChange = { colName = it },
                    label = { Text("نام ستون") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (colName.isNotBlank()) {
                        onAddColumn(headers.size, colName.trim())
                    }
                    showAddColDialog = false
                }) {
                    Text("افزودن")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddColDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }

    // Filter Column Dialog (Excel-style multi-select)
    filterColIndex?.let { colIdx ->
        val allDistinctValues = remember(colIdx, rows) {
            rows.map { it.getOrElse(colIdx) { "" }.trim() }
                .distinct()
                .sorted()
        }

        var selectedSet by remember {
            mutableStateOf(
                filterState.selectedValues[colIdx] ?: allDistinctValues.toSet()
            )
        }

        AlertDialog(
            onDismissRequest = { filterColIndex = null },
            title = { Text("فیلتر ستون: ${headers.getOrElse(colIdx) { "" }}") },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TextButton(onClick = { selectedSet = allDistinctValues.toSet() }) {
                            Text("انتخاب همه")
                        }
                        TextButton(onClick = { selectedSet = emptySet() }) {
                            Text("لغو همه")
                        }
                    }
                    HorizontalDivider()
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp)
                    ) {
                        items(allDistinctValues.size) { i ->
                            val value = allDistinctValues[i]
                            val isChecked = selectedSet.contains(value)
                            val displayLabel = value.ifEmpty { "(خالی)" }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedSet = if (isChecked) {
                                            selectedSet - value
                                        } else {
                                            selectedSet + value
                                        }
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { check ->
                                        selectedSet = if (check) {
                                            selectedSet + value
                                        } else {
                                            selectedSet - value
                                        }
                                    }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = displayLabel,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (selectedSet.size == allDistinctValues.size) {
                        // All selected means no filter
                        onUpdateColumnFilter(colIdx, null)
                    } else {
                        onUpdateColumnFilter(colIdx, selectedSet)
                    }
                    filterColIndex = null
                }) {
                    Text("اعمال فیلتر")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    onUpdateColumnFilter(colIdx, null)
                    filterColIndex = null
                }) {
                    Text("پاک کردن فیلتر")
                }
            }
        )
    }
}

package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.NumberParser
import com.example.ui.theme.LossRed
import com.example.ui.theme.LossRedBg
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.ProfitGreenBg
import com.example.ui.viewmodel.EditorViewModel
import com.example.xlsx.XlsxEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    workbookId: Long,
    viewModel: EditorViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by viewModel.uiState.collectAsState()

    var showRenameDialog by remember { mutableStateOf(false) }
    var showExportOptionsDialog by remember { mutableStateOf(false) }
    var exportOnlyFiltered by remember { mutableStateOf(false) }
    var moreMenuExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(workbookId) {
        viewModel.loadWorkbook(workbookId)
    }

    // SAF CreateDocument Launcher for exporting XLSX
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                try {
                    context.contentResolver.openOutputStream(uri)?.use { os ->
                        val rowsToExport = if (exportOnlyFiltered) state.filteredRows else state.allRows
                        XlsxEngine.writeXlsx(
                            outputStream = os,
                            headers = state.headers,
                            rows = rowsToExport
                        )
                    }
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "فایل اکسل با موفقیت ذخیره شد ✅", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "خطا در خروجی اکسل: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column(modifier = Modifier.padding(start = 4.dp)) {
                        Text(
                            text = state.workbook?.name ?: "جدول بکتست",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        val totalRows = state.allRows.size
                        val filteredCount = state.filteredRows.size
                        val subText = if (state.filterState.isAnyFilterActive) {
                            "$filteredCount از $totalRows ردیف (فیلترشده)"
                        } else {
                            "$totalRows ردیف"
                        }
                        Text(
                            text = subText,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                actions = {
                    // AI Strategy Analyst button
                    FilledTonalButton(
                        onClick = { viewModel.setAiDialogOpen(true) },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Icon(
                            Icons.Default.Psychology,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تحلیل AI", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    // Export XLSX
                    IconButton(
                        onClick = {
                            if (state.filterState.isAnyFilterActive && state.filteredRows.size < state.allRows.size) {
                                showExportOptionsDialog = true
                            } else {
                                exportOnlyFiltered = false
                                val defaultName = "${state.workbook?.name ?: "Backtest"}.xlsx"
                                exportLauncher.launch(defaultName)
                            }
                        }
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = "خروجی اکسل")
                    }

                    // More Menu
                    IconButton(onClick = { moreMenuExpanded = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "منوی بیشتر")
                    }

                    DropdownMenu(
                        expanded = moreMenuExpanded,
                        onDismissRequest = { moreMenuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("تغییر نام جدول") },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                            onClick = {
                                moreMenuExpanded = false
                                showRenameDialog = true
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("تنظیمات برنامه و هوش مصنوعی") },
                            leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null) },
                            onClick = {
                                moreMenuExpanded = false
                                onNavigateToSettings()
                            }
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Search and Filter Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = state.filterState.searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    placeholder = { Text("جستجو در جدول...", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    trailingIcon = {
                        if (state.filterState.searchQuery.isNotBlank()) {
                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "پاک کردن", modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                )

                if (state.filterState.isAnyFilterActive) {
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = { viewModel.clearAllFilters() },
                        modifier = Modifier.size(42.dp)
                    ) {
                        Icon(
                            Icons.Default.DeleteSweep,
                            contentDescription = "پاک کردن همه فیلترها",
                            tint = LossRed
                        )
                    }
                }
            }

            // Active Filter Chips
            if (state.filterState.selectedValues.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    state.filterState.selectedValues.forEach { (colIdx, values) ->
                        val colName = state.headers.getOrElse(colIdx) { "ستون $colIdx" }
                        AssistChip(
                            onClick = { viewModel.updateColumnFilter(colIdx, null) },
                            label = { Text("$colName (${values.size})", fontSize = 11.sp) },
                            trailingIcon = { Icon(Icons.Default.Close, contentDescription = "حذف فیلتر", modifier = Modifier.size(14.dp)) }
                        )
                    }
                }
            }

            // Formula / Cell Edit Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val cellCoord = if (state.selectedRow != null && state.selectedCol != null) {
                    val colLetter = XlsxEngine.columnIndexToLetters(state.selectedCol!!)
                    "$colLetter${state.selectedRow!! + 1}"
                } else {
                    "—"
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                    modifier = Modifier.padding(end = 8.dp)
                ) {
                    Text(
                        text = cellCoord,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                OutlinedTextField(
                    value = state.selectedCellValue,
                    onValueChange = { viewModel.updateSelectedCell(it) },
                    placeholder = { Text("مقدار خانه انتخاب‌شده...", fontSize = 12.sp) },
                    singleLine = true,
                    enabled = state.selectedRow != null && state.selectedCol != null,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                )
            }

            // Main Table and Stats Panel Container
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                // Table Grid
                TableGrid(
                    headers = state.headers,
                    rows = state.filteredRows,
                    originalRowIndices = state.originalRowIndices,
                    selectedRow = state.selectedRow,
                    selectedCol = state.selectedCol,
                    plColumnIndex = state.plColumnIndex,
                    filterState = state.filterState,
                    onSelectCell = { r, c -> viewModel.selectCell(r, c) },
                    onUpdateCell = { r, c, v -> viewModel.updateCell(r, c, v) },
                    onRenameColumn = { c, name -> viewModel.renameColumn(c, name) },
                    onDeleteColumn = { c -> viewModel.deleteColumn(c) },
                    onAddColumn = { idx, name -> viewModel.addColumn(idx, name) },
                    onSetPlColumn = { c -> viewModel.setPlColumn(c) },
                    onUpdateColumnFilter = { c, vals -> viewModel.updateColumnFilter(c, vals) },
                    onSortColumn = { c, asc -> viewModel.sortColumn(c, asc) },
                    onAddRow = { idx -> viewModel.addRow(idx) },
                    onDeleteRow = { idx -> viewModel.deleteRow(idx) },
                    modifier = Modifier.fillMaxSize()
                )

                // Animated Stats Panel Overlay (Sliding in from bottom/top)
                androidx.compose.animation.AnimatedVisibility(
                    visible = state.isStatsPanelOpen,
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
                ) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        StatsPanel(
                            stats = state.statsResult,
                            headers = state.headers,
                            totalWorkbookRows = state.allRows.size,
                            isFilterActive = state.filterState.isAnyFilterActive,
                            plColumnIndex = state.plColumnIndex,
                            onSelectPlColumn = { viewModel.setPlColumn(it) },
                            rrCap = state.rrCap,
                            onUpdateRrCap = { viewModel.updateRrCap(it) },
                            initialBalance = state.initialBalance,
                            riskPercent = state.riskPercent,
                            onUpdateMoneySettings = { b, r -> viewModel.updateMoneySettings(b, r) },
                            onClose = { viewModel.toggleStatsPanel() }
                        )
                    }
                }
            }

            // Quick Trade Logger Toolbar (Bottom for fast mobile entry)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Dash (Stop loss) button
                Button(
                    onClick = { viewModel.updateSelectedCell("-") },
                    shape = RoundedCornerShape(8.dp),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = LossRedBg,
                        contentColor = LossRed
                    ),
                    modifier = Modifier.weight(1f).height(40.dp)
                ) {
                    Text("-", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }

                // Targets 1, 2, 3, 4
                listOf("1", "2", "3", "4").forEach { targetNum ->
                    Button(
                        onClick = { viewModel.updateSelectedCell(targetNum) },
                        shape = RoundedCornerShape(8.dp),
                        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                            containerColor = ProfitGreenBg,
                            contentColor = ProfitGreen
                        ),
                        modifier = Modifier.weight(1f).height(40.dp)
                    ) {
                        Text(targetNum, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }

                // Clear cell
                OutlinedButton(
                    onClick = { viewModel.updateSelectedCell("") },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(40.dp)
                ) {
                    Text("پاک", fontSize = 11.sp)
                }

                // Next row navigation
                IconButton(
                    onClick = {
                        val currR = state.selectedRow ?: 0
                        val currC = state.selectedCol ?: 0
                        if (currR + 1 < state.filteredRows.size) {
                            viewModel.selectCell(currR + 1, currC)
                        } else {
                            viewModel.addRow(state.allRows.size)
                            viewModel.selectCell(currR + 1, currC)
                        }
                    },
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "ردیف بعدی")
                }
            }

            // Bottom Status / Analytics Drawer Bar (Section 5.4.1)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Quick status info
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val res = state.statsResult
                    if (res.countedTradesCount > 0) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                                Text(
                                    text = "وین‌ریت: ${NumberParser.formatDouble(res.winRatePercent, 0)}٪",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "|  سود: ${NumberParser.formatR(res.netR, includeSign = true)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (res.netR >= 0) ProfitGreen else LossRed
                                )
                            }
                        }
                    } else {
                        Text(
                            text = "${state.filteredRows.size} ردیف",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Stats Panel Toggle Button
                Button(
                    onClick = { viewModel.toggleStatsPanel() },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.height(38.dp)
                ) {
                    Icon(
                        Icons.Default.Analytics,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (state.isStatsPanelOpen) "بستن پنل آمار" else "پنل آمار و آنالیز")
                }
            }
        }
    }

    // AI Strategy Analyst Dialog
    if (state.isAiDialogOpen) {
        AiAnalystDialog(
            aiClient = viewModel.getActiveAiClient(),
            preferences = viewModel.preferences,
            stats = state.statsResult,
            headers = state.headers,
            filteredRows = state.filteredRows,
            totalRows = state.allRows.size,
            filterState = state.filterState,
            plColumnIndex = state.plColumnIndex,
            initialBalance = state.initialBalance,
            riskPercent = state.riskPercent,
            rrCap = state.rrCap,
            onOpenSettings = onNavigateToSettings,
            onDismiss = { viewModel.setAiDialogOpen(false) }
        )
    }

    // Rename Workbook Dialog
    if (showRenameDialog) {
        var currentName by remember { mutableStateOf(state.workbook?.name ?: "") }
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = { Text("تغییر نام جدول بکتست") },
            text = {
                OutlinedTextField(
                    value = currentName,
                    onValueChange = { currentName = it },
                    label = { Text("نام جدید جدول") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (currentName.isNotBlank()) {
                        viewModel.renameWorkbook(currentName.trim())
                    }
                    showRenameDialog = false
                }) {
                    Text("ذخیره")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }

    // Export Options Dialog (if filters are active)
    if (showExportOptionsDialog) {
        AlertDialog(
            onDismissRequest = { showExportOptionsDialog = false },
            title = { Text("خروجی اکسل (XLSX)") },
            text = {
                Text("فیلترهایی روی جدول اعمال شده است. مایلید کدام ردیف‌ها ذخیره شوند؟")
            },
            confirmButton = {
                Button(onClick = {
                    showExportOptionsDialog = false
                    exportOnlyFiltered = true
                    val defaultName = "${state.workbook?.name ?: "Backtest"}_filtered.xlsx"
                    exportLauncher.launch(defaultName)
                }) {
                    Text("فقط ردیف‌های فیلترشده (${state.filteredRows.size})")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showExportOptionsDialog = false
                    exportOnlyFiltered = false
                    val defaultName = "${state.workbook?.name ?: "Backtest"}_all.xlsx"
                    exportLauncher.launch(defaultName)
                }) {
                    Text("همه ردیف‌ها (${state.allRows.size})")
                }
            }
        )
    }
}

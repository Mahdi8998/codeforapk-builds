package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.GridData
import com.example.data.model.WorkbookEntity
import com.example.data.preferences.AppPreferences
import com.example.data.repository.WorkbookRepository
import com.example.xlsx.XlsxEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: WorkbookRepository
    val preferences = AppPreferences(application)

    val workbooks: StateFlow<List<WorkbookEntity>>

    init {
        val db = AppDatabase.getInstance(application)
        repository = WorkbookRepository(db.workbookDao())
        workbooks = repository.allWorkbooks.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun createNewWorkbook(name: String, onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val id = repository.createNewWorkbook(name)
            onCreated(id)
        }
    }

    fun createSampleWorkbook(onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val id = repository.createSampleWorkbook()
            onCreated(id)
        }
    }

    fun duplicateWorkbook(id: Long) {
        viewModelScope.launch {
            repository.duplicateWorkbook(id)
        }
    }

    fun renameWorkbook(workbook: WorkbookEntity, newName: String) {
        viewModelScope.launch {
            repository.updateWorkbook(
                workbook.copy(
                    name = newName.ifBlank { workbook.name },
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    fun deleteWorkbook(id: Long) {
        viewModelScope.launch {
            repository.deleteWorkbook(id)
        }
    }

    fun importXlsx(uri: Uri, onImported: (Long) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val context = getApplication<Application>()
                val inputStream = context.contentResolver.openInputStream(uri)
                    ?: throw IllegalArgumentException("امکان خواندن فایل انتخاب‌شده وجود ندارد.")

                val (headers, rows) = inputStream.use { stream ->
                    XlsxEngine.readXlsx(stream)
                }

                if (headers.isEmpty()) {
                    throw IllegalArgumentException("هیچ ستونی در برگه اکسل یافت نشد.")
                }

                // Detect candidate result column: find column named 'نتیجه', 'result', 'p/l', 'pl', or containing mostly numbers and dashes
                var plColIndex: Int? = null
                val lowerHeaders = headers.map { it.lowercase().trim() }
                for (i in lowerHeaders.indices) {
                    val h = lowerHeaders[i]
                    if (h.contains("نتیجه") || h.contains("result") || h.contains("p/l") || h.contains("pl") || h.contains("r")) {
                        plColIndex = i
                        break
                    }
                }
                if (plColIndex == null) {
                    // Check if any column contains '-' and numbers
                    for (c in headers.indices) {
                        val sampleVals = rows.take(15).map { it.getOrElse(c) { "" }.trim() }
                        if (sampleVals.any { it == "-" || it == "−" } && sampleVals.any { it.toIntOrNull() != null }) {
                            plColIndex = c
                            break
                        }
                    }
                }

                val grid = GridData(headers = headers, rows = rows)
                val newWb = WorkbookEntity(
                    name = "اکسل وارد شده (${System.currentTimeMillis() % 10000})",
                    gridJson = grid.toJson(),
                    plColumnIndex = plColIndex,
                    initialBalance = 500.0,
                    riskPercent = 2.0
                )
                val newId = repository.saveWorkbook(newWb)

                withContext(Dispatchers.Main) {
                    onImported(newId)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onError(e.localizedMessage ?: "خطا در بارگذاری فایل اکسل")
                }
            }
        }
    }
}

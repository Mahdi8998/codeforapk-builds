package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.GroupStat
import com.example.engine.NumberParser
import com.example.engine.StatsResult
import com.example.ui.theme.LossRed
import com.example.ui.theme.ProfitGreen
import kotlin.math.max
import kotlin.math.min

enum class ChartUnitMode {
    TARGET_R,
    DOLLAR
}

enum class BarChartMetric {
    NET_VALUE,
    WIN_RATE
}

@Composable
fun ChartsTabContent(
    stats: StatsResult,
    modifier: Modifier = Modifier
) {
    var unitMode by remember { mutableStateOf(ChartUnitMode.TARGET_R) }
    var barMetric by remember { mutableStateOf(BarChartMetric.NET_VALUE) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Unit Selector Toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "واحد نمایش نمودارها:",
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(end = 12.dp)
            )
            FilterChip(
                selected = unitMode == ChartUnitMode.TARGET_R,
                onClick = { unitMode = ChartUnitMode.TARGET_R },
                label = { Text("تارگت (R)") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            FilterChip(
                selected = unitMode == ChartUnitMode.DOLLAR,
                onClick = { unitMode = ChartUnitMode.DOLLAR },
                label = { Text("دلار ($)") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }

        // 1. Equity Curve
        EquityCurveCard(stats = stats, unitMode = unitMode)

        // 2. Win / Loss Donut Chart (Always visible)
        WinLossDonutCard(stats = stats)

        // 3. Group Bar Chart
        GroupBarChartCard(
            stats = stats,
            unitMode = unitMode,
            barMetric = barMetric,
            onMetricToggle = { barMetric = it }
        )
    }
}

@Composable
fun EquityCurveCard(
    stats: StatsResult,
    unitMode: ChartUnitMode
) {
    val points = if (unitMode == ChartUnitMode.TARGET_R) {
        stats.rEquityCurvePoints
    } else {
        stats.dollarEquityCurvePoints
    }

    val isPositive = if (unitMode == ChartUnitMode.TARGET_R) {
        stats.netR >= 0
    } else {
        stats.finalDollarBalance >= stats.initialBalance
    }

    val finalLabel = if (unitMode == ChartUnitMode.TARGET_R) {
        NumberParser.formatR(stats.netR, includeSign = true)
    } else {
        "${NumberParser.formatDollar(stats.finalDollarBalance)} دلار"
    }

    val lineColor = if (isPositive) ProfitGreen else LossRed

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (unitMode == ChartUnitMode.TARGET_R) "منحنی رشد سرمایه (R)" else "منحنی موجودی حساب (دلار)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = finalLabel,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = lineColor
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (points.size < 2) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "داده‌های کافی برای رسم منحنی وجود ندارد (حداقل یک معامله نتیجه‌دار)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                EquityCurveCanvas(
                    points = points,
                    lineColor = lineColor,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                )
            }
        }
    }
}

@Composable
fun EquityCurveCanvas(
    points: List<Double>,
    lineColor: Color,
    modifier: Modifier = Modifier
) {
    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)

    Canvas(modifier = modifier) {
        if (points.size < 2) return@Canvas

        val padding = 24.dp.toPx()
        val width = size.width - (padding * 2)
        val height = size.height - (padding * 2)

        val minVal = points.minOrNull() ?: 0.0
        val maxVal = points.maxOrNull() ?: 0.0
        val range = if (maxVal == minVal) 1.0 else maxVal - minVal

        // Draw horizontal guide lines
        val lineCount = 4
        for (i in 0..lineCount) {
            val y = padding + height - (i * (height / lineCount))
            drawLine(
                color = gridColor,
                start = Offset(padding, y),
                end = Offset(padding + width, y),
                strokeWidth = 1.dp.toPx()
            )
        }

        // Generate line path
        val path = Path()
        val fillPath = Path()

        val stepX = width / (points.size - 1)

        points.forEachIndexed { index, value ->
            val x = padding + (index * stepX)
            val normalizedY = ((value - minVal) / range).toFloat()
            val y = padding + height - (normalizedY * height)

            if (index == 0) {
                path.moveTo(x, y)
                fillPath.moveTo(x, padding + height)
                fillPath.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fillPath.lineTo(x, y)
            }

            if (index == points.size - 1) {
                fillPath.lineTo(x, padding + height)
                fillPath.close()
            }
        }

        // Draw gradient fill below line
        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(lineColor.copy(alpha = 0.25f), Color.Transparent),
                startY = padding,
                endY = padding + height
            )
        )

        // Draw line
        drawPath(
            path = path,
            color = lineColor,
            style = Stroke(
                width = 3.dp.toPx(),
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )

        // Draw point on final trade
        val lastIndex = points.size - 1
        val lastX = padding + (lastIndex * stepX)
        val lastNormY = ((points[lastIndex] - minVal) / range).toFloat()
        val lastY = padding + height - (lastNormY * height)

        drawCircle(
            color = lineColor,
            radius = 5.dp.toPx(),
            center = Offset(lastX, lastY)
        )
    }
}

@Composable
fun WinLossDonutCard(stats: StatsResult) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "نمودار توزیع برد و باخت",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Start
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (stats.countedTradesCount == 0) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "هیچ معامله نتیجه‌داری برای محاسبه وجود ندارد",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                Box(
                    modifier = Modifier.size(180.dp),
                    contentAlignment = Alignment.Center
                ) {
                    DonutCanvas(
                        winCount = stats.winCount,
                        lossCount = stats.lossCount,
                        modifier = Modifier.fillMaxSize()
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${NumberParser.formatDouble(stats.winRatePercent, 1)}٪",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "نرخ برد",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Legend
                val lossRate = if (stats.countedTradesCount > 0) {
                    (stats.lossCount.toDouble() / stats.countedTradesCount.toDouble()) * 100.0
                } else 0.0

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .background(ProfitGreen, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "برد: ${stats.winCount} (${NumberParser.formatDouble(stats.winRatePercent, 0)}٪)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .background(LossRed, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "باخت: ${stats.lossCount} (${NumberParser.formatDouble(lossRate, 0)}٪)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DonutCanvas(
    winCount: Int,
    lossCount: Int,
    modifier: Modifier = Modifier
) {
    val total = winCount + lossCount

    Canvas(modifier = modifier) {
        val strokeWidth = 28.dp.toPx()
        val diameter = size.minDimension - strokeWidth
        val topLeft = Offset(
            (size.width - diameter) / 2f,
            (size.height - diameter) / 2f
        )
        val arcSize = Size(diameter, diameter)

        if (total == 0) {
            drawArc(
                color = Color.Gray.copy(alpha = 0.3f),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
            return@Canvas
        }

        val winSweep = (winCount.toFloat() / total.toFloat()) * 360f
        val lossSweep = 360f - winSweep

        // Draw wins arc (green)
        if (winCount > 0) {
            drawArc(
                color = ProfitGreen,
                startAngle = -90f,
                sweepAngle = winSweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth)
            )
        }

        // Draw losses arc (red)
        if (lossCount > 0) {
            drawArc(
                color = LossRed,
                startAngle = -90f + winSweep,
                sweepAngle = lossSweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth)
            )
        }
    }
}

@Composable
fun GroupBarChartCard(
    stats: StatsResult,
    unitMode: ChartUnitMode,
    barMetric: BarChartMetric,
    onMetricToggle: (BarChartMetric) -> Unit
) {
    val selectedCol = stats.defaultGroupColumnIndex
    val groups = if (selectedCol != null) {
        stats.groupStatsByColumn[selectedCol] ?: emptyList()
    } else {
        emptyList()
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "نمودار میله‌ای گروه‌ها",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Row {
                    FilterChip(
                        selected = barMetric == BarChartMetric.NET_VALUE,
                        onClick = { onMetricToggle(BarChartMetric.NET_VALUE) },
                        label = { Text(if (unitMode == ChartUnitMode.TARGET_R) "سود R" else "سود $", fontSize = 11.sp) }
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    FilterChip(
                        selected = barMetric == BarChartMetric.WIN_RATE,
                        onClick = { onMetricToggle(BarChartMetric.WIN_RATE) },
                        label = { Text("وین‌ریت ٪", fontSize = 11.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (groups.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "هیچ ستون دسته‌بندی با تعداد ۲ تا ۲۰ مقدار یکتا یافت نشد",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                GroupBarChartCanvas(
                    groups = groups,
                    unitMode = unitMode,
                    metric = barMetric,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                )
            }
        }
    }
}

@Composable
fun GroupBarChartCanvas(
    groups: List<GroupStat>,
    unitMode: ChartUnitMode,
    metric: BarChartMetric,
    modifier: Modifier = Modifier
) {
    val axisColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
    val displayGroups = groups.take(8) // Display top 8 groups

    Canvas(modifier = modifier) {
        if (displayGroups.isEmpty()) return@Canvas

        val padding = 20.dp.toPx()
        val bottomMargin = 30.dp.toPx()
        val width = size.width - (padding * 2)
        val height = size.height - padding - bottomMargin

        val values = displayGroups.map { g ->
            when (metric) {
                BarChartMetric.WIN_RATE -> g.winRatePercent
                BarChartMetric.NET_VALUE -> if (unitMode == ChartUnitMode.TARGET_R) g.netR else g.netDollar
            }
        }

        val maxVal = values.maxOrNull() ?: 1.0
        val minVal = values.minOrNull() ?: 0.0

        val maxMagnitude = max(1.0, max(kotlin.math.abs(maxVal), kotlin.math.abs(minVal)))

        // Zero line Y
        val zeroY = if (minVal >= 0) {
            padding + height
        } else {
            val ratio = (maxVal / (maxVal - minVal)).toFloat()
            padding + (height * (1f - (maxMagnitude.toFloat() / (maxMagnitude * 2).toFloat())))
        }

        // Draw zero baseline
        drawLine(
            color = axisColor,
            start = Offset(padding, zeroY),
            end = Offset(padding + width, zeroY),
            strokeWidth = 1.5.dp.toPx()
        )

        val barCount = displayGroups.size
        val slotWidth = width / barCount
        val barWidth = slotWidth * 0.55f

        displayGroups.forEachIndexed { index, group ->
            val value = values[index]
            val barX = padding + (index * slotWidth) + (slotWidth - barWidth) / 2f
            val isPositive = value >= 0

            val barHeight = ((kotlin.math.abs(value) / maxMagnitude) * (height * 0.45f)).toFloat()

            val barTop = if (isPositive) zeroY - barHeight else zeroY
            val color = if (isPositive) ProfitGreen else LossRed

            drawRoundRect(
                color = color,
                topLeft = Offset(barX, barTop),
                size = Size(barWidth, max(barHeight, 2.dp.toPx())),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx(), 4.dp.toPx())
            )
        }
    }

    // Labels row below the canvas
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        displayGroups.forEach { g ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = g.groupValue.take(7),
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = when (metric) {
                        BarChartMetric.WIN_RATE -> "${NumberParser.formatDouble(g.winRatePercent, 0)}٪"
                        BarChartMetric.NET_VALUE -> if (unitMode == ChartUnitMode.TARGET_R) {
                            NumberParser.formatR(g.netR, includeSign = true)
                        } else {
                            "${NumberParser.formatDouble(g.netDollar, 0)}$"
                        }
                    },
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 9.sp,
                    color = if (g.netR >= 0) ProfitGreen else LossRed
                )
            }
        }
    }
}

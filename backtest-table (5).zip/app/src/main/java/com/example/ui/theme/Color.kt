package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand colors - Professional Emerald & Slate for Forex Backtesting
val EmeraldPrimary = Color(0xFF0F766E)
val EmeraldPrimaryLight = Color(0xFF14B8A6)
val EmeraldSecondary = Color(0xFF0284C7)
val EmeraldTertiary = Color(0xFF8B5CF6)

// Trading Profit / Loss Indicators
val ProfitGreen = Color(0xFF16A34A)
val ProfitGreenBg = Color(0xFFDCFCE7)
val LossRed = Color(0xFFDC2626)
val LossRedBg = Color(0xFFFEE2E2)
val NeutralGray = Color(0xFF64748B)

// Light Palette
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnSurface = Color(0xFF0F172A)
val LightOutline = Color(0xFFCBD5E1)

// Dark Palette
val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1F2937)
val DarkOnSurface = Color(0xFFF8FAFC)
val DarkOutline = Color(0xFF374151)

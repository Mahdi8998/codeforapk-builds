package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiClient
import com.example.ai.GEMINI_MODEL
import com.example.ai.GeminiClient
import com.example.ai.OpenAiCompatibleClient
import com.example.data.db.AppDatabase
import com.example.data.model.FilterState
import com.example.data.model.GridData
import com.example.data.model.WorkbookEntity
import com.example.data.preferences.AppPreferences
import com.example.data.repository.WorkbookRepository
import com.example.engine.NumberParser
import com.example.engine.StatsEngine
import com.example.engine.StatsInput
import com.example.engine.StatsResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class EditorUiState(
    val workbook: WorkbookEntity? = null,
    val headers: List<String> = emptyList(),
    val allRows: List<List<String>> = emptyList(),
    val filteredRows: List<List<String>> = emptyList(),
    val originalRowIndices: List<Int> = emptyList(), // Filtered index -> original allRows index
    val filterState: FilterState = FilterState(),
    val selectedRow: Int? = null, // In filtered view
    val selectedCol: Int? = null,
    val selectedCellValue: String = "",
    val plColumnIndex: Int? = null,
    val initialBalance: Double = 500.0,
    val riskPercent: Double = 2.0,
    val rrCap: Double? = null,
    val statsResult: StatsResult = StatsResult(),
    val isStatsPanelOpen: Boolean = false,
    val isAiDialogOpen: Boolean = false,
    val isSaving: Boolean = false
)

class EditorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: WorkbookRepository
    val preferences = AppPreferences(application)

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    private var autoSaveJob: Job? = null
    private var statsComputeJob: Job? = null

    init {
        val db = AppDatabase.getInstance(application)
        repository = WorkbookRepository(db.workbookDao())
    }

    fun loadWorkbook(workbookId: Long) {
        viewModelScope.launch {
            val entity = repository.getWorkbook(workbookId) ?: return@launch
            val grid = GridData.fromJson(entity.gridJson)
            val filter = FilterState.fromJson(entity.filterStateJson)

            _uiState.value = _uiState.value.copy(
                workbook = entity,
                headers = grid.headers,
                allRows = grid.rows,
                filterState = filter,
                plColumnIndex = entity.plColumnIndex,
                initialBalance = entity.initialBalance,
                riskPercent = entity.riskPercent,
                rrCap = entity.rrCap
            )

            applyFiltersAndRecomputeStats()
        }
    }

    fun getActiveAiClient(): AiClient {
        return if (preferences.aiProvider == "gemini") {
            GeminiClient(apiKey = preferences.geminiApiKey)
        } else {
            OpenAiCompatibleClient(
                baseUrl = preferences.openAiBaseUrl,
                modelId = preferences.openAiModelId,
                apiKey = preferences.openAiApiKey
            )
        }
    }

    fun selectCell(displayRow: Int, col: Int) {
        val currentRows = _uiState.value.filteredRows
        val cellVal = currentRows.getOrNull(displayRow)?.getOrNull(col) ?: ""
        _uiState.value = _uiState.value.copy(
            selectedRow = displayRow,
            selectedCol = col,
            selectedCellValue = cellVal
        )
    }

    fun updateSelectedCell(newValue: String) {
        val row = _uiState.value.selectedRow ?: return
        val col = _uiState.value.selectedCol ?: return
        updateCell(row, col, newValue)
    }

    fun updateCell(displayRow: Int, col: Int, newValue: String) {
        val actualRow = _uiState.value.originalRowIndices.getOrNull(displayRow) ?: return
        val rows = _uiState.value.allRows.mapIndexed { rIdx, r ->
            if (rIdx == actualRow) {
                r.mapIndexed { cIdx, c -> if (cIdx == col) newValue else c }
            } else r
        }

        _uiState.value = _uiState.value.copy(
            allRows = rows,
            selectedCellValue = newValue
        )

        applyFiltersAndRecomputeStats()
        triggerAutoSave()
    }

    fun addRow(insertAtActualIndex: Int) {
        val headerCount = _uiState.value.headers.size
        val emptyRow = List(headerCount) { "" }
        val rows = _uiState.value.allRows.toMutableList()
        val index = insertAtActualIndex.coerceIn(0, rows.size)
        rows.add(index, emptyRow)

        _uiState.value = _uiState.value.copy(allRows = rows)
        applyFiltersAndRecomputeStats()
        triggerAutoSave()
    }

    fun deleteRow(actualRowIndex: Int) {
        val rows = _uiState.value.allRows.toMutableList()
        if (actualRowIndex in rows.indices) {
            rows.removeAt(actualRowIndex)
            _uiState.value = _uiState.value.copy(
                allRows = rows,
                selectedRow = null,
                selectedCol = null
            )
            applyFiltersAndRecomputeStats()
            triggerAutoSave()
        }
    }

    fun addColumn(insertAtIndex: Int, name: String) {
        val headers = _uiState.value.headers.toMutableList()
        val index = insertAtIndex.coerceIn(0, headers.size)
        headers.add(index, name)

        val rows = _uiState.value.allRows.map { r ->
            val mutableRow = r.toMutableList()
            mutableRow.add(index.coerceIn(0, mutableRow.size), "")
            mutableRow.toList()
        }

        // Adjust plColumnIndex if inserted before
        val plCol = _uiState.value.plColumnIndex
        val newPlCol = if (plCol != null && index <= plCol) plCol + 1 else plCol

        _uiState.value = _uiState.value.copy(
            headers = headers,
            allRows = rows,
            plColumnIndex = newPlCol
        )
        applyFiltersAndRecomputeStats()
        triggerAutoSave()
    }

    fun renameColumn(colIndex: Int, newName: String) {
        val headers = _uiState.value.headers.mapIndexed { idx, title ->
            if (idx == colIndex) newName else title
        }
        _uiState.value = _uiState.value.copy(headers = headers)
        applyFiltersAndRecomputeStats()
        triggerAutoSave()
    }

    fun deleteColumn(colIndex: Int) {
        if (_uiState.value.headers.size <= 1) return

        val headers = _uiState.value.headers.toMutableList()
        headers.removeAt(colIndex)

        val rows = _uiState.value.allRows.map { r ->
            val m = r.toMutableList()
            if (colIndex in m.indices) m.removeAt(colIndex)
            m.toList()
        }

        val plCol = _uiState.value.plColumnIndex
        val newPlCol = when {
            plCol == null -> null
            plCol == colIndex -> null
            plCol > colIndex -> plCol - 1
            else -> plCol
        }

        _uiState.value = _uiState.value.copy(
            headers = headers,
            allRows = rows,
            plColumnIndex = newPlCol
        )
        applyFiltersAndRecomputeStats()
        triggerAutoSave()
    }

    fun setPlColumn(colIndex: Int) {
        _uiState.value = _uiState.value.copy(plColumnIndex = colIndex)
        applyFiltersAndRecomputeStats()
        triggerAutoSave()
    }

    fun updateRrCap(cap: Double?) {
        _uiState.value = _uiState.value.copy(rrCap = cap)
        applyFiltersAndRecomputeStats()
        triggerAutoSave()
    }

    fun updateMoneySettings(initialBalance: Double, riskPercent: Double) {
        _uiState.value = _uiState.value.copy(
            initialBalance = initialBalance,
            riskPercent = riskPercent
        )
        applyFiltersAndRecomputeStats()
        triggerAutoSave()
    }

    fun updateSearchQuery(query: String) {
        val filter = _uiState.value.filterState.copy(searchQuery = query)
        _uiState.value = _uiState.value.copy(filterState = filter)
        applyFiltersAndRecomputeStats()
        triggerAutoSave()
    }

    fun updateColumnFilter(colIndex: Int, selectedValues: Set<String>?) {
        val currentMap = _uiState.value.filterState.selectedValues.toMutableMap()
        if (selectedValues == null) {
            currentMap.remove(colIndex)
        } else {
            currentMap[colIndex] = selectedValues
        }
        val filter = _uiState.value.filterState.copy(selectedValues = currentMap)
        _uiState.value = _uiState.value.copy(filterState = filter)
        applyFiltersAndRecomputeStats()
        triggerAutoSave()
    }

    fun sortColumn(colIndex: Int, ascending: Boolean) {
        val filter = _uiState.value.filterState.copy(
            sortColumnIndex = colIndex,
            sortAscending = ascending
        )
        _uiState.value = _uiState.value.copy(filterState = filter)
        applyFiltersAndRecomputeStats()
        triggerAutoSave()
    }

    fun clearAllFilters() {
        val filter = FilterState()
        _uiState.value = _uiState.value.copy(filterState = filter)
        applyFiltersAndRecomputeStats()
        triggerAutoSave()
    }

    fun toggleStatsPanel() {
        _uiState.value = _uiState.value.copy(isStatsPanelOpen = !_uiState.value.isStatsPanelOpen)
    }

    fun setAiDialogOpen(open: Boolean) {
        _uiState.value = _uiState.value.copy(isAiDialogOpen = open)
    }

    fun renameWorkbook(newName: String) {
        val wb = _uiState.value.workbook ?: return
        val updated = wb.copy(name = newName.ifBlank { wb.name }, updatedAt = System.currentTimeMillis())
        _uiState.value = _uiState.value.copy(workbook = updated)
        viewModelScope.launch {
            repository.updateWorkbook(updated)
        }
    }

    private fun applyFiltersAndRecomputeStats() {
        val allRows = _uiState.value.allRows
        val filter = _uiState.value.filterState

        val filteredIndices = mutableListOf<Int>()

        for (i in allRows.indices) {
            val row = allRows[i]
            // Search query check (all columns)
            if (filter.searchQuery.isNotBlank()) {
                val matchesSearch = row.any { it.contains(filter.searchQuery, ignoreCase = true) }
                if (!matchesSearch) continue
            }

            // Column filters
            var matchesColFilters = true
            for ((colIdx, validSet) in filter.selectedValues) {
                val cellVal = row.getOrElse(colIdx) { "" }.trim()
                if (!validSet.contains(cellVal)) {
                    matchesColFilters = false
                    break
                }
            }

            if (matchesColFilters) {
                filteredIndices.add(i)
            }
        }

        // Sorting if requested (Section 5.3)
        val sortedIndices = if (filter.sortColumnIndex != null) {
            val sortCol = filter.sortColumnIndex
            filteredIndices.sortedWith { idxA, idxB ->
                val valA = allRows[idxA].getOrElse(sortCol) { "" }.trim()
                val valB = allRows[idxB].getOrElse(sortCol) { "" }.trim()

                val numA = NumberParser.parseNumberOrNull(valA)
                val numB = NumberParser.parseNumberOrNull(valB)

                val cmp = if (numA != null && numB != null) {
                    numA.compareTo(numB)
                } else {
                    valA.compareTo(valB, ignoreCase = true)
                }
                if (filter.sortAscending) cmp else -cmp
            }
        } else {
            filteredIndices
        }

        val filteredRows = sortedIndices.map { allRows[it] }

        _uiState.value = _uiState.value.copy(
            filteredRows = filteredRows,
            originalRowIndices = sortedIndices
        )

        // Debounced StatsEngine compute (Section 5.5.1)
        statsComputeJob?.cancel()
        statsComputeJob = viewModelScope.launch(Dispatchers.Default) {
            delay(150) // Debounce 150ms
            val input = StatsInput(
                allRows = filteredRows,
                headers = _uiState.value.headers,
                plColumnIndex = _uiState.value.plColumnIndex,
                rrCap = _uiState.value.rrCap,
                initialBalance = _uiState.value.initialBalance,
                riskPercent = _uiState.value.riskPercent
            )
            val result = StatsEngine.compute(input)
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(statsResult = result)
            }
        }
    }

    private fun triggerAutoSave() {
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch {
            delay(400) // Debounce auto-save
            val currentWb = _uiState.value.workbook ?: return@launch
            val grid = GridData(headers = _uiState.value.headers, rows = _uiState.value.allRows)
            val updated = currentWb.copy(
                updatedAt = System.currentTimeMillis(),
                gridJson = grid.toJson(),
                filterStateJson = _uiState.value.filterState.toJson(),
                plColumnIndex = _uiState.value.plColumnIndex,
                initialBalance = _uiState.value.initialBalance,
                riskPercent = _uiState.value.riskPercent,
                rrCap = _uiState.value.rrCap
            )
            _uiState.value = _uiState.value.copy(workbook = updated)
            repository.updateWorkbook(updated)
        }
    }
}

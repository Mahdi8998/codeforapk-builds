package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ai.AiClient
import com.example.ai.AiPayloadBuilder
import com.example.ai.AiResult
import com.example.ai.ChatMessage
import com.example.data.model.FilterState
import com.example.data.preferences.AppPreferences
import com.example.engine.StatsResult
import com.example.ui.theme.LossRed
import kotlinx.coroutines.launch

enum class AiDataMode {
    SUMMARY,
    COMPLETE
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiAnalystDialog(
    aiClient: AiClient,
    preferences: AppPreferences,
    stats: StatsResult,
    headers: List<String>,
    filteredRows: List<List<String>>,
    totalRows: Int,
    filterState: FilterState,
    plColumnIndex: Int?,
    initialBalance: Double,
    riskPercent: Double,
    rrCap: Double?,
    onOpenSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var dataMode by remember { mutableStateOf(AiDataMode.SUMMARY) }
    var questionInput by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var analysisResponse by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var lastExecutedPrompt by remember { mutableStateOf("") }

    var showRowLimitDialog by remember { mutableStateOf(false) }

    val presetPrompts = listOf(
        "تحلیل جامع استراتژی",
        "کدام جفت‌ارزها سودده‌تر بوده‌اند؟",
        "بررسی الگوهای باخت و دلایل استاپ",
        "پیشنهاد برای بهبود وین‌ریت و R:R",
        "ارزیابی مدیریت سرمایه و افت حساب"
    )

    val sendAnalysisRequest: (String, AiDataMode) -> Unit = { userPrompt, chosenMode ->
        if (filteredRows.isEmpty()) {
            errorMessage = "هیچ ردیفی برای تحلیل وجود ندارد؛ فیلترها را بردارید."
        } else if (chosenMode == AiDataMode.COMPLETE && filteredRows.size > AiPayloadBuilder.MAX_COMPLETE_ROWS) {
            lastExecutedPrompt = userPrompt
            showRowLimitDialog = true
        } else {
            isLoading = true
            errorMessage = null
            analysisResponse = ""
            lastExecutedPrompt = userPrompt

            val systemPrompt = AiPayloadBuilder.buildSystemPrompt()
            val userPayload = if (chosenMode == AiDataMode.COMPLETE) {
                AiPayloadBuilder.buildCompletePayload(
                    headers = headers,
                    filteredRows = filteredRows,
                    totalRowCount = totalRows,
                    filterState = filterState,
                    plColumnIndex = plColumnIndex,
                    initialBalance = initialBalance,
                    riskPercent = riskPercent,
                    rrCap = rrCap,
                    userQuestionOrPreset = userPrompt
                )
            } else {
                AiPayloadBuilder.buildSummaryPayload(
                    headers = headers,
                    filteredRows = filteredRows,
                    totalRowCount = totalRows,
                    filterState = filterState,
                    plColumnIndex = plColumnIndex,
                    initialBalance = initialBalance,
                    riskPercent = riskPercent,
                    rrCap = rrCap,
                    statsResult = stats,
                    userQuestionOrPreset = userPrompt
                )
            }

            scope.launch {
                val res = aiClient.generateContent(
                    systemPrompt = systemPrompt,
                    messages = listOf(ChatMessage(role = "user", content = userPayload)),
                    onChunk = { chunk ->
                        analysisResponse = (analysisResponse ?: "") + chunk
                    }
                )

                isLoading = false
                when (res) {
                    is AiResult.Success -> {
                        analysisResponse = res.text
                    }
                    is AiResult.Error -> {
                        errorMessage = res.message
                    }
                }
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Psychology,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "تحلیلگر استراتژی با هوش مصنوعی",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            val providerLabel = if (preferences.aiProvider == "gemini") "Google Gemini" else "سرویس سازگار با OpenAI"
                            Text(
                                text = "سرویس: $providerLabel",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "بستن")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Scope indicator & Mode switcher
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val scopeText = if (filterState.isAnyFilterActive && filteredRows.size < totalRows) {
                        "تحلیل روی ${filteredRows.size} ردیف فیلترشده از $totalRows"
                    } else {
                        "تحلیل روی همه ردیف‌ها (${filteredRows.size} ردیف)"
                    }
                    AssistChip(
                        onClick = {},
                        label = { Text(scopeText, fontSize = 11.sp) }
                    )

                    Row {
                        FilterChip(
                            selected = dataMode == AiDataMode.SUMMARY,
                            onClick = { dataMode = AiDataMode.SUMMARY },
                            label = { Text("خلاصه آماری", fontSize = 11.sp) }
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        FilterChip(
                            selected = dataMode == AiDataMode.COMPLETE,
                            onClick = { dataMode = AiDataMode.COMPLETE },
                            label = { Text("کامل (داده‌ها)", fontSize = 11.sp) }
                        )
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                // Preset Prompts Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    presetPrompts.forEach { prompt ->
                        AssistChip(
                            onClick = {
                                questionInput = prompt
                                sendAnalysisRequest(prompt, dataMode)
                            },
                            label = { Text(prompt, fontSize = 12.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Response Area
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    if (isLoading && analysisResponse.isNullOrBlank()) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "در حال تحلیل استراتژی توسط هوش مصنوعی...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else if (errorMessage != null) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = errorMessage ?: "خطایی رخ داده است",
                                color = LossRed,
                                style = MaterialTheme.typography.bodyMedium,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        sendAnalysisRequest(
                                            lastExecutedPrompt.ifBlank { "تحلیل جامع استراتژی" },
                                            dataMode
                                        )
                                    }
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("تلاش مجدد")
                                }
                                if (errorMessage?.contains("کلید") == true || errorMessage?.contains("تنظیم") == true) {
                                    OutlinedButton(onClick = {
                                        onDismiss()
                                        onOpenSettings()
                                    }) {
                                        Text("رفتن به تنظیمات")
                                    }
                                }
                            }
                        }
                    } else if (!analysisResponse.isNullOrBlank()) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "نتیجه تحلیل استراتژی:",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                                IconButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newPlainText("تحلیل استراتژی", analysisResponse)
                                        clipboard.setPrimaryClip(clip)
                                        Toast.makeText(context, "متن تحلیل در کلیپ‌بورد کپی شد", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "کپی تحلیل", modifier = Modifier.size(18.dp))
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = analysisResponse ?: "",
                                style = MaterialTheme.typography.bodyMedium,
                                lineHeight = 24.sp
                            )

                            if (isLoading) {
                                Spacer(modifier = Modifier.height(8.dp))
                                CircularProgressIndicator(modifier = Modifier.size(16.dp))
                            }
                        }
                    } else {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.SmartToy,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "یکی از گزینه‌های بالا را انتخاب کنید یا سوال تحلیلی خود را بنویسید.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Input bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = questionInput,
                        onValueChange = { questionInput = it },
                        placeholder = { Text("سوال یا درخواست تحلیل خود را بنویسید...", fontSize = 13.sp) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            if (questionInput.isNotBlank()) {
                                val q = questionInput
                                questionInput = ""
                                sendAnalysisRequest(q, dataMode)
                            }
                        },
                        enabled = !isLoading && questionInput.isNotBlank()
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Send,
                            contentDescription = "ارسال",
                            tint = if (questionInput.isNotBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        )
                    }
                }
            }
        }
    }

    if (showRowLimitDialog) {
        AlertDialog(
            onDismissRequest = { showRowLimitDialog = false },
            title = { Text("حجم بالای ردیف‌ها") },
            text = {
                Text("تعداد ردیف‌های انتخاب‌شده (${filteredRows.size}) بیشتر از حد مجاز ۵۰۰ ردیف در حالت ارسال کامل است. آیا مایلید داده‌ها به‌صورت خلاصه آماری ارسال شوند؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showRowLimitDialog = false
                        dataMode = AiDataMode.SUMMARY
                        sendAnalysisRequest(lastExecutedPrompt, AiDataMode.SUMMARY)
                    }
                ) {
                    Text("ارسال به‌صورت خلاصه")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRowLimitDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }
}

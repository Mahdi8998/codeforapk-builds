package com.example.xlsx

import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object XlsxEngine {

    /**
     * Reads the first sheet of an XLSX file from an InputStream.
     * Returns a pair of (headers, rows).
     */
    fun readXlsx(inputStream: InputStream): Pair<List<String>, List<List<String>>> {
        // Read all zip entries into memory or temp maps so we can parse sharedStrings first if present
        val zipEntries = mutableMapOf<String, ByteArray>()
        ZipInputStream(inputStream).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) {
                    zipEntries[entry.name] = zis.readBytes()
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        if (zipEntries.isEmpty()) {
            throw IllegalArgumentException("فایل اکسل خالی یا نامعتبر است.")
        }

        // Parse shared strings if present
        val sharedStrings = mutableListOf<String>()
        val sharedStringsBytes = zipEntries["xl/sharedStrings.xml"] ?: zipEntries["xl/sharedstrings.xml"]
        if (sharedStringsBytes != null) {
            parseSharedStrings(sharedStringsBytes, sharedStrings)
        }

        // Find sheet1 xml
        val sheetKey = zipEntries.keys.firstOrNull {
            it.startsWith("xl/worksheets/sheet", ignoreCase = true) && it.endsWith(".xml", ignoreCase = true)
        } ?: throw IllegalArgumentException("هیچ برگه فعالی در فایل اکسل یافت نشد.")

        val sheetBytes = zipEntries[sheetKey] ?: throw IllegalArgumentException("برگه اکسل یافت نشد.")
        val rawTable = parseWorksheet(sheetBytes, sharedStrings)

        if (rawTable.isEmpty()) {
            return Pair(emptyList(), emptyList())
        }

        // Filter out empty rows at the top
        val nonEmptyRows = rawTable.filter { row -> row.any { it.isNotBlank() } }
        if (nonEmptyRows.isEmpty()) {
            return Pair(emptyList(), emptyList())
        }

        val rawHeaders = nonEmptyRows.first()
        // Determine column count by finding the last non-empty header or max row length
        val maxCol = maxOf(rawHeaders.size, nonEmptyRows.maxOfOrNull { it.size } ?: 0)

        val headers = (0 until maxCol).map { colIdx ->
            val h = rawHeaders.getOrElse(colIdx) { "" }.trim()
            if (h.isNotEmpty()) h else "ستون ${colIdx + 1}"
        }

        val dataRows = nonEmptyRows.drop(1).map { row ->
            (0 until maxCol).map { colIdx ->
                row.getOrElse(colIdx) { "" }
            }
        }

        return Pair(headers, dataRows)
    }

    private fun parseSharedStrings(bytes: ByteArray, outStrings: MutableList<String>) {
        try {
            val factory = XmlPullParserFactory.newInstance()
            factory.isNamespaceAware = false
            val parser = factory.newPullParser()
            parser.setInput(bytes.inputStream(), StandardCharsets.UTF_8.name())
            var event = parser.eventType
            val currentText = StringBuilder()
            var insideSi = false

            while (event != XmlPullParser.END_DOCUMENT) {
                when (event) {
                    XmlPullParser.START_TAG -> {
                        if (parser.name.equals("si", ignoreCase = true)) {
                            insideSi = true
                            currentText.setLength(0)
                        }
                    }
                    XmlPullParser.TEXT -> {
                        if (insideSi) {
                            currentText.append(parser.text)
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        if (parser.name.equals("si", ignoreCase = true)) {
                            insideSi = false
                            outStrings.add(currentText.toString())
                        }
                    }
                }
                event = parser.next()
            }
        } catch (e: Exception) {
            // Ignore parse errors, fallback
        }
    }

    private fun parseWorksheet(
        bytes: ByteArray,
        sharedStrings: List<String>
    ): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        val factory = XmlPullParserFactory.newInstance()
        factory.isNamespaceAware = false
        val parser = factory.newPullParser()
        parser.setInput(bytes.inputStream(), StandardCharsets.UTF_8.name())
        var event = parser.eventType

        var currentRow = mutableMapOf<Int, String>()
        var currentCellRef = ""
        var currentCellType = ""
        val currentCellValue = StringBuilder()
        var insideV = false
        var insideIs = false
        var insideT = false

        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    val name = parser.name.lowercase()
                    when (name) {
                        "row" -> {
                            currentRow = mutableMapOf()
                        }
                        "c" -> {
                            currentCellRef = parser.getAttributeValue(null, "r") ?: ""
                            currentCellType = parser.getAttributeValue(null, "t") ?: ""
                            currentCellValue.setLength(0)
                        }
                        "v" -> insideV = true
                        "is" -> insideIs = true
                        "t" -> insideT = true
                    }
                }
                XmlPullParser.TEXT -> {
                    if (insideV || insideT) {
                        currentCellValue.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    val name = parser.name.lowercase()
                    when (name) {
                        "v" -> insideV = false
                        "is" -> insideIs = false
                        "t" -> insideT = false
                        "c" -> {
                            val colIdx = if (currentCellRef.isNotEmpty()) {
                                cellRefToColumnIndex(currentCellRef)
                            } else {
                                currentRow.size
                            }
                            val rawVal = currentCellValue.toString().trim()
                            val cellText = when (currentCellType) {
                                "s" -> {
                                    val idx = rawVal.toIntOrNull()
                                    if (idx != null && idx in sharedStrings.indices) {
                                        sharedStrings[idx]
                                    } else rawVal
                                }
                                "inlineStr", "str" -> rawVal
                                else -> rawVal
                            }
                            currentRow[colIdx] = cellText
                        }
                        "row" -> {
                            if (currentRow.isNotEmpty()) {
                                val maxCol = (currentRow.keys.maxOrNull() ?: -1) + 1
                                val rowList = (0 until maxCol).map { col ->
                                    currentRow[col] ?: ""
                                }
                                rows.add(rowList)
                            }
                        }
                    }
                }
            }
            event = parser.next()
        }
        return rows
    }

    /**
     * Converts a cell reference like "A1" or "BC12" into a 0-based column index.
     */
    fun cellRefToColumnIndex(ref: String): Int {
        var col = 0
        for (ch in ref) {
            if (ch in 'A'..'Z') {
                col = col * 26 + (ch - 'A' + 1)
            } else if (ch in 'a'..'z') {
                col = col * 26 + (ch - 'a' + 1)
            } else {
                break
            }
        }
        return maxOf(0, col - 1)
    }

    /**
     * Converts a 0-based column index into column letters (e.g. 0 -> "A", 25 -> "Z", 26 -> "AA").
     */
    fun columnIndexToLetters(colIndex: Int): String {
        var temp = colIndex + 1
        val sb = StringBuilder()
        while (temp > 0) {
            val rem = (temp - 1) % 26
            sb.append(('A' + rem))
            temp = (temp - 1) / 26
        }
        return sb.reverse().toString()
    }

    /**
     * Writes headers and rows to an XLSX document via OutputStream.
     * Uses OpenXML standard format with inlineStr, supporting UTF-8 Persian perfectly.
     */
    fun writeXlsx(
        outputStream: OutputStream,
        headers: List<String>,
        rows: List<List<String>>
    ) {
        ZipOutputStream(outputStream).use { zos ->
            // 1. [Content_Types].xml
            zos.putNextEntry(ZipEntry("[Content_Types].xml"))
            zos.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
    <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
    <Default Extension="xml" ContentType="application/xml"/>
    <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
    <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>""".toByteArray(StandardCharsets.UTF_8)
            )
            zos.closeEntry()

            // 2. _rels/.rels
            zos.putNextEntry(ZipEntry("_rels/.rels"))
            zos.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
    <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>""".toByteArray(StandardCharsets.UTF_8)
            )
            zos.closeEntry()

            // 3. xl/_rels/workbook.xml.rels
            zos.putNextEntry(ZipEntry("xl/_rels/workbook.xml.rels"))
            zos.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
    <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
</Relationships>""".toByteArray(StandardCharsets.UTF_8)
            )
            zos.closeEntry()

            // 4. xl/workbook.xml
            zos.putNextEntry(ZipEntry("xl/workbook.xml"))
            zos.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
    <sheets>
        <sheet name="Sheet1" sheetId="1" r:id="rId1"/>
    </sheets>
</workbook>""".toByteArray(StandardCharsets.UTF_8)
            )
            zos.closeEntry()

            // 5. xl/worksheets/sheet1.xml
            zos.putNextEntry(ZipEntry("xl/worksheets/sheet1.xml"))
            val sheetBuilder = StringBuilder()
            sheetBuilder.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
    <sheetData>
""")

            var rowIndex = 1

            // Write header row
            sheetBuilder.append("        <row r=\"$rowIndex\">\n")
            for (col in headers.indices) {
                val ref = "${columnIndexToLetters(col)}$rowIndex"
                val text = escapeXml(headers[col])
                sheetBuilder.append("            <c r=\"$ref\" t=\"inlineStr\"><is><t>$text</t></is></c>\n")
            }
            sheetBuilder.append("        </row>\n")
            rowIndex++

            // Write data rows
            for (row in rows) {
                sheetBuilder.append("        <row r=\"$rowIndex\">\n")
                for (col in headers.indices) {
                    val ref = "${columnIndexToLetters(col)}$rowIndex"
                    val cellVal = row.getOrElse(col) { "" }
                    val text = escapeXml(cellVal)
                    sheetBuilder.append("            <c r=\"$ref\" t=\"inlineStr\"><is><t>$text</t></is></c>\n")
                }
                sheetBuilder.append("        </row>\n")
                rowIndex++
            }

            sheetBuilder.append("""    </sheetData>
</worksheet>""")
            zos.write(sheetBuilder.toString().toByteArray(StandardCharsets.UTF_8))
            zos.closeEntry()
        }
    }

    private fun escapeXml(str: String): String {
        return str.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }
}

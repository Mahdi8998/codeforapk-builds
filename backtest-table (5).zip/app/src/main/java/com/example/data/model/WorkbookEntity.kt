package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "workbooks")
data class WorkbookEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val gridJson: String = "{}",
    val filterStateJson: String = "{}",
    val plColumnIndex: Int? = null,
    val initialBalance: Double = 500.0,
    val riskPercent: Double = 2.0,
    val rrCap: Double? = null
)

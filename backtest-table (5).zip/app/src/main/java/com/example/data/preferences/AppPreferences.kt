package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("backtest_app_prefs", Context.MODE_PRIVATE)

    var themeMode: String
        get() = prefs.getString("theme_mode", "system") ?: "system"
        set(value) = prefs.edit().putString("theme_mode", value).apply()

    var aiProvider: String
        get() = prefs.getString("ai_provider", "gemini") ?: "gemini" // "gemini" or "openai"
        set(value) = prefs.edit().putString("ai_provider", value).apply()

    var geminiApiKey: String
        get() = prefs.getString("gemini_api_key", "") ?: ""
        set(value) = prefs.edit().putString("gemini_api_key", value).apply()

    var openAiBaseUrl: String
        get() = prefs.getString("openai_base_url", "https://openrouter.ai/api/v1") ?: "https://openrouter.ai/api/v1"
        set(value) = prefs.edit().putString("openai_base_url", value).apply()

    var openAiModelId: String
        get() = prefs.getString("openai_model_id", "google/gemini-3.5-flash") ?: "google/gemini-3.5-flash"
        set(value) = prefs.edit().putString("openai_model_id", value).apply()

    var openAiApiKey: String
        get() = prefs.getString("openai_api_key", "") ?: ""
        set(value) = prefs.edit().putString("openai_api_key", value).apply()
}

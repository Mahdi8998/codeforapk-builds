package com.example.data.model

import org.json.JSONArray
import org.json.JSONObject

data class GridData(
    val headers: List<String> = emptyList(),
    val rows: List<List<String>> = emptyList()
) {
    fun toJson(): String {
        val root = JSONObject()
        val headersArray = JSONArray()
        headers.forEach { headersArray.put(it) }
        root.put("headers", headersArray)

        val rowsArray = JSONArray()
        rows.forEach { row ->
            val rowArray = JSONArray()
            row.forEach { cell -> rowArray.put(cell) }
            rowsArray.put(rowArray)
        }
        root.put("rows", rowsArray)
        return root.toString()
    }

    companion object {
        fun fromJson(jsonStr: String?): GridData {
            if (jsonStr.isNullOrBlank()) return GridData()
            return try {
                val root = JSONObject(jsonStr)
                val headersArray = root.optJSONArray("headers") ?: JSONArray()
                val headers = mutableListOf<String>()
                for (i in 0 until headersArray.length()) {
                    headers.add(headersArray.getString(i))
                }

                val rowsArray = root.optJSONArray("rows") ?: JSONArray()
                val rows = mutableListOf<List<String>>()
                for (i in 0 until rowsArray.length()) {
                    val rowArray = rowsArray.getJSONArray(i)
                    val row = mutableListOf<String>()
                    for (j in 0 until rowArray.length()) {
                        row.add(rowArray.optString(j, ""))
                    }
                    rows.add(row)
                }
                GridData(headers = headers, rows = rows)
            } catch (e: Exception) {
                GridData()
            }
        }
    }
}

data class FilterState(
    val selectedValues: Map<Int, Set<String>> = emptyMap(),
    val sortColumnIndex: Int? = null,
    val sortAscending: Boolean = true,
    val searchQuery: String = ""
) {
    val isAnyFilterActive: Boolean
        get() = selectedValues.isNotEmpty() || searchQuery.isNotBlank()

    fun toJson(): String {
        val root = JSONObject()
        val filtersObj = JSONObject()
        selectedValues.forEach { (col, values) ->
            val arr = JSONArray()
            values.forEach { arr.put(it) }
            filtersObj.put(col.toString(), arr)
        }
        root.put("selectedValues", filtersObj)
        if (sortColumnIndex != null) {
            root.put("sortColumnIndex", sortColumnIndex)
        }
        root.put("sortAscending", sortAscending)
        root.put("searchQuery", searchQuery)
        return root.toString()
    }

    companion object {
        fun fromJson(jsonStr: String?): FilterState {
            if (jsonStr.isNullOrBlank()) return FilterState()
            return try {
                val root = JSONObject(jsonStr)
                val filtersObj = root.optJSONObject("selectedValues") ?: JSONObject()
                val selectedValues = mutableMapOf<Int, Set<String>>()
                val keys = filtersObj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val col = key.toIntOrNull() ?: continue
                    val arr = filtersObj.getJSONArray(key)
                    val set = mutableSetOf<String>()
                    for (i in 0 until arr.length()) {
                        set.add(arr.getString(i))
                    }
                    selectedValues[col] = set
                }

                val sortCol = if (root.has("sortColumnIndex")) root.getInt("sortColumnIndex") else null
                val sortAsc = root.optBoolean("sortAscending", true)
                val search = root.optString("searchQuery", "")

                FilterState(
                    selectedValues = selectedValues,
                    sortColumnIndex = sortCol,
                    sortAscending = sortAsc,
                    searchQuery = search
                )
            } catch (e: Exception) {
                FilterState()
            }
        }
    }
}

package com.example.data.repository

import com.example.data.db.WorkbookDao
import com.example.data.model.FilterState
import com.example.data.model.GridData
import com.example.data.model.WorkbookEntity
import kotlinx.coroutines.flow.Flow

class WorkbookRepository(private val workbookDao: WorkbookDao) {

    val allWorkbooks: Flow<List<WorkbookEntity>> = workbookDao.getAllWorkbooks()

    suspend fun getWorkbook(id: Long): WorkbookEntity? = workbookDao.getWorkbookById(id)

    fun observeWorkbook(id: Long): Flow<WorkbookEntity?> = workbookDao.observeWorkbookById(id)

    suspend fun saveWorkbook(workbook: WorkbookEntity): Long = workbookDao.insertWorkbook(workbook)

    suspend fun updateWorkbook(workbook: WorkbookEntity) = workbookDao.updateWorkbook(workbook)

    suspend fun deleteWorkbook(id: Long) = workbookDao.deleteWorkbookById(id)

    suspend fun createNewWorkbook(name: String): Long {
        val defaultHeaders = listOf(
            "تاریخ", "جفت‌ارز", "جهت", "قیمت ورود", "قیمت خروج", "حجم", "نتیجه", "توضیحات"
        )
        val initialRows = List(5) { List(defaultHeaders.size) { "" } }
        val grid = GridData(headers = defaultHeaders, rows = initialRows)
        val entity = WorkbookEntity(
            name = name.ifBlank { "جدول بکتست جدید" },
            gridJson = grid.toJson(),
            filterStateJson = FilterState().toJson(),
            plColumnIndex = 6,
            initialBalance = 500.0,
            riskPercent = 2.0,
            rrCap = null
        )
        return workbookDao.insertWorkbook(entity)
    }

    suspend fun duplicateWorkbook(id: Long): Long? {
        val original = workbookDao.getWorkbookById(id) ?: return null
        val copy = original.copy(
            id = 0,
            name = "${original.name} (کپی)",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        return workbookDao.insertWorkbook(copy)
    }

    suspend fun createSampleWorkbook(): Long {
        val headers = listOf(
            "تاریخ", "جفت‌ارز", "جهت", "قیمت ورود", "قیمت خروج", "حجم", "نتیجه", "توضیحات"
        )

        // 40 realistic rows: ~45% dash (18), ~30% "1" (12), ~15% "2" (6), ~10% "3" (4), plus 4 empty results
        // Total = 44 rows with realistic forex details
        val rawSampleTrades = listOf(
            listOf("2024/01/02", "EURUSD", "خرید", "1.09450", "1.09150", "0.10", "-", "استاپ هانت در ابتدای سشن لندن"),
            listOf("2024/01/03", "GBPUSD", "فروش", "1.27200", "1.26600", "0.10", "2", "شکست خط روند روزانه"),
            listOf("2024/01/04", "USDJPY", "خرید", "142.100", "141.800", "0.10", "-", "برگشت از مقاومت روان‌شناختی"),
            listOf("2024/01/05", "EURUSD", "فروش", "1.09600", "1.09300", "0.10", "1", "پولبک به سطح 50 درصد فیبوناچی"),
            listOf("2024/01/08", "XAUUSD", "خرید", "2042.50", "2052.50", "0.05", "1", "تایید تقاطع مووینگ 50 و 200"),
            listOf("2024/01/09", "AUDUSD", "فروش", "0.67100", "0.67400", "0.10", "-", "اخبار CPI استرالیا خلاف جهت"),
            listOf("2024/01/10", "GBPUSD", "خرید", "1.26800", "1.27700", "0.10", "3", "موج سه الیوت در سشن نیویورک"),
            listOf("2024/01/11", "USDJPY", "فروش", "145.400", "144.800", "0.10", "2", "واگرایی منفی در RSI تایم 1h"),
            listOf("2024/01/12", "EURUSD", "خرید", "1.09800", "1.09500", "0.10", "-", "فشار فروش پیش از تعطیلات آخر هفته"),
            listOf("2024/01/15", "XAUUSD", "فروش", "2055.00", "2060.00", "0.05", "-", "فیک بریک‌اوت ناحیه مقاومتی"),
            listOf("2024/01/16", "EURUSD", "فروش", "1.08900", "1.08600", "0.10", "1", "ادامه روند نزولی اصلی"),
            listOf("2024/01/17", "GBPUSD", "خرید", "1.26100", "1.25800", "0.10", "-", "تاچ سطح حمایتی و فعال شدن استاپ"),
            listOf("2024/01/18", "USDJPY", "خرید", "147.200", "147.800", "0.10", "2", "حمایت الگوی پرچم صعودی"),
            listOf("2024/01/19", "AUDUSD", "خرید", "0.65800", "0.65500", "0.10", "-", "شکست فیک در تایم فریم 15 دقیقه"),
            listOf("2024/01/22", "EURUSD", "خرید", "1.08800", "1.09100", "0.10", "1", "الگوی چکش صعودی روی حمایت"),
            listOf("2024/01/23", "XAUUSD", "خرید", "2020.00", "2035.00", "0.05", "3", "رالی طلا بعد از کاهش بازده اوراق"),
            listOf("2024/01/24", "GBPUSD", "فروش", "1.27400", "1.27700", "0.10", "-", "عدم تایید کندل در نیویورک"),
            listOf("2024/01/25", "USDJPY", "فروش", "148.100", "148.500", "0.10", "-", "تثبیت بالای سطح کلیدی"),
            listOf("2024/01/26", "EURUSD", "فروش", "1.08500", "1.08200", "0.10", "1", "کاهش حجم معاملات پایان هفته"),
            listOf("2024/01/29", "AUDUSD", "خرید", "0.66000", "0.66300", "0.10", "1", "برخورد به کف کانال صعودی"),
            listOf("2024/01/30", "XAUUSD", "فروش", "2036.00", "2042.00", "0.05", "-", "فشار خرید نهادی"),
            listOf("2024/01/31", "GBPUSD", "خرید", "1.26900", "1.27500", "0.10", "2", "تصمیم نرخ بهره بانک انگلستان"),
            listOf("2024/02/01", "EURUSD", "خرید", "1.08200", "1.07900", "0.10", "-", "گپ نزولی بعد از انتشار اخبار"),
            listOf("2024/02/02", "USDJPY", "خرید", "146.500", "147.100", "0.10", "2", "کندل ماروبوزو پرقدرت"),
            listOf("2024/02/05", "AUDUSD", "فروش", "0.65200", "0.65500", "0.10", "-", "سایه بلند کندل و تاچ استاپ"),
            listOf("2024/02/06", "XAUUSD", "خرید", "2025.00", "2040.00", "0.05", "3", "موج صعودی بعد از تثبیت کف"),
            listOf("2024/02/07", "EURUSD", "خرید", "1.07600", "1.07900", "0.10", "1", "برگشت از حمایت چند ماهه"),
            listOf("2024/02/08", "GBPUSD", "فروش", "1.26300", "1.26600", "0.10", "-", "مقاومت داینامیک شکسته نشد"),
            listOf("2024/02/09", "USDJPY", "فروش", "149.300", "149.700", "0.10", "-", "حرکت شارپ صعودی خلاف تحلیل"),
            listOf("2024/02/12", "EURUSD", "فروش", "1.07900", "1.07600", "0.10", "1", "الگوی ستاره عصرگاهی"),
            listOf("2024/02/13", "AUDUSD", "خرید", "0.64800", "0.64500", "0.10", "-", "تلاطم شدید به خاطر آمار اشتغال"),
            listOf("2024/02/14", "XAUUSD", "فروش", "1995.00", "2002.00", "0.05", "-", "فشار خریداران در زیر 2000"),
            listOf("2024/02/15", "GBPUSD", "خرید", "1.25600", "1.26200", "0.10", "2", "الگوی دوقلوی کف در 4h"),
            listOf("2024/02/16", "USDJPY", "خرید", "150.100", "150.700", "0.10", "2", "تثبیت قطعی بالای سطح 150"),
            listOf("2024/02/19", "EURUSD", "خرید", "1.07700", "1.08000", "0.10", "1", "تعطیلی بازار آمریکا و رنج آرام"),
            listOf("2024/02/20", "XAUUSD", "خرید", "2018.00", "2033.00", "0.05", "3", "ورود بر اساس اردر بلاک صعودی"),
            listOf("2024/02/21", "AUDUSD", "فروش", "0.65500", "0.65800", "0.10", "-", "سایه بلند و خروج با ضرر"),
            listOf("2024/02/22", "GBPUSD", "فروش", "1.26700", "1.26400", "0.10", "1", "برخورد با خط میانی چنگال"),
            listOf("2024/02/23", "EURUSD", "فروش", "1.08300", "1.08600", "0.10", "-", "تقاطع نزولی فیک در استوکاستیک"),
            listOf("2024/02/26", "USDJPY", "فروش", "150.600", "151.000", "0.10", "-", "مقاومت سقف سالانه عمل نکرد"),
            listOf("2024/02/27", "EURUSD", "خرید", "1.08400", "1.08700", "0.10", "1", "سیگنال ستاپ شکست فشرده"),
            // Empty result rows (unresolved trades, excluded from stats per Section 5.5.2)
            listOf("2024/02/28", "GBPUSD", "خرید", "1.26500", "", "0.10", "", "معامله باز در حال اجرا"),
            listOf("2024/02/28", "USDJPY", "فروش", "150.400", "", "0.10", "  ", "پوزیشن نیمه باز در تایم 4 ساعته"),
            listOf("2024/02/29", "XAUUSD", "خرید", "2034.00", "", "0.05", "", "پندینگ اردر فعال شده")
        )

        val grid = GridData(headers = headers, rows = rawSampleTrades)
        val entity = WorkbookEntity(
            name = "استراتژی پرایس‌اکشن (نمونه)",
            gridJson = grid.toJson(),
            filterStateJson = FilterState().toJson(),
            plColumnIndex = 6,
            initialBalance = 500.0,
            riskPercent = 2.0,
            rrCap = null
        )
        return workbookDao.insertWorkbook(entity)
    }
}

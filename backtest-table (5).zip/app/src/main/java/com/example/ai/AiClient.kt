package com.example.ai

const val GEMINI_MODEL = "gemini-3.5-flash"

data class ChatMessage(
    val role: String, // "user", "model", "system"
    val content: String
)

sealed class AiResult {
    data class Success(val text: String) : AiResult()
    data class Error(val message: String) : AiResult()
}

interface AiClient {
    suspend fun generateContent(
        systemPrompt: String,
        messages: List<ChatMessage>,
        onChunk: ((String) -> Unit)? = null
    ): AiResult

    suspend fun testConnection(): AiResult
}

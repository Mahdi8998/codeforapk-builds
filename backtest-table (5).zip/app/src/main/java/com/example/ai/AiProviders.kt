package com.example.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

class GeminiClient(
    private val apiKey: String,
    private val client: OkHttpClient = defaultOkHttpClient()
) : AiClient {

    override suspend fun generateContent(
        systemPrompt: String,
        messages: List<ChatMessage>,
        onChunk: ((String) -> Unit)?
    ): AiResult = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext AiResult.Error("کلید API گوگل Gemini تنظیم نشده است.")
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$GEMINI_MODEL:streamGenerateContent?key=$apiKey"

            val root = JSONObject()
            if (systemPrompt.isNotBlank()) {
                val systemInst = JSONObject()
                val parts = JSONArray().put(JSONObject().put("text", systemPrompt))
                systemInst.put("parts", parts)
                root.put("system_instruction", systemInst)
            }

            val contentsArray = JSONArray()
            for (msg in messages) {
                val contentObj = JSONObject()
                val role = if (msg.role == "model" || msg.role == "assistant") "model" else "user"
                contentObj.put("role", role)
                contentObj.put("parts", JSONArray().put(JSONObject().put("text", msg.content)))
                contentsArray.put(contentObj)
            }
            root.put("contents", contentsArray)

            val requestBody = root.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(url)
                .addHeader("x-goog-api-key", apiKey)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val code = response.code

            if (!response.isSuccessful) {
                val errorBody = response.body?.string() ?: ""
                return@withContext mapHttpError(code, errorBody, isGemini = true)
            }

            val body = response.body ?: return@withContext AiResult.Error("پاسخی از سرور دریافت نشد.")
            val fullText = StringBuilder()

            BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8)).use { reader ->
                var line: String? = reader.readLine()
                var chunkBuffer = StringBuilder()
                while (line != null) {
                    chunkBuffer.append(line)
                    // Streaming Gemini response can be an array of objects [ { candidates: [...] }, ... ]
                    // or SSE chunks
                    val currentStr = chunkBuffer.toString().trim()
                    if (currentStr.startsWith("[") && currentStr.endsWith("]")) {
                        val parsed = extractGeminiArrayText(currentStr)
                        if (parsed.isNotEmpty()) {
                            val newText = parsed.substring(fullText.length)
                            if (newText.isNotEmpty()) {
                                fullText.append(newText)
                                onChunk?.invoke(newText)
                            }
                        }
                    }
                    line = reader.readLine()
                }

                if (fullText.isEmpty()) {
                    val finalStr = chunkBuffer.toString().trim()
                    val parsed = extractGeminiArrayText(finalStr)
                    if (parsed.isNotEmpty()) {
                        fullText.append(parsed)
                        onChunk?.invoke(parsed)
                    }
                }
            }

            if (fullText.isNotEmpty()) {
                AiResult.Success(fullText.toString())
            } else {
                AiResult.Error("پاسخ دریافتی خالی بود.")
            }
        } catch (e: UnknownHostException) {
            AiResult.Error("عدم اتصال به اینترنت")
        } catch (e: Exception) {
            AiResult.Error("خطا در برقراری ارتباط: ${e.localizedMessage ?: "نامشخص"}")
        }
    }

    override suspend fun testConnection(): AiResult = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext AiResult.Error("کلید API گوگل Gemini وارد نشده است.")
        }
        val testMessages = listOf(ChatMessage(role = "user", content = "سلام. یک کلمه پاسخ بده: تست"))
        generateContent(systemPrompt = "You are a test assistant.", messages = testMessages)
    }

    private fun extractGeminiArrayText(rawJson: String): String {
        return try {
            val sb = StringBuilder()
            val clean = rawJson.trim()
            if (clean.startsWith("[")) {
                val arr = JSONArray(clean)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val candidates = obj.optJSONArray("candidates") ?: continue
                    for (c in 0 until candidates.length()) {
                        val cand = candidates.getJSONObject(c)
                        val content = cand.optJSONObject("content") ?: continue
                        val parts = content.optJSONArray("parts") ?: continue
                        for (p in 0 until parts.length()) {
                            val part = parts.getJSONObject(p)
                            val t = part.optString("text", "")
                            sb.append(t)
                        }
                    }
                }
            } else if (clean.startsWith("{")) {
                val obj = JSONObject(clean)
                val candidates = obj.optJSONArray("candidates")
                if (candidates != null) {
                    for (c in 0 until candidates.length()) {
                        val cand = candidates.getJSONObject(c)
                        val content = cand.optJSONObject("content") ?: continue
                        val parts = content.optJSONArray("parts") ?: continue
                        for (p in 0 until parts.length()) {
                            val part = parts.getJSONObject(p)
                            val t = part.optString("text", "")
                            sb.append(t)
                        }
                    }
                }
            }
            sb.toString()
        } catch (e: Exception) {
            ""
        }
    }
}

class OpenAiCompatibleClient(
    private val baseUrl: String,
    private val modelId: String,
    private val apiKey: String,
    private val client: OkHttpClient = defaultOkHttpClient()
) : AiClient {

    override suspend fun generateContent(
        systemPrompt: String,
        messages: List<ChatMessage>,
        onChunk: ((String) -> Unit)?
    ): AiResult = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext AiResult.Error("کلید API سرویس سازگار با OpenAI وارد نشده است.")
        }
        if (!baseUrl.startsWith("https://", ignoreCase = true)) {
            return@withContext AiResult.Error("آدرس پایه باید با https:// شروع شود.")
        }

        try {
            val trimmedBase = baseUrl.trimEnd('/')
            val endpoint = "$trimmedBase/chat/completions"

            val root = JSONObject()
            root.put("model", modelId.ifBlank { "google/gemini-3.5-flash" })
            root.put("stream", true)

            val messagesArray = JSONArray()
            if (systemPrompt.isNotBlank()) {
                val sysObj = JSONObject().put("role", "system").put("content", systemPrompt)
                messagesArray.put(sysObj)
            }
            for (msg in messages) {
                val role = if (msg.role == "model" || msg.role == "assistant") "assistant" else "user"
                val obj = JSONObject().put("role", role).put("content", msg.content)
                messagesArray.put(obj)
            }
            root.put("messages", messagesArray)

            val requestBody = root.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(endpoint)
                .addHeader("Authorization", "Bearer $apiKey")
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val code = response.code

            if (!response.isSuccessful) {
                val errBody = response.body?.string() ?: ""
                return@withContext mapHttpError(code, errBody, isGemini = false)
            }

            val body = response.body ?: return@withContext AiResult.Error("پاسخی از سرور دریافت نشد.")
            val fullText = StringBuilder()

            BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8)).use { reader ->
                var line: String? = reader.readLine()
                while (line != null) {
                    val trimmed = line.trim()
                    if (trimmed.startsWith("data:")) {
                        val dataContent = trimmed.substring(5).trim()
                        if (dataContent == "[DONE]") break
                        if (dataContent.isNotEmpty()) {
                            try {
                                val chunkObj = JSONObject(dataContent)
                                val choices = chunkObj.optJSONArray("choices")
                                if (choices != null && choices.length() > 0) {
                                    val firstChoice = choices.getJSONObject(0)
                                    val delta = firstChoice.optJSONObject("delta")
                                    val contentPiece = delta?.optString("content", "") ?: ""
                                    if (contentPiece.isNotEmpty()) {
                                        fullText.append(contentPiece)
                                        onChunk?.invoke(contentPiece)
                                    }
                                }
                            } catch (e: Exception) {
                                // Skip non-json lines
                            }
                        }
                    }
                    line = reader.readLine()
                }
            }

            if (fullText.isNotEmpty()) {
                AiResult.Success(fullText.toString())
            } else {
                AiResult.Error("پاسخ دریافتی خالی بود.")
            }
        } catch (e: UnknownHostException) {
            AiResult.Error("عدم اتصال به اینترنت")
        } catch (e: Exception) {
            AiResult.Error("آدرس پایه نامعتبر یا غیرقابل دسترس است: ${e.localizedMessage ?: ""}")
        }
    }

    override suspend fun testConnection(): AiResult = withContext(Dispatchers.IO) {
        if (!baseUrl.startsWith("https://", ignoreCase = true)) {
            return@withContext AiResult.Error("آدرس پایه باید با https:// شروع شود.")
        }
        if (apiKey.isBlank()) {
            return@withContext AiResult.Error("کلید API وارد نشده است.")
        }
        val testMessages = listOf(ChatMessage(role = "user", content = "Hi, reply with one word: OK"))
        generateContent(systemPrompt = "You are a test assistant.", messages = testMessages)
    }
}

fun mapHttpError(code: Int, body: String, isGemini: Boolean): AiResult {
    return when (code) {
        401, 403 -> AiResult.Error("کلید API نامعتبر است")
        404 -> {
            if (isGemini) {
                AiResult.Error("مدل یافت نشد؛ مدل ثابت برنامه را به‌روزرسانی کنید")
            } else {
                AiResult.Error("مدل یا آدرس پایه در سرور یافت نشد (404)")
            }
        }
        429 -> AiResult.Error("محدودیت تعداد درخواست؛ کمی بعد دوباره تلاش کنید")
        in 500..599 -> AiResult.Error("خطای سرور هوش مصنوعی ($code)؛ لطفاً مجدداً تلاش کنید")
        else -> AiResult.Error("خطای پاسخ سرور ($code): ${body.take(100)}")
    }
}

private fun defaultOkHttpClient(): OkHttpClient {
    return OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
}

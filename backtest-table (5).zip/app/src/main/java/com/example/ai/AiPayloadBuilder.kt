package com.example.ai

import com.example.data.model.FilterState
import com.example.engine.NumberParser
import com.example.engine.StatsEngine
import com.example.engine.StatsInput
import com.example.engine.StatsResult
import com.example.engine.TradeResult
import org.json.JSONArray
import org.json.JSONObject

object AiPayloadBuilder {

    const val MAX_COMPLETE_ROWS = 500

    fun buildSystemPrompt(): String {
        return """You are a professional forex trading-strategy backtest analyst.
The input provided to you is a spreadsheet where each row represents one trade from the user's manual backtesting data.
Key guidelines:
1. Results are R-multiples: a dash ("-") means full stop-loss hit (-1R), a positive number N means target N hit (+N R).
2. Treat empty-result rows as open/unresolved trades, NEVER as losses.
3. Use the Persian terms «تارگت» and «استاپ» naturally in your explanation.
4. Dollar figures follow the percentage money-management model (compounding). Reference final balance, return %, and dollar drawdown alongside R-multiples using the Persian terms «موجودی» and «ریسک».
5. When a profit cap (R:R cap) is active, interpret results accordingly (profit was taken at the capped R:R) and, if useful, briefly note in Persian how metrics would differ without the cap, using «مبنا» and «R:R».
6. If FILTER CONTEXT indicates a filtered subset, treat the data as the user's selected slice of their strategy (e.g. only losses, or only one currency pair) and analyze THAT slice; do not assume it represents the whole strategy; note in Persian that conclusions apply to this filtered slice.
7. Analyze critically, cite real numbers from the provided data, use clear Markdown headings and bullet points, give concrete actionable suggestions, and state when the sample size is small. Never invent data.
8. ALWAYS respond in fluent Persian.
9. End your response with this exact Persian disclaimer on a new line:
«توجه: این تحلیل صرفاً جنبه آموزشی و تحلیلی دارد و به هیچ وجه توصیه مالی یا سیگنال معاملاتی نیست.»"""
    }

    fun buildScopeHeader(
        totalRowCount: Int,
        filteredRowCount: Int,
        filterState: FilterState,
        headers: List<String>
    ): String {
        return if (filterState.isAnyFilterActive && filteredRowCount < totalRowCount) {
            val activeDesc = mutableListOf<String>()
            filterState.selectedValues.forEach { (colIdx, values) ->
                val colName = headers.getOrElse(colIdx) { "Column $colIdx" }
                activeDesc.add("$colName = [${values.joinToString(", ")}]")
            }
            if (filterState.searchQuery.isNotBlank()) {
                activeDesc.add("Search query = \"${filterState.searchQuery}\"")
            }
            "FILTER CONTEXT: the rows below are a FILTERED SUBSET ($filteredRowCount of $totalRowCount total rows). Active filters: ${activeDesc.joinToString("; ")}. The user is intentionally analyzing this subset."
        } else {
            "FILTER CONTEXT: the rows below are the FULL TABLE ($filteredRowCount rows); no filters applied."
        }
    }

    fun buildSemanticsHeader(
        headers: List<String>,
        plColumnIndex: Int?,
        initialBalance: Double,
        riskPercent: Double,
        rrCap: Double?
    ): String {
        val plColName = if (plColumnIndex != null && plColumnIndex in headers.indices) {
            headers[plColumnIndex]
        } else "Result"

        val resultHeader = "RESULT COLUMN \"$plColName\": \"-\" = stop-loss hit (−1R); positive number N = target N hit (+N R); empty = trade has no result yet (excluded from all stats)."
        val moneyHeader = "MONEY MANAGEMENT: initial balance $initialBalance USD; risk per trade $riskPercent% of current balance (compounding); loss (-) = -1R; target N = +N R; empty = unresolved trade."
        val profitHeader = if (rrCap != null && rrCap > 0.0) {
            "PROFIT BASIS: user-defined R:R cap = ${rrCap}R — a cell \"3\" means price reached 3R but profit is counted as +${minOf(3.0, rrCap)}R; dash = stop (−1R); empty = unresolved trade."
        } else {
            "PROFIT BASIS: full target value (no cap)."
        }

        return "$resultHeader\n$moneyHeader\n$profitHeader"
    }

    /**
     * Complete mode payload:
     * Scope + Semantics + TSV of filtered rows.
     * Sanitizes tabs and newlines inside cells.
     */
    fun buildCompletePayload(
        headers: List<String>,
        filteredRows: List<List<String>>,
        totalRowCount: Int,
        filterState: FilterState,
        plColumnIndex: Int?,
        initialBalance: Double,
        riskPercent: Double,
        rrCap: Double?,
        userQuestionOrPreset: String
    ): String {
        val scope = buildScopeHeader(totalRowCount, filteredRows.size, filterState, headers)
        val semantics = buildSemanticsHeader(headers, plColumnIndex, initialBalance, riskPercent, rrCap)

        val tsvBuilder = StringBuilder()
        // Headers
        tsvBuilder.append(headers.joinToString("\t") { sanitizeCell(it) }).append("\n")
        // Rows
        for (row in filteredRows) {
            val sanitizedRow = (0 until headers.size).map { col ->
                sanitizeCell(row.getOrElse(col) { "" })
            }
            tsvBuilder.append(sanitizedRow.joinToString("\t")).append("\n")
        }

        return """$scope

$semantics

--- DATA (TSV FORMAT, ${filteredRows.size} ROWS) ---
$tsvBuilder
--- END OF DATA ---

درخواست تحلیل کاربر:
$userQuestionOrPreset"""
    }

    /**
     * Summary mode payload:
     * Scope + Semantics + JSON stats summary + up to 30 sample rows.
     */
    fun buildSummaryPayload(
        headers: List<String>,
        filteredRows: List<List<String>>,
        totalRowCount: Int,
        filterState: FilterState,
        plColumnIndex: Int?,
        initialBalance: Double,
        riskPercent: Double,
        rrCap: Double?,
        statsResult: StatsResult,
        userQuestionOrPreset: String
    ): String {
        val scope = buildScopeHeader(totalRowCount, filteredRows.size, filterState, headers)
        val semantics = buildSemanticsHeader(headers, plColumnIndex, initialBalance, riskPercent, rrCap)

        // Select representative sample rows (up to 30)
        val sampleRows = selectSampleRows(filteredRows, plColumnIndex, maxSamples = 30)

        val json = JSONObject()
        json.put("headers", JSONArray(headers))
        json.put("filtered_row_count", statsResult.totalFilteredRowCount)
        json.put("counted_trades", statsResult.countedTradesCount)
        json.put("excluded_trades", statsResult.excludedTradesCount)
        json.put("win_count", statsResult.winCount)
        json.put("loss_count", statsResult.lossCount)
        json.put("win_rate_percent", statsResult.winRatePercent)
        json.put("net_r", statsResult.netR)
        json.put("profit_factor", if (statsResult.profitFactor.isInfinite()) "Infinity" else statsResult.profitFactor)
        json.put("avg_win_r", statsResult.avgWinR)
        json.put("avg_loss_r", statsResult.avgLossR)
        json.put("reward_to_risk_ratio", if (statsResult.rewardToRiskRatio.isInfinite()) "Infinity" else statsResult.rewardToRiskRatio)
        json.put("expectancy_r", statsResult.expectancyR)
        json.put("best_trade_r", statsResult.bestTradeR ?: "N/A")
        json.put("worst_trade_r", statsResult.worstTradeR ?: "N/A")
        json.put("max_consecutive_wins", statsResult.maxConsecutiveWins)
        json.put("max_consecutive_losses", statsResult.maxConsecutiveLosses)
        json.put("max_drawdown_r", statsResult.maxDrawdownR)
        json.put("max_drawdown_percent_r", statsResult.maxDrawdownPercentR)
        json.put("initial_balance_usd", statsResult.initialBalance)
        json.put("risk_percent", statsResult.riskPercent)
        json.put("final_dollar_balance", statsResult.finalDollarBalance)
        json.put("net_dollar_profit", statsResult.netDollarProfit)
        json.put("total_return_percent", statsResult.totalReturnPercent)
        json.put("max_dollar_drawdown", statsResult.maxDollarDrawdown)
        json.put("max_dollar_drawdown_percent", statsResult.maxDollarDrawdownPercent)

        val groupsJson = JSONArray()
        statsResult.groupStatsByColumn.forEach { (colIdx, groupStats) ->
            val colName = headers.getOrElse(colIdx) { "Col $colIdx" }
            for (g in groupStats) {
                val gObj = JSONObject()
                gObj.put("column", colName)
                gObj.put("group_value", g.groupValue)
                gObj.put("trades", g.tradeCount)
                gObj.put("win_rate_percent", g.winRatePercent)
                gObj.put("net_r", g.netR)
                gObj.put("net_dollar", g.netDollar)
                groupsJson.put(gObj)
            }
        }
        json.put("groups_breakdown", groupsJson)

        val samplesArray = JSONArray()
        for (sample in sampleRows) {
            val rowArr = JSONArray()
            sample.forEach { rowArr.put(sanitizeCell(it)) }
            samplesArray.put(rowArr)
        }
        json.put("sample_trades_selection", samplesArray)

        return """$scope

$semantics

--- SUMMARY STATS & REPRESENTATIVE SAMPLES (JSON) ---
${json.toString(2)}
--- END OF STATS ---

درخواست تحلیل کاربر:
$userQuestionOrPreset"""
    }

    private fun selectSampleRows(
        rows: List<List<String>>,
        plCol: Int?,
        maxSamples: Int = 30
    ): List<List<String>> {
        if (rows.size <= maxSamples) return rows
        if (plCol == null) return rows.take(maxSamples)

        val wins = mutableListOf<List<String>>()
        val losses = mutableListOf<List<String>>()
        val others = mutableListOf<List<String>>()

        for (r in rows) {
            val res = NumberParser.parseTradeResult(r.getOrElse(plCol) { "" })
            when (res) {
                is TradeResult.Counted -> {
                    if (res.isWin) wins.add(r) else losses.add(r)
                }
                is TradeResult.Excluded -> others.add(r)
            }
        }

        val result = mutableListOf<List<String>>()
        val perCategory = maxSamples / 3
        result.addAll(wins.take(perCategory))
        result.addAll(losses.take(perCategory))
        result.addAll(others.take(perCategory))

        // Fill up to maxSamples if some lists were small
        if (result.size < maxSamples) {
            val remaining = rows.filterNot { result.contains(it) }
            result.addAll(remaining.take(maxSamples - result.size))
        }

        return result
    }

    private fun sanitizeCell(text: String): String {
        return text.replace("\t", "    ")
            .replace("\r\n", " ")
            .replace("\n", " ")
            .replace("\r", " ")
    }
}

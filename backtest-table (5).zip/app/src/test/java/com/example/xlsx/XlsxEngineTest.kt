package com.example.xlsx

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class XlsxEngineTest {

    @Test
    fun testWriteAndReadXlsxRoundTrip() {
        val headers = listOf("تاریخ", "جفت ارز", "نتیجه")
        val rows = listOf(
            listOf("2024/01/10", "EURUSD", "2"),
            listOf("2024/01/11", "GBPUSD", "-"),
            listOf("2024/01/12", "XAUUSD", "1.5")
        )

        val bos = ByteArrayOutputStream()
        XlsxEngine.writeXlsx(bos, headers, rows)

        val bytes = bos.toByteArray()
        assertTrue("Output zip must have non-zero bytes", bytes.isNotEmpty())

        val bis = ByteArrayInputStream(bytes)
        val (readHeaders, readRows) = XlsxEngine.readXlsx(bis)

        assertEquals(3, readHeaders.size)
        assertEquals("تاریخ", readHeaders[0])
        assertEquals("جفت ارز", readHeaders[1])
        assertEquals("نتیجه", readHeaders[2])

        assertEquals(3, readRows.size)
        assertEquals(listOf("2024/01/10", "EURUSD", "2"), readRows[0])
        assertEquals(listOf("2024/01/11", "GBPUSD", "-"), readRows[1])
        assertEquals(listOf("2024/01/12", "XAUUSD", "1.5"), readRows[2])
    }
}

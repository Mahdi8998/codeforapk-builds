package com.example.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NumberParserTest {

    @Test
    fun testPersianDigitNormalization() {
        val raw = "۱۲۳.۴۵"
        val normalized = NumberParser.normalize(raw)
        assertEquals("123.45", normalized)

        val parsed = NumberParser.parseNumberOrNull(raw)
        assertNotNull(parsed)
        assertEquals(123.45, parsed!!, 0.001)
    }

    @Test
    fun testThousandsSeparatorStripping() {
        val raw = "۱,۲۵۰,۰۰۰٫۵"
        val normalized = NumberParser.normalize(raw)
        assertEquals("1250000.5", normalized)
        val parsed = NumberParser.parseNumberOrNull(raw)
        assertEquals(1250000.5, parsed!!, 0.001)
    }

    @Test
    fun testTradeResultDashIsStopLoss() {
        val result1 = NumberParser.parseTradeResult("-")
        assertTrue(result1 is TradeResult.Counted)
        val counted1 = result1 as TradeResult.Counted
        assertEquals(-1.0, counted1.value, 0.001)
        assertEquals(false, counted1.isWin)

        val result2 = NumberParser.parseTradeResult(" − ") // unicode minus
        assertTrue(result2 is TradeResult.Counted)
        val counted2 = result2 as TradeResult.Counted
        assertEquals(-1.0, counted2.value, 0.001)
        assertEquals(false, counted2.isWin)
    }

    @Test
    fun testTradeResultPositiveNumberIsWin() {
        val result = NumberParser.parseTradeResult(" ۲ ")
        assertTrue(result is TradeResult.Counted)
        val counted = result as TradeResult.Counted
        assertEquals(2.0, counted.value, 0.001)
        assertEquals(true, counted.isWin)
    }

    @Test
    fun testTradeResultEmptyAndZeroAreExcluded() {
        val emptyResult = NumberParser.parseTradeResult("   ")
        assertTrue(emptyResult is TradeResult.Excluded)

        val zeroResult = NumberParser.parseTradeResult("0")
        assertTrue(zeroResult is TradeResult.Excluded)

        val textResult = NumberParser.parseTradeResult("open")
        assertTrue(textResult is TradeResult.Excluded)
    }
}

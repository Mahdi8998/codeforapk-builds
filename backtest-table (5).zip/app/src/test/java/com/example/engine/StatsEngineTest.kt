package com.example.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StatsEngineTest {

    @Test
    fun testStatsComputationBasic() {
        val headers = listOf("تاریخ", "جفت‌ارز", "نتیجه")
        val rows = listOf(
            listOf("2024/01/01", "EURUSD", "2"),  // +2
            listOf("2024/01/02", "GBPUSD", "-"),  // -1
            listOf("2024/01/03", "USDJPY", "1"),  // +1
            listOf("2024/01/04", "EURUSD", "-"),  // -1
            listOf("2024/01/05", "XAUUSD", "")    // Excluded
        )

        val input = StatsInput(
            allRows = rows,
            headers = headers,
            plColumnIndex = 2,
            rrCap = null,
            initialBalance = 1000.0,
            riskPercent = 1.0
        )

        val result = StatsEngine.compute(input)

        assertEquals(4, result.countedTradesCount)
        assertEquals(1, result.excludedTradesCount)
        assertEquals(2, result.winCount)
        assertEquals(2, result.lossCount)
        assertEquals(50.0, result.winRatePercent, 0.001)

        // Wins: +2 + 1 = 3. Losses: 1 + 1 = 2. Net R = +1.0
        assertEquals(1.0, result.netR, 0.001)
        assertEquals(1.5, result.profitFactor, 0.001) // 3 / 2 = 1.5
        assertEquals(1.5, result.avgWinR, 0.001)      // 3 / 2 = 1.5
        assertEquals(1.0, result.avgLossR, 0.001)     // 2 / 2 = 1.0
    }

    @Test
    fun testRrCapBehavior() {
        val headers = listOf("نتیجه")
        val rows = listOf(
            listOf("3"), // would be +3, capped to 1.5
            listOf("-"), // -1, unchanged
            listOf("2")  // would be +2, capped to 1.5
        )

        val input = StatsInput(
            allRows = rows,
            headers = headers,
            plColumnIndex = 0,
            rrCap = 1.5,
            initialBalance = 500.0,
            riskPercent = 2.0
        )

        val result = StatsEngine.compute(input)

        assertEquals(3, result.countedTradesCount)
        assertEquals(2, result.winCount)
        assertEquals(1, result.lossCount)
        // Win rate unchanged: 2/3 = 66.66%
        assertEquals(66.666, result.winRatePercent, 0.01)

        // Wins capped: 1.5 + 1.5 = 3.0. Loss: 1.0. Net R = 2.0
        assertEquals(2.0, result.netR, 0.001)
    }

    @Test
    fun testCompoundingDollarWalk() {
        val headers = listOf("نتیجه")
        val rows = listOf(
            listOf("1"), // Win +1R at 2% risk: 1000 * 1.02 = 1020
            listOf("-")  // Loss -1R at 2% risk: 1020 * 0.98 = 999.6
        )

        val input = StatsInput(
            allRows = rows,
            headers = headers,
            plColumnIndex = 0,
            rrCap = null,
            initialBalance = 1000.0,
            riskPercent = 2.0
        )

        val result = StatsEngine.compute(input)

        assertEquals(999.6, result.finalDollarBalance, 0.01)
        assertEquals(-0.4, result.netDollarProfit, 0.01)
    }
}

package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class BuildStatus {
    IDLE,
    ANALYZING,
    UPLOADING,
    QUEUED,
    BUILDING,
    SUCCESS,
    FAILED,
    CANCELLED
}

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

@Entity(tableName = "builds")
data class BuildEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val projectName: String,
    val zipFileName: String,
    val fileSizeBytes: Long = 0L,
    val startDate: Long = System.currentTimeMillis(),
    val durationSeconds: Long = 0L,
    val status: String = BuildStatus.UPLOADING.name,
    val workflowRunId: Long? = null,
    val artifactId: Long? = null,
    val artifactName: String? = null,
    val apkFilePath: String? = null,
    val logSummary: String? = null,
    val fullLog: String? = null,
    val errorHint: String? = null
)

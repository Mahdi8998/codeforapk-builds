package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.example.data.model.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class EncryptedPreferenceManager(private val context: Context) {

    private val prefs: SharedPreferences by lazy {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            EncryptedSharedPreferences.create(
                context,
                PREF_FILE_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            Log.e("PreferenceManager", "Failed to create EncryptedSharedPreferences, falling back to standard prefs", e)
            context.getSharedPreferences(PREF_FILE_NAME + "_standard", Context.MODE_PRIVATE)
        }
    }

    private val _themeModeFlow = MutableStateFlow(getThemeMode())
    val themeModeFlow: StateFlow<ThemeMode> = _themeModeFlow.asStateFlow()

    fun getGitHubToken(): String? {
        val token = prefs.getString(KEY_GITHUB_TOKEN, null)
        return if (token.isNullOrBlank()) null else token.trim()
    }

    fun setGitHubToken(token: String?) {
        prefs.edit().apply {
            if (token.isNullOrBlank()) {
                remove(KEY_GITHUB_TOKEN)
            } else {
                putString(KEY_GITHUB_TOKEN, token.trim())
            }
            apply()
        }
    }

    fun getGitHubUsername(): String? {
        return prefs.getString(KEY_GITHUB_USERNAME, null)
    }

    fun setGitHubUsername(username: String?) {
        prefs.edit().putString(KEY_GITHUB_USERNAME, username).apply()
    }

    fun getRepositoryName(): String {
        return prefs.getString(KEY_REPO_NAME, DEFAULT_REPO_NAME) ?: DEFAULT_REPO_NAME
    }

    fun setRepositoryName(repoName: String) {
        val cleanName = repoName.trim().ifEmpty { DEFAULT_REPO_NAME }
        prefs.edit().putString(KEY_REPO_NAME, cleanName).apply()
    }

    fun getDefaultBranch(): String {
        return prefs.getString(KEY_DEFAULT_BRANCH, "main") ?: "main"
    }

    fun setDefaultBranch(branch: String) {
        prefs.edit().putString(KEY_DEFAULT_BRANCH, branch).apply()
    }

    fun getThemeMode(): ThemeMode {
        val name = prefs.getString(KEY_THEME_MODE, ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name
        return try {
            ThemeMode.valueOf(name)
        } catch (e: Exception) {
            ThemeMode.SYSTEM
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        prefs.edit().putString(KEY_THEME_MODE, mode.name).apply()
        _themeModeFlow.value = mode
    }

    fun isConfigured(): Boolean {
        return !getGitHubToken().isNullOrBlank()
    }

    fun clearAll() {
        prefs.edit().clear().apply()
        _themeModeFlow.value = ThemeMode.SYSTEM
    }

    companion object {
        private const val PREF_FILE_NAME = "code_for_apk_secure_prefs"
        private const val KEY_GITHUB_TOKEN = "key_github_token"
        private const val KEY_GITHUB_USERNAME = "key_github_username"
        private const val KEY_REPO_NAME = "key_repo_name"
        private const val KEY_DEFAULT_BRANCH = "key_default_branch"
        private const val KEY_THEME_MODE = "key_theme_mode"

        const val DEFAULT_REPO_NAME = "codeforapk-builds"
    }
}

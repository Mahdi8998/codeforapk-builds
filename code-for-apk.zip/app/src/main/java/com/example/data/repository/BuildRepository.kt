package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.util.Base64
import android.util.Log
import com.example.data.api.GitHubApiClient
import com.example.data.local.AppDatabase
import com.example.data.local.EncryptedPreferenceManager
import com.example.data.model.BuildEntity
import com.example.data.model.BuildStatus
import com.example.data.model.CreateRepoRequest
import com.example.data.model.GitHubRepo
import com.example.data.model.GitHubUser
import com.example.data.model.PutContentRequest
import com.example.data.model.WorkflowDispatchRequest
import com.example.data.model.WorkflowRun
import com.example.util.ErrorDiagnostics
import com.example.util.ZipUtils
import com.example.util.ZipValidationResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

sealed class BuildProgressState {
    object Idle : BuildProgressState()
    data class Analyzing(val fileName: String) : BuildProgressState()
    data class Uploading(val progress: Float, val fileName: String) : BuildProgressState()
    data class Queued(val buildId: Long, val runId: Long?) : BuildProgressState()
    data class Building(val buildId: Long, val runId: Long, val stepName: String? = null, val elapsedSeconds: Long = 0) : BuildProgressState()
    data class DownloadingArtifact(val buildId: Long, val runId: Long) : BuildProgressState()
    data class Success(val buildId: Long, val apkPath: String, val projectName: String, val durationSeconds: Long) : BuildProgressState()
    data class Failed(val buildId: Long, val errorMessage: String, val errorHint: String?, val fullLog: String?) : BuildProgressState()
}

class BuildRepository(
    private val context: Context,
    private val prefs: EncryptedPreferenceManager,
    private val database: AppDatabase
) {
    private val api = GitHubApiClient.apiService
    private val dao = database.buildDao()

    private val _currentProgress = MutableStateFlow<BuildProgressState>(BuildProgressState.Idle)
    val currentProgress: StateFlow<BuildProgressState> = _currentProgress.asStateFlow()

    private var activeJobCancelled = false

    val allBuilds: Flow<List<BuildEntity>> = dao.getAllBuilds()

    fun getBuildFlow(id: Long): Flow<BuildEntity?> = dao.getBuildFlowById(id)

    suspend fun getBuildById(id: Long): BuildEntity? = dao.getBuildById(id)

    suspend fun deleteBuild(id: Long) = dao.deleteBuildById(id)

    suspend fun clearAllBuilds() = dao.clearAllBuilds()

    fun cancelActiveBuild() {
        activeJobCancelled = true
        _currentProgress.value = BuildProgressState.Idle
    }

    fun resetProgressState() {
        _currentProgress.value = BuildProgressState.Idle
    }

    suspend fun validateToken(token: String): Result<GitHubUser> = withContext(Dispatchers.IO) {
        try {
            val authHeader = GitHubApiClient.formatAuthHeader(token)
            val response = api.getAuthenticatedUser(authHeader)
            if (response.isSuccessful && response.body() != null) {
                val user = response.body()!!
                prefs.setGitHubToken(token)
                prefs.setGitHubUsername(user.login)
                Result.success(user)
            } else {
                val errorMsg = if (response.code() == 401) {
                    "Invalid or expired Personal Access Token (401 Unauthorized)."
                } else {
                    "GitHub API Error: ${response.code()} ${response.message()}"
                }
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            Result.failure(Exception("Network error while connecting to GitHub: ${e.localizedMessage ?: "Unknown error"}"))
        }
    }

    suspend fun ensureRepositoryAndWorkflow(): Result<GitHubRepo> = withContext(Dispatchers.IO) {
        try {
            val token = prefs.getGitHubToken() ?: return@withContext Result.failure(Exception("GitHub token is not configured."))
            val username = prefs.getGitHubUsername() ?: return@withContext Result.failure(Exception("GitHub username not found. Please re-validate your token."))
            val repoName = prefs.getRepositoryName()
            val authHeader = GitHubApiClient.formatAuthHeader(token)

            // 1. Check if repository exists
            val repoResponse = api.getRepository(authHeader, username, repoName)
            val repo = if (repoResponse.isSuccessful && repoResponse.body() != null) {
                repoResponse.body()!!
            } else if (repoResponse.code() == 404) {
                // Create private repo
                val createReq = CreateRepoRequest(name = repoName, private = true, autoInit = true)
                val createResp = api.createRepository(authHeader, createReq)
                if (createResp.isSuccessful && createResp.body() != null) {
                    createResp.body()!!
                } else {
                    return@withContext Result.failure(Exception("Failed to create repository '$repoName': ${createResp.code()} ${createResp.errorBody()?.string()}"))
                }
            } else {
                return@withContext Result.failure(Exception("Failed to verify repository '$repoName': ${repoResponse.code()} ${repoResponse.message()}"))
            }

            prefs.setDefaultBranch(repo.defaultBranch ?: "main")

            // 2. Verify or commit workflow file
            val workflowPath = ".github/workflows/build-apk.yml"
            val branch = repo.defaultBranch ?: "main"
            val workflowCheckResp = api.getContent(authHeader, username, repoName, workflowPath, branch)

            val workflowYaml = WORKFLOW_YAML_TEMPLATE
            val encodedYaml = Base64.encodeToString(workflowYaml.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)

            if (!workflowCheckResp.isSuccessful || workflowCheckResp.body()?.sha == null) {
                // Commit workflow file
                val putReq = PutContentRequest(
                    message = "Set up Android APK build workflow (Code for APK)",
                    content = encodedYaml,
                    branch = branch
                )
                val putResp = api.putContent(authHeader, username, repoName, workflowPath, putReq)
                if (!putResp.isSuccessful) {
                    return@withContext Result.failure(Exception("Failed to create workflow file: ${putResp.code()} ${putResp.errorBody()?.string()}"))
                }
            }

            Result.success(repo)
        } catch (e: Exception) {
            Result.failure(Exception("Repository setup error: ${e.localizedMessage ?: "Unknown error"}"))
        }
    }

    suspend fun reCommitWorkflow(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val token = prefs.getGitHubToken() ?: return@withContext Result.failure(Exception("GitHub token missing."))
            val username = prefs.getGitHubUsername() ?: return@withContext Result.failure(Exception("GitHub username missing."))
            val repoName = prefs.getRepositoryName()
            val branch = prefs.getDefaultBranch()
            val authHeader = GitHubApiClient.formatAuthHeader(token)

            val workflowPath = ".github/workflows/build-apk.yml"
            val existingResp = api.getContent(authHeader, username, repoName, workflowPath, branch)
            val sha = if (existingResp.isSuccessful) existingResp.body()?.sha else null

            val workflowYaml = WORKFLOW_YAML_TEMPLATE
            val encodedYaml = Base64.encodeToString(workflowYaml.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)

            val putReq = PutContentRequest(
                message = "Update Android APK build workflow (Code for APK)",
                content = encodedYaml,
                branch = branch,
                sha = sha
            )
            val putResp = api.putContent(authHeader, username, repoName, workflowPath, putReq)
            if (putResp.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Failed to update workflow: ${putResp.code()} ${putResp.errorBody()?.string()}"))
            }
        } catch (e: Exception) {
            Result.failure(Exception("Error committing workflow: ${e.localizedMessage ?: "Unknown error"}"))
        }
    }

    suspend fun startBuildFlow(zipUri: Uri, validation: ZipValidationResult): Result<Long> = withContext(Dispatchers.IO) {
        activeJobCancelled = false
        val token = prefs.getGitHubToken() ?: return@withContext Result.failure(Exception("GitHub token is not configured. Please open Settings."))
        val username = prefs.getGitHubUsername() ?: return@withContext Result.failure(Exception("GitHub username not found."))
        val repoName = prefs.getRepositoryName()
        val branch = prefs.getDefaultBranch()
        val authHeader = GitHubApiClient.formatAuthHeader(token)

        _currentProgress.value = BuildProgressState.Analyzing(validation.fileName)

        // Insert initial build record in Room
        val initialBuild = BuildEntity(
            projectName = validation.detectedProjectName,
            zipFileName = validation.fileName,
            fileSizeBytes = validation.fileSizeBytes,
            startDate = System.currentTimeMillis(),
            status = BuildStatus.UPLOADING.name
        )
        val buildId = dao.insertBuild(initialBuild)

        try {
            // 1. Ensure repository & workflow exists
            val repoCheck = ensureRepositoryAndWorkflow()
            if (repoCheck.isFailure) {
                val errorMsg = repoCheck.exceptionOrNull()?.message ?: "Repository initialization failed"
                updateBuildFailed(buildId, errorMsg, "Check your GitHub Personal Access Token permissions and repository settings.")
                return@withContext Result.failure(Exception(errorMsg))
            }

            if (activeJobCancelled) return@withContext Result.failure(Exception("Build cancelled"))

            // 2. Read ZIP and encode to Base64 with progress
            _currentProgress.value = BuildProgressState.Uploading(0.1f, validation.fileName)

            val base64Zip = try {
                ZipUtils.readUriAsBase64(context, zipUri) { progress ->
                    _currentProgress.value = BuildProgressState.Uploading(progress * 0.7f, validation.fileName)
                }
            } catch (e: Exception) {
                val msg = "Failed to read ZIP file: ${e.localizedMessage}"
                updateBuildFailed(buildId, msg, "Ensure the file still exists and the app has permission to read it.")
                return@withContext Result.failure(Exception(msg))
            }

            if (activeJobCancelled) return@withContext Result.failure(Exception("Build cancelled"))

            // 3. Upload project.zip to GitHub repository root
            _currentProgress.value = BuildProgressState.Uploading(0.85f, validation.fileName)
            val zipPath = "project.zip"
            val existingZipResp = api.getContent(authHeader, username, repoName, zipPath, branch)
            val zipSha = if (existingZipResp.isSuccessful) existingZipResp.body()?.sha else null

            val uploadReq = PutContentRequest(
                message = "Upload project source ZIP: ${validation.fileName}",
                content = base64Zip,
                branch = branch,
                sha = zipSha
            )

            val uploadResp = api.putContent(authHeader, username, repoName, zipPath, uploadReq)
            if (!uploadResp.isSuccessful) {
                val errorBody = uploadResp.errorBody()?.string() ?: ""
                val msg = if (uploadResp.code() == 413 || errorBody.contains("too large")) {
                    "File is too large for GitHub Contents API (>100MB). Try trimming large assets."
                } else {
                    "Upload failed: ${uploadResp.code()} $errorBody"
                }
                updateBuildFailed(buildId, msg, "Verify your repository is accessible and network connection is active.")
                return@withContext Result.failure(Exception(msg))
            }

            _currentProgress.value = BuildProgressState.Uploading(1.0f, validation.fileName)
            delay(1000)

            if (activeJobCancelled) return@withContext Result.failure(Exception("Build cancelled"))

            // 4. Trigger workflow dispatch
            _currentProgress.value = BuildProgressState.Queued(buildId, null)
            val dispatchReq = WorkflowDispatchRequest(
                ref = branch,
                inputs = mapOf("commit_msg" to "Build ${validation.detectedProjectName} (${System.currentTimeMillis()})")
            )
            val dispatchResp = api.dispatchWorkflow(authHeader, username, repoName, "build-apk.yml", dispatchReq)
            if (!dispatchResp.isSuccessful) {
                val msg = "Failed to trigger workflow: ${dispatchResp.code()} ${dispatchResp.errorBody()?.string()}"
                updateBuildFailed(buildId, msg, "Check if GitHub Actions is enabled on your repository.")
                return@withContext Result.failure(Exception(msg))
            }

            // 5. Poll for workflow run
            dao.updateBuild(
                dao.getBuildById(buildId)!!.copy(status = BuildStatus.QUEUED.name)
            )

            val startTime = System.currentTimeMillis()
            var runId: Long? = null

            // Wait a few seconds for GitHub Actions to register the run
            for (attempt in 1..15) {
                if (activeJobCancelled) return@withContext Result.failure(Exception("Build cancelled"))
                delay(3000)

                val runsResp = api.getWorkflowRuns(authHeader, username, repoName, "build-apk.yml", 5)
                if (runsResp.isSuccessful && runsResp.body()?.workflowRuns?.isNotEmpty() == true) {
                    val latestRun = runsResp.body()!!.workflowRuns.first()
                    // Run should have been created around our startTime
                    runId = latestRun.id
                    _currentProgress.value = BuildProgressState.Queued(buildId, runId)
                    dao.updateBuild(
                        dao.getBuildById(buildId)!!.copy(workflowRunId = runId)
                    )
                    break
                }
            }

            if (runId == null) {
                val msg = "Timed out waiting for GitHub Actions workflow to start."
                updateBuildFailed(buildId, msg, "Check repository Actions tab on GitHub to verify workflow dispatch.")
                return@withContext Result.failure(Exception(msg))
            }

            // 6. Poll workflow run execution
            var buildComplete = false
            var finalStatus: String = BuildStatus.BUILDING.name
            var finalConclusion: String? = null
            var pollCount = 0

            while (!buildComplete && !activeJobCancelled) {
                delay(8000)
                pollCount++
                val elapsedSec = (System.currentTimeMillis() - startTime) / 1000

                val runResp = api.getWorkflowRun(authHeader, username, repoName, runId)
                if (runResp.isSuccessful && runResp.body() != null) {
                    val run = runResp.body()!!
                    val status = run.status?.lowercase() ?: "queued"
                    val conclusion = run.conclusion?.lowercase()

                    if (status == "queued") {
                        _currentProgress.value = BuildProgressState.Queued(buildId, runId)
                        dao.updateBuild(
                            dao.getBuildById(buildId)!!.copy(
                                status = BuildStatus.QUEUED.name,
                                durationSeconds = elapsedSec
                            )
                        )
                    } else if (status == "in_progress") {
                        _currentProgress.value = BuildProgressState.Building(
                            buildId = buildId,
                            runId = runId,
                            stepName = "Compiling Android project...",
                            elapsedSeconds = elapsedSec
                        )
                        dao.updateBuild(
                            dao.getBuildById(buildId)!!.copy(
                                status = BuildStatus.BUILDING.name,
                                durationSeconds = elapsedSec
                            )
                        )
                    } else if (status == "completed") {
                        buildComplete = true
                        finalStatus = if (conclusion == "success") BuildStatus.SUCCESS.name else BuildStatus.FAILED.name
                        finalConclusion = conclusion
                    }
                } else if (runResp.code() == 401) {
                    updateBuildFailed(buildId, "GitHub Token expired or unauthorized (401)", "Please update your PAT in Settings.")
                    return@withContext Result.failure(Exception("Unauthorized (401)"))
                }

                // Prevent infinite stuck runs (> 25 minutes)
                if (elapsedSec > 25 * 60) {
                    val msg = "Build timed out after 25 minutes."
                    updateBuildFailed(buildId, msg, "The build took too long to complete. Inspect the project dependencies.")
                    return@withContext Result.failure(Exception(msg))
                }
            }

            if (activeJobCancelled) {
                dao.updateBuild(dao.getBuildById(buildId)!!.copy(status = BuildStatus.CANCELLED.name))
                return@withContext Result.failure(Exception("Build was cancelled by user"))
            }

            val totalDurationSec = (System.currentTimeMillis() - startTime) / 1000

            // 7. Handle Success or Failure
            if (finalConclusion == "success") {
                _currentProgress.value = BuildProgressState.DownloadingArtifact(buildId, runId)

                // Download artifact
                val artifactResult = downloadAndSaveApk(authHeader, username, repoName, runId, validation.detectedProjectName)
                if (artifactResult.isSuccess) {
                    val apkFile = artifactResult.getOrNull()!!
                    dao.updateBuild(
                        dao.getBuildById(buildId)!!.copy(
                            status = BuildStatus.SUCCESS.name,
                            apkFilePath = apkFile.absolutePath,
                            durationSeconds = totalDurationSec,
                            logSummary = "Build succeeded in ${ZipUtils.formatDuration(totalDurationSec)}! APK is ready to install."
                        )
                    )
                    _currentProgress.value = BuildProgressState.Success(
                        buildId = buildId,
                        apkPath = apkFile.absolutePath,
                        projectName = validation.detectedProjectName,
                        durationSeconds = totalDurationSec
                    )
                    Result.success(buildId)
                } else {
                    val msg = artifactResult.exceptionOrNull()?.message ?: "Failed to download APK artifact"
                    updateBuildFailed(buildId, msg, "The build completed, but no debug APK artifact was uploaded. Ensure your project builds an APK output.")
                    Result.failure(Exception(msg))
                }
            } else {
                // Fetch failed job logs
                val logData = fetchJobLogs(authHeader, username, repoName, runId)
                val analysis = ErrorDiagnostics.analyzeLog(logData)

                dao.updateBuild(
                    dao.getBuildById(buildId)!!.copy(
                        status = BuildStatus.FAILED.name,
                        durationSeconds = totalDurationSec,
                        logSummary = analysis.failureType ?: "Build failed",
                        fullLog = analysis.fullLog,
                        errorHint = analysis.diagnosticHint
                    )
                )

                _currentProgress.value = BuildProgressState.Failed(
                    buildId = buildId,
                    errorMessage = analysis.failureType ?: "Build failed on GitHub Actions",
                    errorHint = analysis.diagnosticHint,
                    fullLog = analysis.fullLog
                )

                Result.failure(Exception(analysis.failureType ?: "Build failed"))
            }
        } catch (e: Exception) {
            val errorMsg = e.localizedMessage ?: "Unexpected error during build"
            updateBuildFailed(buildId, errorMsg, "Check network connection and retry.")
            Result.failure(e)
        }
    }

    private suspend fun updateBuildFailed(buildId: Long, summary: String, hint: String?) {
        try {
            val existing = dao.getBuildById(buildId)
            if (existing != null) {
                dao.updateBuild(
                    existing.copy(
                        status = BuildStatus.FAILED.name,
                        logSummary = summary,
                        errorHint = hint
                    )
                )
            }
        } catch (e: Exception) {
            Log.e("BuildRepository", "Failed to update build status", e)
        }
        _currentProgress.value = BuildProgressState.Failed(
            buildId = buildId,
            errorMessage = summary,
            errorHint = hint,
            fullLog = null
        )
    }

    private suspend fun fetchJobLogs(authHeader: String, owner: String, repo: String, runId: Long): String {
        return try {
            val jobsResp = api.getWorkflowJobs(authHeader, owner, repo, runId)
            if (jobsResp.isSuccessful && jobsResp.body()?.jobs?.isNotEmpty() == true) {
                val failedJob = jobsResp.body()!!.jobs.firstOrNull { it.conclusion == "failure" }
                    ?: jobsResp.body()!!.jobs.first()

                val logsResp = api.getJobLogs(authHeader, owner, repo, failedJob.id)
                if (logsResp.isSuccessful && logsResp.body() != null) {
                    logsResp.body()!!.string()
                } else {
                    "Failed to fetch job logs (HTTP ${logsResp.code()})"
                }
            } else {
                "No jobs returned for workflow run $runId"
            }
        } catch (e: Exception) {
            "Error downloading logs: ${e.localizedMessage}"
        }
    }

    private suspend fun downloadAndSaveApk(
        authHeader: String,
        owner: String,
        repo: String,
        runId: Long,
        projectName: String
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            val artifactsResp = api.getArtifacts(authHeader, owner, repo, runId)
            if (!artifactsResp.isSuccessful || artifactsResp.body()?.artifacts.isNullOrEmpty()) {
                return@withContext Result.failure(Exception("No artifacts found for completed workflow run."))
            }

            val artifact = artifactsResp.body()!!.artifacts.firstOrNull {
                it.name.contains("apk", ignoreCase = true)
            } ?: artifactsResp.body()!!.artifacts.first()

            val downloadResp = api.downloadArtifactZip(authHeader, owner, repo, artifact.id)
            if (!downloadResp.isSuccessful || downloadResp.body() == null) {
                return@withContext Result.failure(Exception("Failed to download artifact: HTTP ${downloadResp.code()}"))
            }

            // Save downloaded ZIP artifact to temp cache and extract the .apk
            val tempZipFile = File(context.cacheDir, "artifact_${artifact.id}.zip")
            downloadResp.body()!!.byteStream().use { input ->
                FileOutputStream(tempZipFile).use { output ->
                    input.copyTo(output)
                }
            }

            // Determine target destination (Public Downloads or App External Files)
            val cleanName = projectName.replace("[^a-zA-Z0-9_-]".toRegex(), "_").ifBlank { "app_debug" }
            val timeStamp = System.currentTimeMillis()
            val targetApkName = "${cleanName}_debug_$timeStamp.apk"

            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val targetDir = if (downloadsDir != null && downloadsDir.exists()) {
                File(downloadsDir, "CodeForAPK").apply { mkdirs() }
            } else {
                context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
            }

            val finalApkFile = File(targetDir, targetApkName)

            // Extract .apk from artifact ZIP
            var extracted = false
            ZipInputStream(tempZipFile.inputStream()).use { zipStream ->
                var entry = zipStream.nextEntry
                while (entry != null) {
                    if (entry.name.endsWith(".apk", ignoreCase = true)) {
                        FileOutputStream(finalApkFile).use { output ->
                            zipStream.copyTo(output)
                        }
                        extracted = true
                        break
                    }
                    zipStream.closeEntry()
                    entry = zipStream.nextEntry
                }
            }

            tempZipFile.delete()

            if (extracted && finalApkFile.exists() && finalApkFile.length() > 0) {
                Result.success(finalApkFile)
            } else {
                Result.failure(Exception("Artifact ZIP did not contain any .apk file."))
            }
        } catch (e: Exception) {
            Result.failure(Exception("Failed to extract APK: ${e.localizedMessage}"))
        }
    }

    companion object {
        val WORKFLOW_YAML_TEMPLATE = """
name: Build Android APK

on:
  workflow_dispatch:
    inputs:
      commit_msg:
        description: 'Build trigger note'
        required: false
        default: 'Automated build from Code for APK'

jobs:
  build-apk:
    name: Assemble Debug APK
    runs-on: ubuntu-latest
    timeout-minutes: 25

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Set up Java 17
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'
          cache: 'gradle'

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: Extract Project ZIP
        run: |
          mkdir -p project_extracted
          if [ -f "project.zip" ]; then
            unzip -q -o project.zip -d project_extracted/
          else
            ZIP_FILE=$(find . -maxdepth 2 -name "*.zip" | head -n 1)
            if [ -n "${'$'}ZIP_FILE" ]; then
              unzip -q -o "${'$'}ZIP_FILE" -d project_extracted/
            else
              echo "Error: project.zip not found in repo root!"
              exit 1
            fi
          fi

      - name: Build Debug APK
        run: |
          cd project_extracted
          # If there is a single parent root folder extracted, move into it
          if [ ! -f "build.gradle.kts" ] && [ ! -f "build.gradle" ] && [ ! -f "settings.gradle.kts" ] && [ ! -f "settings.gradle" ]; then
            SUBDIR=$(find . -mindepth 1 -maxdepth 1 -type d | head -n 1)
            if [ -n "${'$'}SUBDIR" ]; then
              cd "${'$'}SUBDIR"
            fi
          fi
          
          echo "Working directory:"
          pwd
          ls -la

          # Ensure gradlew exists and is executable
          if [ -f "./gradlew" ]; then
            chmod +x ./gradlew
          else
            echo "Generating gradle wrapper..."
            gradle wrapper
            chmod +x ./gradlew
          fi

          ./gradlew assembleDebug --stacktrace --no-daemon

      - name: Locate and Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: app-debug-apk
          path: |
            project_extracted/**/build/outputs/apk/debug/*.apk
            project_extracted/**/build/outputs/apk/**/*.apk
          if-no-files-found: error
          retention-days: 7
""".trimIndent()
    }
}

package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class GitHubUser(
    val login: String,
    val id: Long? = null,
    val name: String? = null,
    @Json(name = "avatar_url") val avatarUrl: String? = null,
    @Json(name = "public_repos") val publicRepos: Int? = null,
    @Json(name = "total_private_repos") val totalPrivateRepos: Int? = null
)

@JsonClass(generateAdapter = true)
data class GitHubRepo(
    val id: Long? = null,
    val name: String,
    @Json(name = "full_name") val fullName: String? = null,
    val private: Boolean = true,
    @Json(name = "default_branch") val defaultBranch: String? = "main",
    @Json(name = "html_url") val htmlUrl: String? = null,
    val description: String? = null
)

@JsonClass(generateAdapter = true)
data class CreateRepoRequest(
    val name: String,
    val private: Boolean = true,
    @Json(name = "auto_init") val autoInit: Boolean = true,
    val description: String = "Automated Android APK builds created by Code for APK"
)

@JsonClass(generateAdapter = true)
data class PutContentRequest(
    val message: String,
    val content: String, // Base64 encoded
    val branch: String? = "main",
    val sha: String? = null
)

@JsonClass(generateAdapter = true)
data class GitHubContentResponse(
    val name: String? = null,
    val path: String? = null,
    val sha: String? = null,
    val size: Long? = null,
    @Json(name = "download_url") val downloadUrl: String? = null
)

@JsonClass(generateAdapter = true)
data class WorkflowDispatchRequest(
    val ref: String = "main",
    val inputs: Map<String, String>? = null
)

@JsonClass(generateAdapter = true)
data class WorkflowRunsResponse(
    @Json(name = "total_count") val totalCount: Int = 0,
    @Json(name = "workflow_runs") val workflowRuns: List<WorkflowRun> = emptyList()
)

@JsonClass(generateAdapter = true)
data class WorkflowRun(
    val id: Long,
    val name: String? = null,
    val status: String? = null, // queued, in_progress, completed
    val conclusion: String? = null, // success, failure, neutral, cancelled, timed_out, action_required
    @Json(name = "html_url") val htmlUrl: String? = null,
    @Json(name = "run_number") val runNumber: Int? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "updated_at") val updatedAt: String? = null,
    @Json(name = "head_branch") val headBranch: String? = null,
    @Json(name = "head_sha") val headSha: String? = null
)

@JsonClass(generateAdapter = true)
data class WorkflowJobsResponse(
    @Json(name = "total_count") val totalCount: Int = 0,
    val jobs: List<WorkflowJob> = emptyList()
)

@JsonClass(generateAdapter = true)
data class WorkflowJob(
    val id: Long,
    @Json(name = "run_id") val runId: Long? = null,
    val name: String? = null,
    val status: String? = null,
    val conclusion: String? = null,
    @Json(name = "started_at") val startedAt: String? = null,
    @Json(name = "completed_at") val completedAt: String? = null,
    val steps: List<WorkflowJobStep>? = null
)

@JsonClass(generateAdapter = true)
data class WorkflowJobStep(
    val name: String,
    val status: String? = null,
    val conclusion: String? = null,
    val number: Int = 0
)

@JsonClass(generateAdapter = true)
data class ArtifactsResponse(
    @Json(name = "total_count") val totalCount: Int = 0,
    val artifacts: List<ArtifactItem> = emptyList()
)

@JsonClass(generateAdapter = true)
data class ArtifactItem(
    val id: Long,
    val name: String,
    @Json(name = "size_in_bytes") val sizeInBytes: Long = 0,
    @Json(name = "archive_download_url") val archiveDownloadUrl: String? = null,
    val expired: Boolean = false
)

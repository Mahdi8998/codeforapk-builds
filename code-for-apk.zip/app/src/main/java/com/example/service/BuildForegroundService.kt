package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import com.example.CodeForApkApp
import com.example.MainActivity
import com.example.data.model.BuildStatus
import com.example.data.repository.BuildProgressState
import com.example.util.ZipUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File

class BuildForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var progressJob: Job? = null
    private var activeBuildJob: Job? = null

    private val repository by lazy {
        (application as CodeForApkApp).buildRepository
    }

    private val notificationManager by lazy {
        getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action

        if (action == ACTION_CANCEL_BUILD) {
            repository.cancelActiveBuild()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val zipUriString = intent?.getStringExtra(EXTRA_ZIP_URI)
        if (zipUriString != null && action == ACTION_START_BUILD) {
            val zipUri = Uri.parse(zipUriString)
            startForeground(NOTIFICATION_ID_FOREGROUND, createOngoingNotification("Starting Build...", "Initializing upload..."))
            observeProgress()
            startBuildExecution(zipUri)
        }

        return START_NOT_STICKY
    }

    private fun observeProgress() {
        progressJob?.cancel()
        progressJob = serviceScope.launch {
            repository.currentProgress.collectLatest { state ->
                when (state) {
                    is BuildProgressState.Idle -> {
                        // Idle state
                    }
                    is BuildProgressState.Analyzing -> {
                        updateNotification("Analyzing Project", "Inspecting ${state.fileName}...")
                    }
                    is BuildProgressState.Uploading -> {
                        val pct = (state.progress * 100).toInt()
                        updateNotification("Uploading ZIP ($pct%)", "Uploading ${state.fileName} to GitHub...")
                    }
                    is BuildProgressState.Queued -> {
                        updateNotification("Build Queued", "Waiting for GitHub Actions runner...")
                    }
                    is BuildProgressState.Building -> {
                        val duration = ZipUtils.formatDuration(state.elapsedSeconds)
                        updateNotification("Building APK ($duration)", state.stepName ?: "Compiling with Gradle...")
                    }
                    is BuildProgressState.DownloadingArtifact -> {
                        updateNotification("Downloading APK", "Fetching built artifact from GitHub...")
                    }
                    is BuildProgressState.Success -> {
                        showCompletionNotification(
                            title = "Build Successful! 🎉",
                            message = "${state.projectName} built in ${ZipUtils.formatDuration(state.durationSeconds)}",
                            isSuccess = true,
                            apkPath = state.apkPath,
                            buildId = state.buildId
                        )
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                    }
                    is BuildProgressState.Failed -> {
                        showCompletionNotification(
                            title = "Build Failed ❌",
                            message = state.errorMessage,
                            isSuccess = false,
                            apkPath = null,
                            buildId = state.buildId
                        )
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                    }
                }
            }
        }
    }

    private fun startBuildExecution(zipUri: Uri) {
        activeBuildJob?.cancel()
        activeBuildJob = serviceScope.launch {
            val validation = ZipUtils.validateAndInspectZip(applicationContext, zipUri)
            if (!validation.isValid) {
                showCompletionNotification(
                    title = "Invalid ZIP File ❌",
                    message = validation.errorMessage ?: "File is not a valid Android project ZIP.",
                    isSuccess = false,
                    apkPath = null,
                    buildId = null
                )
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return@launch
            }

            repository.startBuildFlow(zipUri, validation)
        }
    }

    private fun updateNotification(title: String, text: String) {
        val notification = createOngoingNotification(title, text)
        notificationManager.notify(NOTIFICATION_ID_FOREGROUND, notification)
    }

    private fun createOngoingNotification(title: String, text: String): Notification {
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val cancelIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, BuildForegroundService::class.java).apply {
                action = ACTION_CANCEL_BUILD
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID_PROGRESS)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setOngoing(true)
            .setContentIntent(contentIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancel", cancelIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun showCompletionNotification(
        title: String,
        message: String,
        isSuccess: Boolean,
        apkPath: String?,
        buildId: Long?
    ) {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (buildId != null) {
                putExtra("EXTRA_NAV_BUILD_ID", buildId)
            }
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            2,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID_COMPLETION)
            .setContentTitle(title)
            .setContentText(message)
            .setSmallIcon(if (isSuccess) android.R.drawable.stat_sys_download_done else android.R.drawable.stat_notify_error)
            .setAutoCancel(true)
            .setContentIntent(openPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)

        if (isSuccess && apkPath != null) {
            val apkFile = File(apkPath)
            if (apkFile.exists()) {
                val apkUri = FileProvider.getUriForFile(
                    this,
                    "${packageName}.fileprovider",
                    apkFile
                )
                val installIntent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(apkUri, "application/vnd.android.package-archive")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val installPendingIntent = PendingIntent.getActivity(
                    this,
                    3,
                    installIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                builder.addAction(android.R.drawable.ic_input_add, "Install APK", installPendingIntent)
            }
        }

        notificationManager.notify(NOTIFICATION_ID_COMPLETION, builder.build())
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val progressChannel = NotificationChannel(
                CHANNEL_ID_PROGRESS,
                "Build Progress",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live build and upload progress"
            }

            val completionChannel = NotificationChannel(
                CHANNEL_ID_COMPLETION,
                "Build Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifies when APK build completes or fails"
                enableVibration(true)
            }

            notificationManager.createNotificationChannel(progressChannel)
            notificationManager.createNotificationChannel(completionChannel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    companion object {
        const val ACTION_START_BUILD = "com.example.action.START_BUILD"
        const val ACTION_CANCEL_BUILD = "com.example.action.CANCEL_BUILD"
        const val EXTRA_ZIP_URI = "extra_zip_uri"

        private const val CHANNEL_ID_PROGRESS = "code_for_apk_progress"
        private const val CHANNEL_ID_COMPLETION = "code_for_apk_completion"
        private const val NOTIFICATION_ID_FOREGROUND = 1001
        private const val NOTIFICATION_ID_COMPLETION = 1002

        fun start(context: Context, zipUri: Uri) {
            val intent = Intent(context, BuildForegroundService::class.java).apply {
                action = ACTION_START_BUILD
                putExtra(EXTRA_ZIP_URI, zipUri.toString())
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun cancel(context: Context) {
            val intent = Intent(context, BuildForegroundService::class.java).apply {
                action = ACTION_CANCEL_BUILD
            }
            context.startService(intent)
        }
    }
}

package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.local.EncryptedPreferenceManager
import com.example.data.repository.BuildRepository

class CodeForApkApp : Application() {

    val preferenceManager: EncryptedPreferenceManager by lazy {
        EncryptedPreferenceManager(this)
    }

    val database: AppDatabase by lazy {
        AppDatabase.getInstance(this)
    }

    val buildRepository: BuildRepository by lazy {
        BuildRepository(this, preferenceManager, database)
    }

    override fun onCreate() {
        super.onCreate()
    }
}

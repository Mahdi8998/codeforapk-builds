package com.example.util

data class LogAnalysisResult(
    val summaryLines: List<String>,
    val fullLog: String,
    val diagnosticHint: String?,
    val failureType: String?
)

object ErrorDiagnostics {

    fun analyzeLog(rawLog: String): LogAnalysisResult {
        if (rawLog.isBlank()) {
            return LogAnalysisResult(
                summaryLines = listOf("No log output returned from GitHub Actions."),
                fullLog = "",
                diagnosticHint = "GitHub Actions job did not produce logs or the run was cancelled before execution.",
                failureType = "Empty Log"
            )
        }

        val allLines = rawLog.lines()
        val tailLines = if (allLines.size > 250) {
            allLines.takeLast(250)
        } else {
            allLines
        }

        val lowerLog = rawLog.lowercase()

        val (hint, failureType) = when {
            lowerLog.contains("unresolved reference") -> {
                "Unresolved reference detected in Kotlin code. Check if an import is missing or a library dependency is not listed in build.gradle.kts." to "Compilation Error (Unresolved Reference)"
            }
            lowerLog.contains("ksp") && (lowerLog.contains("incompatible") || lowerLog.contains("version")) -> {
                "KSP and Kotlin version mismatch. Verify that your com.google.devtools.ksp version exactly aligns with the Kotlin compiler version in libs.versions.toml." to "KSP / Kotlin Version Mismatch"
            }
            lowerLog.contains("could not find") || lowerLog.contains("failed to resolve") || lowerLog.contains("could not resolve all files") -> {
                "Dependency resolution failure. A requested library or plugin repository could not be downloaded. Check repository declarations (google(), mavenCentral()) in settings.gradle.kts." to "Dependency Resolution Error"
            }
            lowerLog.contains("sdk location not found") || lowerLog.contains("android_home") || lowerLog.contains("sdk.dir") -> {
                "Android SDK path not recognized. The GitHub Actions workflow might need the android-actions/setup-android step." to "Android SDK Configuration"
            }
            lowerLog.contains("java.lang.outofmemoryerror") || lowerLog.contains("metaspace") || lowerLog.contains("heap space") -> {
                "Gradle Daemon ran out of memory. Try setting org.gradle.jvmargs=-Xmx2048m in gradle.properties." to "Out Of Memory (JVM/Gradle)"
            }
            lowerLog.contains("permission denied") && lowerLog.contains("gradlew") -> {
                "gradlew wrapper script does not have executable permissions. The workflow automatically attempts chmod +x ./gradlew." to "File Permissions Error"
            }
            lowerLog.contains("manifest merger failed") -> {
                "AndroidManifest.xml merger conflict. Check for duplicate application tags, incompatible minSdk values, or conflicting activity/service attributes." to "Manifest Merger Conflict"
            }
            lowerLog.contains("type mismatch") || lowerLog.contains("type inference") -> {
                "Type mismatch in Kotlin source code. A parameter or return value did not match expected type definitions." to "Kotlin Type Mismatch"
            }
            lowerLog.contains("duplicate class") -> {
                "Duplicate class found across multiple libraries. Check for conflicting transitive dependencies in build.gradle.kts." to "Duplicate Class Conflict"
            }
            lowerLog.contains("project.zip not found") || lowerLog.contains("cannot find zip") -> {
                "The project.zip file was not found in the repository root. Ensure the file upload completed before triggering the workflow." to "Missing Source ZIP"
            }
            lowerLog.contains("build failed with an exception") || lowerLog.contains("task :app:compiledebug") -> {
                "Gradle compilation failed. Review the specific Kotlin/Java compilation errors in the log below." to "Gradle Build Failure"
            }
            else -> {
                "Build execution encountered an error. Check the detailed log above for task-level stack traces." to "Build Failed"
            }
        }

        return LogAnalysisResult(
            summaryLines = tailLines,
            fullLog = rawLog,
            diagnosticHint = hint,
            failureType = failureType
        )
    }
}

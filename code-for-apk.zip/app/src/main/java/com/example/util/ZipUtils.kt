package com.example.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

data class ZipValidationResult(
    val isValid: Boolean,
    val fileName: String,
    val fileSizeBytes: Long,
    val formattedSize: String,
    val detectedProjectName: String,
    val isLargeFile: Boolean, // > 100 MB
    val containsAndroidProject: Boolean,
    val errorMessage: String? = null
)

object ZipUtils {

    fun validateAndInspectZip(context: Context, uri: Uri): ZipValidationResult {
        var fileName = "project.zip"
        var fileSize: Long = 0L

        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) {
                        fileName = cursor.getString(nameIndex) ?: "project.zip"
                    }
                    if (sizeIndex != -1) {
                        fileSize = cursor.getLong(sizeIndex)
                    }
                }
            }
        } catch (e: Exception) {
            // fallback
        }

        var detectedProjectName = fileName.removeSuffix(".zip").ifBlank { "Android Project" }
        var hasAndroidFiles = false
        var entryCount = 0

        try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                ZipInputStream(inputStream).use { zipStream ->
                    var entry: ZipEntry? = zipStream.nextEntry
                    while (entry != null) {
                        entryCount++
                        val name = entry.name.lowercase()
                        if (name.endsWith("build.gradle") ||
                            name.endsWith("build.gradle.kts") ||
                            name.endsWith("settings.gradle") ||
                            name.endsWith("settings.gradle.kts") ||
                            name.endsWith("androidmanifest.xml")
                        ) {
                            hasAndroidFiles = true
                        }

                        // Try to read rootProject.name if in settings.gradle.kts
                        if (name.endsWith("settings.gradle.kts") || name.endsWith("settings.gradle")) {
                            try {
                                val buffer = ByteArray(2048)
                                val read = zipStream.read(buffer)
                                if (read > 0) {
                                    val content = String(buffer, 0, read)
                                    val regex = """rootProject\.name\s*=\s*["']([^"']+)["']""".toRegex()
                                    val match = regex.find(content)
                                    if (match != null && match.groupValues.size > 1) {
                                        val extracted = match.groupValues[1].trim()
                                        if (extracted.isNotBlank() && extracted != "My Application") {
                                            detectedProjectName = extracted
                                        }
                                    }
                                }
                            } catch (e: Exception) {
                                // Ignore
                            }
                        }

                        zipStream.closeEntry()
                        entry = zipStream.nextEntry
                    }
                }
            }
        } catch (e: Exception) {
            return ZipValidationResult(
                isValid = false,
                fileName = fileName,
                fileSizeBytes = fileSize,
                formattedSize = formatBytes(fileSize),
                detectedProjectName = detectedProjectName,
                isLargeFile = fileSize > 100 * 1024 * 1024,
                containsAndroidProject = false,
                errorMessage = "Selected file is corrupted or not a valid ZIP: ${e.localizedMessage ?: "Unknown parse error"}"
            )
        }

        if (entryCount == 0) {
            return ZipValidationResult(
                isValid = false,
                fileName = fileName,
                fileSizeBytes = fileSize,
                formattedSize = formatBytes(fileSize),
                detectedProjectName = detectedProjectName,
                isLargeFile = false,
                containsAndroidProject = false,
                errorMessage = "The selected ZIP file is empty."
            )
        }

        if (!hasAndroidFiles) {
            return ZipValidationResult(
                isValid = false,
                fileName = fileName,
                fileSizeBytes = fileSize,
                formattedSize = formatBytes(fileSize),
                detectedProjectName = detectedProjectName,
                isLargeFile = fileSize > 100 * 1024 * 1024,
                containsAndroidProject = false,
                errorMessage = "No Android project configuration (build.gradle, AndroidManifest.xml, or settings.gradle) found inside this ZIP archive."
            )
        }

        return ZipValidationResult(
            isValid = true,
            fileName = fileName,
            fileSizeBytes = fileSize,
            formattedSize = formatBytes(fileSize),
            detectedProjectName = detectedProjectName,
            isLargeFile = fileSize > 100 * 1024 * 1024,
            containsAndroidProject = true,
            errorMessage = null
        )
    }

    fun readUriAsBase64(context: Context, uri: Uri, onProgress: ((Float) -> Unit)? = null): String {
        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            val outputStream = ByteArrayOutputStream()
            val buffer = ByteArray(32 * 1024)
            var read: Int
            var totalRead = 0L
            val available = try { inputStream.available().toLong() } catch (e: Exception) { 0L }

            while (inputStream.read(buffer).also { read = it } != -1) {
                outputStream.write(buffer, 0, read)
                totalRead += read
                if (available > 0 && onProgress != null) {
                    val progress = (totalRead.toFloat() / available.toFloat()).coerceIn(0f, 1f)
                    onProgress(progress)
                }
            }
            val bytes = outputStream.toByteArray()
            return Base64.encodeToString(bytes, Base64.NO_WRAP)
        } ?: throw IllegalStateException("Cannot open input stream for selected ZIP")
    }

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
        val formatted = String.format("%.1f", bytes / Math.pow(1024.0, digitGroups.toDouble()))
        return "$formatted ${units[digitGroups.coerceIn(0, units.size - 1)]}"
    }

    fun formatDuration(seconds: Long): String {
        val mins = seconds / 60
        val secs = seconds % 60
        return if (mins > 0) {
            "${mins}m ${secs}s"
        } else {
            "${secs}s"
        }
    }
}

package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.CodeForApkApp
import com.example.data.model.BuildEntity
import com.example.data.model.ThemeMode
import com.example.data.repository.BuildProgressState
import com.example.service.BuildForegroundService
import com.example.util.ZipUtils
import com.example.util.ZipValidationResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = getApplication<CodeForApkApp>()
    private val prefs = app.preferenceManager
    private val repository = app.buildRepository

    val themeMode: StateFlow<ThemeMode> = prefs.themeModeFlow

    val currentProgress: StateFlow<BuildProgressState> = repository.currentProgress

    val buildHistory: StateFlow<List<BuildEntity>> = repository.allBuilds.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _isConfigured = MutableStateFlow(prefs.isConfigured())
    val isConfigured: StateFlow<Boolean> = _isConfigured.asStateFlow()

    private val _githubUsername = MutableStateFlow(prefs.getGitHubUsername())
    val githubUsername: StateFlow<String?> = _githubUsername.asStateFlow()

    private val _repoName = MutableStateFlow(prefs.getRepositoryName())
    val repoName: StateFlow<String> = _repoName.asStateFlow()

    private val _selectedZipUri = MutableStateFlow<Uri?>(null)
    val selectedZipUri: StateFlow<Uri?> = _selectedZipUri.asStateFlow()

    private val _selectedZipValidation = MutableStateFlow<ZipValidationResult?>(null)
    val selectedZipValidation: StateFlow<ZipValidationResult?> = _selectedZipValidation.asStateFlow()

    private val _isVerifyingToken = MutableStateFlow(false)
    val isVerifyingToken: StateFlow<Boolean> = _isVerifyingToken.asStateFlow()

    private val _tokenVerificationError = MutableStateFlow<String?>(null)
    val tokenVerificationError: StateFlow<String?> = _tokenVerificationError.asStateFlow()

    private val _isSettingUpRepo = MutableStateFlow(false)
    val isSettingUpRepo: StateFlow<Boolean> = _isSettingUpRepo.asStateFlow()

    private val _repoSetupMessage = MutableStateFlow<String?>(null)
    val repoSetupMessage: StateFlow<String?> = _repoSetupMessage.asStateFlow()

    private val _repoSetupSuccess = MutableStateFlow<Boolean?>(null)
    val repoSetupSuccess: StateFlow<Boolean?> = _repoSetupSuccess.asStateFlow()

    fun setThemeMode(mode: ThemeMode) {
        prefs.setThemeMode(mode)
    }

    fun setRepositoryName(name: String) {
        prefs.setRepositoryName(name)
        _repoName.value = prefs.getRepositoryName()
    }

    fun validateAndSaveToken(token: String, onComplete: ((Boolean) -> Unit)? = null) {
        viewModelScope.launch {
            _isVerifyingToken.value = true
            _tokenVerificationError.value = null

            val result = repository.validateToken(token)
            _isVerifyingToken.value = false

            if (result.isSuccess) {
                _isConfigured.value = true
                _githubUsername.value = result.getOrNull()?.login
                onComplete?.invoke(true)
            } else {
                _tokenVerificationError.value = result.exceptionOrNull()?.message ?: "Validation failed"
                onComplete?.invoke(false)
            }
        }
    }

    fun setupRepositoryAndWorkflow(onComplete: ((Boolean) -> Unit)? = null) {
        viewModelScope.launch {
            _isSettingUpRepo.value = true
            _repoSetupMessage.value = "Verifying repository and workflow configuration..."
            _repoSetupSuccess.value = null

            val result = repository.ensureRepositoryAndWorkflow()
            _isSettingUpRepo.value = false

            if (result.isSuccess) {
                _repoSetupMessage.value = "Repository & build workflow successfully configured! Ready to build."
                _repoSetupSuccess.value = true
                onComplete?.invoke(true)
            } else {
                _repoSetupMessage.value = result.exceptionOrNull()?.message ?: "Setup failed"
                _repoSetupSuccess.value = false
                onComplete?.invoke(false)
            }
        }
    }

    fun reCommitWorkflow() {
        viewModelScope.launch {
            _isSettingUpRepo.value = true
            _repoSetupMessage.value = "Re-committing GitHub Actions workflow file..."
            val result = repository.reCommitWorkflow()
            _isSettingUpRepo.value = false
            if (result.isSuccess) {
                _repoSetupMessage.value = "Workflow file re-committed successfully!"
                _repoSetupSuccess.value = true
            } else {
                _repoSetupMessage.value = result.exceptionOrNull()?.message ?: "Re-commit failed"
                _repoSetupSuccess.value = false
            }
        }
    }

    fun selectZipFile(uri: Uri?) {
        _selectedZipUri.value = uri
        if (uri != null) {
            viewModelScope.launch {
                val validation = ZipUtils.validateAndInspectZip(app, uri)
                _selectedZipValidation.value = validation
            }
        } else {
            _selectedZipValidation.value = null
        }
    }

    fun clearSelectedZip() {
        _selectedZipUri.value = null
        _selectedZipValidation.value = null
    }

    fun startBuild(uri: Uri) {
        BuildForegroundService.start(app, uri)
    }

    fun cancelBuild() {
        BuildForegroundService.cancel(app)
        repository.cancelActiveBuild()
    }

    fun resetProgress() {
        repository.resetProgressState()
        clearSelectedZip()
    }

    fun deleteBuild(id: Long) {
        viewModelScope.launch {
            repository.deleteBuild(id)
        }
    }

    fun clearAllBuilds() {
        viewModelScope.launch {
            repository.clearAllBuilds()
        }
    }

    fun getBuildFlow(id: Long) = repository.getBuildFlow(id)
}

package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Deep Blue / Violet Developer Palette
val DeepIndigoPrimary = Color(0xFF6C63FF)
val DeepIndigoLight = Color(0xFF4338CA)
val DeepIndigoDark = Color(0xFF818CF8)

val ElectricCyanAccent = Color(0xFF00E5FF)
val ElectricCyanDark = Color(0xFF00B0FF)

val SurfaceDark = Color(0xFF0F111A)
val SurfaceDarkCard = Color(0xFF181B2A)
val SurfaceDarkElevated = Color(0xFF22263D)

val SurfaceLight = Color(0xFFF8FAFC)
val SurfaceLightCard = Color(0xFFFFFFFF)
val SurfaceLightElevated = Color(0xFFEEF2F6)

// Semantic status colors
val StatusSuccess = Color(0xFF10B981)
val StatusSuccessContainer = Color(0xFF064E3B)
val StatusError = Color(0xFFEF4444)
val StatusErrorContainer = Color(0xFF7F1D1D)
val StatusWarning = Color(0xFFF59E0B)
val StatusInfo = Color(0xFF3B82F6)
val StatusQueued = Color(0xFF8B5CF6)

// Code log colors
val LogBackgroundDark = Color(0xFF0A0C13)
val LogTextDark = Color(0xFFE2E8F0)
val LogTimestamp = Color(0xFF64748B)
val LogHighlight = Color(0xFFFACC15)
val LogErrorText = Color(0xFFF87171)
val LogSuccessText = Color(0xFF4ADE80)

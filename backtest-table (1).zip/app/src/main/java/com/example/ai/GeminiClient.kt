package com.example.ai

import com.example.analytics.BacktestStatsCalculator
import com.example.data.model.DataMode
import com.example.data.model.GridData
import com.example.util.NumberParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class ChatMessage(
    val role: String, // "user" or "model"
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

sealed class AiResult {
    data class Success(val responseText: String) : AiResult()
    data class Error(val errorMessage: String, val isKeyError: Boolean = false) : AiResult()
}

class GeminiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val systemInstructionText = """
You are a professional, senior forex trading-strategy backtest analyst.
The input provided to you is spreadsheet data where each row represents a trade from the user's manual backtest.
Instructions:
1. Analyze critically and cite real numbers, percentages, and metrics from the provided data.
2. Structure your analysis with clear, elegant Persian headings and bullet points.
3. Provide concrete, mathematically sound, and actionable suggestions for rule changes and edge refinement.
4. If the sample size is too small for statistical certainty, clearly state this caveat.
5. NEVER invent or hallucinate data that is not in the table.
6. Always respond completely in PERSIAN (فارسی).
7. End your response with a one-line Persian disclaimer stating that this analysis is for educational and backtesting purposes only and is not financial advice (سلب مسئولیت: این تحلیل صرفاً جنبه آموزشی و بررسی بکتست داشته و توصیه مالی محسوب نمی‌شود).
""".trimIndent()

    private val preferredModel = "gemini-3.5-flash"
    private val fallbackModel = "gemini-flash-latest"

    suspend fun testConnection(apiKey: String): AiResult = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) {
            return@withContext AiResult.Error("کلید API گوگل Gemini وارد نشده است.", isKeyError = true)
        }

        try {
            val jsonBody = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", "Ping test. Respond with OK in Persian.")
                            })
                        })
                    })
                })
            }

            // Try preferred model first, fallback if 404
            var result = executeCall(cleanKey, preferredModel, jsonBody)
            if (result is CallResponse.HttpError && result.code == 404) {
                result = executeCall(cleanKey, fallbackModel, jsonBody)
            }

            when (result) {
                is CallResponse.Success -> AiResult.Success("اتصال با موفقیت برقرار شد ✅")
                is CallResponse.HttpError -> {
                    when (result.code) {
                        400, 401, 403 -> AiResult.Error("کلید API نامعتبر است یا دسترسی مجاز نیست (کد: ${result.code})", isKeyError = true)
                        404 -> AiResult.Error("مدل یافت نشد (کد: 404). لطفاً از فعال بودن دسترسی Gemini API در کنسول گوگل اطمینان حاصل کنید.")
                        429 -> AiResult.Error("محدودیت تعداد درخواست (Rate Limit)؛ کمی بعد دوباره تلاش کنید (کد: 429)")
                        else -> AiResult.Error("خطا در برقراری ارتباط با سرور Gemini (کد: ${result.code})")
                    }
                }
                is CallResponse.NetworkError -> AiResult.Error("عدم اتصال به اینترنت یا تایم‌اوت شبکه")
                is CallResponse.ExceptionError -> AiResult.Error("خطا: ${result.message}")
            }
        } catch (e: Exception) {
            AiResult.Error("خطای غیرمنتظره: ${e.localizedMessage ?: "خطای ناشناخته"}")
        }
    }

    suspend fun sendAnalysis(
        apiKey: String,
        prompt: String,
        gridData: GridData,
        dataMode: DataMode,
        history: List<ChatMessage> = emptyList()
    ): AiResult = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) {
            return@withContext AiResult.Error("کلید API تنظیم نشده است. لطفاً ابتدا در بخش تنظیمات کلید خود را وارد کنید.", isKeyError = true)
        }

        try {
            val payloadText = buildDataPayload(gridData, dataMode)
            val fullPrompt = if (history.isEmpty()) {
                """
داده‌های جدول بکتست:
$payloadText

درخواست کاربر:
$prompt
""".trimIndent()
            } else {
                prompt
            }

            val contentsArray = JSONArray()

            // If we have history, insert previous turns; make sure the first turn has the payload context
            if (history.isNotEmpty()) {
                // First turn (User with payload + first prompt)
                val firstUserMsg = history.first()
                contentsArray.put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", "داده‌های جدول بکتست:\n$payloadText\n\nدرخواست کاربر:\n${firstUserMsg.content}")
                        })
                    })
                })

                for (i in 1 until history.size) {
                    val msg = history[i]
                    contentsArray.put(JSONObject().apply {
                        put("role", if (msg.role == "model") "model" else "user")
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", msg.content)
                            })
                        })
                    })
                }

                // Add current prompt
                contentsArray.put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    })
                })
            } else {
                contentsArray.put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", fullPrompt)
                        })
                    })
                })
            }

            val rootJson = JSONObject().apply {
                put("contents", contentsArray)
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", systemInstructionText)
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.3)
                    put("topP", 0.95)
                })
            }

            var result = executeCall(cleanKey, preferredModel, rootJson)
            if (result is CallResponse.HttpError && result.code == 404) {
                result = executeCall(cleanKey, fallbackModel, rootJson)
            }

            when (result) {
                is CallResponse.Success -> {
                    val parsedText = extractTextFromResponse(result.body)
                    if (parsedText != null) {
                        AiResult.Success(parsedText)
                    } else {
                        AiResult.Error("پاسخی از مدل دریافت نشد.")
                    }
                }
                is CallResponse.HttpError -> {
                    when (result.code) {
                        400, 401, 403 -> AiResult.Error("کلید API نامعتبر است (کد: ${result.code})", isKeyError = true)
                        404 -> AiResult.Error("مدل در سرور گوگل یافت نشد (کد: 404)")
                        429 -> AiResult.Error("محدودیت تعداد درخواست؛ لطفاً اندکی بعد مجدداً تلاش نمایید")
                        else -> AiResult.Error("خطا در ارتباط با هوش مصنوعی (کد: ${result.code})")
                    }
                }
                is CallResponse.NetworkError -> AiResult.Error("عدم اتصال به اینترنت یا تایم‌اوت شبکه")
                is CallResponse.ExceptionError -> AiResult.Error("خطا: ${result.message}")
            }
        } catch (e: Exception) {
            AiResult.Error("خطا: ${e.localizedMessage ?: "خطای ناشناخته"}")
        }
    }

    private sealed class CallResponse {
        data class Success(val body: String) : CallResponse()
        data class HttpError(val code: Int, val body: String) : CallResponse()
        data object NetworkError : CallResponse()
        data class ExceptionError(val message: String) : CallResponse()
    }

    private fun executeCall(apiKey: String, model: String, requestJson: JSONObject): CallResponse {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
        val request = Request.Builder()
            .url(url)
            .post(requestJson.toString().toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    CallResponse.Success(body)
                } else {
                    CallResponse.HttpError(response.code, body)
                }
            }
        } catch (e: IOException) {
            CallResponse.NetworkError
        } catch (e: Exception) {
            CallResponse.ExceptionError(e.localizedMessage ?: "Unknown error")
        }
    }

    fun buildDataPayload(gridData: GridData, dataMode: DataMode): String {
        return when (dataMode) {
            DataMode.COMPLETE -> {
                val sb = StringBuilder()
                sb.append("--- حالت کامل (تمام ردیف‌های استراتژی به تفکیک تب/ستون) ---\n")
                sb.append(gridData.columns.joinToString("\t")).append("\n")
                val cappedRows = gridData.rows.take(500)
                for (row in cappedRows) {
                    sb.append(row.joinToString("\t")).append("\n")
                }
                sb.toString()
            }
            DataMode.SUMMARY -> {
                val columns = gridData.columns
                val rows = gridData.rows
                val plIndex = gridData.plColumnIndex ?: BacktestStatsCalculator.findCandidatePlColumn(columns, rows)
                val summary = BacktestStatsCalculator.calculateSummary(columns, rows)
                val advanced = BacktestStatsCalculator.calculateAdvancedStats(rows, plIndex)
                val groupColIdx = BacktestStatsCalculator.findDefaultGroupColumn(columns, rows)
                val groupStats = if (groupColIdx != null) {
                    BacktestStatsCalculator.calculateGroupStats(columns, rows, groupColIdx, plIndex)
                } else emptyList()

                val summaryObj = JSONObject().apply {
                    put("totalRows", rows.size)
                    put("plColumn", plIndex?.let { columns.getOrNull(it) } ?: "تعیین نشده")
                    put("advancedMetrics", JSONObject().apply {
                        put("tradeCount", advanced.tradeCount)
                        put("winCount", advanced.winCount)
                        put("lossCount", advanced.lossCount)
                        put("breakEvenCount", advanced.breakEvenCount)
                        put("winRatePercent", advanced.winRate)
                        put("netProfit", advanced.netProfit)
                        put("grossProfit", advanced.grossProfit)
                        put("grossLoss", advanced.grossLoss)
                        put("profitFactor", advanced.profitFactor ?: "Infinity")
                        put("avgWin", advanced.avgWin)
                        put("avgLoss", advanced.avgLoss)
                        put("rewardToRiskRatio", advanced.rewardToRiskRatio ?: "Infinity")
                        put("expectancy", advanced.expectancy)
                        put("bestTrade", advanced.bestTrade)
                        put("worstTrade", advanced.worstTrade)
                        put("maxConsecutiveWins", advanced.maxConsecutiveWins)
                        put("maxConsecutiveLosses", advanced.maxConsecutiveLosses)
                        put("maxDrawdownValue", advanced.maxDrawdownValue)
                        put("maxDrawdownPercent", advanced.maxDrawdownPercent)
                    })

                    if (groupColIdx != null && groupColIdx in columns.indices) {
                        put("groupByColumn", columns[groupColIdx])
                        val grpArr = JSONArray()
                        for (grp in groupStats) {
                            grpArr.put(JSONObject().apply {
                                put("value", grp.groupValue)
                                put("count", grp.tradeCount)
                                put("winRatePercent", grp.winRate)
                                put("netProfit", grp.netProfit)
                            })
                        }
                        put("groupBreakdown", grpArr)
                    }

                    // Sample rows: up to ~30 representative trades (mix of winning, losing, and random)
                    val winningRows = mutableListOf<List<String>>()
                    val losingRows = mutableListOf<List<String>>()
                    val otherRows = mutableListOf<List<String>>()

                    for (r in rows) {
                        val pl = if (plIndex != null && plIndex in r.indices) NumberParser.parseDouble(r[plIndex]) else null
                        when {
                            pl != null && pl > 0 -> if (winningRows.size < 12) winningRows.add(r)
                            pl != null && pl < 0 -> if (losingRows.size < 12) losingRows.add(r)
                            else -> if (otherRows.size < 6) otherRows.add(r)
                        }
                        if (winningRows.size >= 12 && losingRows.size >= 12 && otherRows.size >= 6) break
                    }

                    val samplesArray = JSONArray()
                    for (r in winningRows + losingRows + otherRows) {
                        val rowObj = JSONObject()
                        for ((idx, colName) in columns.withIndex()) {
                            rowObj.put(colName, r.getOrElse(idx) { "" })
                        }
                        samplesArray.put(rowObj)
                    }
                    put("sampleTrades", samplesArray)
                }

                "--- خلاصه آماری استراتژی + نمونه معاملات ---\n" + summaryObj.toString(2)
            }
        }
    }

    private fun extractTextFromResponse(jsonStr: String): String? {
        return try {
            val root = JSONObject(jsonStr)
            val candidates = root.optJSONArray("candidates") ?: return null
            if (candidates.length() == 0) return null
            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content") ?: return null
            val parts = content.optJSONArray("parts") ?: return null
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                val text = part.optString("text")
                if (text.isNotBlank()) {
                    sb.append(text)
                }
            }
            if (sb.isNotEmpty()) sb.toString() else null
        } catch (_: Exception) {
            null
        }
    }
}

package com.example.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.analytics.AdvancedStats
import com.example.analytics.ColumnSummary
import com.example.analytics.GroupItemStats
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.LossRed
import com.example.ui.theme.ProfitGreen
import com.example.util.NumberParser
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsBottomSheet(
    columns: List<String>,
    filteredRowCount: Int,
    plColumnIndex: Int?,
    selectedTab: Int,
    selectedGroupColIndex: Int?,
    chartMode: Int,
    summaryStats: List<ColumnSummary>,
    advancedStats: AdvancedStats,
    groupStats: List<GroupItemStats>,
    onSelectTab: (Int) -> Unit,
    onSetPlColumn: (Int?) -> Unit,
    onSetGroupColumn: (Int) -> Unit,
    onSetChartMode: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxHeight(0.88f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Outlined.Analytics,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "پنل تحلیل و آمار بکتست",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = "${NumberParser.formatPersian(filteredRowCount)} ردیف فیلترشده",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 4 Tabs: خلاصه | حرفه‌ای | گروه‌بندی | نمودارها
            val tabs = listOf("خلاصه", "حرفه‌ای", "گروه‌بندی", "نمودارها")
            PrimaryTabRow(
                selectedTabIndex = selectedTab,
                modifier = Modifier.fillMaxWidth(),
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { onSelectTab(index) },
                        text = {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Tab Contents
            Box(modifier = Modifier.fillMaxSize()) {
                when (selectedTab) {
                    0 -> SummaryTabContent(filteredRowCount, summaryStats)
                    1 -> AdvancedTabContent(
                        columns = columns,
                        plColumnIndex = plColumnIndex,
                        stats = advancedStats,
                        onSetPlColumn = onSetPlColumn
                    )
                    2 -> GroupTabContent(
                        columns = columns,
                        selectedGroupColIndex = selectedGroupColIndex,
                        groupStats = groupStats,
                        onSetGroupColumn = onSetGroupColumn
                    )
                    3 -> ChartsTabContent(
                        advancedStats = advancedStats,
                        groupStats = groupStats,
                        chartMode = chartMode,
                        onSetChartMode = onSetChartMode
                    )
                }
            }
        }
    }
}

@Composable
private fun SummaryTabContent(
    filteredRowCount: Int,
    summaries: List<ColumnSummary>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (summaries.isEmpty()) {
            item {
                Text(
                    text = "داده‌ای برای محاسبه آمار وجود ندارد.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            items(summaries) { summary ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = summary.columnName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (summary.isNumeric) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                            ) {
                                Text(
                                    text = if (summary.isNumeric) "عددی" else "متنی",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (summary.isNumeric) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        if (summary.isNumeric) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("مجموع", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        text = NumberParser.formatPersian(summary.sum ?: 0.0),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if ((summary.sum ?: 0.0) >= 0) ProfitGreen else LossRed
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("میانگین", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        text = NumberParser.formatPersian(summary.average ?: 0.0),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        } else if (!summary.distinctBreakdown.isNullOrEmpty()) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                summary.distinctBreakdown.forEach { item ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${item.value} (${NumberParser.formatPersian(item.count)})",
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            text = "${NumberParser.formatPersian(item.percentage, 1)}%",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        } else {
                            Text(
                                text = "ستون متنی با تنوع بالا",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdvancedTabContent(
    columns: List<String>,
    plColumnIndex: Int?,
    stats: AdvancedStats,
    onSetPlColumn: (Int?) -> Unit
) {
    var showDropdown by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // P/L Column Selector
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (plColumnIndex == null) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "کدام ستون سود/زیان هر معامله است؟",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Box {
                        OutlinedButton(
                            onClick = { showDropdown = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = plColumnIndex?.let { columns.getOrNull(it) } ?: "انتخاب ستون سود/زیان...",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }

                        DropdownMenu(
                            expanded = showDropdown,
                            onDismissRequest = { showDropdown = false }
                        ) {
                            columns.forEachIndexed { index, colName ->
                                DropdownMenuItem(
                                    text = { Text(colName) },
                                    onClick = {
                                        onSetPlColumn(index)
                                        showDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        if (plColumnIndex == null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "لطفاً ستون سود/زیان را در بالا انتخاب کنید تا معیارهای تخصصی بکتست نمایش داده شوند.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            // Metrics Grid
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Row 1: Trade Count & Net P/L
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(
                            title = "تعداد معاملات",
                            value = NumberParser.formatPersian(stats.tradeCount),
                            subtitle = "${NumberParser.formatPersian(stats.winCount)} برد | ${NumberParser.formatPersian(stats.lossCount)} باخت",
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "خالص سود/زیان",
                            value = NumberParser.formatPersian(stats.netProfit),
                            valueColor = if (stats.netProfit >= 0) ProfitGreen else LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Row 2: Win Rate & Profit Factor
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(
                            title = "درصد برد (Win Rate)",
                            value = "${NumberParser.formatPersian(stats.winRate, 1)}%",
                            valueColor = if (stats.winRate >= 50) ProfitGreen else LossRed,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "فاکتور سود (Profit Factor)",
                            value = stats.profitFactor?.let { NumberParser.formatPersian(it, 2) } ?: "∞",
                            valueColor = if ((stats.profitFactor ?: 2.0) >= 1.5) ProfitGreen else LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Row 3: Avg Win & Avg Loss
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(
                            title = "میانگین معامله برد",
                            value = NumberParser.formatPersian(stats.avgWin),
                            valueColor = ProfitGreen,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "میانگین معامله باخت",
                            value = NumberParser.formatPersian(stats.avgLoss),
                            valueColor = LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Row 4: R:R & Expectancy
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(
                            title = "ریوارد به ریسک (R:R)",
                            value = stats.rewardToRiskRatio?.let { "1:${NumberParser.formatPersian(it, 2)}" } ?: "∞",
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "امید ریاضی هر معامله",
                            value = NumberParser.formatPersian(stats.expectancy, 2),
                            valueColor = if (stats.expectancy >= 0) ProfitGreen else LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Row 5: Best & Worst Trade
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(
                            title = "بهترین معامله",
                            value = NumberParser.formatPersian(stats.bestTrade),
                            valueColor = ProfitGreen,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "بدترین معامله",
                            value = NumberParser.formatPersian(stats.worstTrade),
                            valueColor = LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Row 6: Streaks
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(
                            title = "بیشترین برد پیاپی",
                            value = "${NumberParser.formatPersian(stats.maxConsecutiveWins)} معامله",
                            valueColor = ProfitGreen,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "بیشترین باخت پیاپی",
                            value = "${NumberParser.formatPersian(stats.maxConsecutiveLosses)} معامله",
                            valueColor = LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Row 7: Max Drawdown
                    MetricCard(
                        title = "حداکثر افت سرمایه (Max Drawdown)",
                        value = "${NumberParser.formatPersian(stats.maxDrawdownValue)} واحد (${NumberParser.formatPersian(stats.maxDrawdownPercent, 1)}%)",
                        valueColor = LossRed,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier,
    valueColor: Color = MaterialTheme.colorScheme.onSurface,
    subtitle: String? = null
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = valueColor
            )
            if (subtitle != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun GroupTabContent(
    columns: List<String>,
    selectedGroupColIndex: Int?,
    groupStats: List<GroupItemStats>,
    onSetGroupColumn: (Int) -> Unit
) {
    var showDropdown by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "ستون برای گروه‌بندی (مثلاً جفت‌ارز یا جهت معامله):",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Box {
                        OutlinedButton(
                            onClick = { showDropdown = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = selectedGroupColIndex?.let { columns.getOrNull(it) } ?: "انتخاب ستون...",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }

                        DropdownMenu(
                            expanded = showDropdown,
                            onDismissRequest = { showDropdown = false }
                        ) {
                            columns.forEachIndexed { index, colName ->
                                DropdownMenuItem(
                                    text = { Text(colName) },
                                    onClick = {
                                        onSetGroupColumn(index)
                                        showDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        if (groupStats.isEmpty()) {
            item {
                Text(
                    text = "اطلاعاتی برای گروه‌بندی وجود ندارد.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            item {
                // Compact Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("گروه / مقدار", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.5f))
                    Text("تعداد", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                    Text("وین‌ریت", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                    Text("خالص سود", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f), textAlign = TextAlign.End)
                }
            }

            items(groupStats) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = item.groupValue,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1.5f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = NumberParser.formatPersian(item.tradeCount),
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "${NumberParser.formatPersian(item.winRate, 0)}%",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (item.winRate >= 50) ProfitGreen else LossRed,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = NumberParser.formatPersian(item.netProfit),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (item.netProfit >= 0) ProfitGreen else LossRed,
                            modifier = Modifier.weight(1.2f),
                            textAlign = TextAlign.End
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ChartsTabContent(
    advancedStats: AdvancedStats,
    groupStats: List<GroupItemStats>,
    chartMode: Int,
    onSetChartMode: (Int) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Equity Curve Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "نمودار منحنی رشد سرمایه (Equity Curve)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "مجموع تجمعی سود/زیان معاملات",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (advancedStats.netProfit >= 0) ProfitGreen.copy(alpha = 0.15f) else LossRed.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "خالص: ${NumberParser.formatPersian(advancedStats.netProfit)}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (advancedStats.netProfit >= 0) ProfitGreen else LossRed,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Compose Canvas Equity Curve
                    EquityCurveChart(
                        points = advancedStats.equityCurve,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                    )
                }
            }
        }

        // Group Bar Chart Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "نمودار مقایسه‌ای گروه‌ها",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        // Toggle Net P/L vs Win Rate
                        Row(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                                .padding(2.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (chartMode == 0) MaterialTheme.colorScheme.primary else Color.Transparent,
                                modifier = Modifier.clickable { onSetChartMode(0) }
                            ) {
                                Text(
                                    text = "سود/زیان",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (chartMode == 0) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (chartMode == 1) MaterialTheme.colorScheme.primary else Color.Transparent,
                                modifier = Modifier.clickable { onSetChartMode(1) }
                            ) {
                                Text(
                                    text = "وین‌ریت",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (chartMode == 1) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (groupStats.isEmpty()) {
                        Text(
                            text = "داده‌ای برای نمایش نمودار میله‌ای موجود نیست.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        GroupBarChart(
                            stats = groupStats,
                            isProfitMode = chartMode == 0,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EquityCurveChart(
    points: List<com.example.analytics.EquityPoint>,
    modifier: Modifier = Modifier
) {
    val axisColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
    val finalProfit = points.lastOrNull()?.cumulativePl ?: 0.0
    val lineColor = if (finalProfit >= 0) ProfitGreen else LossRed

    if (points.size <= 1) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text(
                text = "معاملات کافی برای ترسیم منحنی اکوئیتی وجود ندارد.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val padding = 24f

        val minPl = points.minOf { it.cumulativePl }.coerceAtMost(0.0)
        val maxPl = points.maxOf { it.cumulativePl }.coerceAtLeast(0.0)
        val range = (maxPl - minPl).coerceAtLeast(1.0)

        val totalPoints = points.size

        // Zero reference line
        val zeroY = h - padding - (((0.0 - minPl) / range) * (h - 2 * padding)).toFloat()
        drawLine(
            color = axisColor,
            start = Offset(padding, zeroY),
            end = Offset(w - padding, zeroY),
            strokeWidth = 2f
        )

        // Path for Equity Curve
        val path = Path()
        for ((idx, pt) in points.withIndex()) {
            val x = padding + (idx.toFloat() / (totalPoints - 1)) * (w - 2 * padding)
            val y = h - padding - (((pt.cumulativePl - minPl) / range) * (h - 2 * padding)).toFloat()

            if (idx == 0) {
                path.moveTo(x, y)
            } else {
                path.lineTo(x, y)
            }
        }

        drawPath(
            path = path,
            color = lineColor,
            style = Stroke(width = 4f, cap = StrokeCap.Round)
        )

        // Draw circles at start and end
        val lastPt = points.last()
        val lastX = w - padding
        val lastY = h - padding - (((lastPt.cumulativePl - minPl) / range) * (h - 2 * padding)).toFloat()
        drawCircle(
            color = lineColor,
            radius = 6f,
            center = Offset(lastX, lastY)
        )
    }
}

@Composable
private fun GroupBarChart(
    stats: List<GroupItemStats>,
    isProfitMode: Boolean,
    modifier: Modifier = Modifier
) {
    val maxAbsValue = if (isProfitMode) {
        stats.maxOfOrNull { abs(it.netProfit) }?.coerceAtLeast(1.0) ?: 1.0
    } else 100.0

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        stats.forEach { item ->
            val value = if (isProfitMode) item.netProfit else item.winRate
            val ratio = (abs(value) / maxAbsValue).toFloat().coerceIn(0.05f, 1f)
            val barColor = if (value >= 0) ProfitGreen else LossRed

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = item.groupValue,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.width(70.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(20.dp)
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(4.dp))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(ratio)
                            .background(barColor, RoundedCornerShape(4.dp))
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = if (isProfitMode) NumberParser.formatPersian(value) else "${NumberParser.formatPersian(value, 0)}%",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = barColor,
                    modifier = Modifier.width(60.dp),
                    textAlign = TextAlign.End
                )
            }
        }
    }
}

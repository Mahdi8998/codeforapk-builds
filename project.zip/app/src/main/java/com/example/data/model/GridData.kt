package com.example.data.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class GridData(
    val columns: List<String> = emptyList(),
    val rows: List<List<String>> = emptyList(),
    val filterStates: Map<String, ColumnFilterState> = emptyMap(),
    val plColumnIndex: Int? = null
)

@JsonClass(generateAdapter = true)
data class ColumnFilterState(
    val columnIndex: Int,
    val selectedValues: List<String>? = null, // null means all selected
    val sortAscending: Boolean? = null // null: none, true: asc, false: desc
)

enum class DataMode {
    COMPLETE, // Send all rows (capped at 500)
    SUMMARY   // Send computed stats + sample rows
}

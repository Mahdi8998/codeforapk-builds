import { NextResponse } from "next/server";
import { buildBody, describeFailure, geminiUrl, getApiKey, isNetworkError, setApiKey } from "@/lib/server/gemini";

export const dynamic = "force-dynamic";

/** Tiny test request. Optionally tests (and saves) a key passed in the body. */
export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { apiKey?: string };
  let key = body.apiKey?.trim() || "";
  if (key) await setApiKey(key);
  else key = (await getApiKey()) ?? "";
  if (!key) return NextResponse.json({ ok: false, message: "کلید API وارد نشده است" }, { status: 400 });
  try {
    const res = await fetch(geminiUrl(false), {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify(buildBody(null, [{ role: "user", text: "Reply with the single word: OK" }])),
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) {
      const f = await describeFailure(res);
      return NextResponse.json({ ok: false, message: f.message }, { status: f.status === 429 ? 429 : 400 });
    }
    return NextResponse.json({ ok: true, message: "اتصال برقرار است ✅" });
  } catch (e) {
    const message = isNetworkError(e) ? "عدم اتصال به اینترنت" : "خطایی رخ داد. لطفاً دوباره تلاش کنید.";
    return NextResponse.json({ ok: false, message }, { status: 502 });
  }
}

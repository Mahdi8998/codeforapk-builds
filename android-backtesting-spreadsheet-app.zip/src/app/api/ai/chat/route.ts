import { NextResponse } from "next/server";
import { SYSTEM_PROMPT } from "@/lib/ai";
import { buildBody, describeFailure, geminiUrl, getApiKey, isNetworkError, type GeminiMessage } from "@/lib/server/gemini";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

interface GeminiChunk {
  candidates?: { content?: { parts?: { text?: string }[] } }[];
}

/**
 * Streams Gemini's answer as plain text (text/plain; charset=utf-8).
 * Errors before the stream starts are returned as JSON with a Persian message.
 */
export async function POST(req: Request) {
  const body = (await req.json().catch(() => null)) as { messages?: GeminiMessage[] } | null;
  const messages = body?.messages?.filter((m) => m && (m.role === "user" || m.role === "model") && typeof m.text === "string") ?? [];
  if (messages.length === 0) return NextResponse.json({ error: "پیامی ارسال نشده است" }, { status: 400 });
  const key = await getApiKey();
  if (!key) return NextResponse.json({ error: "کلید API تنظیم نشده است", code: "no_key" }, { status: 400 });

  let upstream: Response;
  try {
    upstream = await fetch(geminiUrl(true), {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify(buildBody(SYSTEM_PROMPT, messages)),
      signal: AbortSignal.timeout(110000),
    });
  } catch (e) {
    const message = isNetworkError(e) ? "عدم اتصال به اینترنت" : "خطایی رخ داد. لطفاً دوباره تلاش کنید.";
    return NextResponse.json({ error: message }, { status: 502 });
  }
  if (!upstream.ok || !upstream.body) {
    const f = await describeFailure(upstream);
    return NextResponse.json({ error: f.message }, { status: f.status >= 400 && f.status < 600 ? f.status : 502 });
  }

  const reader = upstream.body.getReader();
  const decoder = new TextDecoder();
  const encoder = new TextEncoder();
  let buffer = "";
  const stream = new ReadableStream<Uint8Array>({
    async pull(controller) {
      const { done, value } = await reader.read();
      if (done) {
        controller.close();
        return;
      }
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("data:")) continue;
        const json = trimmed.slice(5).trim();
        if (!json || json === "[DONE]") continue;
        try {
          const chunk = JSON.parse(json) as GeminiChunk;
          const text = chunk.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
          if (text) controller.enqueue(encoder.encode(text));
        } catch {
          /* partial line – ignore */
        }
      }
    },
    cancel() {
      reader.cancel().catch(() => undefined);
    },
  });
  return new Response(stream, {
    headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-cache", "X-Accel-Buffering": "no" },
  });
}

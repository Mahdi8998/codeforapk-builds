import { NextResponse } from "next/server";
import { getApiKey, setApiKey } from "@/lib/server/gemini";

export const dynamic = "force-dynamic";

export async function GET() {
  const key = await getApiKey();
  return NextResponse.json({ hasKey: !!key, keyMasked: key ? `${key.slice(0, 4)}••••••••${key.slice(-4)}` : "" });
}

export async function PUT(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { apiKey?: string };
  if (typeof body.apiKey !== "string") return NextResponse.json({ error: "درخواست نامعتبر" }, { status: 400 });
  await setApiKey(body.apiKey.trim());
  return NextResponse.json({ ok: true, hasKey: body.apiKey.trim().length > 0 });
}

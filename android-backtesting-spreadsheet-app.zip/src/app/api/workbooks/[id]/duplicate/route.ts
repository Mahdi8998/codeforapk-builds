import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { workbooks } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const id = Number((await ctx.params).id);
  if (!Number.isInteger(id)) return NextResponse.json({ error: "شناسه نامعتبر" }, { status: 400 });
  const [w] = await db.select().from(workbooks).where(eq(workbooks.id, id));
  if (!w) return NextResponse.json({ error: "جدول پیدا نشد" }, { status: 404 });
  const [copy] = await db
    .insert(workbooks)
    .values({
      name: `${w.name} (کپی)`,
      grid: w.grid,
      filterState: w.filterState,
      plColumnIndex: w.plColumnIndex,
      initialBalance: w.initialBalance,
      riskPercent: w.riskPercent,
      rrCap: w.rrCap,
    })
    .returning();
  return NextResponse.json({ id: copy.id, name: copy.name });
}

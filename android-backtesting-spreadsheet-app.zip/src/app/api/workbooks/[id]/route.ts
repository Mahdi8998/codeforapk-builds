import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { workbooks } from "@/db/schema";
import type { FilterState, Grid, WorkbookFull } from "@/lib/types";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

function toFull(w: typeof workbooks.$inferSelect): WorkbookFull {
  return {
    id: w.id,
    name: w.name,
    createdAt: w.createdAt.toISOString(),
    updatedAt: w.updatedAt.toISOString(),
    grid: w.grid,
    filterState: {
      columns: w.filterState?.columns ?? {},
      search: w.filterState?.search ?? "",
      sort: w.filterState?.sort ?? null,
    },
    plColumnIndex: w.plColumnIndex,
    initialBalance: w.initialBalance,
    riskPercent: w.riskPercent,
    rrCap: w.rrCap,
  };
}

export async function GET(_req: Request, ctx: Ctx) {
  const id = Number((await ctx.params).id);
  if (!Number.isInteger(id)) return NextResponse.json({ error: "شناسه نامعتبر" }, { status: 400 });
  const [w] = await db.select().from(workbooks).where(eq(workbooks.id, id));
  if (!w) return NextResponse.json({ error: "جدول پیدا نشد" }, { status: 404 });
  return NextResponse.json(toFull(w));
}

interface Patch {
  name?: string;
  grid?: Grid;
  filterState?: FilterState;
  plColumnIndex?: number | null;
  initialBalance?: number;
  riskPercent?: number;
  rrCap?: number | null;
}

export async function PUT(req: Request, ctx: Ctx) {
  const id = Number((await ctx.params).id);
  if (!Number.isInteger(id)) return NextResponse.json({ error: "شناسه نامعتبر" }, { status: 400 });
  const body = (await req.json().catch(() => null)) as Patch | null;
  if (!body) return NextResponse.json({ error: "درخواست نامعتبر" }, { status: 400 });
  const patch: Partial<typeof workbooks.$inferInsert> = { updatedAt: new Date() };
  if (typeof body.name === "string" && body.name.trim()) patch.name = body.name.trim();
  if (body.grid && Array.isArray(body.grid.headers) && Array.isArray(body.grid.rows)) patch.grid = body.grid;
  if (body.filterState && typeof body.filterState === "object") patch.filterState = body.filterState;
  if (body.plColumnIndex !== undefined) patch.plColumnIndex = body.plColumnIndex;
  if (typeof body.initialBalance === "number" && body.initialBalance > 0) patch.initialBalance = body.initialBalance;
  if (typeof body.riskPercent === "number" && body.riskPercent > 0 && body.riskPercent <= 100) patch.riskPercent = body.riskPercent;
  if (body.rrCap !== undefined) patch.rrCap = body.rrCap === null ? null : body.rrCap > 0 ? body.rrCap : undefined;
  const [w] = await db.update(workbooks).set(patch).where(eq(workbooks.id, id)).returning();
  if (!w) return NextResponse.json({ error: "جدول پیدا نشد" }, { status: 404 });
  return NextResponse.json({ ok: true, updatedAt: w.updatedAt.toISOString() });
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const id = Number((await ctx.params).id);
  if (!Number.isInteger(id)) return NextResponse.json({ error: "شناسه نامعتبر" }, { status: 400 });
  await db.delete(workbooks).where(eq(workbooks.id, id));
  return NextResponse.json({ ok: true });
}

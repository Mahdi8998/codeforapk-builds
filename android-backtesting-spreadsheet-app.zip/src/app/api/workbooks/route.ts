import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { workbooks } from "@/db/schema";
import { buildEmptyGrid, buildSampleGrid } from "@/lib/sample";
import { emptyFilterState, type Grid, type WorkbookMeta } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET() {
  const list = await db.select().from(workbooks).orderBy(desc(workbooks.updatedAt));
  const metas: WorkbookMeta[] = list.map((w) => ({
    id: w.id,
    name: w.name,
    createdAt: w.createdAt.toISOString(),
    updatedAt: w.updatedAt.toISOString(),
    rowCount: w.grid.rows.length,
    colCount: w.grid.headers.length,
  }));
  return NextResponse.json(metas);
}

function sanitizeGrid(g: unknown): Grid | null {
  if (!g || typeof g !== "object") return null;
  const obj = g as { headers?: unknown; rows?: unknown };
  if (!Array.isArray(obj.headers) || !Array.isArray(obj.rows)) return null;
  const headers = obj.headers.map((h) => String(h ?? ""));
  const rows = obj.rows.map((r) => (Array.isArray(r) ? headers.map((_, c) => String(r[c] ?? "")) : headers.map(() => "")));
  return { headers, rows };
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { kind?: string; name?: string; grid?: unknown };
  const kind = body.kind ?? "empty";
  let grid: Grid;
  let name = body.name?.trim() || "";
  if (kind === "sample") {
    grid = buildSampleGrid();
    name = name || "جدول نمونه";
  } else if (kind === "import") {
    const g = sanitizeGrid(body.grid);
    if (!g) return NextResponse.json({ error: "فایل نامعتبر است" }, { status: 400 });
    grid = g;
    name = name || "جدول وارد شده";
  } else {
    grid = buildEmptyGrid();
    name = name || "جدول جدید";
  }
  const [created] = await db
    .insert(workbooks)
    .values({ name, grid, filterState: emptyFilterState(), initialBalance: 500, riskPercent: 2, rrCap: null, plColumnIndex: null })
    .returning();
  return NextResponse.json({ id: created.id, name: created.name });
}

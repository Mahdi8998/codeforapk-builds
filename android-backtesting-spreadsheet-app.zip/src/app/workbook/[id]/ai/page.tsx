import { notFound } from "next/navigation";
import AiClient from "@/components/ai/AiClient";

export const dynamic = "force-dynamic";

export default async function AiPage({ params }: { params: Promise<{ id: string }> }) {
  const id = Number((await params).id);
  if (!Number.isInteger(id)) notFound();
  return <AiClient id={id} />;
}

import { notFound } from "next/navigation";
import Editor from "@/components/editor/Editor";

export const dynamic = "force-dynamic";

export default async function WorkbookPage({ params }: { params: Promise<{ id: string }> }) {
  const id = Number((await params).id);
  if (!Number.isInteger(id)) notFound();
  return <Editor id={id} />;
}

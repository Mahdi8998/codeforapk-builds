import {
  pgTable,
  serial,
  text,
  timestamp,
  jsonb,
  integer,
  doublePrecision,
} from "drizzle-orm/pg-core";
import type { Grid, FilterState } from "@/lib/types";

/** One row per workbook (the "Room entity" of the original spec). */
export const workbooks = pgTable("workbooks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  grid: jsonb("grid").$type<Grid>().notNull(),
  filterState: jsonb("filter_state").$type<FilterState>().notNull().default({ columns: {}, search: "" }),
  plColumnIndex: integer("pl_column_index"),
  initialBalance: doublePrecision("initial_balance").notNull().default(500),
  riskPercent: doublePrecision("risk_percent").notNull().default(2),
  rrCap: doublePrecision("rr_cap"),
});

/** Key/value settings stored outside the workbook table (Gemini API key). */
export const appSettings = pgTable("app_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
});

export type WorkbookRow = typeof workbooks.$inferSelect;

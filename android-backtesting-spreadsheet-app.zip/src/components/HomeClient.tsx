"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import type { WorkbookMeta } from "@/lib/types";
import { gridFromXlsx } from "@/lib/xlsx";
import { Confirm, Icons, MenuList, PromptDialog, Sheet, Spinner, ToastHost, formatDate, useToast } from "./ui";

export default function HomeClient() {
  return (
    <ToastHost>
      <Home />
    </ToastHost>
  );
}

function Home() {
  const router = useRouter();
  const toast = useToast();
  const [list, setList] = useState<WorkbookMeta[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [menuFor, setMenuFor] = useState<WorkbookMeta | null>(null);
  const [renaming, setRenaming] = useState<WorkbookMeta | null>(null);
  const [deleting, setDeleting] = useState<WorkbookMeta | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    const r = await fetch("/api/workbooks", { cache: "no-store" });
    setList((await r.json()) as WorkbookMeta[]);
  }, []);
  useEffect(() => {
    load();
  }, [load]);

  const create = async (kind: "empty" | "sample") => {
    setBusy(true);
    try {
      const r = await fetch("/api/workbooks", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ kind }) });
      const j = (await r.json()) as { id: number };
      router.push(`/workbook/${j.id}`);
    } finally {
      setBusy(false);
    }
  };

  const onFile = async (file: File) => {
    setBusy(true);
    try {
      const buf = await file.arrayBuffer();
      const grid = gridFromXlsx(buf);
      const name = file.name.replace(/\.xlsx$/i, "");
      const r = await fetch("/api/workbooks", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ kind: "import", name, grid }) });
      if (!r.ok) throw new Error((await r.json()).error ?? "خطا");
      const j = (await r.json()) as { id: number };
      toast(`${grid.rows.length} ردیف و ${grid.headers.length} ستون وارد شد`);
      router.push(`/workbook/${j.id}`);
    } catch (e) {
      toast(`فایل اکسل قابل خواندن نیست: ${e instanceof Error ? e.message : ""}`, "err");
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const rename = async (wb: WorkbookMeta, name: string) => {
    await fetch(`/api/workbooks/${wb.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name }) });
    setRenaming(null);
    toast("نام جدول تغییر کرد");
    load();
  };
  const duplicate = async (wb: WorkbookMeta) => {
    setMenuFor(null);
    await fetch(`/api/workbooks/${wb.id}/duplicate`, { method: "POST" });
    toast("کپی ساخته شد");
    load();
  };
  const remove = async (wb: WorkbookMeta) => {
    await fetch(`/api/workbooks/${wb.id}`, { method: "DELETE" });
    setDeleting(null);
    toast("جدول حذف شد");
    load();
  };

  return (
    <div className="mx-auto flex min-h-screen max-w-3xl flex-col">
      <header className="sticky top-0 z-10 flex items-center justify-between border-b border-line bg-surface-2/90 px-4 py-3 backdrop-blur">
        <div className="flex items-center gap-2">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-primary text-primary-fg">{Icons.table()}</span>
          <div>
            <h1 className="text-base font-bold leading-tight">جدول بک‌تست</h1>
            <p className="text-[11px] text-muted">Backtest Table</p>
          </div>
        </div>
        <Link href="/settings" className="icon-btn" aria-label="تنظیمات">
          {Icons.settings()}
        </Link>
      </header>

      <main className="flex-1 px-4 py-4">
        <div className="grid grid-cols-3 gap-2">
          <button className="card flex flex-col items-center gap-2 py-4 hover:border-primary" onClick={() => create("empty")} disabled={busy}>
            <span className="text-primary">{Icons.plus({ className: "h-6 w-6" })}</span>
            <span className="text-xs font-medium">جدول جدید</span>
          </button>
          <button className="card flex flex-col items-center gap-2 py-4 hover:border-primary" onClick={() => fileRef.current?.click()} disabled={busy}>
            <span className="text-primary">{Icons.upload({ className: "h-6 w-6" })}</span>
            <span className="text-xs font-medium">وارد کردن از اکسل</span>
          </button>
          <button className="card flex flex-col items-center gap-2 py-4 hover:border-primary" onClick={() => create("sample")} disabled={busy}>
            <span className="text-primary">{Icons.sparkle({ className: "h-6 w-6" })}</span>
            <span className="text-xs font-medium">جدول نمونه</span>
          </button>
        </div>
        <input ref={fileRef} type="file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" className="hidden" onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} />

        <h2 className="mt-6 mb-2 text-sm font-bold text-muted">جدول‌های ذخیره‌شده</h2>
        {list === null ? (
          <div className="flex justify-center py-10 text-muted">
            <Spinner />
          </div>
        ) : list.length === 0 ? (
          <div className="card flex flex-col items-center gap-2 py-10 text-center">
            <span className="text-muted">{Icons.table({ className: "h-10 w-10" })}</span>
            <p className="font-medium">هنوز جدولی ندارید</p>
            <p className="text-xs text-muted leading-6">یک جدول جدید بسازید، فایل اکسل خود را وارد کنید یا با «جدول نمونه» شروع کنید.</p>
          </div>
        ) : (
          <ul className="space-y-2">
            {list.map((wb) => (
              <li key={wb.id} className="card flex items-center gap-3 p-3">
                <Link href={`/workbook/${wb.id}`} className="flex min-w-0 flex-1 flex-col gap-1">
                  <span className="truncate font-bold">{wb.name}</span>
                  <span className="text-xs text-muted num">
                    {wb.rowCount.toLocaleString("fa-IR")} ردیف • {wb.colCount.toLocaleString("fa-IR")} ستون • {formatDate(wb.updatedAt)}
                  </span>
                </Link>
                <button className="icon-btn" onClick={() => setMenuFor(wb)} aria-label="گزینه‌ها">
                  {Icons.more()}
                </button>
              </li>
            ))}
          </ul>
        )}
      </main>

      <Sheet open={!!menuFor} onClose={() => setMenuFor(null)} title={menuFor?.name}>
        {menuFor && (
          <MenuList
            items={[
              { label: "باز کردن", icon: Icons.table(), onClick: () => router.push(`/workbook/${menuFor.id}`) },
              { label: "تغییر نام", icon: Icons.edit(), onClick: () => { setRenaming(menuFor); setMenuFor(null); } },
              { label: "کپی جدول", icon: Icons.dup(), onClick: () => duplicate(menuFor) },
              { label: "حذف", icon: Icons.trash(), danger: true, onClick: () => { setDeleting(menuFor); setMenuFor(null); } },
            ]}
          />
        )}
      </Sheet>
      <PromptDialog open={!!renaming} title="تغییر نام جدول" label="نام جدید" initial={renaming?.name ?? ""} onCancel={() => setRenaming(null)} onSubmit={(v) => renaming && rename(renaming, v)} />
      <Confirm open={!!deleting} title="حذف جدول" message={`آیا از حذف «${deleting?.name ?? ""}» مطمئن هستید؟ این کار قابل بازگشت نیست.`} confirmLabel="حذف" danger onCancel={() => setDeleting(null)} onConfirm={() => deleting && remove(deleting)} />
    </div>
  );
}

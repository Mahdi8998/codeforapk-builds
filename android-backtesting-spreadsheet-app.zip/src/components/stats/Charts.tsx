"use client";

import { useId } from "react";
import { formatNumber } from "@/lib/numbers";
import type { Point } from "@/lib/stats-engine";

const W = 360;
const H = 200;
const PAD = { l: 44, r: 12, t: 12, b: 24 };

function niceTicks(min: number, max: number, n = 4): number[] {
  if (max === min) return [min];
  const span = max - min;
  const raw = span / n;
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const norm = raw / mag;
  const step = (norm < 1.5 ? 1 : norm < 3 ? 2 : norm < 7 ? 5 : 10) * mag;
  const out: number[] = [];
  for (let v = Math.ceil(min / step) * step; v <= max + 1e-9; v += step) out.push(v);
  return out;
}

export function LineChart({ points, baseline, positive, label, unitLabel }: { points: Point[]; baseline: number; positive: boolean; label: string; unitLabel: string }) {
  const id = useId();
  if (points.length < 2) {
    return <Empty text={points.length === 1 ? "برای رسم نمودار حداقل دو معامله لازم است" : "داده‌ای برای نمودار وجود ندارد"} />;
  }
  const ys = points.map((p) => p.y);
  const minY = Math.min(...ys, baseline);
  const maxY = Math.max(...ys, baseline);
  const padY = (maxY - minY || 1) * 0.08;
  const y0 = minY - padY;
  const y1 = maxY + padY;
  const minX = points[0].x;
  const maxX = points[points.length - 1].x;
  const sx = (x: number) => PAD.l + ((x - minX) / (maxX - minX || 1)) * (W - PAD.l - PAD.r);
  const sy = (y: number) => PAD.t + (1 - (y - y0) / (y1 - y0)) * (H - PAD.t - PAD.b);
  const d = points.map((p, i) => `${i === 0 ? "M" : "L"}${sx(p.x).toFixed(1)},${sy(p.y).toFixed(1)}`).join(" ");
  const area = `${d} L${sx(maxX).toFixed(1)},${sy(baseline).toFixed(1)} L${sx(minX).toFixed(1)},${sy(baseline).toFixed(1)} Z`;
  const color = positive ? "var(--win)" : "var(--loss)";
  const ticks = niceTicks(y0, y1);
  const xt = niceTicks(minX, maxX, 5).filter((v) => Number.isInteger(v));
  return (
    <div>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ direction: "ltr" }} role="img" aria-label={label}>
        <defs>
          <linearGradient id={id} x1="0" x2="0" y1="0" y2="1">
            <stop offset="0" stopColor={color} stopOpacity="0.35" />
            <stop offset="1" stopColor={color} stopOpacity="0.02" />
          </linearGradient>
        </defs>
        {ticks.map((t) => (
          <g key={t}>
            <line x1={PAD.l} x2={W - PAD.r} y1={sy(t)} y2={sy(t)} stroke="var(--line)" strokeDasharray="3 3" />
            <text x={PAD.l - 4} y={sy(t) + 3} fontSize="9" textAnchor="end" fill="var(--muted)">{formatNumber(t, 1)}</text>
          </g>
        ))}
        {xt.map((t) => (
          <text key={t} x={sx(t)} y={H - 6} fontSize="9" textAnchor="middle" fill="var(--muted)">{t}</text>
        ))}
        <line x1={PAD.l} x2={W - PAD.r} y1={sy(baseline)} y2={sy(baseline)} stroke="var(--muted)" strokeWidth="1" />
        <path d={area} fill={`url(#${id})`} />
        <path d={d} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" />
        <circle cx={sx(maxX)} cy={sy(points[points.length - 1].y)} r="3.5" fill={color} />
      </svg>
      <div className="mt-1 flex items-center justify-between text-xs">
        <span className="text-muted">{label}</span>
        <span className="font-bold num" style={{ color }}>{unitLabel}</span>
      </div>
    </div>
  );
}

export function BarChart({ items, unit, valueFormatter }: { items: { label: string; value: number }[]; unit: string; valueFormatter: (n: number) => string }) {
  if (items.length === 0) return <Empty text="گروهی برای نمایش وجود ندارد" />;
  const max = Math.max(...items.map((i) => Math.abs(i.value)), 1e-9);
  return (
    <div className="space-y-2">
      {items.map((it) => {
        const pct = (Math.abs(it.value) / max) * 100;
        const neg = it.value < 0;
        return (
          <div key={it.label} className="flex items-center gap-2 text-xs">
            <span className="w-24 shrink-0 truncate font-medium" dir="auto" title={it.label}>{it.label}</span>
            <div className="relative h-6 flex-1 overflow-hidden rounded-md bg-surface-3">
              <div className="absolute inset-y-0 rounded-md" style={{ width: `${pct}%`, insetInlineStart: 0, background: neg ? "var(--loss)" : "var(--win)", opacity: 0.85 }} />
            </div>
            <span className="w-24 shrink-0 text-end num font-bold" style={{ color: neg ? "var(--loss)" : "var(--win)" }}>
              {valueFormatter(it.value)} {unit}
            </span>
          </div>
        );
      })}
    </div>
  );
}

function Empty({ text }: { text: string }) {
  return <div className="grid h-40 place-items-center rounded-xl border border-dashed border-line text-xs text-muted">{text}</div>;
}

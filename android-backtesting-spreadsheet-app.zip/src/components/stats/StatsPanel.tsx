"use client";

import { useState, type ReactNode } from "react";
import { formatMoney, formatNumber, formatPercent, formatSigned } from "@/lib/numbers";
import { validateBalance, validateRisk, validateRrCap, type StatsResult } from "@/lib/stats-engine";
import { Icons, Sheet } from "../ui";
import { BarChart, LineChart } from "./Charts";

type Tab = "summary" | "pro" | "groups" | "charts" | "dollar";
const TABS: { id: Tab; label: string }[] = [
  { id: "summary", label: "خلاصه" },
  { id: "pro", label: "حرفه‌ای" },
  { id: "groups", label: "گروه‌بندی" },
  { id: "charts", label: "نمودارها" },
  { id: "dollar", label: "دلاری" },
];

interface Props {
  result: StatsResult;
  headers: string[];
  plColumnIndex: number | null;
  onSetPlColumn: (c: number | null) => void;
  onSetGroupColumn: (c: number) => void;
  initialBalance: number;
  riskPercent: number;
  rrCap: number | null;
  onSetMoney: (balance: number, risk: number) => void;
  onSetRrCap: (cap: number | null) => void;
  onClose: () => void;
}

export default function StatsPanel(props: Props) {
  const { result, onClose } = props;
  const [tab, setTab] = useState<Tab>("summary");
  return (
    <div className="flex h-full flex-col bg-surface-2">
      <div className="flex items-center justify-between border-b border-line px-3 py-2">
        <div>
          <h3 className="text-sm font-bold">آمار و تحلیل</h3>
          <p className="text-[11px] text-muted num">
            {result.filtered ? `محاسبه روی ${result.rowCount.toLocaleString("fa-IR")} ردیف فیلترشده از ${result.totalRows.toLocaleString("fa-IR")} ردیف` : `محاسبه روی همه ${result.totalRows.toLocaleString("fa-IR")} ردیف`}
          </p>
        </div>
        <button className="icon-btn" onClick={onClose} aria-label="بستن آمار">
          {Icons.close()}
        </button>
      </div>
      <div className="flex gap-1 overflow-x-auto border-b border-line px-2 py-1.5">
        {TABS.map((t) => (
          <button key={t.id} className={`chip whitespace-nowrap ${tab === t.id ? "chip-active" : ""}`} onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
      </div>
      <div className="flex-1 overflow-y-auto p-3">
        {tab === "summary" && <SummaryTab result={result} />}
        {tab === "pro" && <ProTab {...props} />}
        {tab === "groups" && <GroupsTab {...props} />}
        {tab === "charts" && <ChartsTab {...props} />}
        {tab === "dollar" && <DollarTab {...props} />}
      </div>
    </div>
  );
}

/* ---------------------------------- Shared ---------------------------------- */

function Metric({ label, value, tone, hint }: { label: string; value: ReactNode; tone?: "win" | "loss" | null; hint?: string }) {
  const color = tone === "win" ? "text-win" : tone === "loss" ? "text-loss" : "";
  return (
    <div className="rounded-xl border border-line bg-surface p-3">
      <div className="text-[11px] text-muted">{label}</div>
      <div className={`mt-1 text-base font-bold num ${color}`}>{value}</div>
      {hint && <div className="mt-0.5 text-[10px] text-muted">{hint}</div>}
    </div>
  );
}

const toneOf = (n: number | null | undefined) => (n == null ? null : n > 0 ? "win" : n < 0 ? "loss" : null);

function EmptyTrades({ result }: { result: StatsResult }) {
  return (
    <div className="rounded-xl border border-dashed border-line p-6 text-center text-sm text-muted leading-7">
      هیچ معامله‌ای با نتیجه در ردیف‌های فعلی نیست.
      <br />
      <span className="text-xs">ردیف‌های بدون نتیجه: {result.excludedCount.toLocaleString("fa-IR")} — فیلترها را تغییر دهید یا نتیجه معاملات را وارد کنید.</span>
    </div>
  );
}

function ResultColumnSelector({ headers, plColumnIndex, onSetPlColumn }: Pick<Props, "headers" | "plColumnIndex" | "onSetPlColumn">) {
  return (
    <div className="card mb-3">
      <label className="text-sm font-bold">کدام ستون نتیجه معاملات است؟</label>
      <select className="input mt-2" value={plColumnIndex ?? ""} onChange={(e) => onSetPlColumn(e.target.value === "" ? null : Number(e.target.value))}>
        <option value="">— انتخاب ستون —</option>
        {headers.map((h, i) => (
          <option key={i} value={i}>
            {h}
          </option>
        ))}
      </select>
      <p className="mt-2 text-[11px] leading-6 text-muted">در این ستون: علامت - یعنی استاپ خورده؛ عدد یعنی شماره تارگت (مثلاً ۳ یعنی تارگت ۳ خورده)؛ خانه خالی یعنی بدون نتیجه و از محاسبات حذف می‌شود.</p>
    </div>
  );
}

function ResultColumnChip({ headers, plColumnIndex, onSetPlColumn }: Pick<Props, "headers" | "plColumnIndex" | "onSetPlColumn">) {
  const [open, setOpen] = useState(false);
  if (plColumnIndex === null) return <ResultColumnSelector headers={headers} plColumnIndex={plColumnIndex} onSetPlColumn={onSetPlColumn} />;
  return (
    <div className="mb-3">
      <button className="chip" onClick={() => setOpen((o) => !o)}>
        ستون نتیجه: <b>{headers[plColumnIndex]}</b> <span className="text-muted">(تغییر)</span>
      </button>
      {open && (
        <div className="mt-2">
          <ResultColumnSelector headers={headers} plColumnIndex={plColumnIndex} onSetPlColumn={(c) => { onSetPlColumn(c); setOpen(false); }} />
        </div>
      )}
    </div>
  );
}

/* ---------------------------------- Summary ---------------------------------- */

function SummaryTab({ result }: { result: StatsResult }) {
  return (
    <div className="space-y-3">
      <Metric label="تعداد ردیف‌ها (پس از فیلتر)" value={result.rowCount.toLocaleString("fa-IR")} />
      {result.summary.numeric.length > 0 && (
        <div>
          <h4 className="mb-1 text-xs font-bold text-muted">ستون‌های عددی</h4>
          <div className="grid grid-cols-2 gap-2">
            {result.summary.numeric.map((n) => (
              <div key={n.col} className="rounded-xl border border-line bg-surface p-3">
                <div className="truncate text-[11px] text-muted" title={n.name}>{n.name}</div>
                <div className="mt-1 text-xs num">جمع: <b>{formatNumber(n.sum, 4)}</b></div>
                <div className="text-xs num">میانگین: <b>{formatNumber(n.avg, 4)}</b></div>
              </div>
            ))}
          </div>
        </div>
      )}
      {result.summary.categorical.length > 0 && (
        <div>
          <h4 className="mb-1 text-xs font-bold text-muted">توزیع مقادیر</h4>
          <div className="space-y-2">
            {result.summary.categorical.map((c) => (
              <div key={c.col} className="rounded-xl border border-line bg-surface p-3">
                <div className="mb-1 text-xs font-bold">{c.name}</div>
                <div className="flex flex-wrap gap-1.5">
                  {c.items.map((it) => (
                    <span key={it.value} className="chip num" dir="auto">
                      {it.value} <b>{formatPercent(it.pct, 0)}</b> <span className="text-muted">({it.count.toLocaleString("fa-IR")})</span>
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      {result.summary.numeric.length === 0 && result.summary.categorical.length === 0 && <p className="text-center text-xs text-muted">ستون عددی یا دسته‌بندی‌شده‌ای پیدا نشد.</p>}
    </div>
  );
}

/* ---------------------------------- Pro (R) ---------------------------------- */

function RrCapCard({ rrCap, onSetRrCap }: Pick<Props, "rrCap" | "onSetRrCap">) {
  const [text, setText] = useState(rrCap != null ? String(rrCap) : "1");
  const [err, setErr] = useState<string | null>(null);
  const on = rrCap != null;
  const commit = (raw: string) => {
    const v = validateRrCap(raw);
    if (!v.ok) {
      setErr(v.error);
      return;
    }
    setErr(null);
    onSetRrCap(v.value);
  };
  return (
    <div className="card mb-3">
      <label className="flex items-center justify-between gap-2">
        <span className="text-sm font-bold">محاسبه سود بر اساس R:R مشخص</span>
        <button role="switch" aria-checked={on} className={`relative h-6 w-11 rounded-full transition ${on ? "bg-primary" : "bg-line"}`} onClick={() => (on ? onSetRrCap(null) : commit(text))}>
          <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${on ? "start-[22px]" : "start-0.5"}`} />
        </button>
      </label>
      <div className="mt-2 flex items-center gap-2">
        <label className="text-xs text-muted">مقدار R:R</label>
        <input className="input max-w-[110px] num" inputMode="decimal" disabled={!on} value={text} onChange={(e) => setText(e.target.value)} onBlur={() => on && commit(text)} onKeyDown={(e) => e.key === "Enter" && on && commit(text)} />
      </div>
      {err && <p className="mt-1 text-xs text-loss">{err}</p>}
      <p className="mt-2 text-[11px] leading-6 text-muted">با فعال بودن، هر سودی بزرگ‌تر از این R:R به همان اندازه محدود می‌شود؛ مثلاً با R:R = ۱، تارگت ۳ هم +۱ حساب می‌شود. سمت ضرر (استاپ = −۱) تغییری نمی‌کند.</p>
    </div>
  );
}

function ProTab(props: Props) {
  const { result } = props;
  const r = result.r;
  return (
    <div>
      <ResultColumnChip {...props} />
      <RrCapCard rrCap={props.rrCap} onSetRrCap={props.onSetRrCap} />
      {result.rrCap != null && (
        <div className="mb-3 rounded-xl bg-accent/10 px-3 py-2 text-xs text-accent num">مبنا: R:R = {formatNumber(result.rrCap)} — درصد برد و آمار ضرر تغییری نمی‌کنند (طبیعی است).</div>
      )}
      {!result.resultColumnSet ? null : !r ? (
        <EmptyTrades result={result} />
      ) : (
        <div className="grid grid-cols-2 gap-2">
          <Metric label="تعداد معاملات" value={r.count.toLocaleString("fa-IR")} hint={`ردیف‌های بدون نتیجه: ${result.excludedCount.toLocaleString("fa-IR")}`} />
          <Metric label="نتیجه خالص (تارگت)" value={formatSigned(r.netR)} tone={toneOf(r.netR)} />
          <Metric label="نرخ برد" value={formatPercent(r.winRate)} />
          <Metric label="فکتور سود" value={r.profitFactor === Infinity ? "∞" : formatNumber(r.profitFactor)} tone={r.profitFactor >= 1 ? "win" : "loss"} />
          <Metric label="میانگین برد (تارگت)" value={formatSigned(r.avgWin)} tone="win" />
          <Metric label="میانگین ضرر (تارگت)" value={formatSigned(r.avgLoss)} tone="loss" />
          <Metric label="نسبت ریوارد به ریسک" value={formatNumber(r.rewardRisk)} />
          <Metric label="امید ریاضی هر معامله (تارگت)" value={formatSigned(r.expectancy)} tone={toneOf(r.expectancy)} />
          <Metric label="بهترین معامله (تارگت)" value={formatSigned(r.best)} tone="win" />
          <Metric label="بدترین معامله (تارگت)" value={formatSigned(r.worst)} tone="loss" />
          <Metric label="بیشترین برد متوالی" value={r.maxConsecWins.toLocaleString("fa-IR")} />
          <Metric label="بیشترین باخت متوالی" value={r.maxConsecLosses.toLocaleString("fa-IR")} />
          <Metric label="حداکثر افت سرمایه (تارگت)" value={formatNumber(r.maxDrawdownR)} tone="loss" />
          <Metric label="حداکثر افت سرمایه (٪ از قله)" value={r.maxDrawdownRPct == null ? "—" : formatPercent(r.maxDrawdownRPct)} tone="loss" />
        </div>
      )}
    </div>
  );
}

/* ---------------------------------- Groups ---------------------------------- */

function GroupSelect({ result, headers, onSetGroupColumn }: Pick<Props, "result" | "headers" | "onSetGroupColumn">) {
  return (
    <div className="mb-3 flex items-center gap-2">
      <label className="text-xs text-muted whitespace-nowrap">گروه‌بندی بر اساس</label>
      <select className="input" value={result.groupColumnIndex ?? ""} onChange={(e) => onSetGroupColumn(Number(e.target.value))}>
        {headers.map((h, i) => (
          <option key={i} value={i}>{h}</option>
        ))}
      </select>
    </div>
  );
}

function GroupsTab(props: Props) {
  const { result } = props;
  return (
    <div>
      <ResultColumnChip {...props} />
      {result.resultColumnSet && (
        <>
          <GroupSelect {...props} />
          {!result.r ? (
            <EmptyTrades result={result} />
          ) : (
            <div className="overflow-hidden rounded-xl border border-line">
              <table className="w-full text-xs">
                <thead className="bg-surface-3">
                  <tr>
                    <th className="px-2 py-2 text-start">مقدار</th>
                    <th className="px-2 py-2">تعداد معاملات</th>
                    <th className="px-2 py-2">نرخ برد</th>
                    <th className="px-2 py-2">نتیجه خالص (تارگت)</th>
                  </tr>
                </thead>
                <tbody>
                  {result.groups.map((g) => (
                    <tr key={g.value} className="border-t border-line">
                      <td className="px-2 py-2 font-medium" dir="auto">{g.value}</td>
                      <td className="px-2 py-2 text-center num">{g.count.toLocaleString("fa-IR")}</td>
                      <td className="px-2 py-2 text-center num">{formatPercent(g.winRate, 0)}</td>
                      <td className={`px-2 py-2 text-center num font-bold ${g.netR > 0 ? "text-win" : g.netR < 0 ? "text-loss" : ""}`}>{formatSigned(g.netR)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  );
}

/* ---------------------------------- Charts ---------------------------------- */

function ChartsTab(props: Props) {
  const { result } = props;
  const [unit, setUnit] = useState<"r" | "usd">("r");
  const [barMode, setBarMode] = useState<"net" | "winrate">("net");
  const r = result.r;
  const d = result.dollar;
  return (
    <div>
      <ResultColumnChip {...props} />
      {result.resultColumnSet && (
        <>
          <div className="mb-3 flex gap-1">
            <button className={`chip ${unit === "r" ? "chip-active" : ""}`} onClick={() => setUnit("r")}>تارگت</button>
            <button className={`chip ${unit === "usd" ? "chip-active" : ""}`} onClick={() => setUnit("usd")}>دلار</button>
          </div>
          {!r || !d ? (
            <EmptyTrades result={result} />
          ) : (
            <div className="space-y-4">
              <div className="card">
                <h4 className="mb-2 text-xs font-bold">منحنی رشد سرمایه</h4>
                {unit === "r" ? (
                  <LineChart points={result.rEquity} baseline={0} positive={r.netR >= 0} label="مجموع تجمعی نتیجه (تارگت)" unitLabel={`${formatSigned(r.netR)} تارگت`} />
                ) : (
                  <LineChart points={result.dollarEquity} baseline={d.initialBalance} positive={d.finalBalance >= d.initialBalance} label="موجودی حساب (دلار)" unitLabel={`${formatMoney(d.finalBalance)} دلار`} />
                )}
              </div>
              <div className="card">
                <div className="mb-2 flex items-center justify-between">
                  <h4 className="text-xs font-bold">به تفکیک {result.groupColumnIndex !== null ? props.headers[result.groupColumnIndex] : "گروه"}</h4>
                  <div className="flex gap-1">
                    <button className={`chip ${barMode === "net" ? "chip-active" : ""}`} onClick={() => setBarMode("net")}>{unit === "r" ? "نتیجه خالص" : "سود دلاری"}</button>
                    <button className={`chip ${barMode === "winrate" ? "chip-active" : ""}`} onClick={() => setBarMode("winrate")}>نرخ برد</button>
                  </div>
                </div>
                <GroupSelect {...props} />
                {barMode === "winrate" ? (
                  <BarChart items={result.groups.map((g) => ({ label: g.value, value: g.winRate }))} unit="٪" valueFormatter={(n) => formatNumber(n, 0)} />
                ) : unit === "r" ? (
                  <BarChart items={result.groups.map((g) => ({ label: g.value, value: g.netR }))} unit="تارگت" valueFormatter={(n) => formatSigned(n)} />
                ) : (
                  <BarChart items={result.groups.map((g) => ({ label: g.value, value: g.netDollar }))} unit="دلار" valueFormatter={(n) => formatSigned(n)} />
                )}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

/* ---------------------------------- Dollar ---------------------------------- */

function MoneyCard({ initialBalance, riskPercent, onSetMoney }: Pick<Props, "initialBalance" | "riskPercent" | "onSetMoney">) {
  const [open, setOpen] = useState(false);
  const [b, setB] = useState(String(initialBalance));
  const [r, setR] = useState(String(riskPercent));
  const [err, setErr] = useState<string | null>(null);
  const openDialog = () => {
    setB(String(initialBalance));
    setR(String(riskPercent));
    setErr(null);
    setOpen(true);
  };
  const save = () => {
    const vb = validateBalance(b);
    if (!vb.ok) return setErr(vb.error);
    const vr = validateRisk(r);
    if (!vr.ok) return setErr(vr.error);
    onSetMoney(vb.value, vr.value);
    setOpen(false);
  };
  return (
    <>
      <button className="card mb-3 flex w-full items-center justify-between text-start" onClick={openDialog}>
        <div className="text-xs">
          <div>موجودی اولیه حساب: <b className="num">{formatMoney(initialBalance)} دلار</b></div>
          <div className="mt-1">درصد ریسک هر معامله: <b className="num">{formatNumber(riskPercent)}٪</b></div>
        </div>
        <span className="text-muted">{Icons.edit({ className: "h-4 w-4" })}</span>
      </button>
      <Sheet open={open} onClose={() => setOpen(false)} title="تنظیمات مدیریت سرمایه">
        <label className="mb-1 block text-xs text-muted">موجودی اولیه حساب (دلار)</label>
        <input className="input num" inputMode="decimal" value={b} onChange={(e) => setB(e.target.value)} />
        <label className="mt-3 mb-1 block text-xs text-muted">درصد ریسک هر معامله</label>
        <input className="input num" inputMode="decimal" value={r} onChange={(e) => setR(e.target.value)} />
        {err && <p className="mt-2 text-xs text-loss">{err}</p>}
        <div className="mt-4 flex gap-2">
          <button className="btn-primary flex-1" onClick={save}>ذخیره</button>
          <button className="btn-outline flex-1" onClick={() => setOpen(false)}>انصراف</button>
        </div>
      </Sheet>
    </>
  );
}

function DollarTab(props: Props) {
  const { result } = props;
  const d = result.dollar;
  return (
    <div>
      <ResultColumnChip {...props} />
      <MoneyCard initialBalance={props.initialBalance} riskPercent={props.riskPercent} onSetMoney={props.onSetMoney} />
      <p className="mb-1 text-[11px] text-muted num">مبنای سود: {result.rrCap != null ? `R:R = ${formatNumber(result.rrCap)}` : "بدون محدودیت"}</p>
      <p className="mb-3 text-[11px] text-muted">ترتیب ردیف‌ها به‌عنوان ترتیب زمانی معاملات در نظر گرفته می‌شود.</p>
      {!result.resultColumnSet ? null : !d ? (
        <EmptyTrades result={result} />
      ) : (
        <div className="grid grid-cols-2 gap-2">
          <Metric label="موجودی نهایی" value={`${formatMoney(d.finalBalance)} $`} />
          <Metric label="سود/زیان خالص (دلار)" value={formatSigned(d.netProfit)} tone={toneOf(d.netProfit)} />
          <Metric label="بازده کل" value={formatPercent(d.returnPct)} tone={toneOf(d.returnPct)} />
          <Metric label="تعداد معاملات" value={d.count.toLocaleString("fa-IR")} hint={`ردیف‌های بدون نتیجه: ${result.excludedCount.toLocaleString("fa-IR")}`} />
          <Metric label="میانگین سود هر معامله (دلار)" value={formatSigned(d.avgWin)} tone="win" />
          <Metric label="میانگین ضرر هر معامله (دلار)" value={formatSigned(d.avgLoss)} tone="loss" />
          <Metric label="بهترین معامله (دلار)" value={formatSigned(d.best)} tone="win" />
          <Metric label="بدترین معامله (دلار)" value={formatSigned(d.worst)} tone="loss" />
          <Metric label="حداکثر افت سرمایه (دلار)" value={formatMoney(d.maxDrawdown)} tone="loss" />
          <Metric label="حداکثر افت سرمایه (٪ از قله)" value={formatPercent(d.maxDrawdownPct)} tone="loss" />
        </div>
      )}
    </div>
  );
}

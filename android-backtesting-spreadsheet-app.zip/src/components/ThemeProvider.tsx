"use client";

import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";

export type ThemeMode = "light" | "dark" | "system";

const Ctx = createContext<{ theme: ThemeMode; setTheme: (t: ThemeMode) => void }>({ theme: "system", setTheme: () => undefined });

function apply(t: ThemeMode) {
  const dark = t === "dark" || (t === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
  document.documentElement.classList.toggle("dark", dark);
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<ThemeMode>("system");
  useEffect(() => {
    const saved = (localStorage.getItem("bt-theme") as ThemeMode | null) ?? "system";
    setThemeState(saved);
    apply(saved);
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => {
      const cur = (localStorage.getItem("bt-theme") as ThemeMode | null) ?? "system";
      if (cur === "system") apply(cur);
    };
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);
  const setTheme = useCallback((t: ThemeMode) => {
    localStorage.setItem("bt-theme", t);
    setThemeState(t);
    apply(t);
  }, []);
  return <Ctx.Provider value={{ theme, setTheme }}>{children}</Ctx.Provider>;
}

export const useTheme = () => useContext(Ctx);

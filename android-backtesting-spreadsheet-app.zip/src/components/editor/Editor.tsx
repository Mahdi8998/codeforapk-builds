"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { activeFilterColumns, filteredRowIndexesOriginalOrder, hasActiveFilters, remapFilterColumns, visibleRowIndexes } from "@/lib/filters";
import * as ops from "@/lib/grid-ops";
import { computeStats, type StatsInput } from "@/lib/stats-engine";
import type { FilterState, Grid, WorkbookFull } from "@/lib/types";
import { gridToXlsx } from "@/lib/xlsx";
import { Confirm, Icons, MenuList, PromptDialog, Sheet, Spinner, ToastHost, useToast } from "../ui";
import StatsPanel from "../stats/StatsPanel";
import FilterSheet from "./FilterSheet";
import GridView from "./Grid";

interface Snapshot {
  grid: Grid;
  fs: FilterState;
}
const MAX_HISTORY = 100;

export default function Editor({ id }: { id: number }) {
  return (
    <ToastHost>
      <EditorInner id={id} />
    </ToastHost>
  );
}

function EditorInner({ id }: { id: number }) {
  const router = useRouter();
  const toast = useToast();
  const [wb, setWb] = useState<WorkbookFull | null>(null);
  const [error, setError] = useState<string | null>(null);

  // editable state
  const [name, setName] = useState("");
  const [grid, setGrid] = useState<Grid>({ headers: [], rows: [] });
  const [fs, setFs] = useState<FilterState>({ columns: {}, search: "", sort: null });
  const [pl, setPl] = useState<number | null>(null);
  const [balance, setBalance] = useState(500);
  const [risk, setRisk] = useState(2);
  const [rrCap, setRrCap] = useState<number | null>(null);
  const [groupCol, setGroupCol] = useState<number | null>(null);

  // history
  const past = useRef<Snapshot[]>([]);
  const future = useRef<Snapshot[]>([]);
  const [, bump] = useState(0);

  // ui
  const [searchOpen, setSearchOpen] = useState(false);
  const [statsOpen, setStatsOpen] = useState(false);
  const [filterCol, setFilterCol] = useState<number | null>(null);
  const [headerMenu, setHeaderMenu] = useState<number | null>(null);
  const [rowMenu, setRowMenu] = useState<number | null>(null);
  const [editing, setEditing] = useState<{ r: number; c: number } | null>(null);
  const [editValue, setEditValue] = useState("");
  const [renameOpen, setRenameOpen] = useState(false);
  const [renameCol, setRenameCol] = useState<number | null>(null);
  const [insertCol, setInsertCol] = useState<{ at: number } | null>(null);
  const [deleteCol, setDeleteCol] = useState<number | null>(null);
  const [moreOpen, setMoreOpen] = useState(false);
  const [exportChoice, setExportChoice] = useState(false);
  const [saving, setSaving] = useState<"idle" | "dirty" | "saving" | "saved">("idle");

  /* ------------------------------ load ------------------------------ */
  useEffect(() => {
    let alive = true;
    fetch(`/api/workbooks/${id}`, { cache: "no-store" })
      .then(async (r) => {
        if (!r.ok) throw new Error((await r.json()).error ?? "خطا");
        return (await r.json()) as WorkbookFull;
      })
      .then((w) => {
        if (!alive) return;
        setWb(w);
        setName(w.name);
        setGrid(w.grid);
        setFs(w.filterState);
        setPl(w.plColumnIndex);
        setBalance(w.initialBalance);
        setRisk(w.riskPercent);
        setRrCap(w.rrCap);
      })
      .catch((e) => alive && setError(e instanceof Error ? e.message : "خطا"));
    return () => {
      alive = false;
    };
  }, [id]);

  /* ------------------------------ auto-save ------------------------------ */
  const dirty = useRef(false);
  const latest = useRef({ name, grid, fs, pl, balance, risk, rrCap });
  latest.current = { name, grid, fs, pl, balance, risk, rrCap };
  const save = useCallback(async () => {
    if (!wb) return;
    const s = latest.current;
    setSaving("saving");
    try {
      const r = await fetch(`/api/workbooks/${wb.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: s.name, grid: s.grid, filterState: s.fs, plColumnIndex: s.pl, initialBalance: s.balance, riskPercent: s.risk, rrCap: s.rrCap }),
        keepalive: true,
      });
      if (!r.ok) throw new Error();
      dirty.current = false;
      setSaving("saved");
    } catch {
      setSaving("dirty");
      toast("ذخیره انجام نشد؛ دوباره تلاش می‌شود", "err");
    }
  }, [wb, toast]);

  const firstRun = useRef(true);
  useEffect(() => {
    if (!wb) return;
    if (firstRun.current) {
      firstRun.current = false;
      return;
    }
    dirty.current = true;
    setSaving("dirty");
    const t = setTimeout(save, 500);
    return () => clearTimeout(t);
  }, [wb, name, grid, fs, pl, balance, risk, rrCap, save]);

  useEffect(() => {
    const onHide = () => {
      if (dirty.current) save();
    };
    window.addEventListener("pagehide", onHide);
    document.addEventListener("visibilitychange", onHide);
    return () => {
      window.removeEventListener("pagehide", onHide);
      document.removeEventListener("visibilitychange", onHide);
    };
  }, [save]);

  /* ------------------------------ history ------------------------------ */
  const commit = useCallback(
    (nextGrid: Grid, nextFs?: FilterState) => {
      past.current.push({ grid, fs });
      if (past.current.length > MAX_HISTORY) past.current.shift();
      future.current = [];
      setGrid(nextGrid);
      if (nextFs) setFs(nextFs);
      bump((n) => n + 1);
    },
    [grid, fs],
  );
  const undo = () => {
    const s = past.current.pop();
    if (!s) return;
    future.current.push({ grid, fs });
    setGrid(s.grid);
    setFs(s.fs);
    bump((n) => n + 1);
  };
  const redo = () => {
    const s = future.current.pop();
    if (!s) return;
    past.current.push({ grid, fs });
    setGrid(s.grid);
    setFs(s.fs);
    bump((n) => n + 1);
  };

  /* ------------------------------ derived ------------------------------ */
  const visible = useMemo(() => visibleRowIndexes(grid, fs), [grid, fs]);
  const filteredOriginal = useMemo(() => filteredRowIndexesOriginalOrder(grid, fs), [grid, fs]);
  const activeCols = useMemo(() => new Set(activeFilterColumns(fs)), [fs]);
  const filtersActive = hasActiveFilters(fs);

  // Reactive stats pipeline: single StatsInput -> debounce 200ms -> compute
  const statsInput = useMemo<StatsInput>(
    () => ({
      headers: grid.headers,
      rows: filteredOriginal.map((i) => grid.rows[i]),
      totalRows: grid.rows.length,
      plColumnIndex: pl,
      rrCap,
      initialBalance: balance,
      riskPercent: risk,
      groupColumnIndex: groupCol,
    }),
    [grid, filteredOriginal, pl, rrCap, balance, risk, groupCol],
  );
  const [debouncedInput, setDebouncedInput] = useState<StatsInput | null>(null);
  useEffect(() => {
    if (!statsOpen) return;
    const t = setTimeout(() => setDebouncedInput(statsInput), 200);
    return () => clearTimeout(t);
  }, [statsInput, statsOpen]);
  const stats = useMemo(() => (debouncedInput ? computeStats(debouncedInput) : null), [debouncedInput]);

  /* ------------------------------ actions ------------------------------ */
  const openCell = (r: number, c: number) => {
    setEditing({ r, c });
    setEditValue(grid.rows[r]?.[c] ?? "");
  };
  const saveCell = (moveDown: boolean) => {
    if (!editing) return;
    const next = ops.setCell(grid, editing.r, editing.c, editValue);
    if (next !== grid) commit(next);
    if (moveDown) {
      const pos = visible.indexOf(editing.r);
      const nr = pos >= 0 && pos + 1 < visible.length ? visible[pos + 1] : null;
      if (nr !== null) {
        setEditing({ r: nr, c: editing.c });
        setEditValue(next.rows[nr]?.[editing.c] ?? "");
        return;
      }
    }
    setEditing(null);
  };

  const applyColumnFilter = (values: string[] | undefined) => {
    if (filterCol === null) return;
    const columns = { ...fs.columns };
    if (values === undefined) delete columns[String(filterCol)];
    else columns[String(filterCol)] = { values };
    setFs({ ...fs, columns });
    setFilterCol(null);
  };
  const applySort = (dir: "asc" | "desc" | null) => {
    if (filterCol === null) return;
    setFs({ ...fs, sort: dir ? { column: filterCol, direction: dir } : null });
  };
  const clearAllFilters = () => setFs({ columns: {}, search: "", sort: null });

  const withColumnChange = (res: { grid: Grid; map: (i: number) => number | null }) => {
    const nextFs = remapFilterColumns(fs, res.map);
    commit(res.grid, nextFs);
    if (pl !== null) setPl(res.map(pl));
    if (groupCol !== null) setGroupCol(res.map(groupCol));
  };

  const doExport = async (onlyFiltered: boolean) => {
    setExportChoice(false);
    setMoreOpen(false);
    const rows = onlyFiltered ? visible.map((i) => grid.rows[i]) : grid.rows;
    const buf = gridToXlsx(grid.headers, rows);
    const blob = new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
    const fileName = `${name || "backtest"}.xlsx`;
    const w = window as Window & { showSaveFilePicker?: (o: unknown) => Promise<{ createWritable: () => Promise<{ write: (b: Blob) => Promise<void>; close: () => Promise<void> }> }> };
    try {
      if (w.showSaveFilePicker) {
        const handle = await w.showSaveFilePicker({ suggestedName: fileName, types: [{ description: "Excel", accept: { [blob.type]: [".xlsx"] } }] });
        const ws = await handle.createWritable();
        await ws.write(blob);
        await ws.close();
      } else {
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = fileName;
        a.click();
        setTimeout(() => URL.revokeObjectURL(url), 5000);
      }
      toast(`${rows.length.toLocaleString("fa-IR")} ردیف خروجی گرفته شد`);
    } catch (e) {
      if ((e as Error)?.name !== "AbortError") toast("خروجی گرفته نشد", "err");
    }
  };

  const goAi = async () => {
    if (dirty.current) await save();
    router.push(`/workbook/${id}/ai`);
  };

  /* ------------------------------ render ------------------------------ */
  if (error) {
    return (
      <div className="grid min-h-screen place-items-center p-6 text-center">
        <div>
          <p className="font-bold">{error}</p>
          <Link href="/" className="btn-primary mt-4">بازگشت به خانه</Link>
        </div>
      </div>
    );
  }
  if (!wb) {
    return (
      <div className="grid min-h-screen place-items-center text-muted">
        <Spinner className="h-7 w-7" />
      </div>
    );
  }

  const statsHeight = statsOpen ? "62vh" : "0";
  const selected = editing;

  return (
    <div className="flex h-dvh flex-col overflow-hidden">
      {/* Top bar */}
      <header className="flex items-center gap-0.5 border-b border-line bg-surface-2 px-1 py-1">
        <Link href="/" className="icon-btn" aria-label="بازگشت">{Icons.back({ className: "h-5 w-5 rotate-180" })}</Link>
        <button className="min-w-0 flex-1 truncate text-start text-sm font-bold" onClick={() => setRenameOpen(true)} title="تغییر نام">
          {name}
          <span className="ms-2 text-[10px] font-normal text-muted">{saving === "saving" ? "در حال ذخیره…" : saving === "dirty" ? "ذخیره‌نشده" : saving === "saved" ? "ذخیره شد" : ""}</span>
        </button>
        <button className="icon-btn" onClick={undo} disabled={past.current.length === 0} aria-label="واگرد">{Icons.undo()}</button>
        <button className="icon-btn" onClick={redo} disabled={future.current.length === 0} aria-label="ازنو">{Icons.redo()}</button>
        <button className={`icon-btn ${searchOpen || fs.search ? "text-primary" : ""}`} onClick={() => setSearchOpen((o) => !o)} aria-label="جستجو">{Icons.search()}</button>
        <button className={`icon-btn ${statsOpen ? "text-primary" : ""}`} onClick={() => setStatsOpen((o) => !o)} aria-label="آمار">{Icons.stats()}</button>
        <button className="icon-btn text-accent" onClick={goAi} aria-label="تحلیلگر هوش مصنوعی">{Icons.sparkle()}</button>
        <button className="icon-btn" onClick={() => setMoreOpen(true)} aria-label="بیشتر">{Icons.more()}</button>
      </header>

      {searchOpen && (
        <div className="flex items-center gap-2 border-b border-line bg-surface-2 px-3 py-2">
          <input className="input" placeholder="جستجو در همه ستون‌ها…" value={fs.search} onChange={(e) => setFs({ ...fs, search: e.target.value })} autoFocus />
          <span className="whitespace-nowrap text-xs text-muted num">{fs.search ? `${visible.length.toLocaleString("fa-IR")} نتیجه` : ""}</span>
          <button className="icon-btn" onClick={() => { setFs({ ...fs, search: "" }); setSearchOpen(false); }} aria-label="بستن جستجو">{Icons.close()}</button>
        </div>
      )}

      {filtersActive && (
        <div className="flex items-center gap-2 bg-primary/10 px-3 py-1 text-xs">
          <span className="text-primary">{Icons.filter({ className: "h-3.5 w-3.5", fill: true })}</span>
          <span className="flex-1 num">{visible.length.toLocaleString("fa-IR")} از {grid.rows.length.toLocaleString("fa-IR")} ردیف نمایش داده می‌شود</span>
          <button className="text-primary underline" onClick={clearAllFilters}>حذف همه فیلترها</button>
        </div>
      )}

      {/* Grid */}
      <div className="relative min-h-0 flex-1">
        <GridView grid={grid} visible={visible} activeFilterCols={activeCols} sort={fs.sort ?? null} selected={selected} onCellTap={openCell} onHeaderMenu={setHeaderMenu} onFilter={setFilterCol} onRowMenu={setRowMenu} bottomInset={8} />
      </div>

      {/* Bottom bar */}
      <footer className="flex items-center justify-between border-t border-line bg-surface-2 px-3 py-1.5">
        <button className="btn-primary" onClick={() => { commit(ops.addRow(grid)); }}>
          {Icons.plus({ className: "h-4 w-4" })} ردیف
        </button>
        <span className="text-xs text-muted num">
          {visible.length.toLocaleString("fa-IR")} / {grid.rows.length.toLocaleString("fa-IR")} ردیف • {grid.headers.length.toLocaleString("fa-IR")} ستون
        </span>
        <button className="btn-outline" onClick={() => save().then(() => toast("ذخیره شد ✅"))}>
          {Icons.save({ className: "h-4 w-4" })} ذخیره
        </button>
      </footer>

      {/* Stats panel (collapsible) */}
      <div className="fixed inset-x-0 bottom-0 z-40 overflow-hidden rounded-t-3xl border-t border-line shadow-2xl transition-[height] duration-200" style={{ height: statsHeight }}>
        {statsOpen && stats && (
          <StatsPanel result={stats} headers={grid.headers} plColumnIndex={pl} onSetPlColumn={setPl} onSetGroupColumn={setGroupCol} initialBalance={balance} riskPercent={risk} rrCap={rrCap} onSetMoney={(b, r) => { setBalance(b); setRisk(r); }} onSetRrCap={setRrCap} onClose={() => setStatsOpen(false)} />
        )}
        {statsOpen && !stats && (
          <div className="grid h-full place-items-center bg-surface-2 text-muted"><Spinner /></div>
        )}
      </div>

      {/* Cell editor */}
      <Sheet open={!!editing} onClose={() => setEditing(null)} title={editing ? `${grid.headers[editing.c]} — ردیف ${editing.r + 1}` : ""}>
        {editing && (
          <form onSubmit={(e) => { e.preventDefault(); saveCell(true); }}>
            <textarea className="input min-h-[96px] resize-y" dir="auto" value={editValue} onChange={(e) => setEditValue(e.target.value)} autoFocus onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); saveCell(true); } }} />
            <div className="mt-3 flex gap-2">
              <button type="submit" className="btn-primary flex-1">ذخیره و بعدی ↓</button>
              <button type="button" className="btn-outline" onClick={() => saveCell(false)}>ذخیره</button>
              <button type="button" className="btn-ghost" onClick={() => setEditing(null)}>انصراف</button>
            </div>
          </form>
        )}
      </Sheet>

      {/* Filter sheet */}
      <FilterSheet grid={grid} column={filterCol} filterState={fs} onClose={() => setFilterCol(null)} onApply={applyColumnFilter} onSort={applySort} />

      {/* Header menu */}
      <Sheet open={headerMenu !== null} onClose={() => setHeaderMenu(null)} title={headerMenu !== null ? `ستون: ${grid.headers[headerMenu]}` : ""}>
        {headerMenu !== null && (
          <MenuList
            items={[
              { label: "تغییر نام ستون", icon: Icons.edit(), onClick: () => { setRenameCol(headerMenu); setHeaderMenu(null); } },
              { label: "درج ستون در چپ", icon: Icons.plus(), onClick: () => { setInsertCol({ at: headerMenu }); setHeaderMenu(null); } },
              { label: "درج ستون در راست", icon: Icons.plus(), onClick: () => { setInsertCol({ at: headerMenu + 1 }); setHeaderMenu(null); } },
              { label: "انتقال به چپ", icon: Icons.back({ className: "h-5 w-5 rotate-180" }), onClick: () => { withColumnChange(ops.moveColumn(grid, headerMenu, headerMenu - 1)); setHeaderMenu(null); } },
              { label: "انتقال به راست", icon: Icons.back(), onClick: () => { withColumnChange(ops.moveColumn(grid, headerMenu, headerMenu + 1)); setHeaderMenu(null); } },
              { label: "مرتب‌سازی / فیلتر", icon: Icons.filter(), onClick: () => { setFilterCol(headerMenu); setHeaderMenu(null); } },
              { label: "حذف ستون", icon: Icons.trash(), danger: true, onClick: () => { setDeleteCol(headerMenu); setHeaderMenu(null); } },
            ]}
          />
        )}
      </Sheet>

      {/* Row menu */}
      <Sheet open={rowMenu !== null} onClose={() => setRowMenu(null)} title={rowMenu !== null ? `ردیف ${rowMenu + 1}` : ""}>
        {rowMenu !== null && (
          <MenuList
            items={[
              { label: "درج ردیف بالا", icon: Icons.plus(), onClick: () => { commit(ops.insertRow(grid, rowMenu)); setRowMenu(null); } },
              { label: "درج ردیف پایین", icon: Icons.plus(), onClick: () => { commit(ops.insertRow(grid, rowMenu + 1)); setRowMenu(null); } },
              { label: "کپی ردیف", icon: Icons.dup(), onClick: () => { commit(ops.duplicateRow(grid, rowMenu)); setRowMenu(null); } },
              { label: "حذف ردیف", icon: Icons.trash(), danger: true, onClick: () => { commit(ops.deleteRow(grid, rowMenu)); setRowMenu(null); } },
            ]}
          />
        )}
      </Sheet>

      {/* Overflow menu */}
      <Sheet open={moreOpen} onClose={() => setMoreOpen(false)} title="گزینه‌ها">
        <MenuList
          items={[
            { label: "خروجی اکسل (XLSX)", icon: Icons.download(), onClick: () => (filtersActive ? setExportChoice(true) : doExport(false)) },
            { label: "حذف همه فیلترها", icon: Icons.filter(), onClick: () => { clearAllFilters(); setMoreOpen(false); } },
            { label: "تغییر نام جدول", icon: Icons.edit(), onClick: () => { setRenameOpen(true); setMoreOpen(false); } },
            { label: "تنظیمات", icon: Icons.settings(), onClick: () => router.push("/settings") },
          ]}
        />
      </Sheet>
      <Sheet open={exportChoice} onClose={() => setExportChoice(false)} title="کدام ردیف‌ها خروجی گرفته شود؟">
        <div className="flex flex-col gap-2">
          <button className="btn-primary" onClick={() => doExport(false)}>همه ردیف‌ها ({grid.rows.length.toLocaleString("fa-IR")})</button>
          <button className="btn-outline" onClick={() => doExport(true)}>فقط ردیف‌های فیلترشده ({visible.length.toLocaleString("fa-IR")})</button>
        </div>
      </Sheet>

      {/* Dialogs */}
      <PromptDialog open={renameOpen} title="تغییر نام جدول" label="نام جدول" initial={name} onCancel={() => setRenameOpen(false)} onSubmit={(v) => { setName(v); setRenameOpen(false); }} />
      <PromptDialog open={renameCol !== null} title="تغییر نام ستون" label="نام ستون" initial={renameCol !== null ? grid.headers[renameCol] : ""} onCancel={() => setRenameCol(null)} onSubmit={(v) => { if (renameCol !== null) commit(ops.renameColumn(grid, renameCol, v)); setRenameCol(null); }} />
      <PromptDialog open={insertCol !== null} title="ستون جدید" label="نام ستون" initial="" onCancel={() => setInsertCol(null)} onSubmit={(v) => { if (insertCol) withColumnChange(ops.insertColumn(grid, insertCol.at, v)); setInsertCol(null); }} />
      <Confirm open={deleteCol !== null} title="حذف ستون" message={deleteCol !== null ? `ستون «${grid.headers[deleteCol]}» و همه داده‌های آن حذف شود؟` : ""} confirmLabel="حذف" danger onCancel={() => setDeleteCol(null)} onConfirm={() => { if (deleteCol !== null) withColumnChange(ops.deleteColumn(grid, deleteCol)); setDeleteCol(null); }} />
    </div>
  );
}

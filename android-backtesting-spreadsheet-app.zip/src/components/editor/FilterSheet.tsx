"use client";

import { useEffect, useMemo, useState } from "react";
import { uniqueValues } from "@/lib/filters";
import type { FilterState, Grid } from "@/lib/types";
import { Icons, Sheet } from "../ui";

interface Props {
  grid: Grid;
  column: number | null;
  filterState: FilterState;
  onClose: () => void;
  onApply: (values: string[] | undefined) => void;
  onSort: (dir: "asc" | "desc" | null) => void;
}

export default function FilterSheet({ grid, column, filterState, onClose, onApply, onSort }: Props) {
  const open = column !== null;
  const values = useMemo(() => (column === null ? [] : uniqueValues(grid, column)), [grid, column]);
  const [q, setQ] = useState("");
  const [sel, setSel] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (column === null) return;
    const cur = filterState.columns[String(column)]?.values;
    setSel(new Set(cur ?? values.map((v) => v.value)));
    setQ("");
  }, [column, filterState, values]);

  const shown = useMemo(() => {
    const qq = q.trim().toLowerCase();
    return qq ? values.filter((v) => v.value.toLowerCase().includes(qq)) : values;
  }, [values, q]);
  const allShownSelected = shown.length > 0 && shown.every((v) => sel.has(v.value));

  const toggleAll = () => {
    const next = new Set(sel);
    if (allShownSelected) shown.forEach((v) => next.delete(v.value));
    else shown.forEach((v) => next.add(v.value));
    setSel(next);
  };
  const toggle = (v: string) => {
    const next = new Set(sel);
    if (next.has(v)) next.delete(v);
    else next.add(v);
    setSel(next);
  };
  const apply = () => {
    if (sel.size === values.length) onApply(undefined);
    else onApply(values.filter((v) => sel.has(v.value)).map((v) => v.value));
  };
  const curSort = column !== null && filterState.sort?.column === column ? filterState.sort.direction : null;

  return (
    <Sheet open={open} onClose={onClose} title={column !== null ? `فیلتر: ${grid.headers[column]}` : ""}>
      <div className="flex gap-2">
        <button className={`btn-outline flex-1 ${curSort === "asc" ? "chip-active border-primary" : ""}`} onClick={() => onSort(curSort === "asc" ? null : "asc")}>
          {Icons.sortAsc({ className: "h-4 w-4" })} صعودی
        </button>
        <button className={`btn-outline flex-1 ${curSort === "desc" ? "chip-active border-primary" : ""}`} onClick={() => onSort(curSort === "desc" ? null : "desc")}>
          {Icons.sortDesc({ className: "h-4 w-4" })} نزولی
        </button>
      </div>
      <input className="input mt-3" placeholder="جستجو در مقادیر…" value={q} onChange={(e) => setQ(e.target.value)} />
      <label className="mt-3 flex items-center gap-2 border-b border-line pb-2 text-sm font-medium">
        <input type="checkbox" className="h-4 w-4 accent-[var(--primary)]" checked={allShownSelected} onChange={toggleAll} />
        <span>(انتخاب همه)</span>
        <span className="me-auto text-xs text-muted num">{values.length.toLocaleString("fa-IR")} مقدار</span>
      </label>
      <ul className="max-h-[38vh] overflow-y-auto py-1">
        {shown.map((v) => (
          <li key={v.value}>
            <label className="flex items-center gap-2 rounded-lg px-1 py-1.5 text-sm hover:bg-surface-3">
              <input type="checkbox" className="h-4 w-4 accent-[var(--primary)]" checked={sel.has(v.value)} onChange={() => toggle(v.value)} />
              <span className={`flex-1 truncate ${v.value === "" ? "text-muted italic" : ""}`} dir="auto">
                {v.value === "" ? "(خالی)" : v.value}
              </span>
              <span className="text-xs text-muted num">{v.count.toLocaleString("fa-IR")}</span>
            </label>
          </li>
        ))}
        {shown.length === 0 && <li className="py-4 text-center text-xs text-muted">موردی یافت نشد</li>}
      </ul>
      <div className="mt-3 flex gap-2">
        <button className="btn-primary flex-1" onClick={apply} disabled={sel.size === 0}>
          اعمال فیلتر
        </button>
        <button className="btn-outline flex-1" onClick={() => onApply(undefined)}>
          پاک کردن فیلتر
        </button>
      </div>
    </Sheet>
  );
}

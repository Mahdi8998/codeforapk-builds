"use client";

import { memo, useCallback, useEffect, useRef, useState } from "react";
import type { Grid } from "@/lib/types";
import { Icons } from "../ui";

export const ROW_H = 40;
const HEADER_H = 44;
const COL_W = 128;
const NUM_W = 44;

interface Props {
  grid: Grid;
  visible: number[];
  activeFilterCols: Set<number>;
  sort: { column: number; direction: "asc" | "desc" } | null;
  selected: { r: number; c: number } | null;
  onCellTap: (r: number, c: number) => void;
  onHeaderMenu: (c: number) => void;
  onFilter: (c: number) => void;
  onRowMenu: (r: number) => void;
  bottomInset: number;
}

function useLongPress(cb: () => void, ms = 500) {
  const t = useRef<ReturnType<typeof setTimeout> | null>(null);
  const start = useCallback(() => {
    t.current = setTimeout(cb, ms);
  }, [cb, ms]);
  const clear = useCallback(() => {
    if (t.current) clearTimeout(t.current);
    t.current = null;
  }, []);
  return { onPointerDown: start, onPointerUp: clear, onPointerLeave: clear, onPointerCancel: clear, onPointerMove: clear };
}

const Row = memo(function Row({ grid, r, top, selected, onCellTap, onRowMenu }: { grid: Grid; r: number; top: number; selected: number | null; onCellTap: (r: number, c: number) => void; onRowMenu: (r: number) => void }) {
  const row = grid.rows[r];
  const lp = useLongPress(() => onRowMenu(r));
  return (
    <div className="absolute left-0 flex border-b border-line" style={{ top, height: ROW_H, minWidth: "100%" }} {...lp} onContextMenu={(e) => { e.preventDefault(); onRowMenu(r); }}>
      <button className="sticky left-0 z-10 shrink-0 border-r border-line bg-surface-3 text-[11px] text-muted num hover:text-fg" style={{ width: NUM_W }} onClick={() => onRowMenu(r)} aria-label={`ردیف ${r + 1}`}>
        {r + 1}
      </button>
      {grid.headers.map((_, c) => {
        const v = row[c] ?? "";
        const isSel = selected === c;
        return (
          <button
            key={c}
            className={`shrink-0 overflow-hidden text-ellipsis whitespace-nowrap border-r border-line px-2 text-start text-[13px] leading-[38px] ${isSel ? "bg-primary/15 ring-2 ring-inset ring-primary" : "hover:bg-surface-3/70"}`}
            style={{ width: COL_W, direction: /[\u0600-\u06FF]/.test(v) ? "rtl" : "ltr" }}
            onClick={() => onCellTap(r, c)}
            title={v}
          >
            {v}
          </button>
        );
      })}
    </div>
  );
});

export default function GridView({ grid, visible, activeFilterCols, sort, selected, onCellTap, onHeaderMenu, onFilter, onRowMenu, bottomInset }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const [scrollTop, setScrollTop] = useState(0);
  const [viewH, setViewH] = useState(600);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setViewH(el.clientHeight));
    ro.observe(el);
    setViewH(el.clientHeight);
    return () => ro.disconnect();
  }, []);

  // keep selected cell in view
  useEffect(() => {
    if (!selected || !ref.current) return;
    const pos = visible.indexOf(selected.r);
    if (pos < 0) return;
    const top = HEADER_H + pos * ROW_H;
    const el = ref.current;
    if (top < el.scrollTop + HEADER_H) el.scrollTop = top - HEADER_H;
    else if (top + ROW_H > el.scrollTop + el.clientHeight - bottomInset) el.scrollTop = top + ROW_H - el.clientHeight + bottomInset;
  }, [selected, visible, bottomInset]);

  const total = visible.length;
  const start = Math.max(0, Math.floor((scrollTop - HEADER_H) / ROW_H) - 6);
  const end = Math.min(total, Math.ceil((scrollTop + viewH) / ROW_H) + 6);
  const width = NUM_W + grid.headers.length * COL_W;

  return (
    <div ref={ref} className="ltr-grid relative h-full w-full overflow-auto overscroll-contain bg-surface-2" onScroll={(e) => setScrollTop(e.currentTarget.scrollTop)}>
      <div style={{ height: HEADER_H + total * ROW_H + bottomInset, width, position: "relative", minWidth: "100%" }}>
        {/* Header */}
        <div className="sticky top-0 z-20 flex border-b-2 border-line bg-surface-3" style={{ height: HEADER_H, minWidth: "100%" }}>
          <div className="sticky left-0 z-30 shrink-0 border-r border-line bg-surface-3" style={{ width: NUM_W }} />
          {grid.headers.map((h, c) => (
            <HeaderCell key={c} name={h} c={c} active={activeFilterCols.has(c)} sortDir={sort?.column === c ? sort.direction : null} onMenu={onHeaderMenu} onFilter={onFilter} />
          ))}
        </div>
        {total === 0 && (
          <div className="absolute inset-x-0 top-24 text-center text-sm text-muted" dir="rtl">
            ردیفی برای نمایش وجود ندارد
          </div>
        )}
        {visible.slice(start, end).map((r, k) => (
          <Row key={r} grid={grid} r={r} top={HEADER_H + (start + k) * ROW_H} selected={selected?.r === r ? selected.c : null} onCellTap={onCellTap} onRowMenu={onRowMenu} />
        ))}
      </div>
    </div>
  );
}

const HeaderCell = memo(function HeaderCell({ name, c, active, sortDir, onMenu, onFilter }: { name: string; c: number; active: boolean; sortDir: "asc" | "desc" | null; onMenu: (c: number) => void; onFilter: (c: number) => void }) {
  const lp = useLongPress(() => onMenu(c));
  return (
    <div className="flex shrink-0 items-center border-r border-line" style={{ width: COL_W }}>
      <button className="min-w-0 flex-1 truncate px-2 text-start text-[13px] font-bold" style={{ direction: "rtl" }} title={name} onClick={() => onMenu(c)} {...lp} onContextMenu={(e) => { e.preventDefault(); onMenu(c); }}>
        {sortDir && <span className="me-1 text-primary">{sortDir === "asc" ? "↑" : "↓"}</span>}
        {name}
      </button>
      <button className={`grid h-7 w-7 shrink-0 place-items-center rounded-md me-1 ${active ? "bg-primary text-primary-fg" : "text-muted hover:bg-surface-2"}`} onClick={() => onFilter(c)} aria-label="فیلتر">
        {Icons.filter({ className: "h-4 w-4", fill: active })}
      </button>
    </div>
  );
});

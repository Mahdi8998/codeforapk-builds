"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { buildCompletePayload, buildSummaryPayload, COMPLETE_MODE_CAP, PRESETS, type AiScope, type DataMode } from "@/lib/ai";
import { filteredRowIndexesOriginalOrder, hasActiveFilters } from "@/lib/filters";
import type { WorkbookFull } from "@/lib/types";
import { Icons, Sheet, Spinner, ToastHost, useToast } from "../ui";

interface Msg {
  role: "user" | "model";
  /** full text sent to / received from the model */
  text: string;
  /** short label displayed for user messages (payload hidden) */
  display: string;
  error?: string | null;
  streaming?: boolean;
}

export default function AiClient({ id }: { id: number }) {
  return (
    <ToastHost>
      <AiInner id={id} />
    </ToastHost>
  );
}

function AiInner({ id }: { id: number }) {
  const toast = useToast();
  const [wb, setWb] = useState<WorkbookFull | null>(null);
  const [hasKey, setHasKey] = useState<boolean | null>(null);
  const [scope, setScope] = useState<AiScope | null>(null);
  const [mode, setMode] = useState<DataMode>("summary");
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [tooLarge, setTooLarge] = useState<{ prompt: string; label: string } | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const listRef = useRef<HTMLDivElement>(null);

  const captureScope = useCallback((w: WorkbookFull): AiScope => ({
    grid: w.grid,
    filterState: w.filterState,
    rowIndexes: filteredRowIndexesOriginalOrder(w.grid, w.filterState),
    plColumnIndex: w.plColumnIndex,
    rrCap: w.rrCap,
    initialBalance: w.initialBalance,
    riskPercent: w.riskPercent,
  }), []);

  useEffect(() => {
    fetch(`/api/workbooks/${id}`, { cache: "no-store" })
      .then((r) => r.json() as Promise<WorkbookFull>)
      .then((w) => {
        setWb(w);
        setScope(captureScope(w));
      });
    fetch("/api/settings", { cache: "no-store" })
      .then((r) => r.json() as Promise<{ hasKey: boolean }>)
      .then((s) => setHasKey(s.hasKey))
      .catch(() => setHasKey(false));
    // Session is temporary: everything is discarded on unmount (no persistence).
    return () => abortRef.current?.abort();
  }, [id, captureScope]);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight });
  }, [messages]);

  const filtered = scope ? hasActiveFilters(scope.filterState) : false;
  const scopeLabel = useMemo(() => {
    if (!scope) return "";
    const y = scope.grid.rows.length.toLocaleString("fa-IR");
    const x = scope.rowIndexes.length.toLocaleString("fa-IR");
    return filtered ? `تحلیل روی: ردیف‌های فیلترشده (${x} از ${y} ردیف)` : `تحلیل روی: کل جدول (${y} ردیف)`;
  }, [scope, filtered]);

  const newChat = () => {
    abortRef.current?.abort();
    setMessages([]);
    setBusy(false);
    if (wb) {
      // re-read current state from server so scope reflects latest filters
      fetch(`/api/workbooks/${id}`, { cache: "no-store" })
        .then((r) => r.json() as Promise<WorkbookFull>)
        .then((w) => {
          setWb(w);
          setScope(captureScope(w));
        });
    }
  };

  /** Build the first message (payload + instruction) or a plain follow-up. */
  const send = async (prompt: string, label: string, forceMode?: DataMode) => {
    if (!scope || busy) return;
    if (scope.rowIndexes.length === 0) {
      toast("هیچ ردیفی برای تحلیل وجود ندارد؛ فیلترها را بردارید.", "err");
      return;
    }
    const m = forceMode ?? mode;
    let text = prompt;
    const isFirst = messages.filter((x) => !x.error).length === 0;
    if (isFirst) {
      if (m === "complete") {
        const p = buildCompletePayload(scope);
        if (!p.ok) {
          if (p.reason === "too_large") setTooLarge({ prompt, label });
          else toast("هیچ ردیفی برای تحلیل وجود ندارد؛ فیلترها را بردارید.", "err");
          return;
        }
        text = `${p.text}\n\nTASK: ${prompt}`;
      } else {
        const p = buildSummaryPayload(scope);
        if (!p.ok) {
          toast("هیچ ردیفی برای تحلیل وجود ندارد؛ فیلترها را بردارید.", "err");
          return;
        }
        text = `${p.text}\n\nTASK: ${prompt}`;
      }
    }
    const history = messages.filter((x) => !x.error && !x.streaming).map((x) => ({ role: x.role, text: x.text }));
    const userMsg: Msg = { role: "user", text, display: `${label}${isFirst ? ` (${m === "complete" ? "کامل" : "خلاصه"})` : ""}` };
    const modelMsg: Msg = { role: "model", text: "", display: "", streaming: true };
    setMessages([...messages, userMsg, modelMsg]);
    setBusy(true);
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: [...history, { role: "user", text }] }),
        signal: ctrl.signal,
      });
      if (!res.ok || !res.body) {
        let err = "خطایی رخ داد. لطفاً دوباره تلاش کنید.";
        try {
          err = ((await res.json()) as { error?: string }).error ?? err;
        } catch {
          /* ignore */
        }
        setMessages((ms) => ms.map((x, i) => (i === ms.length - 1 ? { ...x, streaming: false, error: err } : x)));
        return;
      }
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let acc = "";
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        acc += dec.decode(value, { stream: true });
        const snapshot = acc;
        setMessages((ms) => ms.map((x, i) => (i === ms.length - 1 ? { ...x, text: snapshot } : x)));
      }
      const finalText = acc.trim() || "پاسخی دریافت نشد.";
      setMessages((ms) => ms.map((x, i) => (i === ms.length - 1 ? { ...x, text: finalText, streaming: false } : x)));
    } catch (e) {
      if ((e as Error).name === "AbortError") return;
      setMessages((ms) => ms.map((x, i) => (i === ms.length - 1 ? { ...x, streaming: false, error: "عدم اتصال به اینترنت" } : x)));
    } finally {
      setBusy(false);
    }
  };

  const retryLast = () => {
    // remove the failed pair and resend the same user message
    const idx = messages.length - 2;
    if (idx < 0) return;
    const u = messages[idx];
    setMessages(messages.slice(0, idx));
    // the stored user text already contains the payload (if it was the first message) → resend as-is
    setTimeout(() => sendRaw(u.text, u.display), 0);
  };
  const sendRaw = async (text: string, label: string) => {
    // same as send() but without payload building (used by retry)
    if (!scope || busy) return;
    const history = messages.filter((x) => !x.error && !x.streaming).map((x) => ({ role: x.role, text: x.text }));
    setMessages((ms) => [...ms, { role: "user", text, display: label }, { role: "model", text: "", display: "", streaming: true }]);
    setBusy(true);
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    try {
      const res = await fetch("/api/ai/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messages: [...history, { role: "user", text }] }), signal: ctrl.signal });
      if (!res.ok || !res.body) {
        let err = "خطایی رخ داد. لطفاً دوباره تلاش کنید.";
        try { err = ((await res.json()) as { error?: string }).error ?? err; } catch { /* ignore */ }
        setMessages((ms) => ms.map((x, i) => (i === ms.length - 1 ? { ...x, streaming: false, error: err } : x)));
        return;
      }
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let acc = "";
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        acc += dec.decode(value, { stream: true });
        const s = acc;
        setMessages((ms) => ms.map((x, i) => (i === ms.length - 1 ? { ...x, text: s } : x)));
      }
      setMessages((ms) => ms.map((x, i) => (i === ms.length - 1 ? { ...x, text: acc.trim() || "پاسخی دریافت نشد.", streaming: false } : x)));
    } catch (e) {
      if ((e as Error).name === "AbortError") return;
      setMessages((ms) => ms.map((x, i) => (i === ms.length - 1 ? { ...x, streaming: false, error: "عدم اتصال به اینترنت" } : x)));
    } finally {
      setBusy(false);
    }
  };

  const copy = async (t: string) => {
    try {
      await navigator.clipboard.writeText(t);
      toast("کپی شد");
    } catch {
      toast("کپی انجام نشد", "err");
    }
  };

  if (!wb || hasKey === null || !scope) {
    return <div className="grid min-h-screen place-items-center text-muted"><Spinner className="h-7 w-7" /></div>;
  }

  return (
    <div className="mx-auto flex h-dvh max-w-3xl flex-col">
      <header className="flex items-center gap-1 border-b border-line bg-surface-2 px-1 py-1">
        <Link href={`/workbook/${id}`} className="icon-btn" aria-label="بازگشت">{Icons.back({ className: "h-5 w-5 rotate-180" })}</Link>
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-sm font-bold">{wb.name}</h1>
          <p className="text-[10px] text-muted">تحلیلگر استراتژی (Gemini)</p>
        </div>
        <button className="btn-outline" onClick={newChat}>{Icons.chat({ className: "h-4 w-4" })} چت جدید</button>
      </header>

      <div className="border-b border-line bg-surface-2 px-3 py-2">
        <span className={`chip num ${filtered ? "chip-active" : ""}`}>{filtered && Icons.filter({ className: "h-3 w-3", fill: true })} {scopeLabel}</span>
      </div>

      {!hasKey ? (
        <div className="flex flex-1 flex-col items-center justify-center gap-3 p-6 text-center">
          <span className="text-accent">{Icons.sparkle({ className: "h-12 w-12" })}</span>
          <p className="font-bold">کلید API تنظیم نشده است</p>
          <p className="max-w-sm text-sm leading-7 text-muted">برای استفاده از تحلیلگر هوش مصنوعی، ابتدا کلید رایگان Google Gemini خود را در تنظیمات وارد کنید.</p>
          <Link href="/settings" className="btn-primary">رفتن به تنظیمات</Link>
        </div>
      ) : (
        <>
          <div ref={listRef} className="flex-1 space-y-3 overflow-y-auto px-3 py-3">
            {messages.length === 0 && (
              <div className="space-y-3">
                <div className="card">
                  <p className="mb-2 text-xs font-bold">حالت ارسال داده</p>
                  <div className="flex gap-2">
                    <button className={`chip ${mode === "complete" ? "chip-active" : ""}`} onClick={() => setMode("complete")}>کامل</button>
                    <button className={`chip ${mode === "summary" ? "chip-active" : ""}`} onClick={() => setMode("summary")}>خلاصه</button>
                  </div>
                  <p className="mt-2 text-[11px] leading-6 text-muted">
                    {mode === "complete" ? `همه ردیف‌های محدوده (حداکثر ${COMPLETE_MODE_CAP} ردیف) ارسال می‌شود.` : "آمار محاسبه‌شده به‌همراه چند ردیف نمونه ارسال می‌شود (سبک‌تر و سریع‌تر)."}
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {PRESETS.map((p) => (
                    <button key={p.id} className="card text-start hover:border-accent" onClick={() => send(p.prompt, p.label)} disabled={busy}>
                      <span className="text-accent">{Icons.sparkle({ className: "h-5 w-5" })}</span>
                      <span className="mt-1 block text-sm font-bold">{p.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-start" : "justify-end"}`}>
                {m.role === "user" ? (
                  <div className="max-w-[85%] rounded-2xl rounded-tr-sm bg-primary px-3 py-2 text-sm text-primary-fg">{m.display}</div>
                ) : (
                  <div className="max-w-[95%] rounded-2xl rounded-tl-sm border border-line bg-surface-2 px-3 py-2 text-sm">
                    {m.error ? (
                      <div className="flex flex-col gap-2">
                        <span className="text-loss">{m.error}</span>
                        <button className="btn-outline self-start" onClick={retryLast}>تلاش مجدد</button>
                      </div>
                    ) : (
                      <>
                        {m.text ? <Markdown text={m.text} /> : <Spinner className="h-4 w-4" />}
                        {m.streaming && m.text && <span className="inline-block h-4 w-1.5 animate-pulse bg-accent align-middle" />}
                        {!m.streaming && (
                          <div className="mt-2 flex justify-end">
                            <button className="chip" onClick={() => copy(m.text)}>{Icons.copy({ className: "h-3.5 w-3.5" })} کپی</button>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                )}
              </div>
            ))}
            {messages.length > 0 && !busy && (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {PRESETS.map((p) => (
                  <button key={p.id} className="chip hover:border-accent" onClick={() => send(p.prompt, p.label)}>{p.label}</button>
                ))}
              </div>
            )}
          </div>
          <form
            className="border-t border-line bg-surface-2 px-3 pt-2 pb-1"
            onSubmit={(e) => {
              e.preventDefault();
              const q = input.trim();
              if (!q) return;
              setInput("");
              send(q, q);
            }}
          >
            <div className="flex items-center gap-2">
              <input className="input" placeholder="سؤال خود را درباره این داده‌ها بپرسید…" value={input} onChange={(e) => setInput(e.target.value)} disabled={busy} />
              <button type="submit" className="btn-primary h-10 w-10 shrink-0 rounded-full p-0" disabled={busy || !input.trim()} aria-label="ارسال">
                {busy ? <Spinner className="h-4 w-4" /> : Icons.send({ className: "h-4 w-4 -scale-x-100" })}
              </button>
            </div>
            <p className="mt-1.5 text-center text-[10px] text-muted">با هر تحلیل، داده‌های جدول برای پردازش به سرور گوگل (Gemini) ارسال می‌شود.</p>
          </form>
        </>
      )}

      <Sheet open={!!tooLarge} onClose={() => setTooLarge(null)} title="جدول برای حالت کامل بزرگ است">
        <p className="text-sm leading-7 text-muted">
          محدوده انتخاب‌شده {scope.rowIndexes.length.toLocaleString("fa-IR")} ردیف دارد و از سقف {COMPLETE_MODE_CAP} ردیفِ حالت «کامل» بیشتر است. می‌توانید به‌جای آن «خلاصه» (آمار + نمونه ردیف‌ها) را ارسال کنید یا با فیلتر کردن، تعداد ردیف‌ها را کم کنید.
        </p>
        <div className="mt-4 flex gap-2">
          <button className="btn-primary flex-1" onClick={() => { const t = tooLarge; setTooLarge(null); setMode("summary"); if (t) send(t.prompt, t.label, "summary"); }}>ارسال خلاصه</button>
          <button className="btn-outline flex-1" onClick={() => setTooLarge(null)}>انصراف</button>
        </div>
      </Sheet>
    </div>
  );
}

/* ------------------------- tiny markdown renderer ------------------------- */
function inline(s: string): ReactNode[] {
  const parts = s.split(/(\*\*[^*]+\*\*|`[^`]+`)/g);
  return parts.map((p, i) => {
    if (p.startsWith("**") && p.endsWith("**")) return <strong key={i}>{p.slice(2, -2)}</strong>;
    if (p.startsWith("`") && p.endsWith("`")) return <code key={i} className="rounded bg-surface-3 px-1 num">{p.slice(1, -1)}</code>;
    return <span key={i}>{p}</span>;
  });
}

export function Markdown({ text }: { text: string }) {
  const lines = text.replace(/\r/g, "").split("\n");
  const out: ReactNode[] = [];
  let list: { type: "ul" | "ol"; items: string[] } | null = null;
  const flush = () => {
    if (!list) return;
    const L = list;
    out.push(L.type === "ul" ? <ul key={out.length}>{L.items.map((it, i) => <li key={i}>{inline(it)}</li>)}</ul> : <ol key={out.length}>{L.items.map((it, i) => <li key={i}>{inline(it)}</li>)}</ol>);
    list = null;
  };
  for (const raw of lines) {
    const line = raw.trimEnd();
    const h = /^(#{1,3})\s+(.*)$/.exec(line);
    const ul = /^\s*[-*•]\s+(.*)$/.exec(line);
    const ol = /^\s*\d+[.)]\s+(.*)$/.exec(line);
    if (h) {
      flush();
      const Tag = (`h${h[1].length}` as "h1" | "h2" | "h3");
      out.push(<Tag key={out.length}>{inline(h[2])}</Tag>);
    } else if (ul) {
      if (!list || list.type !== "ul") {
        flush();
        list = { type: "ul", items: [] };
      }
      list.items.push(ul[1]);
    } else if (ol) {
      if (!list || list.type !== "ol") {
        flush();
        list = { type: "ol", items: [] };
      }
      list.items.push(ol[1]);
    } else if (/^\s*(-{3,}|\*{3,})\s*$/.test(line)) {
      flush();
      out.push(<hr key={out.length} />);
    } else if (line.trim() === "") {
      flush();
    } else {
      flush();
      out.push(<p key={out.length}>{inline(line)}</p>);
    }
  }
  flush();
  return <div className="md">{out}</div>;
}

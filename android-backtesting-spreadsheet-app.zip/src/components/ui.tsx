"use client";

import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";

/* ----------------------------- Icons (inline SVG) ----------------------------- */
const I = ({ d, className = "h-5 w-5", fill = false }: { d: string; className?: string; fill?: boolean }) => (
  <svg viewBox="0 0 24 24" className={className} fill={fill ? "currentColor" : "none"} stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d={d} />
  </svg>
);
export const Icons = {
  back: (p?: { className?: string }) => <I {...p} d="M5 12h14M12 5l7 7-7 7" />,
  undo: (p?: { className?: string }) => <I {...p} d="M9 14 4 9l5-5M4 9h10a6 6 0 0 1 0 12h-3" />,
  redo: (p?: { className?: string }) => <I {...p} d="m15 14 5-5-5-5M20 9H10a6 6 0 0 0 0 12h3" />,
  search: (p?: { className?: string }) => <I {...p} d="M21 21l-4.3-4.3M11 18a7 7 0 1 1 0-14 7 7 0 0 1 0 14z" />,
  stats: (p?: { className?: string }) => <I {...p} d="M3 3v18h18M7 15l4-4 4 3 5-6" />,
  sparkle: (p?: { className?: string }) => <I {...p} d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3zM5 19l.7 2 .7-2 2-.7-2-.7-.7-2-.7 2-2 .7 2 .7z" />,
  more: (p?: { className?: string }) => <I {...p} d="M12 6h.01M12 12h.01M12 18h.01" />,
  filter: (p?: { className?: string; fill?: boolean }) => <I {...p} d="M3 5h18l-7 8v6l-4-2v-4L3 5z" />,
  plus: (p?: { className?: string }) => <I {...p} d="M12 5v14M5 12h14" />,
  save: (p?: { className?: string }) => <I {...p} d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2zM17 21v-8H7v8M7 3v5h8" />,
  close: (p?: { className?: string }) => <I {...p} d="M18 6 6 18M6 6l12 12" />,
  settings: (p?: { className?: string }) => <I {...p} d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z" />,
  copy: (p?: { className?: string }) => <I {...p} d="M8 8h12v12H8zM16 8V4H4v12h4" />,
  send: (p?: { className?: string }) => <I {...p} d="M22 2 11 13M22 2l-7 20-4-9-9-4 20-7z" />,
  eye: (p?: { className?: string }) => <I {...p} d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12zm10 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />,
  eyeOff: (p?: { className?: string }) => <I {...p} d="M3 3l18 18M10.6 10.6a3 3 0 0 0 4.2 4.2M9.9 5.1A10.4 10.4 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3 3.9M6.1 6.1A16.7 16.7 0 0 0 2 12s3.5 7 10 7c1.4 0 2.6-.3 3.7-.7" />,
  sortAsc: (p?: { className?: string }) => <I {...p} d="M3 6h9M3 12h6M3 18h3M17 20V4M13 8l4-4 4 4" />,
  sortDesc: (p?: { className?: string }) => <I {...p} d="M3 6h3M3 12h6M3 18h9M17 4v16M13 16l4 4 4-4" />,
  table: (p?: { className?: string }) => <I {...p} d="M3 5h18v14H3zM3 10h18M3 15h18M9 5v14M15 5v14" />,
  upload: (p?: { className?: string }) => <I {...p} d="M12 16V4M6 10l6-6 6 6M4 20h16" />,
  download: (p?: { className?: string }) => <I {...p} d="M12 4v12M6 10l6 6 6-6M4 20h16" />,
  trash: (p?: { className?: string }) => <I {...p} d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 11v6M14 11v6" />,
  edit: (p?: { className?: string }) => <I {...p} d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />,
  dup: (p?: { className?: string }) => <I {...p} d="M8 8h12v12H8zM4 16V4h12" />,
  check: (p?: { className?: string }) => <I {...p} d="M20 6 9 17l-5-5" />,
  chat: (p?: { className?: string }) => <I {...p} d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />,
};

/* ----------------------------- Toast ----------------------------- */
const ToastCtx = createContext<(msg: string, kind?: "ok" | "err") => void>(() => undefined);
export const useToast = () => useContext(ToastCtx);

export function ToastHost({ children }: { children: ReactNode }) {
  const [toast, setToast] = useState<{ msg: string; kind: "ok" | "err"; id: number } | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const show = useCallback((msg: string, kind: "ok" | "err" = "ok") => {
    if (timer.current) clearTimeout(timer.current);
    setToast({ msg, kind, id: Date.now() });
    timer.current = setTimeout(() => setToast(null), 3200);
  }, []);
  return (
    <ToastCtx.Provider value={show}>
      {children}
      {toast && (
        <div className="pointer-events-none fixed inset-x-0 bottom-20 z-[100] flex justify-center px-4">
          <div className={`pointer-events-auto rounded-xl px-4 py-2.5 text-sm shadow-lg ${toast.kind === "ok" ? "bg-fg text-surface" : "bg-loss text-white"}`}>{toast.msg}</div>
        </div>
      )}
    </ToastCtx.Provider>
  );
}

/* ----------------------------- Sheet / Modal ----------------------------- */
export function Sheet({ open, onClose, title, children, wide = false }: { open: boolean; onClose: () => void; title?: ReactNode; children: ReactNode; wide?: boolean }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[90] flex items-end justify-center sm:items-center" role="dialog" aria-modal>
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className={`relative flex max-h-[88vh] w-full flex-col rounded-t-3xl bg-surface-2 shadow-2xl sm:rounded-3xl ${wide ? "sm:max-w-2xl" : "sm:max-w-md"}`}>
        <div className="mx-auto mt-2 h-1.5 w-12 rounded-full bg-line sm:hidden" />
        {title !== undefined && (
          <div className="flex items-center justify-between px-4 pt-3 pb-1">
            <h3 className="text-base font-bold">{title}</h3>
            <button className="icon-btn" onClick={onClose} aria-label="بستن">
              {Icons.close()}
            </button>
          </div>
        )}
        <div className="overflow-y-auto px-4 pb-5">{children}</div>
      </div>
    </div>
  );
}

export function Confirm({ open, title, message, confirmLabel = "تأیید", danger, onCancel, onConfirm }: { open: boolean; title: string; message?: string; confirmLabel?: string; danger?: boolean; onCancel: () => void; onConfirm: () => void }) {
  return (
    <Sheet open={open} onClose={onCancel} title={title}>
      {message && <p className="text-sm text-muted leading-7">{message}</p>}
      <div className="mt-4 flex gap-2">
        <button className={danger ? "btn-danger flex-1" : "btn-primary flex-1"} onClick={onConfirm}>
          {confirmLabel}
        </button>
        <button className="btn-outline flex-1" onClick={onCancel}>
          انصراف
        </button>
      </div>
    </Sheet>
  );
}

export function PromptDialog({ open, title, label, initial = "", onCancel, onSubmit }: { open: boolean; title: string; label?: string; initial?: string; onCancel: () => void; onSubmit: (v: string) => void }) {
  const [v, setV] = useState(initial);
  useEffect(() => {
    if (open) setV(initial);
  }, [open, initial]);
  return (
    <Sheet open={open} onClose={onCancel} title={title}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (v.trim()) onSubmit(v.trim());
        }}
      >
        {label && <label className="mb-1 block text-xs text-muted">{label}</label>}
        <input className="input" value={v} onChange={(e) => setV(e.target.value)} autoFocus />
        <div className="mt-4 flex gap-2">
          <button type="submit" className="btn-primary flex-1">
            ذخیره
          </button>
          <button type="button" className="btn-outline flex-1" onClick={onCancel}>
            انصراف
          </button>
        </div>
      </form>
    </Sheet>
  );
}

export function MenuList({ items }: { items: { label: string; icon?: ReactNode; danger?: boolean; onClick: () => void }[] }) {
  return (
    <ul className="divide-y divide-line">
      {items.map((it, i) => (
        <li key={i}>
          <button className={`flex w-full items-center gap-3 px-2 py-3 text-sm hover:bg-surface-3 rounded-lg ${it.danger ? "text-loss" : ""}`} onClick={it.onClick}>
            {it.icon}
            <span>{it.label}</span>
          </button>
        </li>
      ))}
    </ul>
  );
}

export function Spinner({ className = "h-5 w-5" }: { className?: string }) {
  return <svg className={`animate-spin ${className}`} viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" className="opacity-25" /><path d="M22 12a10 10 0 0 1-10 10" stroke="currentColor" strokeWidth="3" strokeLinecap="round" /></svg>;
}

export function formatDate(iso: string): string {
  try {
    return new Intl.DateTimeFormat("fa-IR", { dateStyle: "medium", timeStyle: "short" }).format(new Date(iso));
  } catch {
    return iso;
  }
}

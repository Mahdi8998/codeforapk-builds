"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useTheme, type ThemeMode } from "./ThemeProvider";
import { Icons, Spinner, ToastHost, useToast } from "./ui";

export default function SettingsClient() {
  return (
    <ToastHost>
      <Settings />
    </ToastHost>
  );
}

function Settings() {
  const { theme, setTheme } = useTheme();
  const toast = useToast();
  const [key, setKey] = useState("");
  const [masked, setMasked] = useState("");
  const [hasKey, setHasKey] = useState(false);
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState<"save" | "test" | null>(null);

  useEffect(() => {
    fetch("/api/settings", { cache: "no-store" })
      .then((r) => r.json() as Promise<{ hasKey: boolean; keyMasked: string }>)
      .then((s) => {
        setHasKey(s.hasKey);
        setMasked(s.keyMasked);
      });
  }, []);

  const saveKey = async () => {
    setBusy("save");
    try {
      await fetch("/api/settings", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ apiKey: key }) });
      toast(key.trim() ? "کلید ذخیره شد" : "کلید حذف شد");
      const s = (await (await fetch("/api/settings", { cache: "no-store" })).json()) as { hasKey: boolean; keyMasked: string };
      setHasKey(s.hasKey);
      setMasked(s.keyMasked);
      setKey("");
    } finally {
      setBusy(null);
    }
  };

  const test = async () => {
    setBusy("test");
    try {
      const r = await fetch("/api/ai/test", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ apiKey: key.trim() || undefined }) });
      const j = (await r.json()) as { ok: boolean; message: string };
      toast(j.message, j.ok ? "ok" : "err");
      if (j.ok && key.trim()) {
        setHasKey(true);
        const s = (await (await fetch("/api/settings", { cache: "no-store" })).json()) as { keyMasked: string };
        setMasked(s.keyMasked);
        setKey("");
      }
    } catch {
      toast("عدم اتصال به اینترنت", "err");
    } finally {
      setBusy(null);
    }
  };

  const themes: { id: ThemeMode; label: string }[] = [
    { id: "light", label: "روشن" },
    { id: "dark", label: "تیره" },
    { id: "system", label: "مطابق سیستم" },
  ];

  return (
    <div className="mx-auto flex min-h-screen max-w-2xl flex-col">
      <header className="flex items-center gap-1 border-b border-line bg-surface-2 px-1 py-1">
        <Link href="/" className="icon-btn" aria-label="بازگشت">{Icons.back({ className: "h-5 w-5 rotate-180" })}</Link>
        <h1 className="text-sm font-bold">تنظیمات</h1>
      </header>
      <main className="space-y-4 p-4">
        <section className="card">
          <h2 className="mb-2 text-sm font-bold">پوسته</h2>
          <div className="flex gap-2">
            {themes.map((t) => (
              <button key={t.id} className={`chip ${theme === t.id ? "chip-active" : ""}`} onClick={() => setTheme(t.id)}>{t.label}</button>
            ))}
          </div>
        </section>

        <section className="card">
          <h2 className="mb-2 text-sm font-bold">هوش مصنوعی</h2>
          <label className="mb-1 block text-xs text-muted">کلید API گوگل Gemini</label>
          <div className="relative">
            <input className="input pe-10" style={{ direction: "ltr" }} type={show ? "text" : "password"} value={key} onChange={(e) => setKey(e.target.value)} placeholder={hasKey ? masked : "AIza…"} autoComplete="off" />
            <button type="button" className="absolute inset-y-0 start-auto end-2 my-auto h-8 w-8 text-muted" onClick={() => setShow((s) => !s)} aria-label="نمایش/مخفی">
              {show ? Icons.eyeOff({ className: "h-5 w-5" }) : Icons.eye({ className: "h-5 w-5" })}
            </button>
          </div>
          <p className="mt-2 text-[11px] leading-6 text-muted">
            کلید رایگان را از <a className="text-primary underline" href="https://aistudio.google.com/apikey" target="_blank" rel="noreferrer">aistudio.google.com/apikey</a> بگیرید. کلید فقط روی همین سرور ذخیره می‌شود، هرگز لاگ نمی‌شود و فقط به سرویس Gemini ارسال می‌شود. مدل: gemini-2.5-flash
          </p>
          {hasKey && <p className="mt-1 text-[11px] text-win">کلید ذخیره شده است ({masked})</p>}
          <div className="mt-3 flex gap-2">
            <button className="btn-primary" onClick={saveKey} disabled={busy !== null || (!key.trim() && !hasKey)}>
              {busy === "save" ? <Spinner className="h-4 w-4" /> : Icons.save({ className: "h-4 w-4" })} ذخیره کلید
            </button>
            <button className="btn-outline" onClick={test} disabled={busy !== null || (!key.trim() && !hasKey)}>
              {busy === "test" ? <Spinner className="h-4 w-4" /> : Icons.check({ className: "h-4 w-4" })} تست اتصال
            </button>
          </div>
        </section>

        <section className="card text-[11px] leading-6 text-muted">
          <p>• داده‌های جدول فقط زمانی که شما یک تحلیل هوش مصنوعی را اجرا می‌کنید از دستگاه خارج می‌شوند.</p>
          <p>• هیچ ردیابی یا آماری جمع‌آوری نمی‌شود. گفتگوهای هوش مصنوعی ذخیره نمی‌شوند.</p>
        </section>
      </main>
    </div>
  );
}

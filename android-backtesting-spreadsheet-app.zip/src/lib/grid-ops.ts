import type { Grid } from "./types";

const blankRow = (n: number) => Array.from({ length: n }, () => "");

export function setCell(g: Grid, r: number, c: number, value: string): Grid {
  if ((g.rows[r]?.[c] ?? "") === value) return g;
  const rows = g.rows.slice();
  const row = rows[r].slice();
  row[c] = value;
  rows[r] = row;
  return { ...g, rows };
}

export function addRow(g: Grid): Grid {
  return { ...g, rows: [...g.rows, blankRow(g.headers.length)] };
}

export function insertRow(g: Grid, at: number): Grid {
  const rows = g.rows.slice();
  rows.splice(at, 0, blankRow(g.headers.length));
  return { ...g, rows };
}

export function duplicateRow(g: Grid, r: number): Grid {
  const rows = g.rows.slice();
  rows.splice(r + 1, 0, g.rows[r].slice());
  return { ...g, rows };
}

export function deleteRow(g: Grid, r: number): Grid {
  const rows = g.rows.slice();
  rows.splice(r, 1);
  return { ...g, rows };
}

export function renameColumn(g: Grid, c: number, name: string): Grid {
  const headers = g.headers.slice();
  headers[c] = name;
  return { ...g, headers };
}

/** Returns new grid and a mapper old column index -> new index (null if removed). */
export function insertColumn(g: Grid, at: number, name: string): { grid: Grid; map: (i: number) => number | null } {
  const headers = g.headers.slice();
  headers.splice(at, 0, name);
  const rows = g.rows.map((row) => {
    const r = row.slice();
    r.splice(at, 0, "");
    return r;
  });
  return { grid: { headers, rows }, map: (i) => (i >= at ? i + 1 : i) };
}

export function deleteColumn(g: Grid, c: number): { grid: Grid; map: (i: number) => number | null } {
  const headers = g.headers.slice();
  headers.splice(c, 1);
  const rows = g.rows.map((row) => {
    const r = row.slice();
    r.splice(c, 1);
    return r;
  });
  return { grid: { headers, rows }, map: (i) => (i === c ? null : i > c ? i - 1 : i) };
}

export function moveColumn(g: Grid, from: number, to: number): { grid: Grid; map: (i: number) => number | null } {
  if (to < 0 || to >= g.headers.length || from === to) return { grid: g, map: (i) => i };
  const mv = <T,>(arr: T[]) => {
    const a = arr.slice();
    const [x] = a.splice(from, 1);
    a.splice(to, 0, x);
    return a;
  };
  const grid = { headers: mv(g.headers), rows: g.rows.map((r) => mv(r)) };
  const map = (i: number): number => {
    if (i === from) return to;
    if (from < to && i > from && i <= to) return i - 1;
    if (from > to && i >= to && i < from) return i + 1;
    return i;
  };
  return { grid, map };
}

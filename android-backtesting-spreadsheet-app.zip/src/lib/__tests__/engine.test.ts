import { describe, expect, it } from "vitest";
import { parseNumber } from "../numbers";
import { applyCap, computeStats, parseResult, validateBalance, validateRisk, validateRrCap, type StatsInput } from "../stats-engine";
import { filteredRowIndexesOriginalOrder, uniqueValues, visibleRowIndexes } from "../filters";
import { buildCompletePayload, buildSummaryPayload, mapAiError, scopeHeader, statsForScope, type AiScope } from "../ai";
import { gridFromXlsx, gridToXlsx } from "../xlsx";
import type { FilterState, Grid } from "../types";

const headers = ["جفت‌ارز", "جهت", "نتیجه"];
// dash, 1, 2, 3, empty interleaved
const rows = [
  ["EURUSD", "خرید", "-"],
  ["GBPUSD", "فروش", "1"],
  ["EURUSD", "خرید", ""],
  ["XAUUSD", "فروش", "2"],
  ["GBPUSD", "خرید", "3"],
  ["EURUSD", "فروش", "-"],
  ["XAUUSD", "خرید", ""],
  ["EURUSD", "خرید", "۳"],
];
const grid: Grid = { headers, rows };
const noFilter: FilterState = { columns: {}, search: "", sort: null };
const input = (over: Partial<StatsInput> = {}): StatsInput => ({
  headers,
  rows,
  totalRows: rows.length,
  plColumnIndex: 2,
  rrCap: null,
  initialBalance: 500,
  riskPercent: 2,
  groupColumnIndex: 0,
  ...over,
});

describe("parser", () => {
  it("parses persian/arabic digits and separators", () => {
    expect(parseNumber("۱۲۳٫۵")).toBe(123.5);
    expect(parseNumber("١٢٣")).toBe(123);
    expect(parseNumber("1,234.5")).toBe(1234.5);
    expect(parseNumber("abc")).toBeNull();
    expect(parseNumber("")).toBeNull();
  });
  it("parses results", () => {
    expect(parseResult("-")).toEqual({ kind: "loss", value: -1 });
    expect(parseResult("−")).toEqual({ kind: "loss", value: -1 });
    expect(parseResult("  -  ")).toEqual({ kind: "loss", value: -1 });
    expect(parseResult("۳")).toEqual({ kind: "win", value: 3 });
    expect(parseResult("1.5")).toEqual({ kind: "win", value: 1.5 });
    expect(parseResult("-2")).toEqual({ kind: "loss", value: -2 });
    expect(parseResult("").kind).toBe("excluded");
    expect(parseResult("   ").kind).toBe("excluded");
    expect(parseResult("0").kind).toBe("excluded");
    expect(parseResult("win").kind).toBe("excluded");
  });
  it("cap", () => {
    expect(applyCap(3, 1)).toBe(1);
    expect(applyCap(1, 2)).toBe(1);
    expect(applyCap(-1, 1)).toBe(-1);
    expect(applyCap(3, null)).toBe(3);
    expect(applyCap(3, 1.5)).toBe(1.5);
  });
});

describe("filters", () => {
  it("unique values with counts", () => {
    const u = uniqueValues(grid, 0);
    expect(u.find((x) => x.value === "EURUSD")?.count).toBe(4);
  });
  it("AND across columns + search", () => {
    const fs: FilterState = { columns: { "0": { values: ["EURUSD"] }, "1": { values: ["خرید"] } }, search: "", sort: null };
    expect(visibleRowIndexes(grid, fs)).toEqual([0, 2, 7]);
    expect(visibleRowIndexes(grid, { ...fs, search: "۳" })).toEqual([7]);
    expect(visibleRowIndexes(grid, noFilter).length).toBe(8);
  });
  it("numeric-aware sort", () => {
    const g: Grid = { headers: ["n"], rows: [["10"], ["9"], ["100"]] };
    expect(visibleRowIndexes(g, { columns: {}, search: "", sort: { column: 0, direction: "asc" } })).toEqual([1, 0, 2]);
  });
});

describe("stats engine", () => {
  it("R metrics on mixed data with exclusions", () => {
    const r = computeStats(input());
    expect(r.excludedCount).toBe(2);
    expect(r.r?.count).toBe(6);
    expect(r.r?.netR).toBe(1 + 2 + 3 + 3 - 2);
    expect(r.r?.winRate).toBeCloseTo((4 / 6) * 100);
    expect(r.r?.profitFactor).toBeCloseTo(9 / 2);
    expect(r.r?.best).toBe(3);
    expect(r.r?.worst).toBe(-1);
    expect(r.r?.maxConsecWins).toBe(3);
    expect(r.r?.maxConsecLosses).toBe(1);
    expect(r.rEquity.length).toBe(6);
    expect(r.rEquity[5].y).toBe(r.r?.netR);
  });
  it("profit factor infinity with no losses", () => {
    const r = computeStats(input({ rows: [["a", "b", "1"], ["a", "b", "2"]] }));
    expect(r.r?.profitFactor).toBe(Infinity);
  });
  it("dollar simulation hand-calculated", () => {
    const r = computeStats(input());
    // 500 → 490 → 499.8 → (skip) → 519.792 → 550.97952 → 539.9599296 → (skip) → 572.3575254
    const b = r.trades.map((t) => t.balanceAfter);
    expect(b[0]).toBeCloseTo(490, 6);
    expect(b[1]).toBeCloseTo(499.8, 6);
    expect(b[2]).toBeCloseTo(519.792, 6);
    expect(b[3]).toBeCloseTo(550.97952, 6);
    expect(r.dollar?.finalBalance).toBeCloseTo(572.3575254, 4);
    expect(r.dollarEquity[r.dollarEquity.length - 1].y).toBeCloseTo(r.dollar!.finalBalance);
    // simple examples from spec
    const one = (res: string, cap: number | null = null) => computeStats(input({ rows: [["a", "b", res]], rrCap: cap })).dollar!.finalBalance;
    expect(one("-")).toBeCloseTo(490);
    expect(one("1")).toBeCloseTo(510);
    expect(one("2")).toBeCloseTo(520);
    expect(one("3", 1)).toBeCloseTo(510);
  });
  it("max dollar drawdown", () => {
    const r = computeStats(input({ rows: [["a", "b", "2"], ["a", "b", "-"], ["a", "b", "-"]] }));
    // 520 → 509.6 → 499.408 ; peak 520 → dd 20.592 (3.96%)
    expect(r.dollar?.maxDrawdown).toBeCloseTo(20.592, 4);
    expect(r.dollar?.maxDrawdownPct).toBeCloseTo((20.592 / 520) * 100, 4);
  });
  it("group dollar effect = sum of single-trade effects", () => {
    const r = computeStats(input());
    const eur = r.groups.find((g) => g.value === "EURUSD")!;
    expect(eur.netDollar).toBeCloseTo(10 * (-1 - 1 + 3));
    expect(eur.count).toBe(3);
  });
  it("R:R cap matrix", () => {
    const off = computeStats(input());
    const c2 = computeStats(input({ rrCap: 2 }));
    const c1 = computeStats(input({ rrCap: 1 }));
    expect([off.r?.best, c2.r?.best, c1.r?.best]).toEqual([3, 2, 1]);
    expect(c1.r?.netR).toBe(4 - 2);
    expect(off.r?.winRate).toBe(c2.r?.winRate);
    expect(off.r?.winRate).toBe(c1.r?.winRate);
    expect(off.r?.count).toBe(c1.r?.count);
    expect(off.r?.maxConsecLosses).toBe(c1.r?.maxConsecLosses);
    expect(off.r?.maxConsecWins).toBe(c1.r?.maxConsecWins);
    expect(off.r?.avgLoss).toBe(c1.r?.avgLoss);
    expect(off.dollar?.finalBalance).not.toBe(c1.dollar?.finalBalance);
  });
  it("balance/risk change only dollar fields", () => {
    const a = computeStats(input());
    const b = computeStats(input({ riskPercent: 1 }));
    const c = computeStats(input({ initialBalance: 1000 }));
    expect(JSON.stringify(a.r)).toBe(JSON.stringify(b.r));
    expect(JSON.stringify(a.r)).toBe(JSON.stringify(c.r));
    expect(a.dollar?.finalBalance).not.toBe(b.dollar?.finalBalance);
    expect(c.dollar?.netProfit).toBeCloseTo(a.dollar!.netProfit * 2);
  });
  it("filters: losses-only / wins-only", () => {
    const losses = filteredRowIndexesOriginalOrder(grid, { columns: { "2": { values: ["-"] } }, search: "", sort: null });
    const l = computeStats(input({ rows: losses.map((i) => rows[i]) }));
    expect(l.r?.winRate).toBe(0);
    expect(l.r?.maxConsecLosses).toBe(2);
    const wins = filteredRowIndexesOriginalOrder(grid, { columns: { "2": { values: ["1", "2", "3", "۳"] } }, search: "", sort: null });
    const w = computeStats(input({ rows: wins.map((i) => rows[i]) }));
    expect(w.r?.winRate).toBe(100);
    expect(w.r?.profitFactor).toBe(Infinity);
  });
  it("empty and no-result-column", () => {
    const e = computeStats(input({ rows: [] }));
    expect(e.r).toBeNull();
    expect(e.dollar).toBeNull();
    const n = computeStats(input({ plColumnIndex: null }));
    expect(n.resultColumnSet).toBe(false);
  });
  it("validation", () => {
    expect(validateBalance("0").ok).toBe(false);
    expect(validateBalance("-5").ok).toBe(false);
    expect(validateRisk("0").ok).toBe(false);
    expect(validateRisk("101").ok).toBe(false);
    expect(validateRrCap("0").ok).toBe(false);
    const v = validateBalance("۱٬۰۰۰٫۵");
    expect(v.ok && v.value).toBe(1000.5);
    const r = validateRisk("۲٫۵");
    expect(r.ok && r.value).toBe(2.5);
  });
});

describe("AI payload", () => {
  const mk = (fs: FilterState): AiScope => ({
    grid,
    filterState: fs,
    rowIndexes: filteredRowIndexesOriginalOrder(grid, fs),
    plColumnIndex: 2,
    rrCap: null,
    initialBalance: 500,
    riskPercent: 2,
  });
  it("scope header + filtered rows only", () => {
    const fs: FilterState = { columns: { "0": { values: ["EURUSD"] }, "1": { values: ["خرید"] } }, search: "۳", sort: null };
    const s = mk(fs);
    const h = scopeHeader(s);
    expect(h).toContain("FILTERED SUBSET (1 of 8 total rows)");
    expect(h).toContain('جفت‌ارز = ["EURUSD"]');
    expect(h).toContain('search term = "۳"');
    const p = buildCompletePayload(s);
    expect(p.ok && p.text.split("\n").filter((l) => l.startsWith("EURUSD")).length).toBe(1);
    expect(scopeHeader(mk(noFilter))).toContain("FULL TABLE (8 rows)");
  });
  it("summary equals engine + sample from filtered rows", () => {
    const fs: FilterState = { columns: { "2": { values: ["-"] } }, search: "", sort: null };
    const s = mk(fs);
    const p = buildSummaryPayload(s);
    expect(p.ok).toBe(true);
    if (!p.ok) return;
    const st = statsForScope(s);
    expect(p.stats.r?.winRate).toBe(st.r?.winRate);
    const j = JSON.parse(p.text.split("DATA SUMMARY (JSON):\n")[1]);
    expect(j.rMetrics.winRatePct).toBe(0);
    for (const r of j.sampleRows.rows) expect(r[2]).toBe("-");
  });
  it("cap 500 + empty", () => {
    const big: Grid = { headers, rows: Array.from({ length: 501 }, () => ["a", "b", "1"]) };
    const s: AiScope = { ...mk(noFilter), grid: big, rowIndexes: big.rows.map((_, i) => i) };
    expect(buildCompletePayload(s)).toEqual({ ok: false, reason: "too_large" });
    const empty: AiScope = { ...mk(noFilter), rowIndexes: [] };
    expect(buildCompletePayload(empty)).toEqual({ ok: false, reason: "empty" });
    expect(buildSummaryPayload(empty).ok).toBe(false);
  });
  it("error mapping", () => {
    expect(mapAiError(401)).toBe("کلید API نامعتبر است");
    expect(mapAiError(403)).toBe("کلید API نامعتبر است");
    expect(mapAiError(429)).toContain("محدودیت");
    expect(mapAiError(null, "network")).toBe("عدم اتصال به اینترنت");
  });
});

describe("xlsx round trip", () => {
  it("preserves persian strings and numbers", () => {
    const buf = gridToXlsx(headers, rows);
    const g = gridFromXlsx(buf);
    expect(g.headers).toEqual(headers);
    expect(g.rows).toEqual(rows);
  });
  it("serialization round trip", () => {
    const fs: FilterState = { columns: { "0": { values: ["EURUSD"] } }, search: "x", sort: { column: 1, direction: "desc" } };
    expect(JSON.parse(JSON.stringify({ grid, fs }))).toEqual({ grid, fs });
  });
});

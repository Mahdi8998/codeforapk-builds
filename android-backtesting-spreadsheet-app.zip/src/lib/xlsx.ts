import * as XLSX from "xlsx";
import type { Grid } from "./types";

/** Build a Grid from an xlsx binary (first sheet only, first row = headers, skips empty leading rows/cols). */
export function gridFromXlsx(data: ArrayBuffer | Uint8Array): Grid {
  const wb = XLSX.read(data, { type: "array", cellDates: false, raw: false });
  const sheetName = wb.SheetNames[0];
  if (!sheetName) throw new Error("فایل هیچ برگه‌ای ندارد");
  const ws = wb.Sheets[sheetName];
  const aoa = XLSX.utils.sheet_to_json<unknown[]>(ws, { header: 1, defval: "", raw: false, blankrows: false });
  const matrix: string[][] = aoa.map((r) => (Array.isArray(r) ? r.map((c) => (c == null ? "" : String(c))) : []));
  // drop leading empty rows
  while (matrix.length && matrix[0].every((c) => c.trim() === "")) matrix.shift();
  if (matrix.length === 0) throw new Error("برگه اول خالی است");
  // find leading empty columns (empty in every row)
  const width = Math.max(...matrix.map((r) => r.length));
  let firstCol = 0;
  while (firstCol < width && matrix.every((r) => (r[firstCol] ?? "").trim() === "")) firstCol++;
  let lastCol = width - 1;
  while (lastCol > firstCol && matrix.every((r) => (r[lastCol] ?? "").trim() === "")) lastCol--;
  const cols = lastCol - firstCol + 1;
  const normalized = matrix.map((r) => Array.from({ length: cols }, (_, i) => (r[firstCol + i] ?? "").toString()));
  const headers = normalized[0].map((h, i) => (h.trim() === "" ? `ستون ${i + 1}` : h.trim()));
  const rows = normalized.slice(1).filter((r) => r.some((c) => c.trim() !== ""));
  return { headers, rows };
}

/** Serialize a grid (headers + given rows) to an xlsx ArrayBuffer. */
export function gridToXlsx(headers: string[], rows: string[][], sheetName = "Sheet1"): ArrayBuffer {
  const aoa: string[][] = [headers, ...rows.map((r) => headers.map((_, c) => r[c] ?? ""))];
  const ws = XLSX.utils.aoa_to_sheet(aoa);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheetName);
  return XLSX.write(wb, { type: "array", bookType: "xlsx" }) as ArrayBuffer;
}

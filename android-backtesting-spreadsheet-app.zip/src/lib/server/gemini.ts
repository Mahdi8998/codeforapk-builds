import { eq } from "drizzle-orm";
import { db } from "@/db";
import { appSettings } from "@/db/schema";
import { GEMINI_MODEL } from "@/lib/ai";

export const API_KEY_SETTING = "gemini_api_key";

export async function getApiKey(): Promise<string | null> {
  const [row] = await db.select().from(appSettings).where(eq(appSettings.key, API_KEY_SETTING));
  const v = row?.value?.trim();
  return v ? v : process.env.GEMINI_API_KEY?.trim() || null;
}

export async function setApiKey(value: string): Promise<void> {
  await db
    .insert(appSettings)
    .values({ key: API_KEY_SETTING, value })
    .onConflictDoUpdate({ target: appSettings.key, set: { value } });
}

export interface GeminiMessage {
  role: "user" | "model";
  text: string;
}

export function geminiUrl(stream: boolean): string {
  const base = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}`;
  return stream ? `${base}:streamGenerateContent?alt=sse` : `${base}:generateContent`;
}

export function buildBody(system: string | null, messages: GeminiMessage[]) {
  return {
    ...(system ? { systemInstruction: { parts: [{ text: system }] } } : {}),
    contents: messages.map((m) => ({ role: m.role, parts: [{ text: m.text }] })),
    generationConfig: { temperature: 0.4 },
  };
}

/** Map a Gemini HTTP failure to a Persian message (never leaks the key). */
export async function describeFailure(res: Response): Promise<{ status: number; message: string }> {
  let detail = "";
  try {
    const j = (await res.json()) as { error?: { message?: string } };
    detail = j?.error?.message ?? "";
  } catch {
    /* ignore */
  }
  const s = res.status;
  if (s === 401 || s === 403 || (s === 400 && /api key/i.test(detail))) return { status: s, message: "کلید API نامعتبر است" };
  if (s === 429) return { status: s, message: "محدودیت تعداد درخواست؛ کمی بعد دوباره تلاش کنید" };
  return { status: s, message: "خطایی رخ داد. لطفاً دوباره تلاش کنید." };
}

export function isNetworkError(e: unknown): boolean {
  const msg = e instanceof Error ? `${e.message} ${(e as { cause?: { code?: string } }).cause?.code ?? ""}` : String(e);
  return /ENOTFOUND|ECONNREFUSED|ECONNRESET|EAI_AGAIN|ETIMEDOUT|fetch failed|network/i.test(msg);
}

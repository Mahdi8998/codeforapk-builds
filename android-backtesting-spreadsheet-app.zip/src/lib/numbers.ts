/**
 * ONE shared number parser used by the grid, the StatsEngine and the AI payload builder.
 * Handles Persian digits ۰–۹, Arabic-Indic digits ٠–٩, thousands separators (",", "٬", spaces)
 * and both "." and "٫" as the decimal separator.
 */

const PERSIAN = "۰۱۲۳۴۵۶۷۸۹";
const ARABIC = "٠١٢٣٤٥٦٧٨٩";

export function normalizeDigits(input: string): string {
  let out = "";
  for (const ch of input) {
    const p = PERSIAN.indexOf(ch);
    if (p >= 0) {
      out += String(p);
      continue;
    }
    const a = ARABIC.indexOf(ch);
    if (a >= 0) {
      out += String(a);
      continue;
    }
    out += ch;
  }
  return out;
}

/** Returns a finite number or null if the cell is not numeric. */
export function parseNumber(raw: string | null | undefined): number | null {
  if (raw == null) return null;
  let s = normalizeDigits(String(raw)).trim();
  if (!s) return null;
  // unicode minus, arabic decimal / thousands separators
  s = s.replace(/\u2212/g, "-").replace(/\u066B/g, ".").replace(/[\u066C\u2019' ]/g, "");
  // remove thousands separators "," only when they look like grouping
  s = s.replace(/,/g, "");
  // percent sign / currency are not numbers for us
  if (!/^[+-]?(\d+\.?\d*|\.\d+)$/.test(s)) return null;
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

export function isNumericCell(raw: string): boolean {
  return parseNumber(raw) !== null;
}

/** Format with thousand separators and up to `maxFrac` decimals (Latin digits, RTL-safe). */
export function formatNumber(n: number | null | undefined, maxFrac = 2): string {
  if (n == null || !Number.isFinite(n)) {
    if (n === Infinity) return "∞";
    return "—";
  }
  return new Intl.NumberFormat("en-US", { maximumFractionDigits: maxFrac, minimumFractionDigits: 0 }).format(n);
}

export function formatMoney(n: number | null | undefined): string {
  if (n == null || !Number.isFinite(n)) return "—";
  return new Intl.NumberFormat("en-US", { maximumFractionDigits: 2, minimumFractionDigits: 2 }).format(n);
}

export function formatPercent(n: number | null | undefined, frac = 1): string {
  if (n == null || !Number.isFinite(n)) return "—";
  return `${formatNumber(n, frac)}٪`;
}

export function formatSigned(n: number | null | undefined, frac = 2): string {
  if (n == null || !Number.isFinite(n)) return n === Infinity ? "∞" : "—";
  const s = formatNumber(Math.abs(n), frac);
  return n < 0 ? `−${s}` : `+${s}`;
}

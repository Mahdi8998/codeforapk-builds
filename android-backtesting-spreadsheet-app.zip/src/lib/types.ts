export interface Grid {
  headers: string[];
  rows: string[][];
}

export interface ColumnFilter {
  /** Selected values (raw cell strings). If undefined => no value filter on the column. */
  values?: string[];
}

export interface FilterState {
  columns: Record<string, ColumnFilter>; // key = column index as string
  search: string;
  sort?: { column: number; direction: "asc" | "desc" } | null;
}

export interface WorkbookMeta {
  id: number;
  name: string;
  createdAt: string;
  updatedAt: string;
  rowCount: number;
  colCount: number;
}

export interface WorkbookFull {
  id: number;
  name: string;
  createdAt: string;
  updatedAt: string;
  grid: Grid;
  filterState: FilterState;
  plColumnIndex: number | null;
  initialBalance: number;
  riskPercent: number;
  rrCap: number | null;
}

export const emptyFilterState = (): FilterState => ({ columns: {}, search: "", sort: null });

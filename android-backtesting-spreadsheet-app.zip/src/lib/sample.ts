import type { Grid } from "./types";

export const SAMPLE_HEADERS = ["تاریخ", "جفت‌ارز", "جهت", "قیمت ورود", "قیمت خروج", "حجم", "نتیجه", "توضیحات"];

/** ~40 realistic rows; نتیجه: ~45% dash, ~30% "1", ~15% "2", ~10% "3", plus 4 empty cells. */
export function buildSampleGrid(): Grid {
  const results = [
    "-", "1", "-", "2", "-", "1", "3", "-", "1", "-",
    "2", "-", "1", "", "-", "1", "-", "3", "-", "1",
    "-", "2", "1", "-", "", "1", "-", "-", "2", "1",
    "-", "3", "-", "1", "", "-", "2", "1", "-", "-",
    "1", "", "-", "2",
  ];
  const pairs = ["EURUSD", "GBPUSD", "USDJPY", "XAUUSD", "AUDUSD"];
  const notes = [
    "شکست سطح حمایت", "پولبک به مووینگ", "ورود در جلسه لندن", "الگوی پین‌بار", "واگرایی RSI",
    "شکست خط روند", "ورود بعد از خبر", "اردر بلاک", "ریتست سطح", "",
  ];
  const basePrice: Record<string, number> = { EURUSD: 1.085, GBPUSD: 1.265, USDJPY: 151.2, XAUUSD: 2320, AUDUSD: 0.655 };
  const rows: string[][] = [];
  let seed = 7;
  const rnd = () => {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };
  const start = new Date(2024, 0, 3);
  for (let i = 0; i < results.length; i++) {
    const d = new Date(start.getTime() + i * 2 * 86400000 + Math.floor(rnd() * 86400000));
    const pair = pairs[Math.floor(rnd() * pairs.length)];
    const dir = rnd() < 0.55 ? "خرید" : "فروش";
    const p = basePrice[pair];
    const dec = pair === "USDJPY" ? 3 : pair === "XAUUSD" ? 2 : 5;
    const entry = p * (1 + (rnd() - 0.5) * 0.01);
    const res = results[i];
    const stopDist = p * 0.003;
    let exit = entry;
    if (res === "-") exit = dir === "خرید" ? entry - stopDist : entry + stopDist;
    else if (res !== "") exit = dir === "خرید" ? entry + stopDist * Number(res) : entry - stopDist * Number(res);
    const lot = [0.01, 0.02, 0.05, 0.1][Math.floor(rnd() * 4)];
    rows.push([
      `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`,
      pair,
      dir,
      entry.toFixed(dec),
      res === "" ? "" : exit.toFixed(dec),
      String(lot),
      res,
      notes[Math.floor(rnd() * notes.length)],
    ]);
  }
  return { headers: SAMPLE_HEADERS, rows };
}

export function buildEmptyGrid(): Grid {
  return {
    headers: ["تاریخ", "جفت‌ارز", "جهت", "نتیجه", "توضیحات"],
    rows: Array.from({ length: 5 }, () => ["", "", "", "", ""]),
  };
}

import { activeFilterColumns } from "./filters";
import { computeStats, type StatsInput, type StatsResult } from "./stats-engine";
import type { FilterState, Grid } from "./types";

export const COMPLETE_MODE_CAP = 500;
export const SAMPLE_ROWS = 30;
export const GEMINI_MODEL = "gemini-2.5-flash";

export type DataMode = "complete" | "summary";

export interface AiScope {
  grid: Grid;
  filterState: FilterState;
  /** filtered row indexes in ORIGINAL order (same snapshot the StatsEngine uses) */
  rowIndexes: number[];
  plColumnIndex: number | null;
  rrCap: number | null;
  initialBalance: number;
  riskPercent: number;
}

export const SYSTEM_PROMPT = `You are a professional forex trading-strategy backtest analyst. The input is a spreadsheet in which each row is ONE trade from the user's manual backtest.
Trade results are expressed as R-multiples: a dash "-" means the trade hit its full stop-loss (−1R); a positive number N means target N was hit (+N R); a negative number is a loss of that size. An EMPTY result cell means the trade is still open/unresolved — NEVER treat it as a loss and exclude it from every statistic. Use the Persian terms «تارگت» (target) and «استاپ» (stop) naturally.
Dollar figures follow the stated percentage money-management model: a fixed percentage of the CURRENT balance is risked per trade, so results compound and row order is the chronological order. Reference the final balance, return % and dollar drawdown alongside the R-multiple metrics; use «موجودی» (balance) and «ریسک» (risk) naturally.
When a PROFIT BASIS with an R:R cap is active, interpret the results accordingly (profit was taken at the capped R:R, so a "3" counts as +cap R). If useful, briefly note in Persian how the metrics would differ without the cap; use the terms «مبنا» and «R:R» naturally.
If the FILTER CONTEXT states that the rows are a FILTERED SUBSET, treat the data as the user's deliberately selected slice of their strategy (for example only the losing trades, or only one currency pair) and analyze THAT slice. Do not assume it represents the whole strategy; where relevant, briefly note in Persian that the conclusions apply to this filtered slice.
Analyze critically. Cite real numbers taken from the data. Use clear headings and bullet points. Give concrete, actionable suggestions. State explicitly when the sample size is too small for reliable conclusions. Never invent data that is not present.
ALWAYS respond in Persian (فارسی). End every response with a one-line disclaimer that this is not financial advice (این تحلیل توصیه مالی نیست).`;

export const PRESETS: { id: string; label: string; prompt: string }[] = [
  {
    id: "overall",
    label: "تحلیل کلی استراتژی",
    prompt: "Provide an overall performance analysis of this backtest: key metrics, strengths and weaknesses, and reliability of the sample.",
  },
  {
    id: "losses",
    label: "بررسی باخت‌ها",
    prompt: "Analyze the losing trades in depth: find common patterns (pair, direction, time, notes, size) and explain what distinguishes them from winners.",
  },
  {
    id: "risk",
    label: "مدیریت ریسک و حجم",
    prompt: "Evaluate risk management: drawdown, losing/winning streaks, position sizing and the risk-per-trade percentage. Give feedback on whether the current money management is appropriate.",
  },
  {
    id: "improve",
    label: "پیشنهاد بهبود",
    prompt: "Suggest concrete rule changes worth testing next (entry filters, exits, take-profit level, pair/session selection) with the expected effect on the metrics.",
  },
];

/* ------------------------------------------------------------------ */
/* Headers                                                             */
/* ------------------------------------------------------------------ */

export function scopeHeader(scope: AiScope): string {
  const total = scope.grid.rows.length;
  const x = scope.rowIndexes.length;
  const cols = activeFilterColumns(scope.filterState);
  const search = scope.filterState.search.trim();
  if (cols.length === 0 && !search) {
    return `FILTER CONTEXT: the rows below are the FULL TABLE (${total} rows); no filters applied.`;
  }
  const parts = cols.map((c) => {
    const vals = scope.filterState.columns[String(c)]?.values ?? [];
    const shown = vals.map((v) => (v === "" ? "(empty)" : `"${v}"`)).join(", ");
    return `${scope.grid.headers[c]} = [${shown}]`;
  });
  if (search) parts.push(`search term = "${search}"`);
  return `FILTER CONTEXT: the rows below are a FILTERED SUBSET (${x} of ${total} total rows). Active filters: ${parts.join("; ")}. The user is intentionally analyzing this subset.`;
}

export function semanticsHeaders(scope: AiScope): string {
  const lines: string[] = [];
  const name = scope.plColumnIndex !== null ? scope.grid.headers[scope.plColumnIndex] : "(not selected)";
  lines.push(
    `RESULT COLUMN "${name}": "-" = stop-loss hit (−1R); positive number N = target N hit (+N R); empty = trade has no result yet (excluded from all stats).`,
  );
  lines.push(
    `MONEY MANAGEMENT: initial balance ${scope.initialBalance} USD; risk per trade ${scope.riskPercent}% of current balance (compounding); loss (-) = -1R; target N = +N R; empty = unresolved trade.`,
  );
  if (scope.rrCap != null) {
    lines.push(
      `PROFIT BASIS: user-defined R:R cap = ${scope.rrCap}R — a cell "3" means price reached 3R but profit is counted as +${Math.min(3, scope.rrCap)}R (min(N, ${scope.rrCap})); dash = stop (−1R); empty = unresolved trade.`,
    );
  } else {
    lines.push(`PROFIT BASIS: full target value (no cap).`);
  }
  return lines.join("\n");
}

/* ------------------------------------------------------------------ */
/* Payloads                                                            */
/* ------------------------------------------------------------------ */

export function statsForScope(scope: AiScope): StatsResult {
  const input: StatsInput = {
    headers: scope.grid.headers,
    rows: scope.rowIndexes.map((i) => scope.grid.rows[i]),
    totalRows: scope.grid.rows.length,
    plColumnIndex: scope.plColumnIndex,
    rrCap: scope.rrCap,
    initialBalance: scope.initialBalance,
    riskPercent: scope.riskPercent,
    groupColumnIndex: null,
  };
  return computeStats(input);
}

const tsvEscape = (s: string) => s.replace(/[\t\r\n]+/g, " ");

export function buildCompletePayload(scope: AiScope): { ok: true; text: string } | { ok: false; reason: "empty" | "too_large" } {
  if (scope.rowIndexes.length === 0) return { ok: false, reason: "empty" };
  if (scope.rowIndexes.length > COMPLETE_MODE_CAP) return { ok: false, reason: "too_large" };
  const lines: string[] = [scopeHeader(scope), semanticsHeaders(scope), "", "DATA (TSV, first line = headers):"];
  lines.push(scope.grid.headers.map(tsvEscape).join("\t"));
  for (const i of scope.rowIndexes) {
    const row = scope.grid.rows[i];
    lines.push(scope.grid.headers.map((_, c) => tsvEscape(row[c] ?? "")).join("\t"));
  }
  return { ok: true, text: lines.join("\n") };
}

export function pickSampleRows(scope: AiScope, stats: StatsResult, max = SAMPLE_ROWS): number[] {
  // indexes are positions inside scope.rowIndexes
  const winners = stats.trades.filter((t) => t.kind === "win").map((t) => t.i);
  const losers = stats.trades.filter((t) => t.kind === "loss").map((t) => t.i);
  const tradeSet = new Set(stats.trades.map((t) => t.i));
  const others = scope.rowIndexes.map((_, i) => i).filter((i) => !tradeSet.has(i));
  const take = (arr: number[], n: number) => {
    if (arr.length <= n) return arr;
    const step = arr.length / n;
    const out: number[] = [];
    for (let k = 0; k < n; k++) out.push(arr[Math.floor(k * step)]);
    return out;
  };
  const nOther = Math.min(others.length, 4);
  const remaining = max - nOther;
  const nWin = Math.min(winners.length, Math.ceil(remaining / 2));
  const nLoss = Math.min(losers.length, remaining - nWin);
  const picked = [...take(winners, nWin), ...take(losers, nLoss), ...take(others, nOther)];
  return [...new Set(picked)].sort((a, b) => a - b).map((i) => scope.rowIndexes[i]);
}

export function buildSummaryPayload(scope: AiScope): { ok: true; text: string; stats: StatsResult } | { ok: false; reason: "empty" } {
  if (scope.rowIndexes.length === 0) return { ok: false, reason: "empty" };
  const stats = statsForScope(scope);
  const sampleIdx = pickSampleRows(scope, stats);
  const json = {
    headers: scope.grid.headers,
    filteredRowCount: scope.rowIndexes.length,
    totalRowCount: scope.grid.rows.length,
    summary: {
      numericColumns: stats.summary.numeric.map((n) => ({ column: n.name, sum: round(n.sum), avg: round(n.avg), count: n.count })),
      categoricalColumns: stats.summary.categorical.map((c) => ({
        column: c.name,
        breakdown: c.items.map((i) => ({ value: i.value, count: i.count, pct: round(i.pct) })),
      })),
    },
    resultColumnSelected: stats.resultColumnSet,
    unresolvedRows: stats.excludedCount,
    rMetrics: stats.r
      ? {
          trades: stats.r.count,
          wins: stats.r.wins,
          losses: stats.r.losses,
          netR: round(stats.r.netR),
          winRatePct: round(stats.r.winRate),
          profitFactor: stats.r.profitFactor === Infinity ? "Infinity" : round(stats.r.profitFactor),
          avgWinR: round(stats.r.avgWin),
          avgLossR: round(stats.r.avgLoss),
          rewardRisk: round(stats.r.rewardRisk),
          expectancyR: round(stats.r.expectancy),
          bestR: stats.r.best,
          worstR: stats.r.worst,
          maxConsecutiveWins: stats.r.maxConsecWins,
          maxConsecutiveLosses: stats.r.maxConsecLosses,
          maxDrawdownR: round(stats.r.maxDrawdownR),
          maxDrawdownRPct: round(stats.r.maxDrawdownRPct),
        }
      : null,
    dollarMetrics: stats.dollar
      ? {
          initialBalance: stats.dollar.initialBalance,
          riskPercent: stats.dollar.riskPercent,
          finalBalance: round(stats.dollar.finalBalance),
          netProfit: round(stats.dollar.netProfit),
          returnPct: round(stats.dollar.returnPct),
          avgWinUsd: round(stats.dollar.avgWin),
          avgLossUsd: round(stats.dollar.avgLoss),
          bestTradeUsd: round(stats.dollar.best),
          worstTradeUsd: round(stats.dollar.worst),
          maxDrawdownUsd: round(stats.dollar.maxDrawdown),
          maxDrawdownPct: round(stats.dollar.maxDrawdownPct),
        }
      : null,
    groupBy: stats.groupColumnIndex !== null ? scope.grid.headers[stats.groupColumnIndex] : null,
    groups: stats.groups.map((g) => ({ value: g.value, trades: g.count, winRatePct: round(g.winRate), netR: round(g.netR), netUsd: round(g.netDollar) })),
    sampleRows: {
      note: `A SAMPLE of ${sampleIdx.length} representative rows (winning, losing and unresolved) drawn ONLY from the analyzed rows; not the full data.`,
      headers: scope.grid.headers,
      rows: sampleIdx.map((i) => scope.grid.rows[i]),
    },
  };
  const text = [scopeHeader(scope), semanticsHeaders(scope), "", "DATA SUMMARY (JSON):", JSON.stringify(json)].join("\n");
  return { ok: true, text, stats };
}

function round(n: number | null | undefined): number | null {
  if (n == null || !Number.isFinite(n)) return null;
  return Math.round(n * 100) / 100;
}

/* ------------------------------------------------------------------ */
/* Errors                                                              */
/* ------------------------------------------------------------------ */

export function mapAiError(status: number | null, kind?: "network"): string {
  if (kind === "network") return "عدم اتصال به اینترنت";
  if (status === 401 || status === 403 || status === 400) return "کلید API نامعتبر است";
  if (status === 429) return "محدودیت تعداد درخواست؛ کمی بعد دوباره تلاش کنید";
  return "خطایی رخ داد. لطفاً دوباره تلاش کنید.";
}

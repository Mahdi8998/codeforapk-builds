import { normalizeDigits, parseNumber } from "./numbers";

/* ------------------------------------------------------------------ */
/* Result parsing (R-multiples) — one implementation                    */
/* ------------------------------------------------------------------ */

export type ParsedResult =
  | { kind: "win"; value: number }
  | { kind: "loss"; value: number }
  | { kind: "excluded"; value: null };

export function parseResult(raw: string | null | undefined): ParsedResult {
  if (raw == null) return { kind: "excluded", value: null };
  const s = normalizeDigits(String(raw)).trim();
  if (s === "") return { kind: "excluded", value: null };
  if (/^[-\u2212\u2013]$/.test(s)) return { kind: "loss", value: -1 };
  const n = parseNumber(s);
  if (n === null || n === 0) return { kind: "excluded", value: null };
  return n > 0 ? { kind: "win", value: n } : { kind: "loss", value: n };
}

/** Apply the optional R:R profit cap — wins only. */
export function applyCap(value: number, rrCap: number | null): number {
  if (rrCap != null && rrCap > 0 && value > 0) return Math.min(value, rrCap);
  return value;
}

/* ------------------------------------------------------------------ */
/* Input / Output                                                      */
/* ------------------------------------------------------------------ */

export interface StatsInput {
  headers: string[];
  /** Filtered snapshot in ORIGINAL workbook order */
  rows: string[][];
  totalRows: number;
  plColumnIndex: number | null;
  rrCap: number | null;
  initialBalance: number;
  riskPercent: number;
  /** null => engine picks default */
  groupColumnIndex: number | null;
}

export interface Trade {
  /** index within the filtered snapshot */
  i: number;
  kind: "win" | "loss";
  /** raw (uncapped) R */
  rawR: number;
  /** capped R (what is actually used) */
  r: number;
  /** balance after this trade in the compounding simulation */
  balanceAfter: number;
  /** single-trade dollar effect (order-free): initialBalance × risk% × r */
  singleEffect: number;
  /** compounding dollar change of this trade */
  compEffect: number;
}

export interface RMetrics {
  count: number;
  wins: number;
  losses: number;
  netR: number;
  winRate: number; // %
  profitFactor: number; // Infinity allowed
  avgWin: number | null;
  avgLoss: number | null; // negative
  rewardRisk: number | null;
  expectancy: number;
  best: number;
  worst: number;
  maxConsecWins: number;
  maxConsecLosses: number;
  maxDrawdownR: number;
  maxDrawdownRPct: number | null;
}

export interface DollarMetrics {
  initialBalance: number;
  riskPercent: number;
  finalBalance: number;
  netProfit: number;
  returnPct: number;
  count: number;
  avgWin: number | null;
  avgLoss: number | null;
  best: number;
  worst: number;
  maxDrawdown: number;
  maxDrawdownPct: number;
}

export interface GroupStat {
  value: string;
  count: number;
  winRate: number;
  netR: number;
  netDollar: number;
}

export interface Point {
  x: number;
  y: number;
}

export interface StatsResult {
  rowCount: number;
  totalRows: number;
  filtered: boolean;
  summary: {
    numeric: { col: number; name: string; sum: number; avg: number; count: number }[];
    categorical: { col: number; name: string; items: { value: string; count: number; pct: number }[] }[];
  };
  resultColumnSet: boolean;
  trades: Trade[];
  excludedCount: number;
  rrCap: number | null;
  r: RMetrics | null;
  dollar: DollarMetrics | null;
  groupableColumns: { col: number; name: string }[];
  groupColumnIndex: number | null;
  groups: GroupStat[];
  rEquity: Point[]; // cumulative capped R, one point per counted trade
  dollarEquity: Point[]; // starts with initial balance at x=0
}

/* ------------------------------------------------------------------ */
/* Engine                                                              */
/* ------------------------------------------------------------------ */

function safeDiv(a: number, b: number): number | null {
  return b === 0 ? null : a / b;
}

export function computeStats(input: StatsInput): StatsResult {
  const { headers, rows, plColumnIndex, rrCap, initialBalance, riskPercent } = input;
  const nCols = headers.length;

  /* ---------- Summary (generic) ---------- */
  const numeric: StatsResult["summary"]["numeric"] = [];
  const categorical: StatsResult["summary"]["categorical"] = [];
  const groupable: { col: number; name: string }[] = [];
  for (let c = 0; c < nCols; c++) {
    let sum = 0;
    let numCount = 0;
    let nonEmpty = 0;
    const distinct = new Map<string, number>();
    for (const row of rows) {
      const v = (row[c] ?? "").trim();
      if (v === "") continue;
      nonEmpty++;
      const n = parseNumber(v);
      if (n !== null) {
        sum += n;
        numCount++;
      }
      distinct.set(v, (distinct.get(v) ?? 0) + 1);
    }
    const isNumeric = nonEmpty > 0 && numCount / nonEmpty >= 0.5;
    if (isNumeric && numCount > 0) {
      numeric.push({ col: c, name: headers[c], sum, avg: sum / numCount, count: numCount });
    } else if (nonEmpty > 0) {
      if (distinct.size >= 2 && distinct.size <= 5) {
        const items = [...distinct.entries()]
          .map(([value, count]) => ({ value, count, pct: (count / nonEmpty) * 100 }))
          .sort((a, b) => b.count - a.count);
        categorical.push({ col: c, name: headers[c], items });
      }
      if (distinct.size >= 2 && distinct.size <= 10) groupable.push({ col: c, name: headers[c] });
    }
  }
  // Result column can also be grouped (it's not numeric-mostly when dashes dominate) but exclude it if selected
  const groupableColumns = groupable.filter((g) => g.col !== plColumnIndex);
  // If nothing groupable, allow any non-result column
  const groupCandidates =
    groupableColumns.length > 0 ? groupableColumns : headers.map((name, col) => ({ col, name })).filter((g) => g.col !== plColumnIndex);
  let groupColumnIndex: number | null = input.groupColumnIndex;
  if (groupColumnIndex === null || groupColumnIndex >= nCols) groupColumnIndex = groupCandidates[0]?.col ?? null;

  /* ---------- Trades ---------- */
  const trades: Trade[] = [];
  let excludedCount = 0;
  const resultColumnSet = plColumnIndex !== null && plColumnIndex >= 0 && plColumnIndex < nCols;
  const riskFrac = riskPercent / 100;
  let balance = initialBalance;
  if (resultColumnSet) {
    for (let i = 0; i < rows.length; i++) {
      const p = parseResult(rows[i][plColumnIndex as number]);
      if (p.kind === "excluded") {
        excludedCount++;
        continue;
      }
      const r = applyCap(p.value, rrCap);
      const before = balance;
      balance = balance * (1 + riskFrac * r);
      trades.push({
        i,
        kind: p.kind,
        rawR: p.value,
        r,
        balanceAfter: balance,
        singleEffect: initialBalance * riskFrac * r,
        compEffect: balance - before,
      });
    }
  }

  /* ---------- R metrics ---------- */
  let r: RMetrics | null = null;
  const rEquity: Point[] = [];
  if (trades.length > 0) {
    let wins = 0,
      losses = 0,
      sumWin = 0,
      sumLoss = 0,
      net = 0,
      best = -Infinity,
      worst = Infinity,
      cw = 0,
      cl = 0,
      mcw = 0,
      mcl = 0,
      peak = 0,
      maxDD = 0,
      maxDDPct: number | null = null;
    trades.forEach((t, idx) => {
      net += t.r;
      rEquity.push({ x: idx + 1, y: net });
      if (t.kind === "win") {
        wins++;
        sumWin += t.r;
        cw++;
        cl = 0;
      } else {
        losses++;
        sumLoss += t.r;
        cl++;
        cw = 0;
      }
      mcw = Math.max(mcw, cw);
      mcl = Math.max(mcl, cl);
      best = Math.max(best, t.r);
      worst = Math.min(worst, t.r);
      if (net > peak) peak = net;
      const dd = peak - net;
      if (dd > maxDD) {
        maxDD = dd;
        maxDDPct = peak > 0 ? (dd / peak) * 100 : null;
      }
    });
    const avgWin = safeDiv(sumWin, wins);
    const avgLoss = safeDiv(sumLoss, losses);
    const profitFactor = losses === 0 || sumLoss === 0 ? Infinity : sumWin / Math.abs(sumLoss);
    r = {
      count: trades.length,
      wins,
      losses,
      netR: net,
      winRate: (wins / trades.length) * 100,
      profitFactor,
      avgWin,
      avgLoss,
      rewardRisk: avgWin !== null && avgLoss !== null && avgLoss !== 0 ? avgWin / Math.abs(avgLoss) : null,
      expectancy: net / trades.length,
      best,
      worst,
      maxConsecWins: mcw,
      maxConsecLosses: mcl,
      maxDrawdownR: maxDD,
      maxDrawdownRPct: maxDDPct,
    };
  }

  /* ---------- Dollar metrics ---------- */
  let dollar: DollarMetrics | null = null;
  const dollarEquity: Point[] = [{ x: 0, y: initialBalance }];
  if (trades.length > 0) {
    let peak = initialBalance,
      maxDD = 0,
      maxDDPct = 0,
      sumWinD = 0,
      sumLossD = 0,
      winsD = 0,
      lossesD = 0,
      best = -Infinity,
      worst = Infinity;
    trades.forEach((t, idx) => {
      dollarEquity.push({ x: idx + 1, y: t.balanceAfter });
      if (t.compEffect > 0) {
        sumWinD += t.compEffect;
        winsD++;
      } else {
        sumLossD += t.compEffect;
        lossesD++;
      }
      best = Math.max(best, t.compEffect);
      worst = Math.min(worst, t.compEffect);
      if (t.balanceAfter > peak) peak = t.balanceAfter;
      const dd = peak - t.balanceAfter;
      if (dd > maxDD) {
        maxDD = dd;
        maxDDPct = peak > 0 ? (dd / peak) * 100 : 0;
      }
    });
    const finalBalance = trades[trades.length - 1].balanceAfter;
    dollar = {
      initialBalance,
      riskPercent,
      finalBalance,
      netProfit: finalBalance - initialBalance,
      returnPct: initialBalance > 0 ? ((finalBalance - initialBalance) / initialBalance) * 100 : 0,
      count: trades.length,
      avgWin: safeDiv(sumWinD, winsD),
      avgLoss: safeDiv(sumLossD, lossesD),
      best,
      worst,
      maxDrawdown: maxDD,
      maxDrawdownPct: maxDDPct,
    };
  }

  /* ---------- Groups ---------- */
  const groups: GroupStat[] = [];
  if (groupColumnIndex !== null && trades.length > 0) {
    const map = new Map<string, { count: number; wins: number; netR: number; netDollar: number }>();
    for (const t of trades) {
      const key = (rows[t.i][groupColumnIndex] ?? "").trim() || "(خالی)";
      const g = map.get(key) ?? { count: 0, wins: 0, netR: 0, netDollar: 0 };
      g.count++;
      if (t.kind === "win") g.wins++;
      g.netR += t.r;
      g.netDollar += t.singleEffect;
      map.set(key, g);
    }
    for (const [value, g] of map) {
      groups.push({ value, count: g.count, winRate: (g.wins / g.count) * 100, netR: g.netR, netDollar: g.netDollar });
    }
    groups.sort((a, b) => b.count - a.count);
  }

  return {
    rowCount: rows.length,
    totalRows: input.totalRows,
    filtered: rows.length !== input.totalRows,
    summary: { numeric, categorical },
    resultColumnSet,
    trades,
    excludedCount,
    rrCap,
    r,
    dollar,
    groupableColumns: groupCandidates,
    groupColumnIndex,
    groups,
    rEquity,
    dollarEquity,
  };
}

/* ------------------------------------------------------------------ */
/* Validation helpers (settings dialogs)                               */
/* ------------------------------------------------------------------ */

export function validateBalance(raw: string): { ok: true; value: number } | { ok: false; error: string } {
  const n = parseNumber(raw);
  if (n === null) return { ok: false, error: "لطفاً یک عدد معتبر وارد کنید" };
  if (n <= 0) return { ok: false, error: "موجودی اولیه باید بزرگ‌تر از صفر باشد" };
  return { ok: true, value: n };
}

export function validateRisk(raw: string): { ok: true; value: number } | { ok: false; error: string } {
  const n = parseNumber(raw);
  if (n === null) return { ok: false, error: "لطفاً یک عدد معتبر وارد کنید" };
  if (n <= 0 || n > 100) return { ok: false, error: "درصد ریسک باید بین ۰ و ۱۰۰ باشد" };
  return { ok: true, value: n };
}

export function validateRrCap(raw: string): { ok: true; value: number } | { ok: false; error: string } {
  const n = parseNumber(raw);
  if (n === null) return { ok: false, error: "لطفاً یک عدد معتبر وارد کنید" };
  if (n <= 0) return { ok: false, error: "مقدار R:R باید بزرگ‌تر از صفر باشد" };
  return { ok: true, value: n };
}

import { parseNumber } from "./numbers";
import type { FilterState, Grid } from "./types";

export const cellAt = (row: string[], col: number): string => row[col] ?? "";

/** Unique values of a column with counts (Excel-like), computed on the given row indexes. */
export function uniqueValues(grid: Grid, col: number, rowIdx?: number[]): { value: string; count: number }[] {
  const map = new Map<string, number>();
  const idx = rowIdx ?? grid.rows.map((_, i) => i);
  for (const i of idx) {
    const v = cellAt(grid.rows[i], col);
    map.set(v, (map.get(v) ?? 0) + 1);
  }
  const list = [...map.entries()].map(([value, count]) => ({ value, count }));
  const numeric = isMostlyNumeric(list.map((l) => l.value));
  list.sort((a, b) => compareValues(a.value, b.value, numeric));
  return list;
}

export function isMostlyNumeric(values: string[]): boolean {
  const nonEmpty = values.filter((v) => v.trim() !== "");
  if (nonEmpty.length === 0) return false;
  const num = nonEmpty.filter((v) => parseNumber(v) !== null).length;
  return num / nonEmpty.length >= 0.5;
}

export function compareValues(a: string, b: string, numeric: boolean): number {
  if (numeric) {
    const na = parseNumber(a);
    const nb = parseNumber(b);
    if (na !== null && nb !== null) return na - nb;
    if (na !== null) return -1; // numbers before text
    if (nb !== null) return 1;
  }
  const ea = a.trim() === "";
  const eb = b.trim() === "";
  if (ea && !eb) return 1; // empty last
  if (eb && !ea) return -1;
  return a.localeCompare(b, "fa");
}

export function hasActiveFilters(fs: FilterState): boolean {
  return Object.values(fs.columns).some((c) => c.values !== undefined) || fs.search.trim() !== "";
}

export function activeFilterColumns(fs: FilterState): number[] {
  return Object.entries(fs.columns)
    .filter(([, c]) => c.values !== undefined)
    .map(([k]) => Number(k));
}

/**
 * Returns the indexes of the visible rows (original order, or sorted if a sort is set).
 * Column filters and global search combine with AND.
 */
export function visibleRowIndexes(grid: Grid, fs: FilterState): number[] {
  const colFilters = Object.entries(fs.columns)
    .filter(([, c]) => c.values !== undefined)
    .map(([k, c]) => ({ col: Number(k), set: new Set(c.values) }));
  const q = fs.search.trim().toLowerCase();
  const out: number[] = [];
  for (let i = 0; i < grid.rows.length; i++) {
    const row = grid.rows[i];
    let ok = true;
    for (const f of colFilters) {
      if (!f.set.has(cellAt(row, f.col))) {
        ok = false;
        break;
      }
    }
    if (!ok) continue;
    if (q) {
      let found = false;
      for (let c = 0; c < grid.headers.length; c++) {
        if (cellAt(row, c).toLowerCase().includes(q)) {
          found = true;
          break;
        }
      }
      if (!found) continue;
    }
    out.push(i);
  }
  if (fs.sort) {
    const col = fs.sort.column;
    const numeric = isMostlyNumeric(out.map((i) => cellAt(grid.rows[i], col)));
    const dir = fs.sort.direction === "asc" ? 1 : -1;
    out.sort((a, b) => {
      const r = compareValues(cellAt(grid.rows[a], col), cellAt(grid.rows[b], col), numeric);
      return r !== 0 ? r * dir : a - b;
    });
  }
  return out;
}

/** Visible rows in ORIGINAL workbook order (ignores sort) – used by StatsEngine and AI payload. */
export function filteredRowIndexesOriginalOrder(grid: Grid, fs: FilterState): number[] {
  return visibleRowIndexes(grid, { ...fs, sort: null });
}

/** Remap filter state after column structure changes. */
export function remapFilterColumns(fs: FilterState, mapper: (oldIdx: number) => number | null): FilterState {
  const columns: FilterState["columns"] = {};
  for (const [k, v] of Object.entries(fs.columns)) {
    const n = mapper(Number(k));
    if (n !== null) columns[String(n)] = v;
  }
  let sort = fs.sort ?? null;
  if (sort) {
    const n = mapper(sort.column);
    sort = n === null ? null : { ...sort, column: n };
  }
  return { ...fs, columns, sort };
}

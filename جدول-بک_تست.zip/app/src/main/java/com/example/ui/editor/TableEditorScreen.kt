package com.example.ui.editor

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.FilterAltOff
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.data.xlsx.XlsxHandler
import com.example.engine.StatsInput
import com.example.engine.StatsResult
import com.example.ui.stats.StatsPanel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TableEditorScreen(
    viewModel: TableEditorViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToAi: (statsInput: StatsInput, statsResult: StatsResult, title: String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val visibleIndices by viewModel.visibleRowIndices.collectAsState()
    val statsResult by viewModel.statsResult.collectAsState()

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // UI View states
    var showStatsPanel by remember { mutableStateOf(false) }
    var showSearchBar by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showOverflowMenu by remember { mutableStateOf(false) }

    // Cell editing bottom sheet
    var activeEditingCell by remember { mutableStateOf<Triple<Int, Int, String>?>(null) } // originalRowIdx, colIdx, value
    val cellSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Column filtering bottom sheet
    var activeFilterColIdx by remember { mutableStateOf<Int?>(null) }
    val filterSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Column actions dialogs
    var columnToRename by remember { mutableStateOf<Pair<Int, String>?>(null) }
    var columnToDelete by remember { mutableStateOf<Pair<Int, String>?>(null) }

    // Save indicator toast/snackbar
    LaunchedEffect(uiState.lastSaveMessage) {
        uiState.lastSaveMessage?.let {
            snackbarHostState.showSnackbar(it)
        }
    }

    // Export XLSX file launcher
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    context.contentResolver.openOutputStream(uri)?.use { os ->
                        XlsxHandler.writeXlsx(uiState.gridData.headers, uiState.gridData.rows, os)
                    }
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "فایل اکسل با موفقیت ذخیره شد", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "خطا در خروجی فایل اکسل: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    // Rename Workbook Dialog
    if (showRenameDialog) {
        var newTitle by remember { mutableStateOf(uiState.workbook?.name.orEmpty()) }
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = { Text("تغییر نام جدول") },
            text = {
                OutlinedTextField(
                    value = newTitle,
                    onValueChange = { newTitle = it },
                    label = { Text("نام جدول") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.renameWorkbook(newTitle)
                        showRenameDialog = false
                    }
                ) {
                    Text("تأیید")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }

    // Column Rename Dialog
    columnToRename?.let { (colIdx, currentName) ->
        var newColName by remember { mutableStateOf(currentName) }
        AlertDialog(
            onDismissRequest = { columnToRename = null },
            title = { Text("تغییر نام ستون") },
            text = {
                OutlinedTextField(
                    value = newColName,
                    onValueChange = { newColName = it },
                    label = { Text("نام جدید ستون") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.handleColumnAction(ColumnAction.RENAME, colIdx, newColName)
                        columnToRename = null
                    }
                ) {
                    Text("تأیید")
                }
            },
            dismissButton = {
                TextButton(onClick = { columnToRename = null }) {
                    Text("انصراف")
                }
            }
        )
    }

    // Delete Column Confirmation Dialog
    columnToDelete?.let { (colIdx, colName) ->
        AlertDialog(
            onDismissRequest = { columnToDelete = null },
            title = { Text("حذف ستون") },
            text = {
                Text("آیا از حذف ستون «$colName» و تمام داده‌های آن اطمینان دارید؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.handleColumnAction(ColumnAction.DELETE, colIdx)
                        columnToDelete = null
                    }
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { columnToDelete = null }) {
                    Text("انصراف")
                }
            }
        )
    }

    // Cell Editor Bottom Sheet
    activeEditingCell?.let { (origRowIdx, colIdx, cellVal) ->
        val colName = uiState.gridData.headers.getOrNull(colIdx) ?: "ستون"
        CellEditorBottomSheet(
            sheetState = cellSheetState,
            rowIndex = origRowIdx,
            columnIndex = colIdx,
            columnName = colName,
            initialValue = cellVal,
            onSaveAndClose = { newVal ->
                viewModel.updateCell(origRowIdx, colIdx, newVal)
                activeEditingCell = null
            },
            onSaveAndNext = { newVal ->
                viewModel.updateCell(origRowIdx, colIdx, newVal)
                // Move to next row if available, else create a new row!
                val totalRows = uiState.gridData.rows.size
                if (origRowIdx + 1 < totalRows) {
                    val nextRowVal = uiState.gridData.rows[origRowIdx + 1].getOrNull(colIdx).orEmpty()
                    activeEditingCell = Triple(origRowIdx + 1, colIdx, nextRowVal)
                } else {
                    viewModel.addRowAtEnd()
                    activeEditingCell = Triple(origRowIdx + 1, colIdx, "")
                }
            },
            onDismiss = { activeEditingCell = null }
        )
    }

    // Filter Bottom Sheet
    activeFilterColIdx?.let { colIdx ->
        val colName = uiState.gridData.headers.getOrNull(colIdx) ?: "ستون"
        // Compute unique values & counts from all rows
        val valueCounts = remember(uiState.gridData.rows, colIdx) {
            val map = mutableMapOf<String, Int>()
            for (row in uiState.gridData.rows) {
                val v = row.getOrNull(colIdx)?.trim().orEmpty()
                map[v] = (map[v] ?: 0) + 1
            }
            map.map { (v, c) -> ValueCount(v, c) }.sortedByDescending { it.count }
        }
        val currentFilterSet = uiState.filterState.columnFilters[colIdx]
        val isSortedAsc = if (uiState.filterState.sortColumnIndex == colIdx) uiState.filterState.sortAscending else null

        FilterBottomSheet(
            sheetState = filterSheetState,
            columnIndex = colIdx,
            columnName = colName,
            allUniqueValues = valueCounts,
            initialSelectedValues = currentFilterSet,
            isSortedAscending = isSortedAsc,
            onSort = { asc ->
                viewModel.setSort(colIdx, asc)
                activeFilterColIdx = null
            },
            onApplyFilter = { set ->
                viewModel.setColumnFilter(colIdx, set)
                activeFilterColIdx = null
            },
            onClearFilter = {
                viewModel.clearColumnFilter(colIdx)
                activeFilterColIdx = null
            },
            onDismiss = { activeFilterColIdx = null }
        )
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                TopAppBar(
                    title = {
                        Column(
                            modifier = Modifier
                                .clickable { showRenameDialog = true }
                                .padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = uiState.workbook?.name ?: "جدول بک‌تست",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val scopeSubtitle = if (visibleIndices.size < uiState.gridData.rows.size) {
                                "${visibleIndices.size} از ${uiState.gridData.rows.size} معامله (فیلتر)"
                            } else {
                                "${uiState.gridData.rows.size} معامله"
                            }
                            Text(
                                text = scopeSubtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                        }
                    },
                    actions = {
                        // Undo
                        IconButton(
                            onClick = { viewModel.undo() },
                            enabled = uiState.canUndo,
                            modifier = Modifier.testTag("undo_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "بازگشت به قبل")
                        }

                        // Redo
                        IconButton(
                            onClick = { viewModel.redo() },
                            enabled = uiState.canRedo,
                            modifier = Modifier.testTag("redo_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "انجام مجدد")
                        }

                        // Search Toggle
                        IconButton(
                            onClick = { showSearchBar = !showSearchBar },
                            modifier = Modifier.testTag("search_toggle_button")
                        ) {
                            Icon(Icons.Default.Search, contentDescription = "جستجو")
                        }

                        // AI Strategy Analyst
                        IconButton(
                            onClick = {
                                val filteredRows = visibleIndices.map { uiState.gridData.rows[it] }
                                val filterDescs = mutableListOf<String>()
                                uiState.filterState.columnFilters.forEach { (c, s) ->
                                    val h = uiState.gridData.headers.getOrNull(c) ?: "ستون $c"
                                    filterDescs.add("$h = [${s.joinToString()}]")
                                }
                                if (uiState.searchQuery.isNotBlank()) {
                                    filterDescs.add("جستجو: \"${uiState.searchQuery}\"")
                                }

                                val sInput = StatsInput(
                                    allRows = filteredRows,
                                    headers = uiState.gridData.headers,
                                    plColumnIndex = uiState.workbook?.plColumnIndex,
                                    rrCap = uiState.workbook?.rrCap,
                                    initialBalance = uiState.workbook?.initialBalance ?: 500.0,
                                    riskPercent = uiState.workbook?.riskPercent ?: 2.0,
                                    totalRowCount = uiState.gridData.rows.size,
                                    activeFilterDesc = filterDescs.joinToString(" | ")
                                )

                                onNavigateToAi(sInput, statsResult, uiState.workbook?.name.orEmpty())
                            },
                            modifier = Modifier.testTag("ai_analyst_button")
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = "تحلیل هوشمند AI", tint = MaterialTheme.colorScheme.primary)
                        }

                        // Stats Toggle
                        IconButton(
                            onClick = { showStatsPanel = !showStatsPanel },
                            modifier = Modifier.testTag("stats_toggle_button")
                        ) {
                            Icon(
                                Icons.Default.BarChart,
                                contentDescription = "آمار و تحلیل",
                                tint = if (showStatsPanel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Overflow menu
                        Box {
                            IconButton(onClick = { showOverflowMenu = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "منو")
                            }
                            DropdownMenu(
                                expanded = showOverflowMenu,
                                onDismissRequest = { showOverflowMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("خروجی اکسل (.xlsx)") },
                                    leadingIcon = { Icon(Icons.Default.FileDownload, contentDescription = null) },
                                    onClick = {
                                        showOverflowMenu = false
                                        val filename = "${uiState.workbook?.name ?: "Backtest"}.xlsx"
                                        exportLauncher.launch(filename)
                                    }
                                )
                                if (uiState.filterState.columnFilters.isNotEmpty() || uiState.searchQuery.isNotEmpty()) {
                                    DropdownMenuItem(
                                        text = { Text("پاک کردن همه فیلترها") },
                                        leadingIcon = { Icon(Icons.Default.FilterAltOff, contentDescription = null) },
                                        onClick = {
                                            showOverflowMenu = false
                                            viewModel.clearAllFilters()
                                        }
                                    )
                                }
                                DropdownMenuItem(
                                    text = { Text("ذخیره دستی") },
                                    onClick = {
                                        showOverflowMenu = false
                                        viewModel.saveNow()
                                    }
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
                )
            },
            floatingActionButton = {
                if (!showStatsPanel) {
                    FloatingActionButton(
                        onClick = { viewModel.addRowAtEnd() },
                        modifier = Modifier
                            .testTag("add_row_fab")
                            .navigationBarsPadding()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ردیف", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Optional Search Bar
                if (showSearchBar) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = uiState.searchQuery,
                                onValueChange = { viewModel.setSearchQuery(it) },
                                placeholder = { Text("جستجو در کل جدول...") },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                trailingIcon = {
                                    if (uiState.searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                            Icon(Icons.Default.Clear, contentDescription = null)
                                        }
                                    }
                                },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("table_search_input")
                            )
                            IconButton(onClick = {
                                showSearchBar = false
                                viewModel.setSearchQuery("")
                            }) {
                                Icon(Icons.Default.Close, contentDescription = "بستن جستجو")
                            }
                        }
                    }
                }

                // Active Filters Banner (if any)
                if (uiState.filterState.columnFilters.isNotEmpty()) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.FilterAlt,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "فیلتر فعال روی ${uiState.filterState.columnFilters.size} ستون",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            TextButton(onClick = { viewModel.clearAllFilters() }) {
                                Text("حذف همه فیلترها", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }

                // Main Content: Stats Panel OR Table Grid
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    if (showStatsPanel) {
                        StatsPanel(
                            statsResult = statsResult,
                            headers = uiState.gridData.headers,
                            onSelectPlColumn = { colIdx -> viewModel.setPlColumn(colIdx) },
                            onUpdateRrCap = { cap -> viewModel.setRrCap(cap) },
                            onUpdateMoneyManagement = { balance, risk ->
                                viewModel.setMoneyManagement(balance, risk)
                            },
                            onClose = { showStatsPanel = false }
                        )
                    } else {
                        GridTable(
                            headers = uiState.gridData.headers,
                            rows = uiState.gridData.rows,
                            visibleRowIndices = visibleIndices,
                            activeFilteredColumns = uiState.filterState.columnFilters.keys,
                            plColumnIndex = uiState.workbook?.plColumnIndex,
                            onCellClick = { rowIdx, colIdx, currentVal ->
                                activeEditingCell = Triple(rowIdx, colIdx, currentVal)
                            },
                            onColumnFilterClick = { colIdx ->
                                activeFilterColIdx = colIdx
                            },
                            onRowAction = { action, rowIdx ->
                                viewModel.handleRowAction(action, rowIdx)
                            },
                            onColumnAction = { action, colIdx ->
                                when (action) {
                                    ColumnAction.RENAME -> {
                                        val curName = uiState.gridData.headers.getOrNull(colIdx).orEmpty()
                                        columnToRename = Pair(colIdx, curName)
                                    }
                                    ColumnAction.DELETE -> {
                                        val curName = uiState.gridData.headers.getOrNull(colIdx).orEmpty()
                                        columnToDelete = Pair(colIdx, curName)
                                    }
                                    else -> viewModel.handleColumnAction(action, colIdx)
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

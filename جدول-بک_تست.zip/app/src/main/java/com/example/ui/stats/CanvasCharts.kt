package com.example.ui.stats

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.parser.NumberParser
import com.example.engine.GroupStatItem
import com.example.ui.theme.LossRed
import com.example.ui.theme.WinGreen

@Composable
fun EquityCurveChart(
    points: List<Double>,
    isDollarMode: Boolean,
    initialBalance: Double = 500.0,
    modifier: Modifier = Modifier
) {
    if (points.size < 2) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "داده‌های کافی برای رسم نمودار وجود ندارد (حداقل یک معامله نتیجه‌دار نیاز است)",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    val finalVal = points.last()
    val isPositive = if (isDollarMode) finalVal >= initialBalance else finalVal >= 0.0
    val lineColor = if (isPositive) WinGreen else LossRed
    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
    val textColor = MaterialTheme.colorScheme.onSurface.toArgb()

    val minVal = points.minOrNull() ?: 0.0
    val maxVal = points.maxOrNull() ?: 0.0
    val range = if (maxVal - minVal == 0.0) 1.0 else maxVal - minVal

    val baselineVal = if (isDollarMode) initialBalance else 0.0

    val finalLabel = if (isDollarMode) {
        "${NumberParser.formatNumber(finalVal, 2)} دلار"
    } else {
        "${if (finalVal >= 0) "+" else ""}${NumberParser.formatNumber(finalVal, 2)} تارگت"
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isDollarMode) "منحنی رشد سرمایه (دلاری)" else "منحنی رشد تارگت (R)",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "نهایی: $finalLabel",
                style = MaterialTheme.typography.labelMedium,
                color = lineColor
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .testTag("equity_curve_canvas")
        ) {
            val width = size.width
            val height = size.height
            val padTop = 16f
            val padBottom = 24f
            val padLeft = 40f
            val padRight = 16f

            val chartWidth = width - padLeft - padRight
            val chartHeight = height - padTop - padBottom

            // Draw Y-axis grid lines (3 lines: min, baseline, max)
            val baselineY = padTop + chartHeight * (1f - ((baselineVal - minVal) / range).toFloat().coerceIn(0f, 1f))

            // Baseline dashed line
            drawLine(
                color = Color.Gray.copy(alpha = 0.5f),
                start = Offset(padLeft, baselineY),
                end = Offset(width - padRight, baselineY),
                strokeWidth = 2f
            )

            // Top and bottom grid lines
            drawLine(
                color = gridColor,
                start = Offset(padLeft, padTop),
                end = Offset(width - padRight, padTop),
                strokeWidth = 1f
            )
            drawLine(
                color = gridColor,
                start = Offset(padLeft, height - padBottom),
                end = Offset(width - padRight, height - padBottom),
                strokeWidth = 1f
            )

            // Build path for points
            val stepX = chartWidth / (points.size - 1)
            val linePath = Path()
            val fillPath = Path()

            points.forEachIndexed { i, value ->
                val x = padLeft + i * stepX
                val normalizedY = (1f - ((value - minVal) / range).toFloat()).coerceIn(0f, 1f)
                val y = padTop + chartHeight * normalizedY

                if (i == 0) {
                    linePath.moveTo(x, y)
                    fillPath.moveTo(x, baselineY)
                    fillPath.lineTo(x, y)
                } else {
                    linePath.lineTo(x, y)
                    fillPath.lineTo(x, y)
                }
            }

            val lastX = padLeft + (points.size - 1) * stepX
            fillPath.lineTo(lastX, baselineY)
            fillPath.close()

            // Fill gradient under curve
            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(lineColor.copy(alpha = 0.35f), lineColor.copy(alpha = 0.02f)),
                    startY = padTop,
                    endY = height - padBottom
                )
            )

            // Stroke line
            drawPath(
                path = linePath,
                color = lineColor,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )

            // Draw endpoint circle
            val lastVal = points.last()
            val lastY = padTop + chartHeight * (1f - ((lastVal - minVal) / range).toFloat()).coerceIn(0f, 1f)
            drawCircle(
                color = lineColor,
                radius = 5.dp.toPx(),
                center = Offset(lastX, lastY)
            )

            // Y-Axis labels (native canvas)
            val paint = android.graphics.Paint().apply {
                this.color = textColor
                this.textSize = 24f
                this.textAlign = android.graphics.Paint.Align.RIGHT
                this.isAntiAlias = true
            }

            drawContext.canvas.nativeCanvas.drawText(
                NumberParser.formatNumber(maxVal, 1),
                padLeft - 6f,
                padTop + 10f,
                paint
            )
            drawContext.canvas.nativeCanvas.drawText(
                NumberParser.formatNumber(minVal, 1),
                padLeft - 6f,
                height - padBottom,
                paint
            )
        }
    }
}

@Composable
fun GroupBarChart(
    items: List<GroupStatItem>,
    isDollarMode: Boolean,
    showWinRate: Boolean,
    onToggleMetric: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (items.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(180.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "داده‌ای برای گروه‌بندی وجود ندارد",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    val displayItems = items.take(8) // Display top 8 groups for clarity
    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
    val textColor = MaterialTheme.colorScheme.onSurface.toArgb()
    val primaryColor = MaterialTheme.colorScheme.primary

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (showWinRate) "نرخ برد بر اساس گروه (%)"
                else if (isDollarMode) "سود خالص دلاری بر اساس گروه"
                else "نتیجه خالص (تارگت) بر اساس گروه",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            FilterChip(
                selected = showWinRate,
                onClick = onToggleMetric,
                label = { Text(if (showWinRate) "نمایش سود/زیان" else "نمایش نرخ برد") },
                modifier = Modifier.testTag("group_metric_toggle")
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .testTag("group_bar_chart_canvas")
        ) {
            val width = size.width
            val height = size.height
            val padTop = 20f
            val padBottom = 45f
            val padLeft = 20f
            val padRight = 20f

            val chartWidth = width - padLeft - padRight
            val chartHeight = height - padTop - padBottom

            val values = displayItems.map {
                if (showWinRate) it.winRatePercent
                else if (isDollarMode) it.netDollarEffect
                else it.netR
            }

            val maxVal = if (showWinRate) 100.0 else maxOf(1.0, values.maxOrNull() ?: 1.0)
            val minVal = if (showWinRate) 0.0 else minOf(0.0, values.minOrNull() ?: 0.0)
            val range = if (maxVal - minVal == 0.0) 1.0 else maxVal - minVal

            val baselineY = padTop + chartHeight * (1f - ((0.0 - minVal) / range).toFloat().coerceIn(0f, 1f))

            // Draw zero baseline
            drawLine(
                color = Color.Gray.copy(alpha = 0.6f),
                start = Offset(padLeft, baselineY),
                end = Offset(width - padRight, baselineY),
                strokeWidth = 2f
            )

            val barCount = displayItems.size
            val slotWidth = chartWidth / barCount
            val barWidth = (slotWidth * 0.55f).coerceAtMost(36.dp.toPx())

            val textPaint = android.graphics.Paint().apply {
                this.color = textColor
                this.textSize = 24f
                this.textAlign = android.graphics.Paint.Align.CENTER
                this.isAntiAlias = true
            }

            val labelPaint = android.graphics.Paint().apply {
                this.color = textColor
                this.textSize = 20f
                this.textAlign = android.graphics.Paint.Align.CENTER
                this.isAntiAlias = true
            }

            displayItems.forEachIndexed { idx, item ->
                val v = values[idx]
                val slotCenterX = padLeft + idx * slotWidth + slotWidth / 2f
                val barLeft = slotCenterX - barWidth / 2f

                val barColor = if (showWinRate) {
                    if (v >= 50.0) WinGreen else LossRed
                } else {
                    if (v >= 0.0) WinGreen else LossRed
                }

                val barTop: Float
                val barHeight: Float
                if (v >= 0.0) {
                    val y = padTop + chartHeight * (1f - ((v - minVal) / range).toFloat())
                    barTop = y
                    barHeight = baselineY - y
                } else {
                    val y = padTop + chartHeight * (1f - ((v - minVal) / range).toFloat())
                    barTop = baselineY
                    barHeight = y - baselineY
                }

                drawRect(
                    color = barColor,
                    topLeft = Offset(barLeft, barTop),
                    size = Size(barWidth, barHeight.coerceAtLeast(2f))
                )

                // Draw value label above/below bar
                val valText = if (showWinRate) {
                    "${v.toInt()}%"
                } else {
                    NumberParser.formatNumber(v, 1)
                }
                val valY = if (v >= 0.0) barTop - 6f else barTop + barHeight + 22f
                drawContext.canvas.nativeCanvas.drawText(valText, slotCenterX, valY, labelPaint)

                // Draw group name label under baseline/bottom
                val labelText = if (item.groupValue.length > 8) {
                    item.groupValue.take(7) + "…"
                } else {
                    item.groupValue
                }
                drawContext.canvas.nativeCanvas.drawText(
                    labelText,
                    slotCenterX,
                    height - 10f,
                    textPaint
                )
            }
        }
    }
}

package com.example.ui.list

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.FilterState
import com.example.data.model.GridData
import com.example.data.model.Workbook
import com.example.data.repository.SettingsRepository
import com.example.data.repository.WorkbookRepository
import com.example.data.sample.SampleData
import com.example.data.xlsx.XlsxHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ListUiState(
    val workbooks: List<Workbook> = emptyList(),
    val searchQuery: String = "",
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null
)

class WorkbookListViewModel(
    private val repository: WorkbookRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _errorMessage = MutableStateFlow<String?>(null)
    private val _successMessage = MutableStateFlow<String?>(null)

    val uiState: StateFlow<ListUiState> = combine(
        repository.getAllWorkbooksFlow(),
        _searchQuery,
        _errorMessage,
        _successMessage
    ) { workbooks, search, err, success ->
        val filtered = if (search.isBlank()) {
            workbooks
        } else {
            workbooks.filter { it.name.contains(search.trim(), ignoreCase = true) }
        }
        ListUiState(
            workbooks = filtered,
            searchQuery = search,
            errorMessage = err,
            successMessage = success
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = ListUiState()
    )

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun createNewWorkbook(title: String, onSuccess: (Long) -> Unit) {
        viewModelScope.launch {
            val trimmed = if (title.isBlank()) "بک‌تست جدید" else title.trim()
            val defBalance = settingsRepository.defaultBalanceFlow.first()
            val defRisk = settingsRepository.defaultRiskFlow.first()

            val defaultHeaders = listOf("معامله", "جفت ارز", "جهت", "تایم فریم", "تارگت/استاپ", "توضیحات")
            val defaultRows = listOf(
                listOf("1", "EUR/USD", "Buy", "15m", "2", "شکست سطح حمایت"),
                listOf("2", "GBP/USD", "Sell", "1h", "-", "فیک بریک‌اوت")
            )
            val gridData = GridData(headers = defaultHeaders, rows = defaultRows)

            val newWb = Workbook(
                name = trimmed,
                gridJson = gridData.toJson(),
                filterStateJson = FilterState().toJson(),
                plColumnIndex = 4, // "تارگت/استاپ"
                initialBalance = defBalance,
                riskPercent = defRisk
            )

            val id = repository.insertWorkbook(newWb)
            onSuccess(id)
        }
    }

    fun loadSampleData(onSuccess: (Long) -> Unit) {
        viewModelScope.launch {
            val defBalance = settingsRepository.defaultBalanceFlow.first()
            val defRisk = settingsRepository.defaultRiskFlow.first()
            val sampleWb = SampleData.createSampleWorkbook(defBalance, defRisk)
            val id = repository.insertWorkbook(sampleWb)
            _successMessage.value = "جدول نمونه با موفقیت ایجاد شد"
            onSuccess(id)
        }
    }

    fun importXlsx(context: Context, uri: Uri, onSuccess: (Long) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val gridData = context.contentResolver.openInputStream(uri)?.use { inputStream ->
                    XlsxHandler.readXlsx(inputStream)
                } ?: throw Exception("خطا در باز کردن فایل")

                // Auto-detect result column (P/L)
                val detectedPlCol = SampleData.detectPlColumn(gridData.headers, gridData.rows)

                val defBalance = settingsRepository.defaultBalanceFlow.first()
                val defRisk = settingsRepository.defaultRiskFlow.first()

                // Extract filename without extension for workbook title
                var fileName = "فایل وارد شده"
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (cursor.moveToFirst() && nameIndex >= 0) {
                        fileName = cursor.getString(nameIndex).substringBeforeLast(".")
                    }
                }

                val wb = Workbook(
                    name = fileName,
                    gridJson = gridData.toJson(),
                    filterStateJson = FilterState().toJson(),
                    plColumnIndex = detectedPlCol,
                    initialBalance = defBalance,
                    riskPercent = defRisk
                )

                val id = repository.insertWorkbook(wb)
                withContext(Dispatchers.Main) {
                    _successMessage.value = "فایل اکسل با موفقیت وارد شد"
                    onSuccess(id)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _errorMessage.value = "خطا در وارد کردن فایل اکسل: ${e.message}"
                }
            }
        }
    }

    fun duplicateWorkbook(workbook: Workbook) {
        viewModelScope.launch {
            val copy = workbook.copy(
                id = 0,
                name = "${workbook.name} (کپی)",
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            repository.insertWorkbook(copy)
            _successMessage.value = "جدول تکثیر شد"
        }
    }

    fun renameWorkbook(workbook: Workbook, newName: String) {
        viewModelScope.launch {
            if (newName.isNotBlank()) {
                repository.updateWorkbook(workbook.copy(name = newName.trim()))
                _successMessage.value = "نام جدول تغییر یافت"
            }
        }
    }

    fun deleteWorkbook(workbook: Workbook) {
        viewModelScope.launch {
            repository.deleteWorkbook(workbook)
            _successMessage.value = "جدول حذف شد"
        }
    }

    fun clearMessages() {
        _errorMessage.value = null
        _successMessage.value = null
    }
}

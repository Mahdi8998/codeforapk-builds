package com.example.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiService
import com.example.data.parser.NumberParser
import com.example.data.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ThemeMode(val persianLabel: String) {
    SYSTEM("پیروی از سیستم"),
    LIGHT("روشن"),
    DARK("تاریک")
}

data class SettingsUiState(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val apiKey: String = "",
    val defaultInitialBalance: Double = 500.0,
    val defaultRiskPercent: Double = 2.0,
    val isTestingConnection: Boolean = false,
    val connectionTestSuccess: Boolean? = null,
    val connectionTestMessage: String? = null,
    val saveMessage: String? = null
)

class SettingsViewModel(
    private val repository: SettingsRepository,
    private val geminiService: GeminiService = GeminiService()
) : ViewModel() {

    private val _isTesting = MutableStateFlow(false)
    private val _testSuccess = MutableStateFlow<Boolean?>(null)
    private val _testMessage = MutableStateFlow<String?>(null)
    private val _saveMessage = MutableStateFlow<String?>(null)

    val uiState: StateFlow<SettingsUiState> = combine(
        repository.themeModeFlow,
        repository.geminiApiKeyFlow,
        repository.defaultBalanceFlow,
        repository.defaultRiskFlow,
        _isTesting,
        _testSuccess,
        _testMessage,
        _saveMessage
    ) { params ->
        val themeStr = params[0] as String
        val key = params[1] as String
        val balance = params[2] as Double
        val risk = params[3] as Double
        val isTesting = params[4] as Boolean
        val testSuccess = params[5] as Boolean?
        val testMessage = params[6] as String?
        val saveMsg = params[7] as String?

        val mode = when (themeStr) {
            "light" -> ThemeMode.LIGHT
            "dark" -> ThemeMode.DARK
            else -> ThemeMode.SYSTEM
        }

        SettingsUiState(
            themeMode = mode,
            apiKey = key,
            defaultInitialBalance = balance,
            defaultRiskPercent = risk,
            isTestingConnection = isTesting,
            connectionTestSuccess = testSuccess,
            connectionTestMessage = testMessage,
            saveMessage = saveMsg
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = SettingsUiState()
    )

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            val str = when (mode) {
                ThemeMode.LIGHT -> "light"
                ThemeMode.DARK -> "dark"
                ThemeMode.SYSTEM -> "system"
            }
            repository.setThemeMode(str)
        }
    }

    fun saveApiKey(newKey: String) {
        viewModelScope.launch {
            repository.setGeminiApiKey(newKey.trim())
            _saveMessage.value = "کلید API ذخیره شد"
            _testSuccess.value = null
            _testMessage.value = null
        }
    }

    fun testConnection(key: String) {
        viewModelScope.launch {
            _isTesting.value = true
            _testSuccess.value = null
            _testMessage.value = null

            val result = geminiService.testConnection(key.trim())
            _isTesting.value = false
            if (result.isSuccess) {
                _testSuccess.value = true
                _testMessage.value = "اتصال با موفقیت برقرار شد"
            } else {
                _testSuccess.value = false
                _testMessage.value = result.exceptionOrNull()?.message ?: "خطا در برقراری اتصال"
            }
        }
    }

    fun saveDefaults(balanceStr: String, riskStr: String) {
        viewModelScope.launch {
            val b = NumberParser.parseDouble(balanceStr) ?: 500.0
            val r = NumberParser.parseDouble(riskStr) ?: 2.0
            repository.setDefaultBalance(b)
            repository.setDefaultRisk(r)
            _saveMessage.value = "تنظیمات پیش‌فرض ذخیره شد"
        }
    }

    fun clearSaveMessage() {
        _saveMessage.value = null
    }
}

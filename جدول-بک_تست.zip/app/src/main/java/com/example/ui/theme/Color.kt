package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary emerald / fintech theme
val EmeraldPrimary = Color(0xFF00897B)
val EmeraldPrimaryContainer = Color(0xFFE0F2F1)
val EmeraldOnPrimary = Color(0xFFFFFFFF)
val EmeraldOnPrimaryContainer = Color(0xFF004D40)

val DarkEmeraldPrimary = Color(0xFF4DB6AC)
val DarkEmeraldPrimaryContainer = Color(0xFF004D40)
val DarkEmeraldOnPrimary = Color(0xFF00251A)
val DarkEmeraldOnPrimaryContainer = Color(0xFFB2DFDB)

val SlateSecondary = Color(0xFF455A64)
val SlateSecondaryContainer = Color(0xFFECEFF1)
val SlateOnSecondary = Color(0xFFFFFFFF)
val SlateOnSecondaryContainer = Color(0xFF263238)

val DarkSlateSecondary = Color(0xFF90A4AE)
val DarkSlateSecondaryContainer = Color(0xFF37474F)
val DarkSlateOnSecondary = Color(0xFF1C2833)
val DarkSlateOnSecondaryContainer = Color(0xFFCFD8DC)

val WinGreen = Color(0xFF2E7D32)
val WinGreenContainer = Color(0xFFE8F5E9)
val LossRed = Color(0xFFC62828)
val LossRedContainer = Color(0xFFFFEBEE)

val TableHeaderBgLight = Color(0xFFECEFF1)
val TableHeaderBgDark = Color(0xFF263238)
val TableGridLineLight = Color(0xFFCFD8DC)
val TableGridLineDark = Color(0xFF37474F)
val TableRowAltLight = Color(0xFFF9FBFB)
val TableRowAltDark = Color(0xFF1E282D)
val TableCellSelectedLight = Color(0xFFB2DFDB)
val TableCellSelectedDark = Color(0xFF004D40)

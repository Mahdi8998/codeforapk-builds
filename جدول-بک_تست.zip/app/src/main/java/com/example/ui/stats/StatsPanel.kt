package com.example.ui.stats

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.parser.NumberParser
import com.example.engine.GroupStatItem
import com.example.engine.StatsResult
import com.example.ui.theme.LossRed
import com.example.ui.theme.WinGreen

@Composable
fun StatsPanel(
    statsResult: StatsResult,
    headers: List<String>,
    onSelectPlColumn: (Int) -> Unit,
    onUpdateRrCap: (Double?) -> Unit,
    onUpdateMoneyManagement: (initialBalance: Double, riskPercent: Double) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("خلاصه", "حرفه‌ای", "گروه‌بندی", "نمودارها", "دلاری")

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Surface(
            modifier = modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "تحلیل و آمار بک‌تست",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        val scopeText = if (statsResult.filteredRowCount < statsResult.totalRowCount) {
                            "محاسبه روی ${statsResult.filteredRowCount} ردیف فیلترشده از ${statsResult.totalRowCount} ردیف"
                        } else {
                            "محاسبه روی کل ${statsResult.totalRowCount} ردیف"
                        }
                        Text(
                            text = scopeText,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.testTag("close_stats_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "بستن پنل آمار")
                    }
                }

                // Tab Row
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    edgePadding = 12.dp,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = { Text(title, style = MaterialTheme.typography.titleSmall) },
                            modifier = Modifier.testTag("stats_tab_$index")
                        )
                    }
                }

                // Tab Content
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    when (selectedTab) {
                        0 -> SummaryTab(statsResult)
                        1 -> ProfessionalTab(
                            statsResult = statsResult,
                            headers = headers,
                            onSelectPlColumn = onSelectPlColumn,
                            onUpdateRrCap = onUpdateRrCap
                        )
                        2 -> GroupingTab(
                            statsResult = statsResult,
                            headers = headers,
                            onSelectPlColumn = onSelectPlColumn
                        )
                        3 -> ChartsTab(
                            statsResult = statsResult,
                            headers = headers,
                            onSelectPlColumn = onSelectPlColumn
                        )
                        4 -> DollarTab(
                            statsResult = statsResult,
                            headers = headers,
                            onSelectPlColumn = onSelectPlColumn,
                            onUpdateMoneyManagement = onUpdateMoneyManagement
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 1: SUMMARY TAB («خلاصه»)
// -------------------------------------------------------------
@Composable
private fun SummaryTab(statsResult: StatsResult) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("تعداد کل ردیف‌های نمایشی:", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        text = "${statsResult.filteredRowCount}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        items(statsResult.columnSummaries) { col ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ستون: ${col.header}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    if (col.isNumeric && col.sum != null && col.average != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("مجموع:", style = MaterialTheme.typography.bodyMedium)
                            Text(NumberParser.formatNumber(col.sum), fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("میانگین:", style = MaterialTheme.typography.bodyMedium)
                            Text(NumberParser.formatNumber(col.average), fontWeight = FontWeight.SemiBold)
                        }
                    } else if (col.categoricalBreakdown != null) {
                        Text(
                            text = "درصد تفکیک مقادیر:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        col.categoricalBreakdown.forEach { (category, pct) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(category, style = MaterialTheme.typography.bodyMedium)
                                Text("${NumberParser.formatNumber(pct, 1)}%", fontWeight = FontWeight.SemiBold)
                            }
                        }
                    } else {
                        Text(
                            text = "تعداد مقادیر متمایز: ${col.distinctCount}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 2: PROFESSIONAL TAB («حرفه‌ای»)
// -------------------------------------------------------------
@Composable
private fun ProfessionalTab(
    statsResult: StatsResult,
    headers: List<String>,
    onSelectPlColumn: (Int) -> Unit,
    onUpdateRrCap: (Double?) -> Unit
) {
    if (statsResult.plColumnIndex == null) {
        ResultColumnSelectorCard(headers = headers, onSelect = onSelectPlColumn)
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Result Column Selector Button (Changeable)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ستون نتیجه: ${statsResult.plColumnHeader ?: "—"}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "معاملات محاسبه‌شده: ${statsResult.countedTradesCount} | ردیف‌های بدون نتیجه: ${statsResult.excludedEmptyCount + statsResult.excludedInvalidCount}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    var showDropdown by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { showDropdown = true }) {
                            Text("تغییر ستون")
                        }
                        DropdownMenu(
                            expanded = showDropdown,
                            onDismissRequest = { showDropdown = false }
                        ) {
                            headers.forEachIndexed { idx, h ->
                                DropdownMenuItem(
                                    text = { Text(h) },
                                    onClick = {
                                        showDropdown = false
                                        onSelectPlColumn(idx)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // R:R Cap Settings Card
        item {
            RrCapCard(
                currentCap = statsResult.rrCap,
                onUpdateRrCap = onUpdateRrCap
            )
        }

        if (statsResult.countedTradesCount == 0) {
            item {
                EmptyTradesCard()
            }
        } else {
            // Metric Cards Grid
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard(
                            title = "نتیجه خالص (تارگت)",
                            value = "${if (statsResult.netR >= 0) "+" else ""}${NumberParser.formatNumber(statsResult.netR, 2)} R",
                            valueColor = if (statsResult.netR >= 0) WinGreen else LossRed,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "نرخ برد",
                            value = "${NumberParser.formatNumber(statsResult.winRatePercent, 1)}%",
                            valueColor = if (statsResult.winRatePercent >= 50) WinGreen else LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard(
                            title = "فکتور سود (Profit Factor)",
                            value = if (statsResult.profitFactor.isInfinite()) "∞" else NumberParser.formatNumber(statsResult.profitFactor, 2),
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "امید ریاضی (Expectancy)",
                            value = "${if (statsResult.expectancyR >= 0) "+" else ""}${NumberParser.formatNumber(statsResult.expectancyR, 2)} R",
                            valueColor = if (statsResult.expectancyR >= 0) WinGreen else LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard(
                            title = "میانگین برد (R)",
                            value = "+${NumberParser.formatNumber(statsResult.avgWinR, 2)}",
                            valueColor = WinGreen,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "میانگین ضرر (R)",
                            value = "-${NumberParser.formatNumber(statsResult.avgLossR, 2)}",
                            valueColor = LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard(
                            title = "نسبت ریوارد به ریسک",
                            value = NumberParser.formatNumber(statsResult.rewardToRiskRatio, 2),
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "بردها / باخت‌ها",
                            value = "${statsResult.winsCount} / ${statsResult.lossesCount}",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard(
                            title = "بهترین معامله (R)",
                            value = "+${NumberParser.formatNumber(statsResult.bestTradeR, 2)}",
                            valueColor = WinGreen,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "بدترین معامله (R)",
                            value = "${NumberParser.formatNumber(statsResult.worstTradeR, 2)}",
                            valueColor = LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard(
                            title = "بیشترین برد متوالی",
                            value = "${statsResult.maxConsecutiveWins}",
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "بیشترین باخت متوالی",
                            value = "${statsResult.maxConsecutiveLosses}",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard(
                            title = "حداکثر افت سرمایه (Drawdown)",
                            value = "${NumberParser.formatNumber(statsResult.maxDrawdownR, 2)} R (${NumberParser.formatNumber(statsResult.maxDrawdownPercent, 1)}%)",
                            valueColor = LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 3: GROUPING TAB («گروه‌بندی»)
// -------------------------------------------------------------
@Composable
private fun GroupingTab(
    statsResult: StatsResult,
    headers: List<String>,
    onSelectPlColumn: (Int) -> Unit
) {
    if (statsResult.plColumnIndex == null) {
        ResultColumnSelectorCard(headers = headers, onSelect = onSelectPlColumn)
        return
    }

    var selectedColIdx by remember(statsResult.defaultGroupColIndex) {
        mutableStateOf(statsResult.defaultGroupColIndex ?: 0)
    }

    val availableCols = headers.indices.filter { it != statsResult.plColumnIndex }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("گروه‌بندی بر اساس ستون:", style = MaterialTheme.typography.bodyMedium)
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { expanded = true }) {
                            Text(headers.getOrNull(selectedColIdx) ?: "انتخاب ستون")
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            availableCols.forEach { idx ->
                                DropdownMenuItem(
                                    text = { Text(headers[idx]) },
                                    onClick = {
                                        selectedColIdx = idx
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        val groupList = statsResult.groupStatsByColumn[selectedColIdx] ?: emptyList()
        if (groupList.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("هیچ داده‌ای برای این ستون وجود ندارد.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            items(groupList) { item ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = item.groupValue,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${item.tradeCount} معامله",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("نرخ برد: ${NumberParser.formatNumber(item.winRatePercent, 1)}%", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = "نتیجه: ${if (item.netR >= 0) "+" else ""}${NumberParser.formatNumber(item.netR, 2)} تارگت",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (item.netR >= 0) WinGreen else LossRed
                            )
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 4: CHARTS TAB («نمودارها»)
// -------------------------------------------------------------
@Composable
private fun ChartsTab(
    statsResult: StatsResult,
    headers: List<String>,
    onSelectPlColumn: (Int) -> Unit
) {
    if (statsResult.plColumnIndex == null) {
        ResultColumnSelectorCard(headers = headers, onSelect = onSelectPlColumn)
        return
    }

    var isDollarMode by remember { mutableStateOf(false) }
    var showBarWinRate by remember { mutableStateOf(false) }

    val defaultGroupIdx = statsResult.defaultGroupColIndex ?: 0
    val groupItems = statsResult.groupStatsByColumn[defaultGroupIdx] ?: emptyList()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Unit Toggle
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("واحد نمودار:", style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.width(12.dp))
                FilterChip(
                    selected = !isDollarMode,
                    onClick = { isDollarMode = false },
                    label = { Text("تارگت (R)") }
                )
                Spacer(modifier = Modifier.width(8.dp))
                FilterChip(
                    selected = isDollarMode,
                    onClick = { isDollarMode = true },
                    label = { Text("دلار ($)") }
                )
            }
        }

        // Equity Curve
        item {
            val curvePoints = if (isDollarMode) statsResult.dollarEquityCurve else statsResult.rEquityCurve
            EquityCurveChart(
                points = curvePoints,
                isDollarMode = isDollarMode,
                initialBalance = statsResult.initialBalance
            )
        }

        // Bar Chart by Group
        item {
            GroupBarChart(
                items = groupItems,
                isDollarMode = isDollarMode,
                showWinRate = showBarWinRate,
                onToggleMetric = { showBarWinRate = !showBarWinRate }
            )
        }
    }
}

// -------------------------------------------------------------
// TAB 5: DOLLAR TAB («دلاری»)
// -------------------------------------------------------------
@Composable
private fun DollarTab(
    statsResult: StatsResult,
    headers: List<String>,
    onSelectPlColumn: (Int) -> Unit,
    onUpdateMoneyManagement: (initialBalance: Double, riskPercent: Double) -> Unit
) {
    if (statsResult.plColumnIndex == null) {
        ResultColumnSelectorCard(headers = headers, onSelect = onSelectPlColumn)
        return
    }

    var showEditDialog by remember { mutableStateOf(false) }

    if (showEditDialog) {
        MoneyManagementDialog(
            currentBalance = statsResult.initialBalance,
            currentRisk = statsResult.riskPercent,
            onDismiss = { showEditDialog = false },
            onConfirm = { b, r ->
                onUpdateMoneyManagement(b, r)
                showEditDialog = false
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Money Management Settings Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "تنظیمات مدیریت سرمایه",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        OutlinedButton(onClick = { showEditDialog = true }) {
                            Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ویرایش")
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("موجودی اولیه: $${NumberParser.formatNumber(statsResult.initialBalance, 0)}")
                        Text("درصد ریسک هر معامله: ${NumberParser.formatNumber(statsResult.riskPercent, 1)}%")
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    val basisNote = if (statsResult.rrCap != null && statsResult.rrCap > 0) {
                        "مبنای سود: R:R = ${NumberParser.formatNumber(statsResult.rrCap, 1)}"
                    } else {
                        "مبنای سود: بدون محدودیت"
                    }
                    Text(
                        text = basisNote,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "ترتیب ردیف‌ها به‌عنوان ترتیب زمانی معاملات در نظر گرفته می‌شود.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (statsResult.countedTradesCount == 0) {
            item {
                EmptyTradesCard()
            }
        } else {
            // Dollar Metrics
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard(
                            title = "موجودی نهایی",
                            value = "$${NumberParser.formatNumber(statsResult.finalBalance, 2)}",
                            valueColor = if (statsResult.finalBalance >= statsResult.initialBalance) WinGreen else LossRed,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "سود/زیان خالص (دلار)",
                            value = "${if (statsResult.netProfitDollar >= 0) "+" else ""}$${NumberParser.formatNumber(statsResult.netProfitDollar, 2)}",
                            valueColor = if (statsResult.netProfitDollar >= 0) WinGreen else LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard(
                            title = "بازده کل (Return)",
                            value = "${if (statsResult.totalReturnPercent >= 0) "+" else ""}${NumberParser.formatNumber(statsResult.totalReturnPercent, 1)}%",
                            valueColor = if (statsResult.totalReturnPercent >= 0) WinGreen else LossRed,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "تعداد کل معاملات",
                            value = "${statsResult.countedTradesCount} (بدون نتیجه: ${statsResult.excludedEmptyCount})",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard(
                            title = "میانگین سود معامله",
                            value = "+$${NumberParser.formatNumber(statsResult.avgWinDollar, 2)}",
                            valueColor = WinGreen,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "میانگین ضرر معامله",
                            value = "-$${NumberParser.formatNumber(statsResult.avgLossDollar, 2)}",
                            valueColor = LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard(
                            title = "بهترین معامله (دلار)",
                            value = "+$${NumberParser.formatNumber(statsResult.bestTradeDollar, 2)}",
                            valueColor = WinGreen,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "بدترین معامله (دلار)",
                            value = "$${NumberParser.formatNumber(statsResult.worstTradeDollar, 2)}",
                            valueColor = LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard(
                            title = "حداکثر افت سرمایه (دلاری)",
                            value = "$${NumberParser.formatNumber(statsResult.maxDrawdownDollar, 2)}",
                            valueColor = LossRed,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "حداکثر افت سرمایه (درصدی)",
                            value = "${NumberParser.formatNumber(statsResult.maxDrawdownDollarPercent, 1)}%",
                            valueColor = LossRed,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// REUSABLE HELPER COMPONENTS
// -------------------------------------------------------------

@Composable
private fun MetricCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = valueColor
            )
        }
    }
}

@Composable
private fun ResultColumnSelectorCard(
    headers: List<String>,
    onSelect: (Int) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "کدام ستون نتیجه معاملات است؟",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "در این ستون: علامت - یعنی استاپ خورده؛ عدد یعنی شماره تارگت (مثلاً ۳ یعنی تارگت ۳ خورده)؛ خانه خالی یعنی بدون نتیجه و از محاسبات حذف می‌شود.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(14.dp))

            var expanded by remember { mutableStateOf(false) }
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { expanded = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("انتخاب ستون نتیجه")
                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                }
                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    headers.forEachIndexed { idx, h ->
                        DropdownMenuItem(
                            text = { Text(h) },
                            onClick = {
                                expanded = false
                                onSelect(idx)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RrCapCard(
    currentCap: Double?,
    onUpdateRrCap: (Double?) -> Unit
) {
    var isEnabled by remember(currentCap) { mutableStateOf(currentCap != null && currentCap > 0) }
    var capInput by remember(currentCap) {
        mutableStateOf(currentCap?.let { NumberParser.formatNumber(it, 1, false) } ?: "1.5")
    }
    var inputError by remember { mutableStateOf<String?>(null) }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "محاسبه سود بر اساس R:R مشخص",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Switch(
                    checked = isEnabled,
                    onCheckedChange = { checked ->
                        isEnabled = checked
                        if (!checked) {
                            inputError = null
                            onUpdateRrCap(null)
                        } else {
                            val parsed = NumberParser.parseDouble(capInput)
                            if (parsed != null && parsed > 0) {
                                inputError = null
                                onUpdateRrCap(parsed)
                            } else {
                                inputError = "عدد بزرگ‌تر از ۰ وارد کنید"
                            }
                        }
                    }
                )
            }

            if (isEnabled) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = capInput,
                        onValueChange = { newVal ->
                            capInput = newVal
                            val parsed = NumberParser.parseDouble(newVal)
                            if (parsed != null && parsed > 0) {
                                inputError = null
                                onUpdateRrCap(parsed)
                            } else {
                                inputError = "مقدار باید بزرگتر از صفر باشد"
                            }
                        },
                        label = { Text("مقدار R:R (مثلاً ۱ یا ۱.۵ یا ۲)") },
                        isError = inputError != null,
                        supportingText = inputError?.let { { Text(it) } },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = "مبنا: R:R = ${capInput} — درصد برد و آمار ضرر تغییری نمی‌کنند (طبیعی است).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "با فعال بودن، هر سودی بزرگ‌تر از این R:R به همان اندازه محدود می‌شود؛ مثلاً با R:R = ۱، تارگت ۳ هم +۱ حساب می‌شود. سمت ضرر (استاپ = −۱) تغییری نمی‌کند.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun MoneyManagementDialog(
    currentBalance: Double,
    currentRisk: Double,
    onDismiss: () -> Unit,
    onConfirm: (Double, Double) -> Unit
) {
    var balanceText by remember { mutableStateOf(NumberParser.formatNumber(currentBalance, 0, false)) }
    var riskText by remember { mutableStateOf(NumberParser.formatNumber(currentRisk, 1, false)) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تنظیمات مدیریت سرمایه") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = balanceText,
                    onValueChange = { balanceText = it },
                    label = { Text("موجودی اولیه (دلار)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = riskText,
                    onValueChange = { riskText = it },
                    label = { Text("درصد ریسک هر معامله (%)") },
                    modifier = Modifier.fillMaxWidth()
                )
                if (errorMsg != null) {
                    Text(
                        text = errorMsg!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsedBalance = NumberParser.parseDouble(balanceText)
                    val parsedRisk = NumberParser.parseDouble(riskText)

                    if (parsedBalance == null || parsedBalance <= 0) {
                        errorMsg = "موجودی اولیه باید بزرگتر از صفر باشد."
                        return@Button
                    }
                    if (parsedRisk == null || parsedRisk <= 0 || parsedRisk > 100) {
                        errorMsg = "درصد ریسک باید بین ۰ و ۱۰۰ باشد."
                        return@Button
                    }

                    onConfirm(parsedBalance, parsedRisk)
                }
            ) {
                Text("ذخیره")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("انصراف")
            }
        }
    )
}

@Composable
private fun EmptyTradesCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("—", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.outline)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "هیچ معامله دارای نتیجه‌ای در این نما یافت نشد.",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "مطمئن شوید در ستون نتیجه علامت '-' یا عدد تارگت وارد شده است.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

package com.example.ui.ai

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiDataMode
import com.example.ai.AiPayloadBuilder
import com.example.ai.ChatMessage
import com.example.ai.GeminiService
import com.example.data.repository.SettingsRepository
import com.example.engine.StatsInput
import com.example.engine.StatsResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class AiMessageItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val role: String, // "user" or "model"
    val text: String,
    val isStreaming: Boolean = false
)

data class AiScreenUiState(
    val apiKey: String = "",
    val isApiKeyMissing: Boolean = false,
    val selectedDataMode: AiDataMode = AiDataMode.SUMMARY,
    val messages: List<AiMessageItem> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val showRowCapDialog: Boolean = false,
    val pendingQuery: String? = null
)

class AiAnalystViewModel(
    private val settingsRepository: SettingsRepository,
    private val geminiService: GeminiService = GeminiService()
) : ViewModel() {

    private val _uiState = MutableStateFlow(AiScreenUiState())
    val uiState: StateFlow<AiScreenUiState> = _uiState.asStateFlow()

    // Captured snapshot at session start or reset
    private var capturedStatsInput: StatsInput? = null
    private var capturedStatsResult: StatsResult? = null

    private var activeStreamJob: Job? = null

    init {
        viewModelScope.launch {
            val key = settingsRepository.geminiApiKeyFlow.first()
            _uiState.value = _uiState.value.copy(
                apiKey = key,
                isApiKeyMissing = key.isBlank()
            )
        }
    }

    fun initSession(statsInput: StatsInput, statsResult: StatsResult) {
        if (capturedStatsInput == null) {
            capturedStatsInput = statsInput
            capturedStatsResult = statsResult
        }
    }

    fun resetSession(newStatsInput: StatsInput, newStatsResult: StatsResult) {
        activeStreamJob?.cancel()
        capturedStatsInput = newStatsInput
        capturedStatsResult = newStatsResult
        _uiState.value = _uiState.value.copy(
            messages = emptyList(),
            isLoading = false,
            errorMessage = null,
            pendingQuery = null,
            showRowCapDialog = false
        )
    }

    fun setDataMode(mode: AiDataMode) {
        _uiState.value = _uiState.value.copy(selectedDataMode = mode)
    }

    fun triggerPreset(presetTitle: String) {
        sendMessage(presetTitle)
    }

    fun sendMessage(userText: String) {
        val trimmed = userText.trim()
        if (trimmed.isEmpty()) return

        val input = capturedStatsInput ?: return
        val result = capturedStatsResult ?: return

        if (input.allRows.isEmpty()) {
            _uiState.value = _uiState.value.copy(
                errorMessage = "هیچ ردیفی برای تحلیل وجود ندارد؛ فیلترها را بردارید."
            )
            return
        }

        // Check complete mode 500 row cap
        if (_uiState.value.selectedDataMode == AiDataMode.COMPLETE && input.allRows.size > AiPayloadBuilder.COMPLETE_ROW_CAP) {
            _uiState.value = _uiState.value.copy(
                showRowCapDialog = true,
                pendingQuery = trimmed
            )
            return
        }

        executeAnalysis(trimmed, _uiState.value.selectedDataMode)
    }

    fun confirmSendSummaryMode() {
        val pending = _uiState.value.pendingQuery ?: return
        _uiState.value = _uiState.value.copy(
            showRowCapDialog = false,
            selectedDataMode = AiDataMode.SUMMARY,
            pendingQuery = null
        )
        executeAnalysis(pending, AiDataMode.SUMMARY)
    }

    fun dismissRowCapDialog() {
        _uiState.value = _uiState.value.copy(showRowCapDialog = false, pendingQuery = null)
    }

    fun dismissError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    private fun executeAnalysis(query: String, mode: AiDataMode) {
        val input = capturedStatsInput ?: return
        val result = capturedStatsResult ?: return
        val apiKey = _uiState.value.apiKey

        if (apiKey.isBlank()) {
            _uiState.value = _uiState.value.copy(isApiKeyMissing = true)
            return
        }

        val userMessage = AiMessageItem(role = "user", text = query)
        val assistantMessage = AiMessageItem(role = "model", text = "", isStreaming = true)

        val updatedMessages = _uiState.value.messages + listOf(userMessage, assistantMessage)
        _uiState.value = _uiState.value.copy(
            messages = updatedMessages,
            isLoading = true,
            errorMessage = null
        )

        activeStreamJob?.cancel()
        activeStreamJob = viewModelScope.launch {
            try {
                val systemPrompt = AiPayloadBuilder.buildSystemInstruction()
                val promptPayload = AiPayloadBuilder.buildPrompt(input, result, mode, query)

                // Build conversation history for API
                val apiConversation = mutableListOf<ChatMessage>()
                // First message includes the table data payload
                val existingHistory = _uiState.value.messages.dropLast(1)
                if (existingHistory.isEmpty()) {
                    apiConversation.add(ChatMessage(role = "user", content = promptPayload))
                } else {
                    // Send first message with payload, then subsequent Q&As
                    apiConversation.add(ChatMessage(role = "user", content = promptPayload))
                    for (msg in existingHistory) {
                        apiConversation.add(ChatMessage(role = msg.role, content = msg.text))
                    }
                }

                val accumulatedText = StringBuilder()
                geminiService.streamGenerateContent(
                    apiKey = apiKey,
                    systemInstruction = systemPrompt,
                    conversation = apiConversation
                ).catch { e ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = e.message ?: "خطای ناشناخته در دریافت پاسخ",
                        messages = _uiState.value.messages.dropLast(1) // remove empty streaming message
                    )
                }.collect { chunk ->
                    accumulatedText.append(chunk)
                    val currentList = _uiState.value.messages.toMutableList()
                    val lastIdx = currentList.lastIndex
                    if (lastIdx >= 0) {
                        currentList[lastIdx] = currentList[lastIdx].copy(
                            text = accumulatedText.toString(),
                            isStreaming = true
                        )
                        _uiState.value = _uiState.value.copy(messages = currentList)
                    }
                }

                // Finished streaming
                val currentList = _uiState.value.messages.toMutableList()
                val lastIdx = currentList.lastIndex
                if (lastIdx >= 0) {
                    currentList[lastIdx] = currentList[lastIdx].copy(isStreaming = false)
                    _uiState.value = _uiState.value.copy(
                        messages = currentList,
                        isLoading = false
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = e.message ?: "خطا در ارتباط با سرور",
                    messages = _uiState.value.messages.dropLast(1)
                )
            }
        }
    }
}

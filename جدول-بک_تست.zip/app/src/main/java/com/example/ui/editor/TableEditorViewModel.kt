package com.example.ui.editor

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.FilterState
import com.example.data.model.GridData
import com.example.data.model.Workbook
import com.example.data.parser.NumberParser
import com.example.data.repository.WorkbookRepository
import com.example.engine.StatsEngine
import com.example.engine.StatsInput
import com.example.engine.StatsResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class EditorUiState(
    val workbook: Workbook? = null,
    val gridData: GridData = GridData(),
    val filterState: FilterState = FilterState(),
    val searchQuery: String = "",
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val isAutoSaving: Boolean = false,
    val lastSaveMessage: String? = null
)

@OptIn(FlowPreview::class)
class TableEditorViewModel(
    private val workbookId: Long,
    private val repository: WorkbookRepository
) : ViewModel() {

    private val _workbookState = MutableStateFlow<Workbook?>(null)
    private val _gridDataState = MutableStateFlow(GridData())
    private val _filterState = MutableStateFlow(FilterState())
    private val _searchQueryState = MutableStateFlow("")
    private val _saveMessageState = MutableStateFlow<String?>(null)

    // Undo / Redo history
    private val undoStack = mutableListOf<GridData>()
    private val redoStack = mutableListOf<GridData>()
    private val _canUndo = MutableStateFlow(false)
    private val _canRedo = MutableStateFlow(false)

    private var autoSaveJob: Job? = null

    init {
        loadWorkbook()
    }

    private fun loadWorkbook() {
        viewModelScope.launch {
            val wb = repository.getWorkbook(workbookId)
            if (wb != null) {
                _workbookState.value = wb
                val grid = GridData.fromJson(wb.gridJson)
                _gridDataState.value = grid
                val filters = FilterState.fromJson(wb.filterStateJson)
                _filterState.value = filters
            }
        }
    }

    val uiState: StateFlow<EditorUiState> = combine(
        _workbookState,
        _gridDataState,
        _filterState,
        _searchQueryState,
        _canUndo,
        _canRedo,
        _saveMessageState
    ) { params ->
        val wb = params[0] as Workbook?
        val grid = params[1] as GridData
        val filter = params[2] as FilterState
        val search = params[3] as String
        val canUndo = params[4] as Boolean
        val canRedo = params[5] as Boolean
        val saveMsg = params[6] as String?

        EditorUiState(
            workbook = wb,
            gridData = grid,
            filterState = filter,
            searchQuery = search,
            canUndo = canUndo,
            canRedo = canRedo,
            lastSaveMessage = saveMsg
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = EditorUiState()
    )

    // Filtered & Sorted Row Indices
    val visibleRowIndices: StateFlow<List<Int>> = combine(
        _gridDataState,
        _filterState,
        _searchQueryState
    ) { grid, filter, search ->
        val total = grid.rows.size
        val matchingIndices = mutableListOf<Int>()

        for (i in 0 until total) {
            val row = grid.rows[i]

            // 1. Column filters check (AND / intersection)
            var passesFilters = true
            for ((colIdx, allowedValues) in filter.columnFilters) {
                val cellVal = row.getOrNull(colIdx)?.trim().orEmpty()
                if (!allowedValues.contains(cellVal)) {
                    passesFilters = false
                    break
                }
            }
            if (!passesFilters) continue

            // 2. Global search check
            if (search.isNotBlank()) {
                val matchesSearch = row.any { it.contains(search.trim(), ignoreCase = true) }
                if (!matchesSearch) continue
            }

            matchingIndices.add(i)
        }

        // 3. Sorting check
        val sortCol = filter.sortColumnIndex
        if (sortCol != null && sortCol in grid.headers.indices) {
            val isAscending = filter.sortAscending
            // Determine if column is mostly numeric
            val colValues = matchingIndices.map { grid.rows[it].getOrNull(sortCol)?.trim().orEmpty() }
            val numericValues = colValues.mapNotNull { NumberParser.parseDouble(it) }
            val isNumeric = colValues.isNotEmpty() && numericValues.size >= (colValues.size * 0.7)

            if (isNumeric) {
                matchingIndices.sortedWith { idx1, idx2 ->
                    val v1 = NumberParser.parseDouble(grid.rows[idx1].getOrNull(sortCol))
                    val v2 = NumberParser.parseDouble(grid.rows[idx2].getOrNull(sortCol))
                    val cmp = when {
                        v1 == null && v2 == null -> 0
                        v1 == null -> 1
                        v2 == null -> -1
                        else -> v1.compareTo(v2)
                    }
                    if (isAscending) cmp else -cmp
                }
            } else {
                matchingIndices.sortedWith { idx1, idx2 ->
                    val s1 = grid.rows[idx1].getOrNull(sortCol).orEmpty()
                    val s2 = grid.rows[idx2].getOrNull(sortCol).orEmpty()
                    val cmp = s1.compareTo(s2, ignoreCase = true)
                    if (isAscending) cmp else -cmp
                }
            }
        } else {
            matchingIndices
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = emptyList()
    )

    // -------------------------------------------------------------
    // STATS ENGINE REACTIVE PIPELINE (Section 5.5.0)
    // -------------------------------------------------------------
    private val statsInputFlow: StateFlow<StatsInput> = combine(
        _gridDataState,
        visibleRowIndices,
        _workbookState,
        _filterState,
        _searchQueryState
    ) { grid, visibleIndices, wb, filter, search ->
        val filteredRows = visibleIndices.map { grid.rows[it] }

        // Filter description string
        val filterDescs = mutableListOf<String>()
        filter.columnFilters.forEach { (colIdx, set) ->
            val h = grid.headers.getOrNull(colIdx) ?: "Col $colIdx"
            filterDescs.add("$h = [${set.joinToString()}]")
        }
        if (search.isNotBlank()) {
            filterDescs.add("جستجو: \"$search\"")
        }

        StatsInput(
            allRows = filteredRows,
            headers = grid.headers,
            plColumnIndex = wb?.plColumnIndex,
            rrCap = wb?.rrCap,
            initialBalance = wb?.initialBalance ?: 500.0,
            riskPercent = wb?.riskPercent ?: 2.0,
            totalRowCount = grid.rows.size,
            activeFilterDesc = filterDescs.joinToString(" | ")
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = StatsInput(emptyList(), emptyList(), null, null, 500.0, 2.0)
    )

    val statsResult: StateFlow<StatsResult> = statsInputFlow
        .debounce(200)
        .map { input ->
            StatsEngine.compute(input)
        }
        .flowOn(Dispatchers.Default)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = StatsResult()
        )

    // -------------------------------------------------------------
    // GRID EDIT ACTIONS WITH UNDO / REDO & AUTO-SAVE
    // -------------------------------------------------------------

    private fun pushUndoState(currentGrid: GridData) {
        undoStack.add(currentGrid)
        if (undoStack.size > 50) {
            undoStack.removeAt(0)
        }
        redoStack.clear()
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = false
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val previous = undoStack.removeAt(undoStack.lastIndex)
        redoStack.add(_gridDataState.value)
        _gridDataState.value = previous
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = true
        scheduleAutoSave()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val next = redoStack.removeAt(redoStack.lastIndex)
        undoStack.add(_gridDataState.value)
        _gridDataState.value = next
        _canUndo.value = true
        _canRedo.value = redoStack.isNotEmpty()
        scheduleAutoSave()
    }

    fun updateCell(rowIndex: Int, colIndex: Int, newValue: String) {
        val currentGrid = _gridDataState.value
        if (rowIndex !in currentGrid.rows.indices) return
        val row = currentGrid.rows[rowIndex]
        val oldVal = row.getOrNull(colIndex).orEmpty()
        if (oldVal == newValue) return

        pushUndoState(currentGrid)

        val newRows = currentGrid.rows.mapIndexed { rIdx, r ->
            if (rIdx == rowIndex) {
                val updatedRow = r.toMutableList()
                while (updatedRow.size <= colIndex) {
                    updatedRow.add("")
                }
                updatedRow[colIndex] = newValue
                updatedRow
            } else {
                r
            }
        }

        _gridDataState.value = currentGrid.copy(rows = newRows)
        scheduleAutoSave()
    }

    fun addRowAtEnd() {
        val currentGrid = _gridDataState.value
        pushUndoState(currentGrid)
        val blankRow = List(currentGrid.headers.size) { "" }
        _gridDataState.value = currentGrid.copy(rows = currentGrid.rows + listOf(blankRow))
        scheduleAutoSave()
    }

    fun handleRowAction(action: RowAction, rowIndex: Int) {
        val currentGrid = _gridDataState.value
        if (rowIndex !in currentGrid.rows.indices) return

        pushUndoState(currentGrid)
        val mutableRows = currentGrid.rows.toMutableList()

        when (action) {
            RowAction.INSERT_ABOVE -> {
                val blankRow = List(currentGrid.headers.size) { "" }
                mutableRows.add(rowIndex, blankRow)
            }
            RowAction.INSERT_BELOW -> {
                val blankRow = List(currentGrid.headers.size) { "" }
                mutableRows.add(rowIndex + 1, blankRow)
            }
            RowAction.DUPLICATE -> {
                val copyRow = currentGrid.rows[rowIndex].toList()
                mutableRows.add(rowIndex + 1, copyRow)
            }
            RowAction.DELETE -> {
                mutableRows.removeAt(rowIndex)
            }
        }

        _gridDataState.value = currentGrid.copy(rows = mutableRows)
        scheduleAutoSave()
    }

    fun handleColumnAction(action: ColumnAction, colIndex: Int, newName: String? = null) {
        val currentGrid = _gridDataState.value
        if (colIndex !in currentGrid.headers.indices) return

        pushUndoState(currentGrid)
        val mutableHeaders = currentGrid.headers.toMutableList()
        val mutableRows = currentGrid.rows.map { it.toMutableList() }.toMutableList()

        when (action) {
            ColumnAction.RENAME -> {
                if (!newName.isNullOrBlank()) {
                    mutableHeaders[colIndex] = newName.trim()
                }
            }
            ColumnAction.INSERT_LEFT -> {
                val name = "ستون جدید"
                mutableHeaders.add(colIndex, name)
                mutableRows.forEach { it.add(colIndex, "") }
                shiftPlColumnOnInsert(colIndex)
            }
            ColumnAction.INSERT_RIGHT -> {
                val name = "ستون جدید"
                val target = colIndex + 1
                mutableHeaders.add(target, name)
                mutableRows.forEach { it.add(target, "") }
                shiftPlColumnOnInsert(target)
            }
            ColumnAction.MOVE_LEFT -> {
                if (colIndex > 0) {
                    val h = mutableHeaders.removeAt(colIndex)
                    mutableHeaders.add(colIndex - 1, h)
                    mutableRows.forEach {
                        val cell = it.removeAt(colIndex)
                        it.add(colIndex - 1, cell)
                    }
                    swapPlColumn(colIndex, colIndex - 1)
                }
            }
            ColumnAction.MOVE_RIGHT -> {
                if (colIndex < mutableHeaders.size - 1) {
                    val h = mutableHeaders.removeAt(colIndex)
                    mutableHeaders.add(colIndex + 1, h)
                    mutableRows.forEach {
                        val cell = it.removeAt(colIndex)
                        it.add(colIndex + 1, cell)
                    }
                    swapPlColumn(colIndex, colIndex + 1)
                }
            }
            ColumnAction.DELETE -> {
                mutableHeaders.removeAt(colIndex)
                mutableRows.forEach { it.removeAt(colIndex) }
                adjustPlColumnOnDelete(colIndex)
            }
        }

        _gridDataState.value = GridData(mutableHeaders, mutableRows)
        scheduleAutoSave()
    }

    private fun shiftPlColumnOnInsert(insertedIdx: Int) {
        val current = _workbookState.value?.plColumnIndex ?: return
        if (insertedIdx <= current) {
            setPlColumn(current + 1)
        }
    }

    private fun adjustPlColumnOnDelete(deletedIdx: Int) {
        val current = _workbookState.value?.plColumnIndex ?: return
        if (deletedIdx == current) {
            setPlColumn(null)
        } else if (deletedIdx < current) {
            setPlColumn(current - 1)
        }
    }

    private fun swapPlColumn(from: Int, to: Int) {
        val current = _workbookState.value?.plColumnIndex ?: return
        if (current == from) {
            setPlColumn(to)
        } else if (current == to) {
            setPlColumn(from)
        }
    }

    // -------------------------------------------------------------
    // FILTER & SEARCH ACTIONS
    // -------------------------------------------------------------

    fun setColumnFilter(colIndex: Int, allowedValues: Set<String>?) {
        val currentFilters = _filterState.value.columnFilters.toMutableMap()
        if (allowedValues == null) {
            currentFilters.remove(colIndex)
        } else {
            currentFilters[colIndex] = allowedValues
        }
        _filterState.value = _filterState.value.copy(columnFilters = currentFilters)
        scheduleAutoSave()
    }

    fun clearColumnFilter(colIndex: Int) {
        val currentFilters = _filterState.value.columnFilters.toMutableMap()
        currentFilters.remove(colIndex)
        _filterState.value = _filterState.value.copy(columnFilters = currentFilters)
        scheduleAutoSave()
    }

    fun clearAllFilters() {
        _filterState.value = _filterState.value.copy(columnFilters = emptyMap())
        _searchQueryState.value = ""
        scheduleAutoSave()
    }

    fun setSort(colIndex: Int, ascending: Boolean) {
        _filterState.value = _filterState.value.copy(
            sortColumnIndex = colIndex,
            sortAscending = ascending
        )
        scheduleAutoSave()
    }

    fun setSearchQuery(query: String) {
        _searchQueryState.value = query
    }

    // -------------------------------------------------------------
    // WORKBOOK SETTINGS (P/L Column, R:R Cap, Money Management)
    // -------------------------------------------------------------

    fun setPlColumn(index: Int?) {
        val wb = _workbookState.value ?: return
        val updated = wb.copy(plColumnIndex = index)
        _workbookState.value = updated
        scheduleAutoSave()
    }

    fun setRrCap(cap: Double?) {
        val wb = _workbookState.value ?: return
        val updated = wb.copy(rrCap = cap)
        _workbookState.value = updated
        scheduleAutoSave()
    }

    fun setMoneyManagement(initialBalance: Double, riskPercent: Double) {
        val wb = _workbookState.value ?: return
        val updated = wb.copy(initialBalance = initialBalance, riskPercent = riskPercent)
        _workbookState.value = updated
        scheduleAutoSave()
    }

    fun renameWorkbook(newName: String) {
        val wb = _workbookState.value ?: return
        if (newName.isBlank()) return
        val updated = wb.copy(name = newName.trim())
        _workbookState.value = updated
        scheduleAutoSave()
    }

    // -------------------------------------------------------------
    // AUTO-SAVE (500 ms debounce)
    // -------------------------------------------------------------

    private fun scheduleAutoSave() {
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch {
            delay(500)
            saveNow()
        }
    }

    fun saveNow() {
        viewModelScope.launch {
            val wb = _workbookState.value ?: return@launch
            val grid = _gridDataState.value
            val filter = _filterState.value
            val toSave = wb.copy(
                gridJson = grid.toJson(),
                filterStateJson = filter.toJson(),
                updatedAt = System.currentTimeMillis()
            )
            repository.updateWorkbook(toSave)
            _saveMessageState.value = "تغییرات ذخیره شد"
            delay(1500)
            _saveMessageState.value = null
        }
    }
}

package com.example.ui.editor

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.outlined.FilterAlt
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.parser.ResultParser
import com.example.data.parser.TradeParseResult
import com.example.ui.theme.LossRed
import com.example.ui.theme.LossRedContainer
import com.example.ui.theme.TableGridLineDark
import com.example.ui.theme.TableGridLineLight
import com.example.ui.theme.TableHeaderBgDark
import com.example.ui.theme.TableHeaderBgLight
import com.example.ui.theme.TableRowAltDark
import com.example.ui.theme.TableRowAltLight
import com.example.ui.theme.WinGreen
import com.example.ui.theme.WinGreenContainer

val COLUMN_WIDTH = 110.dp
val ROW_NUMBER_WIDTH = 48.dp
val ROW_HEIGHT = 44.dp

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GridTable(
    headers: List<String>,
    rows: List<List<String>>,
    visibleRowIndices: List<Int>, // Indices into original rows
    activeFilteredColumns: Set<Int>,
    plColumnIndex: Int?,
    onCellClick: (originalRowIdx: Int, colIdx: Int, currentVal: String) -> Unit,
    onColumnFilterClick: (colIdx: Int) -> Unit,
    onRowAction: (action: RowAction, originalRowIdx: Int) -> Unit,
    onColumnAction: (action: ColumnAction, colIdx: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val hScrollState = rememberScrollState()
    val isDark = MaterialTheme.colorScheme.background.red < 0.5f
    val gridLineColor = if (isDark) TableGridLineDark else TableGridLineLight
    val headerBgColor = if (isDark) TableHeaderBgDark else TableHeaderBgLight
    val altRowBgColor = if (isDark) TableRowAltDark else TableRowAltLight

    // Strict LTR layout for the table grid (Excel desktop style)
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .horizontalScroll(hScrollState)
        ) {
            // 1. Sticky Header Row
            Row(
                modifier = Modifier
                    .background(headerBgColor)
                    .border(1.dp, gridLineColor)
                    .height(ROW_HEIGHT),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Corner cell (row number header)
                Box(
                    modifier = Modifier
                        .width(ROW_NUMBER_WIDTH)
                        .fillMaxHeight()
                        .border(0.5.dp, gridLineColor),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "#",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Column Headers
                headers.forEachIndexed { colIdx, headerTitle ->
                    val hasFilter = activeFilteredColumns.contains(colIdx)
                    var showHeaderMenu by remember { mutableStateOf(false) }

                    Box(
                        modifier = Modifier
                            .width(COLUMN_WIDTH)
                            .fillMaxHeight()
                            .border(0.5.dp, gridLineColor)
                            .combinedClickable(
                                onClick = { onColumnFilterClick(colIdx) },
                                onLongClick = { showHeaderMenu = true }
                            )
                            .padding(horizontal = 4.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = headerTitle,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )

                            // Filter Button
                            IconButton(
                                onClick = { onColumnFilterClick(colIdx) },
                                modifier = Modifier
                                    .size(28.dp)
                                    .testTag("filter_icon_col_$colIdx")
                            ) {
                                if (hasFilter) {
                                    Icon(
                                        Icons.Filled.FilterAlt,
                                        contentDescription = "فیلتر فعال",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                } else {
                                    Icon(
                                        Icons.Outlined.FilterAlt,
                                        contentDescription = "فیلتر",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }

                        // Header Long-press Menu
                        DropdownMenu(
                            expanded = showHeaderMenu,
                            onDismissRequest = { showHeaderMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("تغییر نام ستون") },
                                onClick = {
                                    showHeaderMenu = false
                                    onColumnAction(ColumnAction.RENAME, colIdx)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("افزودن ستون به چپ") },
                                onClick = {
                                    showHeaderMenu = false
                                    onColumnAction(ColumnAction.INSERT_LEFT, colIdx)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("افزودن ستون به راست") },
                                onClick = {
                                    showHeaderMenu = false
                                    onColumnAction(ColumnAction.INSERT_RIGHT, colIdx)
                                }
                            )
                            if (colIdx > 0) {
                                DropdownMenuItem(
                                    text = { Text("انتقال به چپ") },
                                    onClick = {
                                        showHeaderMenu = false
                                        onColumnAction(ColumnAction.MOVE_LEFT, colIdx)
                                    }
                                )
                            }
                            if (colIdx < headers.size - 1) {
                                DropdownMenuItem(
                                    text = { Text("انتقال به راست") },
                                    onClick = {
                                        showHeaderMenu = false
                                        onColumnAction(ColumnAction.MOVE_RIGHT, colIdx)
                                    }
                                )
                            }
                            DropdownMenuItem(
                                text = { Text("حذف ستون", color = MaterialTheme.colorScheme.error) },
                                onClick = {
                                    showHeaderMenu = false
                                    onColumnAction(ColumnAction.DELETE, colIdx)
                                }
                            )
                        }
                    }
                }
            }

            // 2. Data Rows (LazyColumn)
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                itemsIndexed(
                    items = visibleRowIndices,
                    key = { _, originalIdx -> originalIdx }
                ) { displayIdx, originalIdx ->
                    val rowData = rows.getOrNull(originalIdx) ?: emptyList()
                    val isAlt = displayIdx % 2 == 1
                    var showRowMenu by remember { mutableStateOf(false) }

                    Row(
                        modifier = Modifier
                            .background(if (isAlt) altRowBgColor else Color.Transparent)
                            .height(ROW_HEIGHT),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Row Number Cell (clickable for row options)
                        Box(
                            modifier = Modifier
                                .width(ROW_NUMBER_WIDTH)
                                .fillMaxHeight()
                                .background(headerBgColor.copy(alpha = 0.5f))
                                .border(0.5.dp, gridLineColor)
                                .combinedClickable(
                                    onClick = { showRowMenu = true },
                                    onLongClick = { showRowMenu = true }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${originalIdx + 1}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            DropdownMenu(
                                expanded = showRowMenu,
                                onDismissRequest = { showRowMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("درج ردیف در بالا") },
                                    onClick = {
                                        showRowMenu = false
                                        onRowAction(RowAction.INSERT_ABOVE, originalIdx)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("درج ردیف در پایین") },
                                    onClick = {
                                        showRowMenu = false
                                        onRowAction(RowAction.INSERT_BELOW, originalIdx)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("تکثیر ردیف") },
                                    onClick = {
                                        showRowMenu = false
                                        onRowAction(RowAction.DUPLICATE, originalIdx)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("حذف ردیف", color = MaterialTheme.colorScheme.error) },
                                    onClick = {
                                        showRowMenu = false
                                        onRowAction(RowAction.DELETE, originalIdx)
                                    }
                                )
                            }
                        }

                        // Cells in this row
                        headers.indices.forEach { colIdx ->
                            val cellValue = rowData.getOrNull(colIdx).orEmpty()
                            val isPlColumn = colIdx == plColumnIndex

                            // Formatting for P/L column
                            val cellBgColor = if (isPlColumn && cellValue.isNotBlank()) {
                                when (val parseRes = ResultParser.parse(cellValue)) {
                                    is TradeParseResult.Counted -> {
                                        if (parseRes.isWin) WinGreenContainer.copy(alpha = 0.4f)
                                        else LossRedContainer.copy(alpha = 0.4f)
                                    }
                                    else -> Color.Transparent
                                }
                            } else {
                                Color.Transparent
                            }

                            val cellTextColor = if (isPlColumn && cellValue.isNotBlank()) {
                                when (val parseRes = ResultParser.parse(cellValue)) {
                                    is TradeParseResult.Counted -> {
                                        if (parseRes.isWin) WinGreen else LossRed
                                    }
                                    else -> MaterialTheme.colorScheme.onSurface
                                }
                            } else {
                                MaterialTheme.colorScheme.onSurface
                            }

                            Box(
                                modifier = Modifier
                                    .width(COLUMN_WIDTH)
                                    .fillMaxHeight()
                                    .background(cellBgColor)
                                    .border(0.5.dp, gridLineColor)
                                    .combinedClickable(
                                        onClick = { onCellClick(originalIdx, colIdx, cellValue) },
                                        onLongClick = { showRowMenu = true }
                                    )
                                    .padding(horizontal = 8.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text(
                                    text = cellValue,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = cellTextColor,
                                    fontWeight = if (isPlColumn) FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

enum class RowAction {
    INSERT_ABOVE,
    INSERT_BELOW,
    DUPLICATE,
    DELETE
}

enum class ColumnAction {
    RENAME,
    INSERT_LEFT,
    INSERT_RIGHT,
    DELETE,
    MOVE_LEFT,
    MOVE_RIGHT
}

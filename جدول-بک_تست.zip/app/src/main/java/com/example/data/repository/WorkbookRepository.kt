package com.example.data.repository

import com.example.data.db.WorkbookDao
import com.example.data.model.GridData
import com.example.data.model.Workbook
import kotlinx.coroutines.flow.Flow

class WorkbookRepository(private val workbookDao: WorkbookDao) {

    val allWorkbooks: Flow<List<Workbook>> = workbookDao.getAllWorkbooks()

    fun getAllWorkbooksFlow(): Flow<List<Workbook>> = allWorkbooks

    suspend fun insertWorkbook(workbook: Workbook): Long = workbookDao.insertWorkbook(workbook)

    suspend fun getWorkbook(id: Long): Workbook? = workbookDao.getWorkbookById(id)

    fun getWorkbookFlow(id: Long): Flow<Workbook?> = workbookDao.getWorkbookFlow(id)

    suspend fun createWorkbook(
        name: String,
        gridData: GridData = GridData(
            headers = listOf("ستون ۱", "ستون ۲", "ستون ۳"),
            rows = listOf(listOf("", "", ""), listOf("", "", ""))
        ),
        plColumnIndex: Int? = null,
        initialBalance: Double = 500.0,
        riskPercent: Double = 2.0,
        rrCap: Double? = null
    ): Long {
        val workbook = Workbook(
            name = name,
            gridJson = gridData.toJson(),
            filterStateJson = "{}",
            plColumnIndex = plColumnIndex,
            initialBalance = initialBalance,
            riskPercent = riskPercent,
            rrCap = rrCap,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        return workbookDao.insertWorkbook(workbook)
    }

    suspend fun updateWorkbook(workbook: Workbook) {
        workbookDao.updateWorkbook(workbook.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun duplicateWorkbook(workbook: Workbook): Long {
        val copy = workbook.copy(
            id = 0,
            name = "${workbook.name} (کپی)",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        return workbookDao.insertWorkbook(copy)
    }

    suspend fun deleteWorkbook(workbook: Workbook) {
        workbookDao.deleteWorkbook(workbook)
    }

    suspend fun deleteWorkbookById(id: Long) {
        workbookDao.deleteWorkbookById(id)
    }
}

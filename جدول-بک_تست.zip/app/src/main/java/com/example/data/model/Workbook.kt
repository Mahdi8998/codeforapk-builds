package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import org.json.JSONArray
import org.json.JSONObject

@Entity(tableName = "workbooks")
data class Workbook(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val gridJson: String,
    val filterStateJson: String = "{}",
    val plColumnIndex: Int? = null,
    val initialBalance: Double = 500.0,
    val riskPercent: Double = 2.0,
    val rrCap: Double? = null
)

data class GridData(
    val headers: List<String> = emptyList(),
    val rows: List<List<String>> = emptyList()
) {
    fun toJson(): String {
        val json = JSONObject()
        val hArray = JSONArray()
        headers.forEach { hArray.put(it) }
        json.put("headers", hArray)

        val rArray = JSONArray()
        rows.forEach { row ->
            val rowArr = JSONArray()
            row.forEach { rowArr.put(it) }
            rArray.put(rowArr)
        }
        json.put("rows", rArray)
        return json.toString()
    }

    companion object {
        fun fromJson(jsonStr: String): GridData {
            if (jsonStr.isBlank()) return GridData()
            return try {
                val json = JSONObject(jsonStr)
                val hArray = json.optJSONArray("headers") ?: JSONArray()
                val headers = mutableListOf<String>()
                for (i in 0 until hArray.length()) {
                    headers.add(hArray.optString(i, ""))
                }

                val rArray = json.optJSONArray("rows") ?: JSONArray()
                val rows = mutableListOf<List<String>>()
                for (i in 0 until rArray.length()) {
                    val rowArr = rArray.optJSONArray(i) ?: JSONArray()
                    val row = mutableListOf<String>()
                    for (j in 0 until rowArr.length()) {
                        row.add(rowArr.optString(j, ""))
                    }
                    rows.add(row)
                }
                GridData(headers, rows)
            } catch (e: Exception) {
                GridData()
            }
        }
    }
}

data class FilterState(
    // Map of columnIndex to set of selected values
    val columnFilters: Map<Int, Set<String>> = emptyMap(),
    val sortColumnIndex: Int? = null,
    val sortAscending: Boolean = true
) {
    fun toJson(): String {
        val json = JSONObject()
        val filtersObj = JSONObject()
        columnFilters.forEach { (colIdx, selectedSet) ->
            val arr = JSONArray()
            selectedSet.forEach { arr.put(it) }
            filtersObj.put(colIdx.toString(), arr)
        }
        json.put("columnFilters", filtersObj)
        if (sortColumnIndex != null) {
            json.put("sortColumnIndex", sortColumnIndex)
            json.put("sortAscending", sortAscending)
        }
        return json.toString()
    }

    companion object {
        fun fromJson(jsonStr: String): FilterState {
            if (jsonStr.isBlank() || jsonStr == "{}") return FilterState()
            return try {
                val json = JSONObject(jsonStr)
                val filtersObj = json.optJSONObject("columnFilters")
                val columnFilters = mutableMapOf<Int, Set<String>>()
                if (filtersObj != null) {
                    val keys = filtersObj.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        val colIdx = key.toIntOrNull() ?: continue
                        val arr = filtersObj.optJSONArray(key) ?: continue
                        val set = mutableSetOf<String>()
                        for (i in 0 until arr.length()) {
                            set.add(arr.optString(i))
                        }
                        columnFilters[colIdx] = set
                    }
                }
                val sortCol = if (json.has("sortColumnIndex")) json.getInt("sortColumnIndex") else null
                val sortAsc = json.optBoolean("sortAscending", true)
                FilterState(columnFilters, sortCol, sortAsc)
            } catch (e: Exception) {
                FilterState()
            }
        }
    }
}

package com.example.data.repository

import android.content.Context
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "app_settings")

class SettingsRepository(private val context: Context) {

    private val KEY_GEMINI_API_KEY = stringPreferencesKey("gemini_api_key")
    private val KEY_THEME_MODE = stringPreferencesKey("theme_mode") // "system", "light", "dark"
    private val KEY_DEFAULT_BALANCE = doublePreferencesKey("default_balance")
    private val KEY_DEFAULT_RISK = doublePreferencesKey("default_risk")

    val geminiApiKeyFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[KEY_GEMINI_API_KEY] ?: ""
    }

    val themeModeFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[KEY_THEME_MODE] ?: "system"
    }

    val defaultBalanceFlow: Flow<Double> = context.dataStore.data.map { preferences ->
        preferences[KEY_DEFAULT_BALANCE] ?: 500.0
    }

    val defaultRiskFlow: Flow<Double> = context.dataStore.data.map { preferences ->
        preferences[KEY_DEFAULT_RISK] ?: 2.0
    }

    suspend fun saveGeminiApiKey(key: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_GEMINI_API_KEY] = key.trim()
        }
    }

    suspend fun setGeminiApiKey(key: String) = saveGeminiApiKey(key)

    suspend fun saveThemeMode(mode: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_THEME_MODE] = mode
        }
    }

    suspend fun setThemeMode(mode: String) = saveThemeMode(mode)

    suspend fun setDefaultBalance(balance: Double) {
        context.dataStore.edit { preferences ->
            preferences[KEY_DEFAULT_BALANCE] = balance
        }
    }

    suspend fun setDefaultRisk(risk: Double) {
        context.dataStore.edit { preferences ->
            preferences[KEY_DEFAULT_RISK] = risk
        }
    }
}

package com.example.data.parser

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

object NumberParser {

    /**
     * Converts Persian/Arabic digits to standard ASCII 0-9.
     */
    fun normalizeDigits(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input) {
            when (ch) {
                // Persian digits ۰-۹
                in '\u06F0'..'\u06F9' -> sb.append((ch - '\u06F0' + '0'.code).toChar())
                // Arabic-Indic digits ٠-٩
                in '\u0660'..'\u0669' -> sb.append((ch - '\u0660' + '0'.code).toChar())
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * Parses a string to Double handling Persian/Arabic digits,
     * thousands separators (',', '٬', space), and decimal separators ('.', '٫').
     */
    fun parseDouble(input: String?): Double? {
        if (input.isNullOrBlank()) return null
        val normalized = normalizeDigits(input.trim())

        // Check negative signs
        var isNegative = false
        var clean = normalized
        if (clean.startsWith("-") || clean.startsWith("−") || clean.startsWith("–")) {
            isNegative = true
            clean = clean.substring(1).trim()
        } else if (clean.startsWith("+")) {
            clean = clean.substring(1).trim()
        }

        // Replace Persian decimal separator '٫' (U+066B) or '/' with '.'
        // Strip thousands separators: ',', '،' (U+060C), '٬' (U+066C), spaces
        clean = clean.replace("٬", "")
            .replace(",", "")
            .replace("،", "")
            .replace(" ", "")
            .replace("٫", ".")
            .replace("/", ".")

        val value = clean.toDoubleOrNull() ?: return null
        return if (isNegative) -value else value
    }

    /**
     * Formats a double into a readable string with up to [maxFractionDigits]
     * and optional thousand grouping.
     */
    fun formatNumber(
        value: Double,
        maxFractionDigits: Int = 2,
        useGrouping: Boolean = true
    ): String {
        if (value.isNaN()) return "—"
        if (value.isInfinite()) {
            return if (value > 0) "∞" else "-∞"
        }

        val symbols = DecimalFormatSymbols(Locale.US).apply {
            groupingSeparator = ','
            decimalSeparator = '.'
        }
        val pattern = if (useGrouping) {
            "#,##0." + "#".repeat(maxFractionDigits)
        } else {
            "0." + "#".repeat(maxFractionDigits)
        }
        val df = DecimalFormat(pattern.trimEnd('.'), symbols)
        df.maximumFractionDigits = maxFractionDigits
        df.minimumFractionDigits = 0
        return df.format(value)
    }

    /**
     * Returns true if the string can be parsed as a number.
     */
    fun isNumeric(input: String?): Boolean {
        return parseDouble(input) != null
    }
}

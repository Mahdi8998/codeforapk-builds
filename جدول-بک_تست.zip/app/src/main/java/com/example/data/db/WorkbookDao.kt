package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Workbook
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkbookDao {

    @Query("SELECT * FROM workbooks ORDER BY updatedAt DESC")
    fun getAllWorkbooks(): Flow<List<Workbook>>

    @Query("SELECT * FROM workbooks WHERE id = :id")
    suspend fun getWorkbookById(id: Long): Workbook?

    @Query("SELECT * FROM workbooks WHERE id = :id")
    fun getWorkbookFlow(id: Long): Flow<Workbook?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkbook(workbook: Workbook): Long

    @Update
    suspend fun updateWorkbook(workbook: Workbook)

    @Delete
    suspend fun deleteWorkbook(workbook: Workbook)

    @Query("DELETE FROM workbooks WHERE id = :id")
    suspend fun deleteWorkbookById(id: Long)
}

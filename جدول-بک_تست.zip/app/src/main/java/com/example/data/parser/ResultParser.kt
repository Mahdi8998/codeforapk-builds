package com.example.data.parser

sealed class TradeParseResult {
    data class Counted(
        val originalR: Double,
        val isWin: Boolean
    ) : TradeParseResult() {
        /**
         * Returns the effective R after applying the optional R:R cap.
         * When rrCap is active (> 0), wins are capped at min(originalR, rrCap).
         * Losses are NEVER modified by the cap.
         */
        fun getCappedR(rrCap: Double?): Double {
            return if (isWin && rrCap != null && rrCap > 0.0) {
                minOf(originalR, rrCap)
            } else {
                originalR
            }
        }
    }

    object ExcludedEmpty : TradeParseResult()
    object ExcludedInvalid : TradeParseResult()

    val isCounted: Boolean get() = this is Counted
}

object ResultParser {

    /**
     * Parses a cell from the designated result column into a [TradeParseResult].
     */
    fun parse(cellValue: String?): TradeParseResult {
        if (cellValue == null) return TradeParseResult.ExcludedEmpty
        val trimmed = cellValue.trim()
        if (trimmed.isEmpty()) return TradeParseResult.ExcludedEmpty

        // Lone dash check: "-" (U+002D), "−" (U+2212), "–" (U+2013)
        if (trimmed == "-" || trimmed == "−" || trimmed == "–") {
            return TradeParseResult.Counted(originalR = -1.0, isWin = false)
        }

        val num = NumberParser.parseDouble(trimmed) ?: return TradeParseResult.ExcludedInvalid

        return when {
            num > 0.0 -> TradeParseResult.Counted(originalR = num, isWin = true)
            num < 0.0 -> TradeParseResult.Counted(originalR = num, isWin = false)
            else -> TradeParseResult.ExcludedInvalid // 0 is excluded
        }
    }
}

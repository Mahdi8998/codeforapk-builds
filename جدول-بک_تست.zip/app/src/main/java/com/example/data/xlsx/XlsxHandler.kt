package com.example.data.xlsx

import com.example.data.model.GridData
import com.example.data.parser.NumberParser
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object XlsxHandler {

    /**
     * Reads the first sheet from an XLSX InputStream and returns [GridData].
     * First row is used as headers; empty leading rows/columns are skipped.
     */
    fun readXlsx(inputStream: InputStream): GridData {
        val sharedStrings = mutableListOf<String>()
        var sheetXmlBytes: ByteArray? = null

        ZipInputStream(inputStream).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                val name = entry.name
                if (name.equals("xl/sharedStrings.xml", ignoreCase = true)) {
                    sharedStrings.addAll(parseSharedStrings(zis.readBytes()))
                } else if (name.startsWith("xl/worksheets/sheet", ignoreCase = true) &&
                    name.endsWith(".xml", ignoreCase = true) && sheetXmlBytes == null
                ) {
                    sheetXmlBytes = zis.readBytes()
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        if (sheetXmlBytes == null) {
            throw IllegalArgumentException("فایل اکسل معتبر نیست یا شیت کاری پیدا نشد.")
        }

        val rawRows = parseSheetXml(sheetXmlBytes!!, sharedStrings)
        if (rawRows.isEmpty()) {
            return GridData()
        }

        // Skip empty leading rows
        val nonEmptyRowIndex = rawRows.indexOfFirst { row -> row.any { it.isNotBlank() } }
        if (nonEmptyRowIndex == -1) {
            return GridData()
        }

        val trimmedRows = rawRows.subList(nonEmptyRowIndex, rawRows.size)
        val headerRow = trimmedRows.first()

        // Find max non-empty column index to trim trailing empty columns
        var maxCol = 0
        for (row in trimmedRows) {
            val lastNonEmpty = row.indexOfLast { it.isNotBlank() }
            if (lastNonEmpty > maxCol) maxCol = lastNonEmpty
        }

        val headers = headerRow.take(maxCol + 1).mapIndexed { idx, title ->
            if (title.isBlank()) "ستون ${idx + 1}" else title.trim()
        }

        val dataRows = trimmedRows.drop(1).map { row ->
            List(headers.size) { colIdx ->
                row.getOrNull(colIdx)?.trim().orEmpty()
            }
        }

        return GridData(headers = headers, rows = dataRows)
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val strings = mutableListOf<String>()
        val factory = XmlPullParserFactory.newInstance()
        val parser = factory.newPullParser()
        parser.setInput(bytes.inputStream(), StandardCharsets.UTF_8.name())

        var eventType = parser.eventType
        var currentString = StringBuilder()
        var insideT = false

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    if (parser.name.equals("t", ignoreCase = true)) {
                        insideT = true
                    } else if (parser.name.equals("si", ignoreCase = true)) {
                        currentString = StringBuilder()
                    }
                }
                XmlPullParser.TEXT -> {
                    if (insideT) {
                        currentString.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name.equals("t", ignoreCase = true)) {
                        insideT = false
                    } else if (parser.name.equals("si", ignoreCase = true)) {
                        strings.add(currentString.toString())
                    }
                }
            }
            eventType = parser.next()
        }
        return strings
    }

    private fun parseSheetXml(bytes: ByteArray, sharedStrings: List<String>): List<List<String>> {
        val rows = mutableListOf<MutableList<String>>()
        val factory = XmlPullParserFactory.newInstance()
        val parser = factory.newPullParser()
        parser.setInput(bytes.inputStream(), StandardCharsets.UTF_8.name())

        var eventType = parser.eventType
        var currentRow = mutableListOf<String>()
        var currentCellColIndex = 0
        var currentCellType = ""
        var currentCellValue = StringBuilder()
        var insideV = false
        var insideT = false

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    when (parser.name.lowercase()) {
                        "row" -> {
                            currentRow = mutableListOf()
                            currentCellColIndex = 0
                        }
                        "c" -> {
                            val rAttr = parser.getAttributeValue(null, "r")
                            currentCellColIndex = if (rAttr != null) {
                                columnNameToIndex(rAttr)
                            } else {
                                currentCellColIndex
                            }
                            currentCellType = parser.getAttributeValue(null, "t").orEmpty()
                            currentCellValue = StringBuilder()
                        }
                        "v" -> insideV = true
                        "t" -> insideT = true
                    }
                }
                XmlPullParser.TEXT -> {
                    if (insideV || insideT) {
                        currentCellValue.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name.lowercase()) {
                        "v" -> insideV = false
                        "t" -> insideT = false
                        "c" -> {
                            val raw = currentCellValue.toString()
                            val resolvedValue = when (currentCellType) {
                                "s" -> {
                                    val sIndex = raw.toIntOrNull()
                                    if (sIndex != null && sIndex in sharedStrings.indices) {
                                        sharedStrings[sIndex]
                                    } else {
                                        raw
                                    }
                                }
                                else -> raw
                            }
                            // Pad row up to currentCellColIndex
                            while (currentRow.size <= currentCellColIndex) {
                                currentRow.add("")
                            }
                            currentRow[currentCellColIndex] = resolvedValue
                            currentCellColIndex++
                        }
                        "row" -> {
                            rows.add(currentRow)
                        }
                    }
                }
            }
            eventType = parser.next()
        }

        return rows
    }

    private fun columnNameToIndex(cellRef: String): Int {
        var col = 0
        for (ch in cellRef) {
            if (ch in 'A'..'Z') {
                col = col * 26 + (ch - 'A' + 1)
            } else if (ch in 'a'..'z') {
                col = col * 26 + (ch - 'a' + 1)
            } else {
                break
            }
        }
        return if (col > 0) col - 1 else 0
    }

    private fun indexToColumnName(colIndex: Int): String {
        var temp = colIndex + 1
        val sb = StringBuilder()
        while (temp > 0) {
            val rem = (temp - 1) % 26
            sb.append(('A'.code + rem).toChar())
            temp = (temp - 1) / 26
        }
        return sb.reverse().toString()
    }

    private fun escapeXml(str: String): String {
        return str.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }

    /**
     * Exports headers and rows to an XLSX OutputStream.
     */
    fun writeXlsx(
        headers: List<String>,
        rows: List<List<String>>,
        outputStream: OutputStream
    ) {
        ZipOutputStream(outputStream).use { zos ->
            // 1. [Content_Types].xml
            zos.putNextEntry(ZipEntry("[Content_Types].xml"))
            zos.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>""".toByteArray(StandardCharsets.UTF_8)
            )
            zos.closeEntry()

            // 2. _rels/.rels
            zos.putNextEntry(ZipEntry("_rels/.rels"))
            zos.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>""".toByteArray(StandardCharsets.UTF_8)
            )
            zos.closeEntry()

            // 3. xl/_rels/workbook.xml.rels
            zos.putNextEntry(ZipEntry("xl/_rels/workbook.xml.rels"))
            zos.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>""".toByteArray(StandardCharsets.UTF_8)
            )
            zos.closeEntry()

            // 4. xl/workbook.xml
            zos.putNextEntry(ZipEntry("xl/workbook.xml"))
            zos.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="Backtest" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>""".toByteArray(StandardCharsets.UTF_8)
            )
            zos.closeEntry()

            // 5. xl/styles.xml
            zos.putNextEntry(ZipEntry("xl/styles.xml"))
            zos.write(
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts>
  <fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>
  <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs>
</styleSheet>""".toByteArray(StandardCharsets.UTF_8)
            )
            zos.closeEntry()

            // 6. xl/worksheets/sheet1.xml
            zos.putNextEntry(ZipEntry("xl/worksheets/sheet1.xml"))
            val sheetBuilder = StringBuilder()
            sheetBuilder.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
            sheetBuilder.append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""")
            sheetBuilder.append("""<sheetData>""")

            // Write header row (Row 1)
            var rowNum = 1
            sheetBuilder.append("""<row r="$rowNum">""")
            headers.forEachIndexed { colIdx, headerText ->
                val cellRef = "${indexToColumnName(colIdx)}$rowNum"
                sheetBuilder.append("""<c r="$cellRef" t="inlineStr"><is><t>${escapeXml(headerText)}</t></is></c>""")
            }
            sheetBuilder.append("""</row>""")

            // Write data rows
            for (row in rows) {
                rowNum++
                sheetBuilder.append("""<row r="$rowNum">""")
                for (colIdx in headers.indices) {
                    val value = row.getOrNull(colIdx)?.trim().orEmpty()
                    if (value.isNotEmpty()) {
                        val cellRef = "${indexToColumnName(colIdx)}$rowNum"
                        val numericVal = NumberParser.parseDouble(value)
                        // If it parses as pure number without text, output as number cell, else inlineStr
                        if (numericVal != null && !value.startsWith("+") && value != "-" && value != "−") {
                            sheetBuilder.append("""<c r="$cellRef"><v>$numericVal</v></c>""")
                        } else {
                            sheetBuilder.append("""<c r="$cellRef" t="inlineStr"><is><t>${escapeXml(value)}</t></is></c>""")
                        }
                    }
                }
                sheetBuilder.append("""</row>""")
            }

            sheetBuilder.append("""</sheetData></worksheet>""")
            zos.write(sheetBuilder.toString().toByteArray(StandardCharsets.UTF_8))
            zos.closeEntry()
        }
    }
}

package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.db.AppDatabase
import com.example.data.repository.SettingsRepository
import com.example.data.repository.WorkbookRepository
import com.example.engine.StatsInput
import com.example.engine.StatsResult
import com.example.ui.ai.AiAnalystScreen
import com.example.ui.ai.AiAnalystViewModel
import com.example.ui.editor.TableEditorScreen
import com.example.ui.editor.TableEditorViewModel
import com.example.ui.list.WorkbookListScreen
import com.example.ui.list.WorkbookListViewModel
import com.example.ui.settings.SettingsScreen
import com.example.ui.settings.SettingsViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(applicationContext)
        val workbookRepository = WorkbookRepository(database.workbookDao())
        val settingsRepository = SettingsRepository(applicationContext)

        setContent {
            val themeMode by settingsRepository.themeModeFlow.collectAsState(initial = "system")
            val isDarkTheme = when (themeMode) {
                "dark" -> true
                "light" -> false
                else -> isSystemInDarkTheme()
            }

            MyApplicationTheme(darkTheme = isDarkTheme) {
                AppNavigation(
                    workbookRepository = workbookRepository,
                    settingsRepository = settingsRepository
                )
            }
        }
    }
}

@Composable
fun AppNavigation(
    workbookRepository: WorkbookRepository,
    settingsRepository: SettingsRepository
) {
    val navController = rememberNavController()

    // Temporary shared state for AI Analyst session
    var currentAiStatsInput by remember { mutableStateOf<StatsInput?>(null) }
    var currentAiStatsResult by remember { mutableStateOf<StatsResult?>(null) }
    var currentAiWorkbookTitle by remember { mutableStateOf("") }

    NavHost(
        navController = navController,
        startDestination = "list"
    ) {
        // 1. Workbook List Screen
        composable("list") {
            val viewModel: WorkbookListViewModel = viewModel {
                WorkbookListViewModel(workbookRepository, settingsRepository)
            }
            WorkbookListScreen(
                viewModel = viewModel,
                onOpenWorkbook = { id ->
                    navController.navigate("editor/$id")
                },
                onNavigateToSettings = {
                    navController.navigate("settings")
                }
            )
        }

        // 2. Table Editor Screen
        composable(
            route = "editor/{workbookId}",
            arguments = listOf(navArgument("workbookId") { type = NavType.LongType })
        ) { backStackEntry ->
            val workbookId = backStackEntry.arguments?.getLong("workbookId") ?: 0L
            val viewModel: TableEditorViewModel = viewModel(key = "editor_$workbookId") {
                TableEditorViewModel(workbookId, workbookRepository)
            }

            TableEditorScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToAi = { statsInput, statsResult, title ->
                    currentAiStatsInput = statsInput
                    currentAiStatsResult = statsResult
                    currentAiWorkbookTitle = title
                    navController.navigate("ai_analyst")
                }
            )
        }

        // 3. AI Strategy Analyst Screen
        composable("ai_analyst") {
            val statsInput = currentAiStatsInput ?: StatsInput(emptyList(), emptyList(), null, null, 500.0, 2.0)
            val statsResult = currentAiStatsResult ?: StatsResult()
            val viewModel: AiAnalystViewModel = viewModel {
                AiAnalystViewModel(settingsRepository)
            }

            AiAnalystScreen(
                viewModel = viewModel,
                statsInput = statsInput,
                statsResult = statsResult,
                workbookTitle = currentAiWorkbookTitle,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToSettings = { navController.navigate("settings") }
            )
        }

        // 4. Settings Screen
        composable("settings") {
            val viewModel: SettingsViewModel = viewModel {
                SettingsViewModel(settingsRepository)
            }
            SettingsScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}

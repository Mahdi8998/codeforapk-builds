package com.example.engine

data class ColumnSummary(
    val columnIndex: Int,
    val header: String,
    val isNumeric: Boolean,
    val sum: Double?,
    val average: Double?,
    val distinctCount: Int,
    val categoricalBreakdown: List<Pair<String, Double>>? // e.g. [("خرید", 60.0), ("فروش", 40.0)]
)

data class GroupStatItem(
    val groupValue: String,
    val tradeCount: Int,
    val winsCount: Int,
    val lossesCount: Int,
    val winRatePercent: Double,
    val netR: Double,
    val netDollarEffect: Double
)

data class StatsInput(
    val allRows: List<List<String>>, // Filtered snapshot in original workbook order
    val headers: List<String>,
    val plColumnIndex: Int?,
    val rrCap: Double?,
    val initialBalance: Double,
    val riskPercent: Double,
    val totalRowCount: Int = allRows.size,
    val activeFilterDesc: String = ""
)

data class StatsResult(
    val filteredRowCount: Int = 0,
    val totalRowCount: Int = 0,
    val activeFilterDesc: String = "",

    // Generic summary (Tab 1: «خلاصه»)
    val columnSummaries: List<ColumnSummary> = emptyList(),

    // Result Column Status
    val plColumnIndex: Int? = null,
    val plColumnHeader: String? = null,
    val countedTradesCount: Int = 0,
    val excludedEmptyCount: Int = 0,
    val excludedInvalidCount: Int = 0,

    // Advanced R Metrics (Tab 2: «حرفه‌ای»)
    val winsCount: Int = 0,
    val lossesCount: Int = 0,
    val winRatePercent: Double = 0.0,
    val netR: Double = 0.0,
    val profitFactor: Double = 0.0, // Double.POSITIVE_INFINITY if no losses
    val avgWinR: Double = 0.0,
    val avgLossR: Double = 0.0,
    val rewardToRiskRatio: Double = 0.0,
    val expectancyR: Double = 0.0,
    val bestTradeR: Double = 0.0,
    val worstTradeR: Double = 0.0,
    val maxConsecutiveWins: Int = 0,
    val maxConsecutiveLosses: Int = 0,
    val maxDrawdownR: Double = 0.0,
    val maxDrawdownPercent: Double = 0.0,

    // Grouping (Tab 3: «گروه‌بندی»)
    val defaultGroupColIndex: Int? = null,
    val groupStatsByColumn: Map<Int, List<GroupStatItem>> = emptyMap(),

    // Dollar Simulation (Tab 5: «دلاری»)
    val initialBalance: Double = 500.0,
    val riskPercent: Double = 2.0,
    val rrCap: Double? = null,
    val finalBalance: Double = 500.0,
    val netProfitDollar: Double = 0.0,
    val totalReturnPercent: Double = 0.0,
    val avgWinDollar: Double = 0.0,
    val avgLossDollar: Double = 0.0,
    val bestTradeDollar: Double = 0.0,
    val worstTradeDollar: Double = 0.0,
    val maxDrawdownDollar: Double = 0.0,
    val maxDrawdownDollarPercent: Double = 0.0,

    // Charts (Tab 4: «نمودارها»)
    val rEquityCurve: List<Double> = emptyList(), // length = countedTradesCount + 1 (starts at 0.0)
    val dollarEquityCurve: List<Double> = emptyList() // length = countedTradesCount + 1 (starts at initialBalance)
)

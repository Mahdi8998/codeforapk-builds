package com.example.engine

import com.example.data.parser.NumberParser
import com.example.data.parser.ResultParser
import com.example.data.parser.TradeParseResult
import kotlin.math.abs

object StatsEngine {

    /**
     * Pure function: calculates immutable StatsResult from immutable StatsInput.
     */
    fun compute(input: StatsInput): StatsResult {
        val totalRows = input.totalRowCount
        val filteredRows = input.allRows
        val filteredCount = filteredRows.size

        // 1. Generic summary on all filtered rows (Tab 1: «خلاصه»)
        val columnSummaries = input.headers.mapIndexed { colIdx, header ->
            computeColumnSummary(colIdx, header, filteredRows)
        }

        // 2. Result column verification
        val plColIdx = input.plColumnIndex
        if (plColIdx == null || plColIdx !in input.headers.indices) {
            return StatsResult(
                filteredRowCount = filteredCount,
                totalRowCount = totalRows,
                activeFilterDesc = input.activeFilterDesc,
                columnSummaries = columnSummaries,
                plColumnIndex = null,
                plColumnHeader = null,
                initialBalance = input.initialBalance,
                riskPercent = input.riskPercent,
                rrCap = input.rrCap
            )
        }

        val plHeader = input.headers[plColIdx]
        var excludedEmpty = 0
        var excludedInvalid = 0

        // Parse trades in original row order, keeping reference to original row for group breakdown
        data class ParsedTrade(
            val originalRow: List<String>,
            val countedResult: TradeParseResult.Counted,
            val cappedR: Double
        )

        val countedTrades = mutableListOf<ParsedTrade>()

        for (row in filteredRows) {
            val cell = row.getOrNull(plColIdx)
            when (val res = ResultParser.parse(cell)) {
                is TradeParseResult.ExcludedEmpty -> excludedEmpty++
                is TradeParseResult.ExcludedInvalid -> excludedInvalid++
                is TradeParseResult.Counted -> {
                    val cappedR = res.getCappedR(input.rrCap)
                    countedTrades.add(ParsedTrade(row, res, cappedR))
                }
            }
        }

        val countedCount = countedTrades.size
        if (countedCount == 0) {
            return StatsResult(
                filteredRowCount = filteredCount,
                totalRowCount = totalRows,
                activeFilterDesc = input.activeFilterDesc,
                columnSummaries = columnSummaries,
                plColumnIndex = plColIdx,
                plColumnHeader = plHeader,
                countedTradesCount = 0,
                excludedEmptyCount = excludedEmpty,
                excludedInvalidCount = excludedInvalid,
                initialBalance = input.initialBalance,
                riskPercent = input.riskPercent,
                rrCap = input.rrCap,
                finalBalance = input.initialBalance,
                rEquityCurve = listOf(0.0),
                dollarEquityCurve = listOf(input.initialBalance)
            )
        }

        // 3. Advanced R Metrics (Tab 2: «حرفه‌ای»)
        var winsCount = 0
        var lossesCount = 0
        var sumWins = 0.0
        var sumLosses = 0.0
        var netR = 0.0

        var bestTradeR = countedTrades.first().cappedR
        var worstTradeR = countedTrades.first().cappedR

        var currentWinStreak = 0
        var maxWinStreak = 0
        var currentLossStreak = 0
        var maxLossStreak = 0

        // R Equity curve & Max Drawdown
        val rEquityCurve = ArrayList<Double>(countedCount + 1)
        rEquityCurve.add(0.0)
        var cumulativeR = 0.0
        var peakR = 0.0
        var maxDdR = 0.0
        var maxDdPercent = 0.0

        for (trade in countedTrades) {
            val r = trade.cappedR
            netR += r
            if (r > bestTradeR) bestTradeR = r
            if (r < worstTradeR) worstTradeR = r

            if (trade.countedResult.isWin) {
                winsCount++
                sumWins += r
                currentWinStreak++
                if (currentWinStreak > maxWinStreak) maxWinStreak = currentWinStreak
                currentLossStreak = 0
            } else {
                lossesCount++
                sumLosses += abs(r)
                currentLossStreak++
                if (currentLossStreak > maxLossStreak) maxLossStreak = currentLossStreak
                currentWinStreak = 0
            }

            cumulativeR += r
            rEquityCurve.add(cumulativeR)

            if (cumulativeR > peakR) {
                peakR = cumulativeR
            } else {
                val dd = peakR - cumulativeR
                if (dd > maxDdR) maxDdR = dd
                if (peakR > 0.0) {
                    val ddPct = (dd / peakR) * 100.0
                    if (ddPct > maxDdPercent) maxDdPercent = ddPct
                }
            }
        }

        val winRatePercent = (winsCount.toDouble() / countedCount) * 100.0
        val profitFactor = when {
            sumLosses == 0.0 && sumWins > 0.0 -> Double.POSITIVE_INFINITY
            sumLosses == 0.0 -> 0.0
            else -> sumWins / sumLosses
        }
        val avgWinR = if (winsCount > 0) sumWins / winsCount else 0.0
        val avgLossR = if (lossesCount > 0) sumLosses / lossesCount else 0.0
        val rewardToRisk = if (avgLossR > 0.0) avgWinR / avgLossR else 0.0
        val expectancyR = netR / countedCount

        // 4. Dollar Simulation (Tab 5: «دلاری»)
        val riskFrac = input.riskPercent / 100.0
        var currentBalance = input.initialBalance
        val dollarEquityCurve = ArrayList<Double>(countedCount + 1)
        dollarEquityCurve.add(currentBalance)

        var peakDollar = currentBalance
        var maxDdDollar = 0.0
        var maxDdDollarPercent = 0.0

        val winDollarAmounts = mutableListOf<Double>()
        val lossDollarAmounts = mutableListOf<Double>()
        var bestTradeDollar = 0.0
        var worstTradeDollar = 0.0

        for (i in countedTrades.indices) {
            val trade = countedTrades[i]
            val r = trade.cappedR
            val tradeDollarEffect: Double
            if (trade.countedResult.isWin) {
                // Compounding win: balance * riskFrac * R
                val winDollar = currentBalance * riskFrac * r
                currentBalance += winDollar
                winDollarAmounts.add(winDollar)
                tradeDollarEffect = winDollar
            } else {
                // Compounding loss: balance * riskFrac * |R|
                val lossDollar = currentBalance * riskFrac * abs(r)
                currentBalance -= lossDollar
                lossDollarAmounts.add(lossDollar)
                tradeDollarEffect = -lossDollar
            }

            if (i == 0) {
                bestTradeDollar = tradeDollarEffect
                worstTradeDollar = tradeDollarEffect
            } else {
                if (tradeDollarEffect > bestTradeDollar) bestTradeDollar = tradeDollarEffect
                if (tradeDollarEffect < worstTradeDollar) worstTradeDollar = tradeDollarEffect
            }

            dollarEquityCurve.add(currentBalance)

            if (currentBalance > peakDollar) {
                peakDollar = currentBalance
            } else {
                val dd = peakDollar - currentBalance
                if (dd > maxDdDollar) maxDdDollar = dd
                if (peakDollar > 0.0) {
                    val ddPct = (dd / peakDollar) * 100.0
                    if (ddPct > maxDdDollarPercent) maxDdDollarPercent = ddPct
                }
            }
        }

        val netProfitDollar = currentBalance - input.initialBalance
        val totalReturnPercent = if (input.initialBalance > 0.0) {
            (netProfitDollar / input.initialBalance) * 100.0
        } else {
            0.0
        }
        val avgWinDollar = if (winDollarAmounts.isNotEmpty()) winDollarAmounts.average() else 0.0
        val avgLossDollar = if (lossDollarAmounts.isNotEmpty()) lossDollarAmounts.average() else 0.0

        // 5. Group breakdown (Tab 3: «گروه‌بندی»)
        val groupStatsByCol = mutableMapOf<Int, List<GroupStatItem>>()
        var defaultGroupCol: Int? = null

        input.headers.forEachIndexed { colIdx, _ ->
            if (colIdx != plColIdx) {
                val groups = mutableMapOf<String, MutableList<ParsedTrade>>()
                for (trade in countedTrades) {
                    val rawVal = trade.originalRow.getOrNull(colIdx)?.trim().orEmpty()
                    val key = if (rawVal.isEmpty()) "(خالی)" else rawVal
                    groups.getOrPut(key) { mutableListOf() }.add(trade)
                }

                if (groups.isNotEmpty()) {
                    val items = groups.map { (groupValue, trades) ->
                        val count = trades.size
                        val gWins = trades.count { it.countedResult.isWin }
                        val gLosses = trades.count { !it.countedResult.isWin }
                        val gWinRate = if (count > 0) (gWins.toDouble() / count) * 100.0 else 0.0
                        val gNetR = trades.sumOf { it.cappedR }
                        // Order-free single trade dollar effect sum: initialBalance * riskFrac * cappedR
                        val gDollarEffect = trades.sumOf { input.initialBalance * riskFrac * it.cappedR }
                        GroupStatItem(
                            groupValue = groupValue,
                            tradeCount = count,
                            winsCount = gWins,
                            lossesCount = gLosses,
                            winRatePercent = gWinRate,
                            netR = gNetR,
                            netDollarEffect = gDollarEffect
                        )
                    }.sortedByDescending { it.tradeCount }

                    groupStatsByCol[colIdx] = items

                    if (defaultGroupCol == null && items.size in 2..10) {
                        defaultGroupCol = colIdx
                    }
                }
            }
        }

        if (defaultGroupCol == null) {
            defaultGroupCol = groupStatsByCol.keys.firstOrNull()
        }

        return StatsResult(
            filteredRowCount = filteredCount,
            totalRowCount = totalRows,
            activeFilterDesc = input.activeFilterDesc,
            columnSummaries = columnSummaries,
            plColumnIndex = plColIdx,
            plColumnHeader = plHeader,
            countedTradesCount = countedCount,
            excludedEmptyCount = excludedEmpty,
            excludedInvalidCount = excludedInvalid,
            winsCount = winsCount,
            lossesCount = lossesCount,
            winRatePercent = winRatePercent,
            netR = netR,
            profitFactor = profitFactor,
            avgWinR = avgWinR,
            avgLossR = avgLossR,
            rewardToRiskRatio = rewardToRisk,
            expectancyR = expectancyR,
            bestTradeR = bestTradeR,
            worstTradeR = worstTradeR,
            maxConsecutiveWins = maxWinStreak,
            maxConsecutiveLosses = maxLossStreak,
            maxDrawdownR = maxDdR,
            maxDrawdownPercent = maxDdPercent,
            defaultGroupColIndex = defaultGroupCol,
            groupStatsByColumn = groupStatsByCol,
            initialBalance = input.initialBalance,
            riskPercent = input.riskPercent,
            rrCap = input.rrCap,
            finalBalance = currentBalance,
            netProfitDollar = netProfitDollar,
            totalReturnPercent = totalReturnPercent,
            avgWinDollar = avgWinDollar,
            avgLossDollar = avgLossDollar,
            bestTradeDollar = bestTradeDollar,
            worstTradeDollar = worstTradeDollar,
            maxDrawdownDollar = maxDdDollar,
            maxDrawdownDollarPercent = maxDdDollarPercent,
            rEquityCurve = rEquityCurve,
            dollarEquityCurve = dollarEquityCurve
        )
    }

    private fun computeColumnSummary(
        colIdx: Int,
        header: String,
        rows: List<List<String>>
    ): ColumnSummary {
        val nonBlankValues = rows.mapNotNull { row ->
            row.getOrNull(colIdx)?.trim()?.takeIf { it.isNotEmpty() }
        }

        val numericValues = nonBlankValues.mapNotNull { NumberParser.parseDouble(it) }
        val isMostlyNumeric = nonBlankValues.isNotEmpty() &&
                numericValues.size >= (nonBlankValues.size * 0.7)

        val sum = if (isMostlyNumeric && numericValues.isNotEmpty()) numericValues.sum() else null
        val avg = if (isMostlyNumeric && numericValues.isNotEmpty()) numericValues.average() else null

        val distinctValues = nonBlankValues.distinct()
        val categoricalBreakdown: List<Pair<String, Double>>? =
            if (!isMostlyNumeric && distinctValues.size in 2..5 && nonBlankValues.isNotEmpty()) {
                val total = nonBlankValues.size.toDouble()
                val counts = nonBlankValues.groupingBy { it }.eachCount()
                distinctValues.map { v ->
                    val pct = (counts[v] ?: 0).toDouble() / total * 100.0
                    v to pct
                }.sortedByDescending { it.second }
            } else {
                null
            }

        return ColumnSummary(
            columnIndex = colIdx,
            header = header,
            isNumeric = isMostlyNumeric,
            sum = sum,
            average = avg,
            distinctCount = distinctValues.size,
            categoricalBreakdown = categoricalBreakdown
        )
    }
}

package com.example.ai

import com.example.data.parser.ResultParser
import com.example.data.parser.TradeParseResult
import com.example.engine.StatsEngine
import com.example.engine.StatsInput
import com.example.engine.StatsResult

enum class AiDataMode(val persianLabel: String) {
    COMPLETE("کامل"),
    SUMMARY("خلاصه")
}

object AiPayloadBuilder {

    const val COMPLETE_ROW_CAP = 500

    /**
     * Builds the system prompt instructing the model to act as a professional forex backtest analyst
     * and strictly answer in Persian with trading terminology and disclaimer.
     */
    fun buildSystemInstruction(): String {
        return """
You are a senior professional forex trading-strategy backtest analyst.
The user is providing manual backtest data from their trading strategy spreadsheet.

Core Rules & Semantics:
1. Results are expressed in R-multiples:
   - A lone dash "-" or "-1" represents a full stop-loss hit (−1R).
   - A positive number N represents target N hit (+N R).
   - Empty or whitespace cells are open/unresolved trades. Crucially, NEVER treat empty cells as losses or 0. Exclude them from win/loss ratios.
   - Use the Persian trading terms «تارگت» (target) and «استاپ» (stop-loss) naturally.
2. Dollar figures follow the percentage money-management compounding model provided. Reference final balance («موجودی نهایی»), return % («بازده کل»), and dollar drawdown («افت سرمایه») alongside R-multiples. Use «موجودی» and «ریسک» naturally.
3. If a profit cap (R:R cap) is active, interpret results accordingly (wins were limited to that R:R level). Note how metrics behave with/without the cap when helpful. Use «مبنا» and «R:R».
4. FILTER CONTEXT: If the data is a FILTERED SUBSET (e.g. only losses, or only one pair like EUR/USD, or filtered by direction), analyze THAT specific subset without assuming it represents the entire strategy. Clearly state in Persian that findings apply specifically to this filtered slice.
5. Provide critical, data-driven analysis:
   - Cite specific numbers and percentages directly from the data.
   - Use clear markdown headings and bullet points.
   - Provide concrete, testable rule improvements.
   - Warn if the sample size is small (< 30 trades).
   - Never invent imaginary trades or numbers.
6. Language: YOU MUST ALWAYS RESPOND IN PERSIAN (فارسی).
7. Disclaimer: Always conclude your response with this exact one-line Persian disclaimer:
«این تحلیل صرفاً جنبه آماری و آموزشی داشته و به هیچ عنوان توصیه مالی یا سیگنال معاملاتی نیست.»
""".trimIndent()
    }

    /**
     * Builds the scope and semantics headers for the prompt.
     */
    fun buildHeaders(
        statsInput: StatsInput,
        filteredCount: Int,
        totalCount: Int
    ): String {
        val sb = StringBuilder()

        // 1. Scope header (English)
        val hasFilters = filteredCount < totalCount || statsInput.activeFilterDesc.isNotBlank()
        if (hasFilters) {
            val filterDesc = if (statsInput.activeFilterDesc.isNotBlank()) statsInput.activeFilterDesc else "active column filters"
            sb.appendLine("FILTER CONTEXT: the rows below are a FILTERED SUBSET ($filteredCount of $totalCount total rows). Active filters: $filterDesc. The user is intentionally analyzing this subset.")
        } else {
            sb.appendLine("FILTER CONTEXT: the rows below are the FULL TABLE ($totalCount rows); no filters applied.")
        }

        // 2. Semantics headers (English)
        val plColIdx = statsInput.plColumnIndex
        val plName = if (plColIdx != null && plColIdx in statsInput.headers.indices) {
            statsInput.headers[plColIdx]
        } else {
            "Result"
        }
        sb.appendLine("RESULT COLUMN \"$plName\": \"-\" = stop-loss hit (−1R); positive number N = target N hit (+N R); empty = trade has no result yet (excluded from all stats).")

        sb.appendLine("MONEY MANAGEMENT: initial balance ${statsInput.initialBalance} USD; risk per trade ${statsInput.riskPercent}% of current balance (compounding); loss (-) = -1R; target N = +N R; empty = unresolved trade.")

        if (statsInput.rrCap != null && statsInput.rrCap > 0.0) {
            sb.appendLine("PROFIT BASIS: user-defined R:R cap = ${statsInput.rrCap}R — a cell \"3\" means price reached 3R but profit is counted as +${minOf(3.0, statsInput.rrCap)}R; dash = stop (−1R); empty = unresolved trade.")
        } else {
            sb.appendLine("PROFIT BASIS: full target value (no cap).")
        }

        return sb.toString()
    }

    /**
     * Builds the user prompt payload in either COMPLETE or SUMMARY mode.
     */
    fun buildPrompt(
        statsInput: StatsInput,
        statsResult: StatsResult,
        mode: AiDataMode,
        userQueryOrPreset: String
    ): String {
        val headers = buildHeaders(statsInput, statsResult.filteredRowCount, statsResult.totalRowCount)
        val sb = StringBuilder()
        sb.append(headers)
        sb.appendLine()

        when (mode) {
            AiDataMode.COMPLETE -> {
                sb.appendLine("DATA (COMPLETE FILTERED ROWS AS TSV):")
                sb.appendLine(statsInput.headers.joinToString("\t"))
                val rowsToTake = statsInput.allRows.take(COMPLETE_ROW_CAP)
                for (row in rowsToTake) {
                    sb.appendLine(row.joinToString("\t"))
                }
            }
            AiDataMode.SUMMARY -> {
                sb.appendLine("STATISTICAL ENGINE SUMMARY (COMPUTED ON FILTERED SUBSET):")
                sb.appendLine("- Filtered Trades Count: ${statsResult.filteredRowCount} (Counted: ${statsResult.countedTradesCount}, Excluded Empty: ${statsResult.excludedEmptyCount})")
                sb.appendLine("- Wins: ${statsResult.winsCount}, Losses: ${statsResult.lossesCount}, Win Rate: ${String.format("%.1f", statsResult.winRatePercent)}%")
                sb.appendLine("- Net Result: ${String.format("%.2f", statsResult.netR)} R")
                sb.appendLine("- Profit Factor: ${if (statsResult.profitFactor.isInfinite()) "Infinity (No Losses)" else String.format("%.2f", statsResult.profitFactor)}")
                sb.appendLine("- Avg Win: ${String.format("%.2f", statsResult.avgWinR)} R, Avg Loss: ${String.format("%.2f", statsResult.avgLossR)} R, R:R Ratio: ${String.format("%.2f", statsResult.rewardToRiskRatio)}")
                sb.appendLine("- Expectancy: ${String.format("%.2f", statsResult.expectancyR)} R per trade")
                sb.appendLine("- Best Trade: ${statsResult.bestTradeR} R, Worst Trade: ${statsResult.worstTradeR} R")
                sb.appendLine("- Max Consecutive Wins: ${statsResult.maxConsecutiveWins}, Max Consecutive Losses: ${statsResult.maxConsecutiveLosses}")
                sb.appendLine("- Max Drawdown: ${String.format("%.2f", statsResult.maxDrawdownR)} R (${String.format("%.1f", statsResult.maxDrawdownPercent)}%)")
                sb.appendLine("- Compounding Dollar Final Balance: $${String.format("%.2f", statsResult.finalBalance)} (Net: $${String.format("%.2f", statsResult.netProfitDollar)}, Return: ${String.format("%.1f", statsResult.totalReturnPercent)}%)")
                sb.appendLine("- Max Dollar Drawdown: $${String.format("%.2f", statsResult.maxDrawdownDollar)} (${String.format("%.1f", statsResult.maxDrawdownDollarPercent)}%)")

                // Group stats if available
                val defaultGroupCol = statsResult.defaultGroupColIndex
                if (defaultGroupCol != null) {
                    val groupName = statsInput.headers.getOrNull(defaultGroupCol) ?: "Group"
                    val groups = statsResult.groupStatsByColumn[defaultGroupCol] ?: emptyList()
                    if (groups.isNotEmpty()) {
                        sb.appendLine("\nGROUP BREAKDOWN BY \"$groupName\":")
                        for (g in groups.take(8)) {
                            sb.appendLine("  * ${g.groupValue}: ${g.tradeCount} trades, WinRate ${String.format("%.1f", g.winRatePercent)}%, Net ${String.format("%.1f", g.netR)} R")
                        }
                    }
                }

                // Representative sample rows (up to 30 drawn strictly from filtered subset)
                sb.appendLine("\nREPRESENTATIVE SAMPLE ROWS (SUBSET):")
                sb.appendLine(statsInput.headers.joinToString("\t"))
                val sampleRows = pickSampleRows(statsInput.allRows, statsInput.plColumnIndex, limit = 30)
                for (row in sampleRows) {
                    sb.appendLine(row.joinToString("\t"))
                }
            }
        }

        sb.appendLine()
        sb.appendLine("USER REQUEST / ANALYSIS GOAL:")
        sb.appendLine(userQueryOrPreset)

        return sb.toString()
    }

    private fun pickSampleRows(
        rows: List<List<String>>,
        plColIdx: Int?,
        limit: Int = 30
    ): List<List<String>> {
        if (rows.size <= limit) return rows

        val wins = mutableListOf<List<String>>()
        val losses = mutableListOf<List<String>>()
        val others = mutableListOf<List<String>>()

        for (row in rows) {
            val cell = if (plColIdx != null) row.getOrNull(plColIdx) else null
            when (val res = ResultParser.parse(cell)) {
                is TradeParseResult.Counted -> {
                    if (res.isWin) wins.add(row) else losses.add(row)
                }
                else -> others.add(row)
            }
        }

        val result = mutableListOf<List<String>>()
        val winTake = minOf(12, wins.size)
        val lossTake = minOf(12, losses.size)
        val otherTake = minOf(limit - winTake - lossTake, others.size)

        result.addAll(wins.take(winTake))
        result.addAll(losses.take(lossTake))
        result.addAll(others.take(otherTake))

        if (result.size < limit) {
            val remaining = rows.filterNot { result.contains(it) }
            result.addAll(remaining.take(limit - result.size))
        }

        return result
    }
}

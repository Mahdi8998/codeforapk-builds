package com.example.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

data class ChatMessage(
    val role: String, // "user" or "model"
    val content: String
)

class GeminiService(private val client: OkHttpClient = defaultClient()) {

    companion object {
        private const val MODEL_NAME = "gemini-2.5-flash"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

        fun defaultClient(): OkHttpClient {
            return OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build()
        }
    }

    /**
     * Sends a tiny test request to verify API key validity.
     * Returns Result.success(Unit) or Result.failure with a user-friendly Persian message.
     */
    suspend fun testConnection(apiKey: String): Result<Unit> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(Exception("کلید API وارد نشده است."))
        }

        val url = "$BASE_URL/$MODEL_NAME:generateContent?key=$apiKey"
        val payload = JSONObject().apply {
            val contentsArr = JSONArray()
            val messageObj = JSONObject().apply {
                val partsArr = JSONArray().apply {
                    put(JSONObject().put("text", "سلام"))
                }
                put("parts", partsArr)
            }
            contentsArr.put(messageObj)
            put("contents", contentsArr)
        }

        val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url(url)
            .post(body)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                when (response.code) {
                    200 -> Result.success(Unit)
                    400, 401, 403 -> Result.failure(Exception("کلید API نامعتبر است."))
                    429 -> Result.failure(Exception("محدودیت تعداد درخواست؛ کمی بعد دوباره تلاش کنید."))
                    else -> Result.failure(Exception("خطا از سرور (کد ${response.code}): ${response.message}"))
                }
            }
        } catch (e: UnknownHostException) {
            Result.failure(Exception("عدم اتصال به اینترنت"))
        } catch (e: Exception) {
            Result.failure(Exception(e.message ?: "خطای ناشناخته در اتصال"))
        }
    }

    /**
     * Streams or returns the generated content response from Gemini.
     * Emits chunks of text as they arrive from streamGenerateContent.
     */
    fun streamGenerateContent(
        apiKey: String,
        systemInstruction: String,
        conversation: List<ChatMessage>
    ): Flow<String> = flow {
        if (apiKey.isBlank()) {
            throw IllegalArgumentException("کلید API گوگل Gemini تنظیم نشده است.")
        }

        val url = "$BASE_URL/$MODEL_NAME:streamGenerateContent?alt=sse&key=$apiKey"

        val rootObj = JSONObject()

        // System instruction
        if (systemInstruction.isNotBlank()) {
            val sysObj = JSONObject().apply {
                val parts = JSONArray().apply {
                    put(JSONObject().put("text", systemInstruction))
                }
                put("parts", parts)
            }
            rootObj.put("systemInstruction", sysObj)
        }

        // Conversation contents
        val contentsArr = JSONArray()
        for (msg in conversation) {
            val cObj = JSONObject().apply {
                put("role", if (msg.role == "model") "model" else "user")
                val parts = JSONArray().apply {
                    put(JSONObject().put("text", msg.content))
                }
                put("parts", parts)
            }
            contentsArr.put(cObj)
        }
        rootObj.put("contents", contentsArr)

        val body = rootObj.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url(url)
            .post(body)
            .build()

        val response = try {
            client.newCall(request).execute()
        } catch (e: UnknownHostException) {
            throw Exception("عدم اتصال به اینترنت")
        } catch (e: Exception) {
            throw Exception("خطا در برقراری ارتباط با اینترنت: ${e.localizedMessage}")
        }

        if (!response.isSuccessful) {
            val errCode = response.code
            val errBody = response.body?.string().orEmpty()
            response.close()
            when (errCode) {
                400, 401, 403 -> throw Exception("کلید API نامعتبر است")
                429 -> throw Exception("محدودیت تعداد درخواست؛ کمی بعد دوباره تلاش کنید")
                else -> throw Exception("خطا از سرور گوگل (کد $errCode): $errBody")
            }
        }

        val responseBody = response.body ?: throw Exception("پاسخی از سرور دریافت نشد.")
        val reader = BufferedReader(InputStreamReader(responseBody.byteStream(), Charsets.UTF_8))

        var line: String? = reader.readLine()
        while (line != null) {
            if (line.startsWith("data: ")) {
                val dataJson = line.substring(6).trim()
                if (dataJson.isNotEmpty() && dataJson != "[DONE]") {
                    val chunkText = extractTextFromChunk(dataJson)
                    if (chunkText.isNotEmpty()) {
                        emit(chunkText)
                    }
                }
            }
            line = reader.readLine()
        }
        responseBody.close()
    }.flowOn(Dispatchers.IO)

    private fun extractTextFromChunk(jsonStr: String): String {
        return try {
            val json = JSONObject(jsonStr)
            val candidates = json.optJSONArray("candidates") ?: return ""
            if (candidates.length() == 0) return ""
            val candidate = candidates.getJSONObject(0)
            val content = candidate.optJSONObject("content") ?: return ""
            val parts = content.optJSONArray("parts") ?: return ""
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                sb.append(part.optString("text", ""))
            }
            sb.toString()
        } catch (e: Exception) {
            ""
        }
    }
}

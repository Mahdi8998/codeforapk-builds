package com.example

import com.example.data.model.GridData
import com.example.data.xlsx.XlsxHandler
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun testXlsxRoundTrip() {
        val headers = listOf("ردیف", "نماد", "نتیجه", "توضیحات")
        val rows = listOf(
            listOf("1", "EUR/USD", "1", "خرید موفق"),
            listOf("2", "USD/JPY", "-", "استاپ هانت"),
            listOf("3", "طلا", "3.5", "تارگت ۳٫۵ با جهش قیمت")
        )

        val out = ByteArrayOutputStream()
        XlsxHandler.writeXlsx(headers, rows, out)
        val bytes = out.toByteArray()
        assertTrue(bytes.isNotEmpty())

        val inStream = ByteArrayInputStream(bytes)
        val parsedGrid = XlsxHandler.readXlsx(inStream)

        assertEquals(4, parsedGrid.headers.size)
        assertEquals("ردیف", parsedGrid.headers[0])
        assertEquals("نماد", parsedGrid.headers[1])
        assertEquals("نتیجه", parsedGrid.headers[2])
        assertEquals(3, parsedGrid.rows.size)
        assertEquals("EUR/USD", parsedGrid.rows[0][1])
        assertEquals("-", parsedGrid.rows[1][2])
        assertEquals("خرید موفق", parsedGrid.rows[0][3])
    }
}

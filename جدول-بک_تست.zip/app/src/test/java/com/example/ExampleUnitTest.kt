package com.example

import com.example.data.parser.NumberParser
import com.example.data.parser.ResultParser
import com.example.data.parser.TradeParseResult
import com.example.engine.StatsEngine
import com.example.engine.StatsInput
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testPersianAndArabicNumberParsing() {
        // Persian digits: ۰ ۱ ۲ ۳ ۴ ۵ ۶ ۷ ۸ ۹
        assertEquals(1234.56, NumberParser.parseDouble("۱۲۳۴٫۵۶")!!, 0.001)
        // Arabic digits: ٠ ١ ٢ ٣ ٤ ٥ ٦ ٧ ٨ ٩
        assertEquals(789.0, NumberParser.parseDouble("٧٨٩")!!, 0.001)
        // Persian comma / slash
        assertEquals(1500.5, NumberParser.parseDouble("۱،۵۰۰٫۵")!!, 0.001)
        assertEquals(2.5, NumberParser.parseDouble("۲/۵")!!, 0.001)
        // Negative number
        assertEquals(-1.0, NumberParser.parseDouble("-۱")!!, 0.001)
        assertEquals(-2.5, NumberParser.parseDouble("−۲٫۵")!!, 0.001)
    }

    @Test
    fun testResultParser() {
        // Dash / Stop (-1R)
        val stopDash = ResultParser.parse("-")
        assertTrue(stopDash is TradeParseResult.Counted)
        val countedDash = stopDash as TradeParseResult.Counted
        assertFalse(countedDash.isWin)
        assertEquals(-1.0, countedDash.originalR, 0.001)

        val stopMinusOne = ResultParser.parse("-1")
        assertTrue(stopMinusOne is TradeParseResult.Counted)
        assertFalse((stopMinusOne as TradeParseResult.Counted).isWin)

        val stopPersianMinus = ResultParser.parse("−۱")
        assertTrue(stopPersianMinus is TradeParseResult.Counted)
        assertFalse((stopPersianMinus as TradeParseResult.Counted).isWin)

        // Positive targets (Wins)
        val target1 = ResultParser.parse("1")
        assertTrue(target1 is TradeParseResult.Counted)
        val countedTarget1 = target1 as TradeParseResult.Counted
        assertTrue(countedTarget1.isWin)
        assertEquals(1.0, countedTarget1.originalR, 0.001)

        val target3 = ResultParser.parse("۳")
        assertTrue(target3 is TradeParseResult.Counted)
        val countedTarget3 = target3 as TradeParseResult.Counted
        assertTrue(countedTarget3.isWin)
        assertEquals(3.0, countedTarget3.originalR, 0.001)

        // Empty / Unresolved (Must be excluded, NOT counted as loss or 0)
        val emptyResult = ResultParser.parse("")
        assertTrue(emptyResult is TradeParseResult.ExcludedEmpty)

        val spacesResult = ResultParser.parse("   ")
        assertTrue(spacesResult is TradeParseResult.ExcludedEmpty)

        val nullResult = ResultParser.parse(null)
        assertTrue(nullResult is TradeParseResult.ExcludedEmpty)

        // Invalid
        val invalidResult = ResultParser.parse("unknown text")
        assertTrue(invalidResult is TradeParseResult.ExcludedInvalid)
    }

    @Test
    fun testStatsEngineCalculations() {
        val headers = listOf("Trade", "Pair", "Result")
        val rows = listOf(
            listOf("1", "EUR/USD", "1"),   // +1R
            listOf("2", "EUR/USD", "-"),   // -1R
            listOf("3", "GBP/USD", "2"),   // +2R
            listOf("4", "GBP/USD", "3"),   // +3R
            listOf("5", "USD/JPY", "-"),   // -1R
            listOf("6", "USD/JPY", ""),    // Unresolved
            listOf("7", "USD/JPY", "   ")  // Unresolved
        )

        // 1. Without cap
        val inputWithoutCap = StatsInput(
            allRows = rows,
            headers = headers,
            plColumnIndex = 2,
            rrCap = null,
            initialBalance = 1000.0,
            riskPercent = 2.0
        )

        val resNoCap = StatsEngine.compute(inputWithoutCap)
        assertEquals(7, resNoCap.filteredRowCount)
        assertEquals(5, resNoCap.countedTradesCount)
        assertEquals(2, resNoCap.excludedEmptyCount)
        assertEquals(3, resNoCap.winsCount)
        assertEquals(2, resNoCap.lossesCount)
        assertEquals(60.0, resNoCap.winRatePercent, 0.01) // 3/5 = 60%
        assertEquals(4.0, resNoCap.netR, 0.01) // (+1 - 1 + 2 + 3 - 1) = 4R
        assertEquals(3.0, resNoCap.profitFactor, 0.01) // 6R / 2R = 3.0

        // 2. With R:R cap = 1.0
        // Target 2 becomes +1R, Target 3 becomes +1R
        // Wins count and Win rate must remain identical (60%)
        // Stop (-1R) must NOT change
        val inputWithCap = inputWithoutCap.copy(rrCap = 1.0)
        val resWithCap = StatsEngine.compute(inputWithCap)
        assertEquals(3, resWithCap.winsCount)
        assertEquals(2, resWithCap.lossesCount)
        assertEquals(60.0, resWithCap.winRatePercent, 0.01)
        assertEquals(1.0, resWithCap.netR, 0.01) // (+1 - 1 + 1 + 1 - 1) = 1R
        assertEquals(1.5, resWithCap.profitFactor, 0.01) // 3R / 2R = 1.5
    }
}
